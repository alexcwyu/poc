
#TODO: move this to a config file outside of the project
MAKERS = {'maker':[], 'maker1':[]} #Maps a list of takers

TAKERS = {'SBI':{'password':'virtualcfd89', 'maker':'maker'},
          'Minna':{'password':'btcforall', 'maker':'maker1'}}

for taker0, obj in TAKERS.items():
    assert obj['maker'] in MAKERS
    MAKERS[obj['maker']].append(taker0)

    

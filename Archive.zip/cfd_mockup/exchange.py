import os
import time
import threading
import uuid
from cdecimal import Decimal as D

#No price/time priority will be given
class Exchange(object):
    def __init__(self, maker): #symlist
        self.maker = maker
        self.orders = {} #id0 -> json order
        self.fills = []
        self.lock = threading.Lock() #need to lock making and taking

    def get_open_orders(self):
        return self.orders.values()
        
    #maker interface
    def add_lmt_order(self, id0, sym, side, price, qty):
        #assert unique id system wide
        if id0 in self.orders:
            return {'success':False, 'msg':'duplicate id'}

        #assert does not cross existing order
        if side == 'buy':
            p,q = self.top_ask(sym)
            if p and D(price) >= D(p):
                return {'success':False, 'msg':'cannot cross'}
        else:
            p,q = self.top_bid(sym)
            if p and D(price) <= D(p):
                return {'success':False, 'msg':'cannot cross'}
        
        self.orders[id0] = {'orderid':id0,
                            'side':side,
                            'symbol':sym,
                            'price':price,
                            'qty':qty,
                            'filled':'0',
                            'remain':qty,
                            'maker':self.maker,
                            'last_modified':time.time()}
        return {'success':True, 'orderid':id0}

    def cancel_lmt_order(self, id0):
        success = True #cancels regardless
        sym = None
        if id0 in self.orders:
            sym = self.orders[id0]['symbol']
            del self.orders[id0]
            success = True
        return {'success':success, 'sym':sym}
    
    #taker interface
    def hit(self, sym, qty, taker):
        bids = [o for o in self.orders.values() if o['symbol'] == sym and o['side'] == 'buy']
        if len(bids) == 0: return 0
        ts = time.time()
        rem = D(qty)
        newqty = {} #new qty
        for b0 in sorted(bids, key=lambda x:float(x['price']))[::-1]:
            id0,sym0,p,q = b0['orderid'], b0['symbol'], b0['price'], b0['remain']
            q = D(q)
            if q <= rem:
                #eats the entire order
                rem -= q
                self.fills.append({'fillid':str(uuid.uuid4()),'orderid':id0, 'price':p, 'qty':str(q), 'ts':ts, 'symbol':sym, 'taker_direction':'sell', 'taker':taker, 'maker':self.maker})
                newqty[id0] = 0
            else:
                #eats partial order
                newqty[id0] = q - rem
                self.fills.append({'fillid':str(uuid.uuid4()),'orderid':id0, 'price':p, 'qty':str(rem), 'ts':ts, 'symbol':sym, 'taker_direction':'sell', 'taker':taker, 'maker':self.maker})
                rem = 0
            if rem == 0:
                break

        for id0, nqty in newqty.items():
            if nqty == 0:
                #self.orders[id0]['remain'] = str(0)
                #self.orders[id0]['filled'] = self.orders[id0]['qty']
                del self.orders[id0]
            else:
                self.orders[id0]['remain'] = str(nqty)
                self.orders[id0]['filled'] = str(D(self.orders[id0]['qty']) - D(self.orders[id0]['remain']))
        return D(qty)-rem
            
    def lift(self, sym, qty, taker):
        asks = [o for o in self.orders.values() if o['symbol'] == sym and o['side'] == 'sell']
        if len(asks) == 0: return 0
        ts = time.time()
        rem = D(qty)
        newqty = {}
        for a0 in sorted(asks, key=lambda x:float(x['price'])):
            id0,sym0,p,q = a0['orderid'], a0['symbol'], a0['price'], a0['remain']
            q = D(q)
            if q <= rem:
                rem -= q
                self.fills.append({'fillid':str(uuid.uuid4()),'orderid':id0, 'price':p, 'qty':str(q), 'ts':ts, 'symbol':sym, 'taker_direction':'buy', 'taker':taker, 'maker':self.maker})
                newqty[id0] = 0
            else:
                #eats partial order
                newqty[id0] = q - rem
                self.fills.append({'fillid':str(uuid.uuid4()),'orderid':id0, 'price':p, 'qty':str(rem), 'ts':ts, 'symbol':sym, 'taker_direction':'buy', 'taker':taker, 'maker':self.maker})
                rem = 0

            if rem == 0:
                break

        for id0, nqty in newqty.items():
            if nqty == 0:
                del self.orders[id0]
            else:
                self.orders[id0]['remain'] = str(nqty)
                self.orders[id0]['filled'] = str(D(self.orders[id0]['qty']) - D(self.orders[id0]['remain']))
        return D(qty)-rem
    
    def top_bid(self, sym):
        bids = [o for o in self.orders.values() if o['symbol'] == sym and o['side'] == 'buy']
        if len(bids) == 0:
            return None, None
        bids = sorted(bids, key=lambda x:float(x['price']))
        return bids[-1]['price'], bids[-1]['remain']

    def top_ask(self, sym):
        asks = [o for o in self.orders.values() if o['symbol'] == sym and o['side'] == 'sell']
        if len(asks) == 0:
            return None, None
        asks = sorted(asks, key=lambda x:float(x['price']))
        return asks[0]['price'], asks[0]['remain']
    

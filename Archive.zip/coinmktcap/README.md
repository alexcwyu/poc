This project periodically downloads coinmarketcap info

Just add this to cron as follows:

#Run every 5 minutes
*/5 * * * *	cd /[path/to/file]/coinmktcap && ./run >> log

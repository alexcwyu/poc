import shutil
import json
import os
import tarfile
import pandas as pd
import shelve
from multiprocessing import Pool
from mmbot.utils.book import Book

#Build tick db
RAWDB = '/mnt/sensus/md/dc'
TICKDB = '/mnt/sensus/md/bookdb'
WORKINGDIR = '/mnt/sensus/md/temp2'
CACHE = '.bookdb'

def generate(fname):
#    print 'extracting {}'.format(fname)
#    try:
#        tar = tarfile.open(fname, 'r')
#        tar.extractall(path=WORKINGDIR)
#        tar.close()
#    except:
#        print 'Problem with extraction'

    #child files only
    for path_,_,files in os.walk(WORKINGDIR):
        for f in files:
            venue = f.replace('.data','')
            dat = parse_venue(venue, path_ + '/' + f)
            print venue, len(dat), '<<<<'
            if len(dat) == 0: continue
            for sym, grp in dat.groupby('symbol'):
                try:
                    grp = grp.sort_values('exchts')
                    savepath = '{}/{}/{}'.format(TICKDB, venue, sym)
                    #needs rounding?
                    fname = '{}.{}.ticks'.format(int(grp.exchts.min()), int(grp.exchts.max()))
                    if not os.path.exists(savepath):
                        os.makedirs(savepath)
                    grp.to_csv(savepath + '/' + fname, index=False)
                except:
                    print venue, sym, 'ERROR'

    shutil.rmtree(WORKINGDIR)
                
def parse_venue(venue, fpath):
    data = open(fpath, 'r')
    books = {}
    results = []
    i = 0
    for line in data:
        try:
            keys = line.split(';')
            ts = keys[0]
            symbol = keys[3]
            if keys[1] == 'fb':
                print ts, venue, symbol
                jsondata = json.loads(keys[4])
                books[symbol] = Book(jsondata['bids'], jsondata['asks'], 0)
                
            elif keys[1] == 'db':
                if symbol in books:
                    jsondata = json.loads(keys[4])
                    i += 1
                    books[symbol].applyupdates(jsondata['dbids'], jsondata['dasks'], i)
            if symbol in books:
                bb, ba = books[symbol].best_bid, books[symbol].best_ask
                results.append([ts, symbol, bb[0], bb[1], ba[0], ba[1]])
                
        except KeyError:
            break
        except:
            continue
    dat = pd.DataFrame(results, columns=['timestamp','symbol','bid','bsize','ask','asize'])
    return dat

if __name__ == '__main__':
    #generate(RAWDB + '/20180531.tar.gz')
    parse_venue('okexspot', '/mnt/sensus/md/temp2/data/20180531/okexspot.data')

    3/0
    for f in sorted(os.listdir(RAWDB)):
        s = shelve.open(CACHE, writeback=True)
        if f not in s.keys():
            print 'processing', f
            generate(RAWDB + '/' + f)
            s[f] = 'processed'
        s.close()

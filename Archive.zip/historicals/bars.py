import datetime
import calendar
import pandas as pd
import time
import ticks
import os
from collections import defaultdict
from multiprocessing import Pool
import sys

BARSDB = '/mnt/sensus/md/barsdb'
START = '2018-03-05'

def build_1m_bars(args):
    venue,symbol = args
    #TODO: need a better storage format other than flat files
    ts_s = calendar.timegm(time.strptime(START,'%Y-%m-%d'))
    while ts_s < time.time():
        ts_e = ts_s + 60*60*24
        tdate = datetime.datetime.utcfromtimestamp(ts_e)
        fname = '{}.{}.1m'.format(ts_s, ts_e)
        fpath = '{}/{}/{}'.format(BARSDB, venue, symbol)
        if not os.path.exists(fpath):
            os.makedirs(fpath)

        if not os.path.exists(fpath + '/' + fname):
            dat = _build_1min_bars('bitmex', 'XBTUSD', ts_s, ts_e)
            if len(dat) > 0:
                dat = dat.sort_values('ts')
                dat[['ts','open','high','low','close','volume']].to_csv(fpath + '/' + fname, index=False)
            else:
                print 'No data'
            print symbol, tdate, len(dat)
        else:
            print symbol, tdate, 'Already have'
            
        ts_s = ts_e


#TODO: need to think about boundaries!
def _build_1min_bars(venue, symbol, from_ts, to_ts):

    ticker = ticks.Ticker(venue, symbol)
    try:
        ticker.advance(from_ts)
    except:
        return pd.DataFrame()

    barticks = defaultdict(list)
    for tick in ticker:
        if tick.exchts > to_ts:
            break
        
        belongs_ts = int(tick.exchts/60 + 1)*60 #belongs to this bar
        barticks[belongs_ts].append(tick)

    bars = []
    for barts, arr in barticks.iteritems():
        bars.append({'ts':barts, 'open':arr[0].price, 'high':max([a.price for a in arr]), 'low':min([a.price for a in arr]), 'close':arr[-1].price, 'volume':sum([a.qty for a in arr])})

    return pd.DataFrame(bars)

if __name__ == '__main__':
    jobs = []
    for venue in ['bitmex','okexfut','cf','deribit']:
        syms = os.listdir(ticks.TICKDB + '/' + venue)
        for sym in syms:
            jobs.append((venue, sym))
    
    p = Pool(6)
    p.map(build_1m_bars, jobs)

#    build_1m_bars(sys.argv[1],sys.argv[2])

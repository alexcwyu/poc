import shutil
import json
import os
import tarfile
import pandas as pd
import shelve
from multiprocessing import Pool

#Build tick db
RAWDB = '/mnt/sensus/md/dc'
TICKDB = '/mnt/sensus/md/tickdb'
WORKINGDIR = '/mnt/sensus/md/temp'
CACHE = '.tickdb'

def generate(fname):
    print 'extracting {}'.format(fname)
    try:
        tar = tarfile.open(fname, 'r')
        tar.extractall(path=WORKINGDIR)
        tar.close()
    except:
        print 'Problem with extraction'

    #child files only
    for path_,_,files in os.walk(WORKINGDIR):
        for f in files:
            venue = f.replace('.data','')
            dat = parse_venue(venue, path_ + '/' + f)
            print venue, len(dat), '<<<<'
            if len(dat) == 0: continue
            for sym, grp in dat.groupby('symbol'):
                try:
                    grp = grp.sort_values('exchts')
                    savepath = '{}/{}/{}'.format(TICKDB, venue, sym)
                    #needs rounding?
                    fname = '{}.{}.ticks'.format(int(grp.exchts.min()), int(grp.exchts.max()))
                    if not os.path.exists(savepath):
                        os.makedirs(savepath)
                    grp.to_csv(savepath + '/' + fname, index=False)
                except:
                    print venue, sym, 'ERROR'

    shutil.rmtree(WORKINGDIR)
                
def parse_venue(venue, fpath):
    data = open(fpath, 'r')
    results = []
    for line in data:
        try:
            keys = line.split(';')
            if keys[1] == 't':
                symbol = keys[3]
                jsondata = json.loads(keys[4])
                jsondata['symbol'] = symbol
                results.append(jsondata)
        except:
            continue
    dat = pd.DataFrame(results)
    return dat

if __name__ == '__main__':
    for f in sorted(os.listdir(RAWDB)):
        s = shelve.open(CACHE, writeback=True)
        if f not in s.keys():
            print 'processing', f
            generate(RAWDB + '/' + f)
            s[f] = 'processed'
        s.close()

class Ticker(object):
    def __init__(self, venue, sym):
        self.venue, self.sym = venue, sym
        self.tickdb = '{}/{}/{}'.format(TICKDB, venue, sym)
        self.files = sorted(os.listdir(self.tickdb))
        if len(self.files) == 0: raise Exception('No data for {}@{}'.format(sym, venue))
        self.first_ts = int(self.files[0].split('.')[0])
        self.last_ts = int(self.files[-1].split('.')[1])
        self.byend = {int(f.split('.')[1]):f for f in self.files} #endtime
        
    def _getfile2use(self, ts):
        file2use = self.byend[[et for et in sorted(self.byend.keys()) if et > ts][0]]
        return file2use

    def _load_data(self, ts):
        self.f2u = self._getfile2use(ts)
        self.dat = pd.read_csv('{}/{}'.format(self.tickdb, self.f2u))
        self.n = len(self.dat)
        first = self.dat[self.dat.exchts >= ts]
        self.idx = max(0, first.index[0]-1)
        self.timenow = self.dat.iloc[self.idx].exchts
    
    def advance(self, ts):
        if ts > self.last_ts:
            raise Exception('No data after {}'.format(self.last_ts))
        self._load_data(ts)

    def __iter__(self):
        return self

    def next(self):
        self.idx +=1
        if self.idx == self.n:
            if self.timenow >= self.last_ts:
                raise StopIteration
            self._load_data(self.timenow)

        datapoint = self.dat.iloc[self.idx]
        self.timenow = datapoint.exchts
        return datapoint

    def __repr__(self):
        return 'Ticker Object {}@{}'.format(self.sym, self.venue)
    

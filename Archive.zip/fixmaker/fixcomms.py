#!/usr/bin/env python
from cdecimal import Decimal as D
import datetime
import time
import quickfix as fix
import quickfix44
import config

class FixApplication(fix.Application):    
    orderID = 0
    execID = 0
    quoteID = 1
    def __init__(self, exchange):
        #Only support one pricing and one trading session from one client now
        self.pricingsession = None
        self.tradingsession = None
        self.exchange = exchange
        super(FixApplication, self).__init__()

    def get_maker(self, tgtid):
        return config.TAKERS[tgtid]['maker']
        
    def notify_takers(self, maker, sym):
        if self.pricingsession:
            self.massQuote(self.pricingsession, sym, firstcall=False)

    def session_eq(self, session1, session2):
        a = session1.getTargetCompID().getValue() == session2.getTargetCompID().getValue()
        b = session1.getSenderCompID().getValue() == session2.getSenderCompID().getValue()
        return a and b
            
    def onCreate(self, sessionid):
        return
    
    def onLogon(self, sessionid):
        tgtid = sessionid.getSenderCompID().getValue()
        client_info = config.TAKERS.get(tgtid, None)
        if client_info is None:
            #TODO: Reject invalid client
            return
        
        if client_info['session_type'] == 'pricing':
            self.pricingsession = sessionid
        elif client_info['session_type'] == 'trading':
            self.tradingsession = sessionid
        
        self.send = {} #sym -> id
        print '{} logged on, using {}'.format(tgtid, self.get_maker(tgtid))

    def onLogout(self, sessionid):
        print 'logout'
        return
    def toAdmin(self, message, sessionid): return
    def toApp(self, message, sessionid): return
    def fromAdmin(self, message, sessionid):
        #check password
        msgType = fix.MsgType()
        message.getHeader().getField(msgType)
        if msgType.getValue() == fix.MsgType_Logon:
            tgtid = sessionid.getTargetCompID().getValue()
            client_info = config.TAKERS.get(tgtid, None)
            if client_info is None:
                #reject here?
                return
            uname = fix.Username()
            pwd = fix.Password()
            message.getField(uname)
            message.getField(pwd)
            
            if not (client_info['password'] == pwd.getValue() and client_info['username'] == uname.getValue()):
                #TODO: reject here!
                pass
            print 'USR PWD', uname, pwd
        
        
    def fromApp(self, message, sessionid):
        
        if self.pricingsession and self.session_eq(sessionid, self.pricingsession):
            self.handle_pricing_msg(message, sessionid)

        elif self.tradingsession and self.session_eq(sessionid, self.tradingsession):
            self.handle_trading_msg(message, sessionid)

        else:
            print 'unrecognized client' #reject?
            print self.pricingsession
            print self.tradingsession

    def handle_trading_msg(self, message, sessionid):
        msgType = fix.MsgType()
        message.getHeader().getField(msgType)
        mtype = msgType.getValue()
        if mtype == fix.MsgType_NewOrderSingle:
            #MKT or LMT IOC or FOK
            quickfix44.NewOrderSingle()
            #possibilities - reject (symbol incorrect, size incorrect (less than zero, lot size) etc.)
            #              - partially filled
            #              - filled
            taker = sessionid.getTargetCompID().getValue()
            maker = self.get_maker(taker)

            Fsymbol = fix.Symbol()
            Fside = fix.Side()
            FordType = fix.OrdType()
            ForderQty = fix.OrderQty()
            Fprice = fix.Price()
            FclOrdID = fix.ClOrdID()
            Faccount = fix.Account()
            message.getField(Fsymbol)
            message.getField(Fside)
            message.getField(FordType)
            message.getField(ForderQty)
            message.getField(FclOrdID)
            message.getField(Faccount)
            
            #optional fields
            Fcurrency = fix.Currency()
            FminQty = fix.MinQty()
            Fttl = fix.StringField(10000)
            Fdeviation = fix.StringField(10001)
            for field in [Fcurrency, FminQty, Fttl, Fdeviation]:
                try: message.getField(field)
                except: pass

                
            #parse actual variables
            symbol = Fsymbol.getValue()

            #TODO: check every field!!
            #check clOrdID is unique
            #check accountid

            rejectmsg = None
            #COMMENT: ttl and dev ignored for now
            # try:
            #     ttl = Fttl.getValue()
            #     if ttl == '': ttl = None
            # except: ttl = None
            # try:
            #     dev = Fdeviation.getValue()
            #     if dev == '': dev = None
            # except: dev = None
            # if ttl is not None or dev is not None:
            #     rejectmsg = 'ttl and deviation not supported'
            
            ordertype = FordType.getValue()
            if ordertype == fix.OrdType_LIMIT:
                message.getField(Fprice)
                lmtp = D(Fprice.getValue())
            elif ordertype == fix.OrdType_MARKET:
                lmtp = None
            else:
                rejectmsg = 'Invalid order type'

            #check symbol proper
            if symbol not in config.PAIRS:
                rejectmsg = 'Improper symbol'

            #check side proper
            side = Fside.getValue()
            if side not in [fix.Side_SELL, fix.Side_BUY]:
                rejectmsg = 'Improper side'

            #check size correct and lot size correct (greater than zero)
            base, quote = symbol.split('/')
            lot = D(config.LOTSIZE.get(base, '1'))
            qty = D(ForderQty.getValue())
            
            if int(qty/lot)*lot != qty:
                rejectmsg = 'Improper lot'
            
            minqty = 0
            try: minqty = FminQty.getValue()
            except: pass
                
            #R
            #N--->F [fillqty = desired]
            #N--->C (FOK) [zero fill]
            #N--->PF--->C (IOC) [fillqty < desired]
            #N--->PF ... PF --->F (not supported (requires ttl))
            lmtp0 = None
            if lmtp: lmtp0 = float(lmtp)
            if rejectmsg:
                print 'order was rejected: {}'.format(rejectmsg)
                #REJECT
                self.send_execution(FclOrdID.getValue(), None, fix.ExecType_REJECTED, symbol, side, float(qty), float(minqty), ordertype, base, lmtp0, fix.OrdStatus_REJECTED, lastQty=None, lastPx=None, leavesQty=None, cumQty=None, avgP=None, settlDate=None, text=rejectmsg, transactTime=None)
                return
            else:
                #NEW
                self.send_execution(FclOrdID.getValue(), None, fix.ExecType_NEW, symbol, side, float(qty), float(minqty), ordertype, base, lmtp0, fix.OrdStatus_NEW, lastQty=None, lastPx=None, leavesQty=float(qty), cumQty=0, avgP=None, settlDate=None, text=None, transactTime=None)

                side_ = 'buy' if side == fix.Side_BUY else 'sell'
                t_fills = self.exchange.match(symbol, str(minqty), str(qty), side_, taker, lmtp)

                if len(t_fills) == 0: #no fills
                    #CANCEL
                    self.send_execution(FclOrdID.getValue(), None, fix.ExecType_CANCELED, symbol, side, float(qty), float(minqty), ordertype, base, lmtp0, fix.OrdStatus_CANCELED, lastQty=None, lastPx=None, leavesQty=float(qty), cumQty=0, avgP=None, settlDate=None, text=None, transactTime=None)

                else:
                    fill = t_fills[0] #only one taker fill for now

                    #ASSUME T+2 settlement
                    execdt = datetime.datetime.utcfromtimestamp(fill['ts'])
                    settledt = execdt.date() + datetime.timedelta(2) #TODO: needs better logic
                    settled = settledt.strftime('%Y%m%d')
                    transactdt = execdt.strftime('%Y%m%d-%H:%M:%S.%f')[:-3] #truncate microsecs to millisecs
                    
                    if D(fill['qty']) == D(qty):
                        #Full fill
                        self.send_execution(FclOrdID.getValue(), fill['fillid'], fix.ExecType_TRADE, fill['symbol'], side, float(qty), float(minqty), ordertype, base, lmtp0, fix.OrdStatus_FILLED, lastQty=float(fill['qty']), lastPx=float(fill['price']), leavesQty=0, cumQty=float(fill['qty']), avgP=float(fill['price']), settlDate=settled, text=None, transactTime=transactdt)
                    
                    else:
                        #Partial + Cancel
                        #PARTIAL
                        self.send_execution(FclOrdID.getValue(), fill['fillid'], fix.ExecType_TRADE, fill['symbol'], side, float(qty), float(minqty), ordertype, base, lmtp0, fix.OrdStatus_PARTIALLY_FILLED, lastQty=float(fill['qty']), lastPx=float(fill['price']), leavesQty=float(qty-D(fill['qty'])), cumQty=float(fill['qty']), avgP=float(fill['price']), settlDate=settled, text=None, transactTime=transactdt)

                        #CANCEL
                        self.send_execution(FclOrdID.getValue(), None, fix.ExecType_CANCELED, symbol, side, float(qty), float(minqty), ordertype, base, lmtp0, fix.OrdStatus_CANCELED, lastQty=None, lastPx=None, leavesQty=float(qty-D(fill['qty'])), cumQty=float(fill['qty']), avgP=None, settlDate=None, text=None, transactTime=None)
                    
                    self.notify_takers(maker, symbol)

    def send_execution(self, clOrdID, execID, execType, symbol, side, qty, minqty, ordertype, currency, price, ordStatus, lastQty, lastPx, leavesQty, cumQty, avgP, settlDate, text, transactTime):
        executionReport = quickfix44.ExecutionReport()

        #Mandatory fields
        executionReport.setField(fix.ClOrdID(clOrdID))
        if execType == fix.ExecType_TRADE:
            executionReport.setField(fix.ExecID(execID))
        else:
            executionReport.setField(fix.ExecID('0'))
        executionReport.setField(fix.ExecType(execType))
        executionReport.setField(fix.Symbol(symbol))
        executionReport.setField(fix.Side(side))
        executionReport.setField(fix.OrderQty(qty)) #float
        executionReport.setField(fix.MinQty(minqty)) #float
        executionReport.setField(fix.OrdType(ordertype))
        executionReport.setField(fix.Currency(currency))

        if price:
            #Conditional
            executionReport.setField(fix.Price(price))

        #Optional
        #executionReport.setField(fix.OrderID())

        #Mandatory
        executionReport.setField(fix.OrdStatus(ordStatus))

        #Conditional
        if lastQty: executionReport.setField(fix.LastQty(lastQty))
        if lastPx: executionReport.setField(fix.LastPx(lastPx))
        if leavesQty: executionReport.setField(fix.LeavesQty(leavesQty))
        if cumQty: executionReport.setField(fix.CumQty(cumQty))
        if avgP: executionReport.setField(fix.AvgPx(avgP))
        if settlDate: executionReport.setField(fix.SettlDate(settlDate))

        #Mandatory (spec says mandatory but example says otherwise)
        if text: executionReport.setField(fix.Text(text))

        #Conditional
        if transactTime:
            x = fix.TransactTime()
            x.setString(transactTime)
            executionReport.setField(x)
            
        try:
            fix.Session.sendToTarget(executionReport, self.tradingsession)
        except fix.SessionNotFound as e:
            print 'no session'
            
            
    def handle_pricing_msg(self, message, sessionid):
        msgType = fix.MsgType()
        message.getHeader().getField(msgType)
        mtype = msgType.getValue()
        if mtype == fix.MsgType_MarketDataRequest:

            group = quickfix44.MarketDataRequest().NoRelatedSym()
            message.getGroup(1, group)

            symtag = fix.Symbol()
            group.getField(symtag)
            sym = symtag.getValue()
            symidtag = fix.MDReqID()
            message.getField(symidtag)
            symid = symidtag.getValue()
            if sym not in config.PAIRS:
                rejectmsg = quickfix44.MarketDataRequestReject()
                rejectmsg.setField(fix.MDReqID(symid))
                rejectmsg.setField(fix.Text('symbol not found'))
                try:
                    fix.Session.sendToTarget(rejectmsg, sessionid)
                except fix.SessionNotFound as e:
                    print 'no sess'
            else: #else symbol valid
                srt = fix.SubscriptionRequestType()
                message.getField(srt)
                print 'subscription request {}'.format(sym), srt.getValue(), '<<<<< REQUEST TYPE'
                if srt.getValue() == fix.SubscriptionRequestType_DISABLE_PREVIOUS_SNAPSHOT_PLUS_UPDATE_REQUEST: #unsubscribe
                    self.send.pop(sym, None)
                elif srt.getValue() == fix.SubscriptionRequestType_SNAPSHOT_PLUS_UPDATES:
                    if sym in self.send:
                        rejectmsg = quickfix44.MarketDataRequestReject()
                        rejectmsg.setField(fix.MDReqID(symid))
                        rejectmsg.setField(fix.Text('already subscribed as another id'))
                        try:
                            fix.Session.sendToTarget(rejectmsg, sessionid)
                        except fix.SessionNotFound as e:
                            print 'no session'
                    else:
                        self.send[sym] = symid
                        self.massQuote(sessionid, sym, True)
                else:
                    print 'not supported; reject'
                    

    def genExecID(self):
        self.execID += 1
        return self.execID
            
    def massQuote(self, sessionid, sym, firstcall=False):
        assert self.session_eq(sessionid, self.pricingsession)
        #first call param will prevent sending if there is no quote
        if sym not in self.send:
            return
        print sym, self.send, self.send[sym]
        maker = self.get_maker(sessionid.getSenderCompID().getValue())
        msg = quickfix44.MassQuote()
        msg.setField(fix.QuoteID(str(self.quoteID))) #If set, then maker should expect MassQuoteAcknowledgement
        self.quoteID += 1
        group = quickfix44.MassQuote().NoQuoteSets()

        group.setField(fix.QuoteSetID(self.send[sym])) #Required, same as mdrequest tag mdreqid
        group1 = quickfix44.MassQuote().NoQuoteSets().NoQuoteEntries()

        group1.setField(fix.QuoteEntryID('0'))
                
        topbid, topbidsz = self.exchange.top_bid(sym)
        topask, topasksz = self.exchange.top_ask(sym)

        #do not send if massQuote is due to subscription and there is nothing
        if topbid is None and topask is None and firstcall:
            return
        
        #TODO: what to do about float precision?
        group1.setField(fix.BidSize(float(topbidsz) if topbidsz else -1)) #Optional, -1 quote cancel                
        group1.setField(fix.OfferSize(float(topasksz) if topasksz else -1)) #Ditto
        if topbid:
            group1.setField(fix.BidSpotRate(float(topbid))) #Optional,spot bid rate  not set = no changes
        if topask:
            group1.setField(fix.OfferSpotRate(float(topask))) #Ditto
                    
        group.addGroup(group1)
        msg.addGroup(group)

        try:
            fix.Session.sendToTarget(msg, sessionid)
        except fix.SessionNotFound as e:
            print 'no sess'

        

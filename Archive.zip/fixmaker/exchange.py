import os
import time
import threading
import uuid
import numpy as np
from collections import defaultdict
from cdecimal import Decimal as D
import operator
from pymongo import MongoClient

def synchronized(lock):
    def wrap(f):
        def newFunction(*args, **kwargs):
            lock.acquire()
            try:
                return f(*args, **kwargs)
            finally:
                lock.release()
        return newFunction
    return wrap

#TODO: lock should not be global
lock = threading.Lock() #need to lock making and taking

#No time priority will be given as all orders are maker orders
class Exchange(object):
    def __init__(self, maker): #symlist
        self.maker = maker
        self.orders = {} #id0 -> json order
        self.client = MongoClient()
        self.db = self.client[maker]
        
    @synchronized(lock)
    def get_open_orders(self):
        return self.orders.values()

    @synchronized(lock)
    def get_maker_fills(self, lastfillid):
        #query
        print 'lastfillid not yet used'
        fills = list(self.db['maker_fills'].find())
        [x.pop('_id',None) for x in fills]
        return fills
    
    #maker interface
    @synchronized(lock)
    def add_lmt_order(self, id0, sym, side, price, qty):
        #assert unique id system wide
        if id0 in self.orders:
            return {'success':False, 'msg':'duplicate id'}
        #assert does not cross existing order
        if side == 'buy':
            p,q = self._top_ask(sym)
            if p and D(price) >= D(p):
                return {'success':False, 'msg':'cannot cross'}
        else:
            p,q = self._top_bid(sym)
            if p and D(price) <= D(p):
                return {'success':False, 'msg':'cannot cross'}
        self.orders[id0] = {'orderid':id0,
                            'side':side,
                            'symbol':sym,
                            'price':price,
                            'qty':qty,
                            'filled':'0',
                            'remain':qty,
                            'maker':self.maker,
                            'last_modified':time.time()}
        return {'success':True, 'orderid':id0}

    @synchronized(lock)
    def cancel_lmt_order(self, id0):
        success = True #cancels regardless
        sym = None
        if id0 in self.orders:
            sym = self.orders[id0]['symbol']
            del self.orders[id0]
            success = True
        return {'success':success, 'sym':sym}
    
    #taker interface

    @synchronized(lock)
    def match(self, sym, min_qty, qty, taker_side, taker, lmtp=None):
        if taker_side == 'buy':
            maker_side = 'sell'
            comp_func = operator.le #x <= y
            if lmtp is None: lmtp = np.inf
        else:
            assert taker_side == 'sell'
            maker_side = 'buy'
            comp_func = operator.ge 
            if lmtp is None: lmtp = -np.inf

        eligible_orders = [o for o in self.orders.values() if o['symbol'] == sym and o['side'] == maker_side and comp_func(D(o['price']), D(lmtp))]
        szavail = sum(D(o['remain']) for o in eligible_orders)
        if szavail < D(min_qty):
            print szavail, min_qty, '< no size!'
            return [],[]

        ts = time.time()
        rem = D(qty)
        #TODO: sort by partial fills as well so those orders get matched first
        orders = sorted(eligible_orders, key=lambda x:float(x['price']))
        if taker_side == 'sell': orders.reverse()

        newqty = {}
        match_id = str(uuid.uuid4())
        maker_fills = []
        taker_fills = []
        for order0 in orders:
            id0,sym0,p,q = order0['orderid'],order0['symbol'],order0['price'],order0['remain']
            q = D(q)
            if q <= rem:
                #eat the entire order
                rem -= q
                maker_fills.append({'fillid':str(uuid.uuid4()),'orderid':id0,'price':p,'qty':str(q),'ts':ts,'symbol':sym,'taker_direction':taker_side,'taker':taker,'maker':self.maker,'match_id':match_id})
                newqty[id0] = 0
            else:
                #eats partial order
                newqty[id0] = q - rem
                maker_fills.append({'fillid':str(uuid.uuid4()),'orderid':id0,'price':p,'qty':str(rem),'ts':ts,'symbol':sym,'taker_direction':taker_side,'taker':taker,'maker':self.maker,'match_id':match_id})
                rem = 0
            if rem == 0:
                break
        for id0, nqty in newqty.items():
            if nqty == 0:
                del self.orders[id0]
            else:
                self.orders[id0]['remain'] = str(nqty)
                self.orders[id0]['filled'] = str(D(self.orders[id0]['qty']) - D(self.orders[id0]['remain']))

        #create one big fill for the taker (to satisfy minqty or else can get weird behavior)
        allday = D(qty) - rem
        avgp = sum([D(f['price'])*D(f['qty']) for f in maker_fills])/allday
        
        taker_fills = [{'fillid':str(uuid.uuid4()), 'qty':str(allday), 'price': str(avgp), 'ts':ts, 'symbol':sym, 'taker_direction':taker_side, 'taker':taker, 'maker':self.maker,'match_id':match_id}]

        #persist everything
        self.db['maker_fills'].insert_many(maker_fills)
        self.db['taker_fills'].insert_many(taker_fills)
        return maker_fills, taker_fills
    
    @synchronized(lock)
    def top_bid(self, sym):
        return self._top_bid(sym)

    def _top_bid(self, sym):
        bids = [o for o in self.orders.values() if o['symbol'] == sym and o['side'] == 'buy']
        if len(bids) == 0:
            return None, None
        bids = sorted(bids, key=lambda x:float(x['price']))
        return bids[-1]['price'], bids[-1]['remain']

    @synchronized(lock)
    def top_ask(self, sym):
        return self._top_ask(sym)

    def _top_ask(self, sym):
        asks = [o for o in self.orders.values() if o['symbol'] == sym and o['side'] == 'sell']
        if len(asks) == 0:
            return None, None
        asks = sorted(asks, key=lambda x:float(x['price']))
        return asks[0]['price'], asks[0]['remain']
    


#TODO: move this to a config file outside of the project
MAKERS = {'maker':[]} #Maps a list of takers

TAKERS = {'PXM_PRICING':{'username':'cryptotrader','password':'btc123','maker':'maker','session_type':'pricing'},
          'PXM_TRADING':{'username':'cryptotrader','password':'btc123','maker':'maker','session_type':'trading'}}

for taker0, obj in TAKERS.items():
    assert obj['maker'] in MAKERS
    MAKERS[obj['maker']].append(taker0)

#PAIRS = ['BTC/USD','BTC/JPY','XRP/JPY','ETH/JPY', 'BCH/JPY', 'LTC/JPY', 'EOS/JPY','ADA/JPY','XLM/JPY','NEO/JPY','IOTA/JPY','XMR/JPY','DASH/JPY','XEM/JPY','ETC/JPY','QTUM/JPY','ETH/USD','XRP/USD','BCH/USD','LTC/USD','EOS/USD','ADA/USD','XLM/USD','NEO/USD','IOTA/USD','XMR/USD','DASH/USD','XEM/USD','ETC/USD','QTUM/USD']

PAIRS = {'BTCUSD':{'base':'BTC','quote':'USD'},
         'ETHUSD':{'base':'ETH','quote':'USD'},
         'XRPUSD':{'base':'XRP','quote':'USD'},
         'BCHUSD':{'base':'BCH','quote':'USD'},
         'LTCUSD':{'base':'LTC','quote':'USD'},
         'EOSUSD':{'base':'EOS','quote':'USD'},
         'ADAUSD':{'base':'ADA','quote':'USD'},
         'XLMUSD':{'base':'XLM','quote':'USD'},
         'NEOUSD':{'base':'NEO','quote':'USD'},
         'IOTAUSD':{'base':'IOTA','quote':'USD'},
         'XMRUSD':{'base':'XMR','quote':'USD'},
         'DASHUSD':{'base':'DASH','quote':'USD'},
         'XEMUSD':{'base':'XEM','quote':'USD'},
         'ETCUSD':{'base':'ETC','quote':'USD'}}#,'BTC/JPY']

DFLT_WIDTH_FUNC = lambda base: {'BTC':'0.005', 'ETH':'0.006', 'XRP':'0.006', 'BCH':'0.006',
                                'LTC':'0.006'}.get(base, '0.01')

NOMINAL_QUOTE_FUNC = lambda base: {'BTC':'500000', 'ETH':'500000', 'XRP':'250000', 'BCH':'250000',
                                   'LTC':'250000'}.get(base, '100000')


STALE_SECS = 30 #price is considered stale if there is no tv update in this time

DESC = {'BTC':'Bitcoin',
        'USD':'Dollar',
        'JPY':'Yen',
        'XRP':'Ripple',
        'ETH':'Ethereum',
        'BCH':'Bitcoin Cash',
        'LTC':'Litecoin',
        'EOS':'EOS',
        'ADA':'Cardano',
        'XLM':'Stellar',
        'NEO':'Neo',
        'IOTA':'MIOTA',
        'XMR':'Monero',
        'DASH':'Dash',
        'XEM':'NEM',
        'ETC':'Eth Classic',
        'QTUM':'QTUM'}

LOTSIZE = {'BTC':'0.01',
           'XRP':'200',
           'ETH':'0.25',
           'BCH':'0.2',
           'LTC':'1',
           'EOS':'20',
           'ADA':'500',
           'XLM':'500',
           'NEO':'1',
           'IOTA':'100',
           'XMR':'0.5',
           'DASH':'0.5',
           'XEM':'500',
           'ETC':'5',
           'QTUM':'5'}

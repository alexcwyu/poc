package com.bfam.riskreport.mgr

import com.bfam.riskreport.service.ReportRequest
import com.bfam.riskreport.service.ReportResponse


interface RiskManager {
    fun start()
    fun refresh()
    fun query(query: ReportRequest?): ReportResponse?
    fun stop()
}
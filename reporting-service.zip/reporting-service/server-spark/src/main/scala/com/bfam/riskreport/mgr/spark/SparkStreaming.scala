package com.bfam.riskreport.mgr.spark

import org.apache.spark.sql.streaming.StreamingQueryListener
import org.apache.spark.sql.types._
import org.apache.spark.sql._
import org.apache.spark.sql.functions._

object SparkStreaming {


  class ConsoleWriter[T] extends ForeachWriter[T] {
    override def open(partitionId: Long, version: Long): Boolean = {
      true
    }

    override def process(value: T): Unit = {
      println(value)
    }

    override def close(errorOrNull: Throwable): Unit = {
    }
  }


  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .master("local")
      .appName("StructuredNetworkWordCount")
      .getOrCreate()

    import spark.implicits._

    val myQueryListener = new StreamingQueryListener {

      import org.apache.spark.sql.streaming.StreamingQueryListener._

      def onQueryTerminated(event: QueryTerminatedEvent): Unit = {
        println(s"Query ${event.id} terminated")
      }

      def onQueryStarted(event: QueryStartedEvent): Unit = {
        println(s"Query ${event.id} started")
      }

      def onQueryProgress(event: QueryProgressEvent): Unit = {
        println(s"Query ${event.progress} progressing")
      }
    }

    //spark.streams.addListener(myQueryListener)

    val lines = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9999)
      .load()

    val realtimeName = spark.readStream
      .format("socket")
      .option("host", "localhost")
      .option("port", 9998)
      .load()


    val data = Seq(
      Row("Alex", "important"),
      Row("William", "important")
    )

    val schema = StructType(
      List(
        StructField("name", StringType, true),
        StructField("status", StringType, true)
      )
    )

    val staticDF = spark.createDataFrame(spark.sparkContext.parallelize(data), schema)

    // Split the lines into words
    val words = lines.as[String].flatMap(_.split(" "))

    // Generate running word count
    val wordCounts = words.groupBy("value").count()
    val realtimeNameDF = realtimeName.distinct()

    val joinDF = wordCounts.join(realtimeNameDF, wordCounts.col("value") ===realtimeNameDF.col("value"), joinType = "left_outer" )

    //val writer = new ConsoleWriter[Row]


    //memory
    val query = joinDF.writeStream
      .format("memory")
      .outputMode("complete")
      .queryName("inmemoryTable")
      .start()


    var i = 0
    while (i < 1000) {
      i = i + 1
      spark.sql("select * from inmemoryTable").show()
      Thread.sleep(1000 * 5)
    }
    //    val query = wordCounts.writeStream
    //        .foreach(writer)
    //        .outputMode("complete")
    //        .start()

    //    val query = wordCounts.writeStream
    //      .outputMode("complete")
    //      .format("console")
    //      .trigger(Trigger.ProcessingTime(10.seconds))
    //      .start()


    query.awaitTermination()
  }
}

package com.bfam.riskreport.grpc

import com.bfam.riskreport.mgr.spark.KotlinSparkRiskManager
import com.bfam.riskreport.service.ReportRequest
import com.bfam.riskreport.service.ReportResponse
import com.bfam.riskreport.service.ReportServiceGrpc
import io.grpc.stub.StreamObserver
import java.util.logging.Logger
import kotlin.concurrent.thread
import kotlin.system.measureTimeMillis

class KotlinSparkReportService : ReportServiceGrpc.ReportServiceImplBase() {

    private val logger = Logger.getLogger(KotlinSparkReportService::class.java.name)
    val manager = KotlinSparkRiskManager()

    init {
        manager.start()
    }

    override fun query(request: ReportRequest, responseObserver: StreamObserver<ReportResponse>) {
        //thread(start = true) {
            logger.info("working on requestId: ${request.requestId}")
            val executionTime = measureTimeMillis {
                val response = manager.query(request)
                responseObserver.onNext(response)
            }

            logger.info("requestId: ${request.requestId} executionTime: ${executionTime}")
            responseObserver.onCompleted()
        //}
    }

    override fun subscribe(responseObserver: StreamObserver<ReportResponse>?): StreamObserver<ReportRequest> {
        return super.subscribe(responseObserver)
    }
}

fun main(args: Array<String>) {
    val server = KotlinGrpcServer(KotlinSparkReportService())
    server.start()
    server.blockUntilShutdown()
}
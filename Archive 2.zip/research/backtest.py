import pandas as pd
import datetime

# Strategy:
#  Go opposite after big liquidations

data_dir = '../../md/dc'
symbols = ['XBTUSD', 'ETHH18', 'DASHH18', 'ETC7D', 'LTCH18', 'XBTH18', 'XBTM18', 'XMRH18', 'XRPH18']

entry_delay = 1
hold_time = 60*10 #<- vary this

mytrades = []

for sym in symbols:
    signals = pd.read_csv(data_dir + '/bigones.' + sym)
    signals = signals.sort_values('end')
    trades = pd.read_csv(data_dir + '/trades' + sym + '.csv')

    for _,sig in signals.iterrows():

        entry_t = sig.end + entry_delay
        exit_t = entry_t + hold_time
        utcdt = datetime.datetime.utcfromtimestamp(entry_t)

        focus = trades[(trades.ts >= entry_t) & (trades.ts <= exit_t)]

        if len(focus) > 0:
            startp, endp = focus.iloc[0].price, focus.iloc[-1].price
            if sig.side == 'Buy':
                #sell this market
                mytrades.append([utcdt, sym, 'sell', (startp-endp)/startp])

            elif sig.side == 'Sell':
                mytrades.append([utcdt, sym, 'buy', (endp-startp)/startp])
            else:
                raise Exception('boo')
            #print sig.side, len(focus), focus.iloc[0].price, focus.iloc[-1].price


        else:
            print 'nodata'


dat = pd.DataFrame(mytrades, columns=['ts','sym','side','plpct'])


for sym in symbols:
    print sym
    df = dat[dat.sym == sym]
    print df
    print df.plpct.mean(), df.plpct.std()
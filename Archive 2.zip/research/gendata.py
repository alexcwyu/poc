
import pandas as pd
import json
import os
import tarfile
import shutil

data_dir = '../../md/dc'
data_name = 'bitmex.data'

def generate():
    trades = {}

    symbols = []
    prices = []
    exchts = []
    sides = []
    qtys = []

    for filename in os.listdir(data_dir):

        if filename.endswith('.tar.gz'):

            tar = tarfile.open(data_dir + '/' + filename)
            tar.extractall(path=data_dir)
            tar.close()

            basedir = 'dc/' + filename[0:-7]
            print basedir
            bitmexdatafile = data_dir + '/' + basedir + '/' + data_name

            try:
                data = open(bitmexdatafile, 'r')
            except IOError:
                bitmexdatafile = data_dir + '/' + basedir + '/' + data_name
                data = open(bitmexdatafile, 'r')

            for line in data:
                try:
                    keys = line.split(";")
                    if keys[1] == 't':
                        symbol = keys[3]

                        jsondata = json.loads(keys[4])
                        symbols.append(symbol)
                        prices.append(jsondata['price'])
                        exchts.append(jsondata['exchts'])
                        sides.append(jsondata['side'])
                        qtys.append(jsondata['qty'])
                except:
                    continue

            try:
                shutil.rmtree(data_dir + '/' + basedir)
            except OSError:
                shutil.rmtree(data_dir + '/' + basedir)

    trades['sym'] = symbols
    trades['price'] = prices
    trades['ts'] = exchts
    trades['side'] = sides
    trades['qty'] = qtys

    df = pd.DataFrame(data=trades)
    df = df.sort_values(by=['ts'])
    uniqueSymbols = set(symbols)
    return df, uniqueSymbols

if __name__ == '__main__':
    df, uniqueSymbols = generate()

    for sym in uniqueSymbols:
        print sym
        df1 = df[df['sym'] == sym]
        df1.to_csv(data_dir + '/trades' + sym + '.csv', sep=',', encoding='utf-8')
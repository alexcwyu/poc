import pandas as pd
import json
import numpy
from cdecimal import Decimal as D

data_dir = '../../md/dc'

def parse():
    pd.set_option('precision', 10)
    chat = open(data_dir + '/bitmex.misc', 'r')
    liquidations = {}

    qtys = []
    prices = []
    sides = []
    tstamps = []
    actions = []
    orderids = []
    symbols = []

    for line in chat:

        try:
            keys = line.split(";")
            if keys[1] == 'liquidation':
                ts = keys[0]
                table = json.loads(keys[2])
                data = table['data']
                action = table['action']

                for d in data:
                    leavesQty = (d.get('leavesQty', numpy.nan))
                    price = (d.get('price', numpy.nan))
                    side = d.get('side', numpy.nan)
                    oid = d.get('orderID','')
                    sym = d.get('symbol','')
                    qtys.append(leavesQty)
                    prices.append(price)
                    sides.append(side)
                    tstamps.append(D(ts))
                    actions.append(action)
                    orderids.append(oid)
                    symbols.append(sym)
        except:
            continue

    liquidations['qty'] = qtys
    liquidations['price'] = prices
    liquidations['side'] = sides
    liquidations['ts'] = tstamps
    liquidations['action'] = actions
    liquidations['oid'] = orderids
    liquidations['sym'] = symbols

    df = pd.DataFrame(data=liquidations)
    df = df.sort_values(by=['oid', 'ts'])
    cols = ['price', 'qty', 'side']
    df[cols] = df[cols].ffill()
    return df

if __name__ == '__main__':
    df = parse()

    df['maxQty'] = df.groupby('oid')['qty'].transform(max)
    df['end'] = df.groupby('oid')['ts'].transform(max)
    df['start'] = df.groupby('oid')['ts'].transform(min)
    df['duration'] = df['end'] - df['start']

    df1 = df[df['action'].isin(['partial', 'insert'])]
    df2 = df[df['action'] == 'delete']

    df1 = df1.loc[:, ['oid', 'price']]
    df2 = df2.loc[:, ['oid', 'price']]

    df3 = pd.merge(df1, df2, on='oid')
    df3['impact'] = (df3['price_y'].astype('float') - df3['price_x'].astype('float')) / df3['price_x']
    df3 = df3.loc[:, ['oid', 'impact']]

    df4 = pd.merge(df, df3, on='oid')
    df4 = df4.loc[:, ['oid', 'maxQty', 'sym', 'side', 'duration', 'impact', 'end']]

    df4 = df4.drop_duplicates()

    sym = 'XBTUSD'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 1000000]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'ETHH18'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 100]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'DASHH18'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 100]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'ETC7D'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 1000]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'LTCH18'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 100]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'XBTH18'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 500000]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'XBTM18'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 500000]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'XMRH18'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 100]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')

    sym = 'XRPH18'
    dfsym = df4[df4['sym'] == sym]
    dfsym = dfsym[dfsym['maxQty'] > 100000]
    dfsym.to_csv(data_dir + '/bigones.' + sym, sep=',', encoding='utf-8')
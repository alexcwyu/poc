import time
from decimal import Decimal as D
import pandas as pd
import backoffice

5/0
#Expects UTC timestamps
dat = pd.read_csv('statements/bitmex_20180114.csv', parse_dates=[0], dtype={'lastQty':str, 'lastPx':str,'execCost':str,'commission':str,'execComm':str,'orderQty':str,'leavesQty':str,'price':str,'side':str})
assert set(dat.execType.unique()) == {'Trade','Funding', 'Settlement'}
dat['fill_ts'] = dat.transactTime.view('int64')//pd.Timedelta(1, unit='s')

dat.rename(columns={'lastQty':'fill_qty','lastPx':'fill_p','orderID':'orderid','commission':'comms'}, inplace=True)


#For some reason - bitmex timestamps are different than the ones we get
funding = dat[dat.execType == 'Funding']
funding['key'] = ['|'.join(x) for x in funding[['comms','fill_p']].values]

bo=backoffice.BackOffice('sensus.sqlite')
ours = bo.fills('bitmex:sensus',0,time.time())
ourf = ours[ours.orderid == '00000000-0000-0000-0000-000000000000']
ourf['key'] = ['|'.join(x) for x in ourf[['comms','fill_p']].values]

oursnottheirs = []
for _, our in ourf.iterrows():
    if len(funding[funding.key == our['key']]) > 0:
        idx = funding[funding.key==our['key']].iloc[0].name
        funding.drop(idx, inplace=True)
    else:
        oursnottheirs.append(our)
if len(oursnottheirs) > 0:
    ont = pd.concat(oursnottheirs)
    print ont
    raise Exception('Manually pick it out!')

for idx, t0 in funding.iterrows():
    inp = {'physical':'bitmex:sensus',
           'symbol':t0['symbol'],
           'cost':t0['comms'],
           'costccy':'XBt',
           'ts':t0['fill_ts'],
           'qty':t0['fill_qty'],
           'price':t0['fill_p'],
           'side':'',
           'multiplier':'1',
           'orderid':'00000000-0000-0000-0000-000000000000',
           'fillid':'funding-{}'.format(t0['fill_ts'])} #ensures immutability
    print inp
    bo.updateFill(inp)

settles = dat[dat.execType == 'Settlement']

for idx,t0 in settles.iterrows():
    inp = {'physical':'bitmex:sensus',
           'symbol':t0['symbol'],
           'cost':t0['comms'],
           'costccy':'XBt',
           'ts':t0['fill_ts'],
           'qty':t0['fill_qty'],
           'price':t0['fill_p'],
           'side':t0['side'].lower(),
           'multiplier':'1',
           'orderid':'settlement',
           'fillid':'settlement-{}'.format(t0['symbol'])} #ensures immutability
    print inp
    bo.updateFill(inp)

trades = dat[dat.execType == 'Trade']
trades['side'] = [str(x).lower() for x in trades['side']]
theirs = trades
theirs['key'] = ['|'.join(x) for x in theirs[['side','fill_qty','fill_p','symbol','orderid']].values.tolist()]


bo=backoffice.BackOffice('sensus.sqlite')
ours = bo.fills('bitmex:sensus',0,time.time())
ours = ours[ours.orderid != '00000000-0000-0000-0000-000000000000']
ours['key'] = ['|'.join(x) for x in ours[['side','fill_qty','fill_p','symbol','orderid']].values.tolist()]

print len(theirs), '<<< RAW'
oursnottheirs = []
for _, our in ours.iterrows():
    if len(theirs[theirs.key == our['key']]) > 0:
        idx = theirs[theirs.key==our['key']].iloc[0].name
        theirs.drop(idx, inplace=True)
    else:
        oursnottheirs.append(our)

print len(theirs), '<<< UNRECONCILED'
k=0
for idx, t0 in theirs.iterrows():
    inp = {'physical':'bitmex:sensus',
           'symbol':t0['symbol'],
           'cost':t0['comms'],
           'costccy':'XBt',
           'ts':t0['fill_ts'],
           'qty':t0['fill_qty'],
           'price':t0['fill_p'],
           'side':t0['side'],
           'multiplier':'1',
           }
    bo.updateFill(inp)

if len(oursnottheirs) > 0:
    ont = pd.concat(oursnottheirs)
    print ont
    raise Exception('Manually pick it out!')


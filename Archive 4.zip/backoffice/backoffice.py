import dateutil.parser
import time
import datetime, pytz
import pandas as pd
import numpy as np
from collections import defaultdict
import os
from decimal import Decimal as D
import cPickle
import json
import symbolspnl
import sqlite3
import logging

#reconciliation

class BackOffice(object):
    def __init__(self, dbpath):
        self.con = sqlite3.connect(dbpath)

    def getsetAccount(self, account_name, allowcreate=False):
        acctype = account_name.split('/')[0]
        assert acctype in ['assets','liabilities','income','expenses','fxconv']
        c = self.con.cursor()
        items = c.execute("SELECT * FROM accounts WHERE name=?", (account_name,)).fetchall()
        if len(items) == 0:
            if allowcreate:
                c.execute("INSERT INTO accounts (name) VALUES (?)", (account_name,))
                id0 = c.lastrowid
                self.con.commit()
            else:
                raise Exception('Account not recognized')
        elif len(items) == 1:
            id0 = items[0][0]
        else:
            raise Exception('Duplicated accounts')
        return id0
            
    def isvalidAccount(self, account_name):
        c = self.con.cursor()
        items = c.execute("SELECT * FROM accounts WHERE name=?", (account_name,)).fetchall()
        return len(items) > 0
        
    def getsetPhysical(self, physical, allowcreate=False):
        venue, name = physical.split(':')
        c = self.con.cursor()
        items = c.execute("SELECT * FROM physicals WHERE venue=? and name=?", (venue, name)).fetchall()
        if len(items) == 0:
            if allowcreate:
                c.execute("INSERT INTO physicals (venue,name) VALUES (?,?)", (venue, name))
                id0 = c.lastrowid
                self.con.commit()
            else:
                raise Exception('Physical not recognized')
        elif len(items) == 1:
            id0 = items[0][0]
        else:
            raise Exception('duplicated accounts')
        return id0
        
    def updateFill(self, filldi):
        assert set(filldi.keys()).issuperset({'physical','symbol','cost','costccy','ts','qty','price','side','multiplier'})
        fillid = filldi.get('fillid',None) #fillid is optional
        orderid = filldi.get('orderid',None) #orderid is optional
        c = self.con.cursor()

        #check for duplicate
        items = []
        if fillid:
            items = c.execute("SELECT * FROM fills WHERE fillid=?", (fillid,)).fetchall()
        physical_id = self.getsetPhysical(filldi['physical'], allowcreate=True)

        if len(items) == 0:
            c.execute("INSERT INTO fills (physical_id,orderid,fillid,symbol,multiplier,comms,comms_ccy,fill_ts,fill_qty,fill_p,handler,side) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",(physical_id,orderid,fillid,filldi['symbol'],filldi['multiplier'],filldi['cost'],filldi['costccy'],filldi['ts'],filldi['qty'],filldi['price'],filldi['handler'],filldi['side']))
            self.con.commit()
        elif len(items) == 1:
            #do some checking here
            pass
        else:
            raise Exception('duplicated fill in database')

    @property
    def fxlatesttimestamp(self):
        c = self.con.cursor()
        max_ts = c.execute("SELECT max(ts) FROM fx").fetchall()[0][0]
        if max_ts is None: max_ts = 0
        return max_ts
        
    def updateFX(self, timestamp, base, quote, rate, commit=True):
        c = self.con.cursor()
        c.execute("INSERT INTO fx (ts,base,quote,rate) VALUES (?,?,?,?)",(timestamp, base, quote, rate))
        if commit: #allow batch
            self.con.commit()

    def updateMarks(self, timestamp, symbol, price, commit=True):
        c = self.con.cursor()
        c.execute("INSERT INTO marks (ts,symbol,mark) VALUES (?,?,?)",(timestamp, symbol, price))
        if commit:
            self.con.commit()

    def updateTransaction(self, txdict):
        assert set(txdict.keys()) == {'datetime','description','entries'} #superset?
        timestamp = time.mktime(dateutil.parser.parse(txdict['datetime']).utctimetuple())
        desc = txdict['description']
        byccy = defaultdict(lambda:D('0'))
        for entry in txdict['entries']:
            account,physical,fund,amt,ccy = entry
            byccy[ccy] += D(amt)
        assert all([x==D('0') for x in byccy.values()]) #transactions must balance

        c = self.con.cursor()
        items = c.execute("SELECT * FROM ledger WHERE ts=? AND description=?", (timestamp,desc)).fetchall()
        if len(items) == 0:
            #lookup account and physical
            for entry in txdict['entries']:
                account,physical,fund,amt,ccy = entry
                if physical == '':
                    phys_id = None
                else:
                    phys_id = self.getsetPhysical(physical, allowcreate=True)
                acc_id = self.getsetAccount(account, allowcreate=False)

                c.execute("INSERT INTO ledger (ts,description,account_id,physical_id,fund,amt,ccy) VALUES (?,?,?,?,?,?,?)", (timestamp,desc,acc_id,phys_id,fund,amt,ccy))
            self.con.commit()
        else:
            print('Already have this transaction')

    def updateTransfer(self, xferdict):
        assert set(xferdict.keys()) == {'rmk','transfer_requested','transfer_leftsrc','transfer_arrived','fee_withdraw','fee_withdraw_ccy','fee_transport','fee_transport_ccy','fee_deposit','fee_deposit_ccy','source','destination','amount','ccy'}

        if xferdict['transfer_requested'] == '': ts0 = None
        else: ts0 = time.mktime(dateutil.parser.parse(xferdict['transfer_requested']).utctimetuple())
        if xferdict['transfer_leftsrc'] == '': ts1 = None
        else: ts1 = time.mktime(dateutil.parser.parse(xferdict['transfer_leftsrc']).utctimetuple())

        if xferdict['transfer_arrived'] == '': ts2 = None
        else: ts2 = time.mktime(dateutil.parser.parse(xferdict['transfer_arrived']).utctimetuple())

        src_id = self.getsetPhysical(xferdict['source'], allowcreate=True)
        dest_id = self.getsetPhysical(xferdict['destination'], allowcreate=True)
        
        cashacc = self.getsetAccount('assets/cash') #only cash transfers now
        
        c = self.con.cursor()
        c.execute("INSERT into transfers (src_id,src_acc_id,dest_id,dest_acc_id,ts_requested,ts_leftsrc,ts_arrdest,fee_withdraw,fee_withdraw_ccy,fee_transport,fee_transport_ccy,fee_deposit,fee_deposit_ccy,amt,ccy,rmk) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (src_id,cashacc,dest_id,cashacc,ts0,ts1,ts2,xferdict['fee_withdraw'],xferdict['fee_withdraw_ccy'],xferdict['fee_transport'],xferdict['fee_transport_ccy'],xferdict['fee_deposit'],xferdict['fee_deposit_ccy'],xferdict['amount'],xferdict['ccy'],xferdict['rmk']))
        self.con.commit()
        
        
    def getfx(self, timestamp, base, quote, stale_thresh=60*60*24*7):
        c = self.con.cursor()
        items = c.execute("SELECT * FROM fx WHERE base=? AND quote=? AND ts>=? AND ts<? ORDER BY ts ASC", (base,quote,timestamp-stale_thresh, timestamp)).fetchall()
        if len(items) == 0:
            return None, None
        _,ts,base0,quote0,rate = items[-1]
        return float(ts), D(rate)
        
    def getmark(self, timestamp, symbol, stale_thresh=60*60*24*7):
        c = self.con.cursor()
        items = c.execute("SELECT * FROM marks WHERE symbol=? AND ts>=? AND ts<? ORDER BY ts ASC", (symbol, timestamp-stale_thresh, timestamp)).fetchall()
        if len(items) == 0:
            return None, None
        _,ts,sym,mark = items[-1]
        return float(ts), D(mark)

    def _tradespl(self, from_ts, to_ts):
        query = "SELECT fills.fillid,fills.orderid,fills.symbol,fills.multiplier,fills.comms,fills.comms_ccy,fills.fill_ts,fills.fill_qty,fills.side,fills.fill_p,fills.handler,physicals.venue,physicals.name FROM fills INNER JOIN physicals ON fills.physical_id = physicals.id WHERE fills.fill_ts >= {} AND fills.fill_ts < {}".format(from_ts, to_ts)

        dat = pd.read_sql(query, self.con)
        dat.fill_p = [D(x) for x in dat.fill_p]
        dat.fill_qty = [D(x) for x in dat.fill_qty]
        dat['utcdt'] = [datetime.datetime.utcfromtimestamp(float(ts)) for ts in dat.fill_ts]
        dat.comms = [D('0') if x is None else D(x) for x in dat.comms]
        dat.multiplier= [D(x) for x in dat.multiplier]
        dat['qty'] = dat.multiplier*dat.fill_qty
        return dat

    def trades2journal(self, from_ts, to_ts):
        pd.set_option('display.width', 200)
        tpl = self._tradespl(from_ts, to_ts)
        entries = []
        deltas = defaultdict(lambda: D(0))
        positions = defaultdict(lambda: D('0'))
        if len(tpl) == 0:
            entries = pd.DataFrame(entries, columns=['ts','desc','physical','fund','account','amt','ccy'])
            return entries, deltas, positions

        tpl['physical'] = ['{}:{}'.format(v,n) for v,n in zip(tpl['venue'], tpl['name'])]
        tpl['ispair'] = ['/' in sym for sym in tpl['symbol']] #smarter about this?
        tradespl = tpl[~tpl.ispair]
        if tradespl.size > 0:
            #print tradespl
            assert tradespl.venue.unique() == 'bitmex'
        for sym, group in tradespl.groupby('symbol'):
            actfills = group[group.handler != 'Funding']
            actfills = actfills.sort_values(['utcdt'], ascending=True)

            assert actfills.comms_ccy.unique() == ['BTC']
            assert len(actfills.physical.unique()) == 1
            physical0 = actfills.physical.unique()[0]

            comms = actfills.comms.sum()
            entries.append([to_ts,'comms',physical0,'','expenses/commissions',comms,'BTC'])
            entries.append([to_ts,'comms',physical0,'','assets/cash',-comms,'BTC'])

            funding = group[group.handler == 'Funding']
            swapfunding = D(0)
            if len(funding) > 0:
                assert sym == 'XBTUSD'
                swapfunding -= funding.comms.sum()
                entries.append([to_ts,'swapfunding',physical0,'','income/swapfunding',swapfunding,'BTC'])
                entries.append([to_ts,'swapfunding',physical0,'','assets/cash',-swapfunding,'BTC'])

            actfills.sort_values('fill_ts', ascending=True)

            actfills['execDir'] = np.where(actfills.side =='buy', D(1), D(-1))
            actfills['execQty'] = actfills['execDir'] * actfills.fill_qty
            actfills['openQty'] = np.cumsum(actfills['execQty'])
            actfills['prevOpenQty'] = np.roll(actfills['openQty'], 1)
            actfills['prevOpenQty'].iloc[0] = D(0)
            
            actfills['diffDir'] = np.where(actfills['execDir']*actfills['prevOpenQty'] < D(0), D(1), D(0))
            actfills['closedQty'] = actfills['diffDir']*np.minimum(np.absolute(actfills['prevOpenQty']),np.absolute(actfills['execQty']))*actfills['execDir']
            actfills['closedValue'] = symbolspnl.xbtvalue(sym, actfills['closedQty'], actfills.fill_p)
            actfills['openedQty'] = actfills['execQty'] - actfills['closedQty']
            actfills['openedValue'] = symbolspnl.xbtvalue(sym, actfills['openedQty'], actfills.fill_p)


            prevAvgPx = D(0)
            n = 0
            for i , row in actfills.iterrows():
                if n == 0:
                    prevAvgPx = row.fill_p
                    actfills.set_value(i, 'avgPx', row.fill_p)
                elif row['closedQty'] == 0 :
                    prevOpenValue =symbolspnl.xbtvalue(sym, row['prevOpenQty'], prevAvgPx)
                    prevAvgPx = symbolspnl.avgpx(sym,  prevOpenValue + row['openedValue'], (row['prevOpenQty'] + row['openedQty']))
                    actfills.set_value(i, 'avgPx', prevAvgPx)
                    #except Exception as e:
                    #    print row
                elif row['openedQty'] == 0:
                    actfills.set_value(i, 'avgPx', prevAvgPx)
                else:
                    actfills.set_value(i, 'avgPx', row.fill_p)
                    prevAvgPx = row.fill_p
                n += 1
                    
            actfills['realized'] = actfills['closedValue'] - symbolspnl.xbtvalue(sym, actfills['closedQty'], actfills['avgPx'])

            rem_qty = actfills['openQty'].iloc[-1]
            avgPx = actfills['avgPx'].iloc[-1]

            realizedpl = np.sum(actfills['realized'])
            entries.append([to_ts,'realized',physical0,'','income/trading',-realizedpl,'BTC'])
            entries.append([to_ts,'realized',physical0,'','assets/cash',realizedpl,'BTC'])
            #print ('realized', sym, realizedpl)
                
            data_ts, markPx = self.getmark(to_ts, sym)
            #is the remaining position long or short
            unrealizedpl, delta = D(0), {}
            if markPx is None: markPx = avgPx
            if markPx != avgPx:
                unrealizedpl = symbolspnl.xbtvalue(sym, rem_qty, avgPx) - symbolspnl.xbtvalue(sym, rem_qty, markPx)
                #print ('unrealized: ', sym, unrealizedpl, rem_qty, avgPx, markPx)
            delta = symbolspnl.getdelta(sym, rem_qty, markPx)
            positions[sym] += rem_qty
                
            #print sym, rem_qty, avgPx, realizedpl, unrealizedpl, delta
            for ccy,amt in delta.items():
                deltas[ccy] += amt

            if unrealizedpl != 0:
                entries.append([to_ts,'unrealized',physical0,'','income/trading',-unrealizedpl,'BTC'])
                entries.append([to_ts,'unrealized',physical0,'','equity/unrealized',unrealizedpl,'BTC'])

            #if sym == 'XBTUSD':
            #    print actfills[['symbol', 'utcdt', 'execQty', 'prevOpenQty', 'openQty', 'openedQty', 'openedValue', 'closedQty', 'closedValue', 'avgPx', 'fill_p', 'realized']]
            
        fxpl = tpl[tpl.ispair]        
        for _, row in fxpl.iterrows():
            ts = row['fill_ts']
            phys = row['physical']

            if row['comms_ccy'] is not None:
                entries.append([ts,'comms',phys,'','expenses/commissions',row['comms'],row['comms_ccy']])
                
                entries.append([ts,'comms',phys,'','assets/cash',-row['comms'],row['comms_ccy']])

            base, quote = row['symbol'].split('/')
            if row['side'] == 'buy':
                baseimpact = row['fill_qty']
                quoteimpact = -row['fill_qty']*row['fill_p']
            else:
                assert row['side'] == 'sell'
                baseimpact = -row['fill_qty']
                quoteimpact = row['fill_qty']*row['fill_p']
                
            entries.append([ts,'trade',phys,'','assets/cash',baseimpact,base])
            entries.append([ts,'trade',phys,'','assets/cash',quoteimpact,quote])

            #dummy entries for books to balance
            entries.append([ts,'trade',phys,'','fxconv',-baseimpact,base])
            entries.append([ts,'trade',phys,'','fxconv',-quoteimpact,quote])

            
        entries = pd.DataFrame(entries, columns=['ts','desc','physical','fund','account','amt','ccy'])
        return entries, deltas, positions

    def ledger2journal(self, ts):
        query = "SELECT ledger.ts,ledger.description,ledger.fund,ledger.amt,ledger.ccy,accounts.name,physicals.venue,physicals.name as pname FROM ledger INNER JOIN accounts ON ledger.account_id = accounts.id JOIN physicals ON ledger.physical_id = physicals.id WHERE ledger.ts <={}".format(ts)
        dat = pd.read_sql(query, self.con)

        dat['account'] = dat.name
        dat['physical'] = ['{}:{}'.format(v,n) for v,n in zip(dat.venue, dat.pname)]
        dat['amt'] = [D(amt) for amt in dat.amt]
        dat['desc'] = dat['description']
        return dat[['ts','desc','physical','fund','account','amt','ccy']]

    def transfers2journal(self, ts):
        entries = []
        query = """SELECT p1.venue v1,p1.name n1,p2.venue v2,p2.name n2,ac1.name acc1,ac2.name acc2,t.*
        FROM transfers t 
        JOIN physicals p1
        JOIN physicals p2
        JOIN accounts ac1
        JOIN accounts ac2
        WHERE p1.id=t.src_id AND p2.id=t.dest_id AND ac1.id=t.src_acc_id AND ac2.id=t.dest_acc_id AND ts_arrdest <= {}""".format(ts)
        
        xfers = pd.read_sql(query, self.con)

        for idx,xfer in xfers.iterrows():
            venue1 = '{}:{}'.format(xfer['v1'], xfer['n1'])
            venue2 = '{}:{}'.format(xfer['v2'], xfer['n2'])
            acc1 = xfer['acc1']
            acc2 = xfer['acc2']
            amt = xfer['amt']
            ts = xfer['ts_arrdest']

            #transfer convention is to specify full amount at venue1 then deduct all fees at the dest
            if D(xfer['fee_withdraw']) > 0:
                fee = D(xfer['fee_withdraw'])
                feeccy = xfer['fee_withdraw_ccy']
                entries.append([ts,'withdrawal fee',venue1,'','expenses/fees',fee,feeccy])
                entries.append([ts,'withdrawal fee',venue2,'',acc2,-fee,feeccy])

            if D(xfer['fee_transport']) > 0:
                fee = D(xfer['fee_transport'])
                feeccy = xfer['fee_transport_ccy']
                entries.append([ts,'network fee','network','','expenses/fees',fee,feeccy])
                entries.append([ts,'network fee',venue2,'',acc2,-fee,feeccy])

            if D(xfer['fee_deposit']) > 0:
                fee = D(xfer['fee_deposit'])
                feeccy = xfer['fee_deposit_ccy']
                entries.append([ts,'deposit fee',venue2,'','expenses/fees',fee,feeccy])
                entries.append([ts,'deposit fee',venue2,'',acc2,-fee,feeccy])

            ccy = xfer['ccy']
            entries.append([ts,'withdrawal',venue1,'',acc1,-D(amt),ccy])
            entries.append([ts,'deposit',venue2,'',acc1,D(amt),ccy])

        return pd.DataFrame(entries, columns=['ts','desc','physical','fund','account','amt','ccy'])
    
    def journal(self, ts):
        #load journals
        manualentries = self.ledger2journal(ts)
        #print manualentries
        xferentries = self.transfers2journal(ts)
        autoentries,deltas,pos = self.trades2journal(0,ts)
        aggjournal = pd.concat([manualentries, autoentries, xferentries])
        #print aggjournal.sort_values('ts')
        return aggjournal.sort_values('ts')

    def fills(self, physical, from_ts, to_ts):
        phys_id = self.getsetPhysical(physical, allowcreate=False)
        query = "SELECT fills.fillid,fills.orderid,fills.symbol,fills.multiplier,fills.comms,fills.comms_ccy,fills.fill_ts,fills.fill_qty,fills.side,fills.fill_p,fills.handler,physicals.venue,physicals.name FROM fills INNER JOIN physicals ON fills.physical_id = physicals.id WHERE fills.fill_ts >= {} AND fills.fill_ts < {} AND fills.physical_id = {}".format(from_ts, to_ts, phys_id)

        dat = pd.read_sql(query, self.con)
        return dat

    #TODO: probably makes sense to combine deltas and positions
    def positions(self, ts):
        autoentries, deltas, pos = self.trades2journal(0, ts)
        return pos
    
    def delta(self, ts):
        #account | underlying | amt
        autoentries, deltas, pos = self.trades2journal(0, ts)
        return deltas
    
    def reg(self, ts, physical, account):
        if not self.isvalidAccount(account):
            raise Exception('Not a valid account')
        journal = self.journal(ts)
        register = journal[(journal.physical==physical) & (journal.account==account)]
        register['dt'] = [datetime.datetime.utcfromtimestamp(float(ts)) for ts in register.ts]
        print register.to_string()
        byccy = {}
        for ccy, group in register.groupby('ccy'):
            group['cum'] = group.amt.cumsum()
            byccy[ccy] = group[['dt','desc','amt','ccy','cum']]
        return byccy
    
    def bal(self, ts):
        journal = self.journal(ts)
        dat = journal.groupby(['account','physical','fund','ccy']).agg({'amt':sum}).reset_index()
        return dat[(dat.account != 'fxconv') & (dat.amt.abs() > 0)]

    def nav(self, timestamp, numeraire_ccy):
        assert numeraire_ccy in ['USD']
        dat = self.bal(timestamp)
        dat['is_bs'] = ['assets' in acc or 'liabilities' in acc for acc in dat.account]
        bdat = dat[dat.is_bs].groupby('ccy').agg({'amt':'sum'})
        bdat['rate'] = [self.getfx(timestamp,ccy0,numeraire_ccy)[-1] for ccy0 in bdat.index]
        bdat['nval'] = bdat.amt*bdat.rate
        return bdat.nval.sum()
        
    def close(self):
        self.con.close()
        
        # for (fund,acc,strat,cid),grp in tdf.groupby(['fund','account','strategy','contract_uid']):
        #     comms = grp.comms.sum()
        #     assert len(grp.comms_ccy.unique()) == 1
        #     commsccy = grp.comms_ccy.iloc[0]
        #     buys = [(q,p) for q,p in zip(grp.qty, grp.fill_p) if q > 0]
        #     sells = [(q,p) for q,p in zip(grp.qty, grp.fill_p) if q < 0]
        #     bqty = sum([q for (q,p) in buys])
        #     sqty = sum([q for (q,p) in sells])
        #     avgbp, avgsp = 0,0
        #     if bqty > 0: avgbp = sum([q*p for (q,p) in buys])/bqty
        #     if sqty < 0: avgsp = sum([q*p for (q,p) in sells])/sqty

        #     cqty = min(abs(bqty), abs(sqty)) #closed qty
        #     rqty = max(abs(bqty), abs(sqty)) - cqty #residual qty abs
        #     rqty = rqty if abs(bqty) >= abs(sqty) else -rqty #residual qty

        #     instr = parse_cid(cid)
        #     if type(instr) in [cdm.Future, cdm.Stock]:
        #         if cqty > 0:
        #             closedpl = cqty*(avgsp - avgbp)
        #             entries += [[sdate, fund, acc, 'assets/cash', instr.ccy, closedpl],
        #                         [sdate, fund, acc, 'income/trading/%s' % strat, instr.ccy, -closedpl]]

        #         if abs(comms) > 0:
        #             entries += [[sdate, fund, acc, 'assets/cash', commsccy, -comms],
        #                         [sdate, fund, acc, 'expenses/commissions/%s' % strat, commsccy, comms]]

        #         #add offsetting cash items (trading account securities)
        #         if type(instr) == cdm.Stock: 
        #             for _, row in grp[grp.tdate == sdate].iterrows():
        #                 cashused = row['qty']*row['fill_p']
        #                 entries += [[sdate, fund, acc, 'assets/cash', instr.ccy, -cashused],
        #                             [sdate, fund, acc, 'assets/securities', instr.ccy, cashused]] 

        #         if rqty != 0: #multi-day trades
        #             lastdate, mark = getmark(sdate, cid, db, strict=True)
        #             if lastdate is None:
        #                 print 'exact price unavailable for %s on %s for %s' % (cid, sdate, strat)
        #                 mark = avgbp if rqty>0 else avgsp

        #             mtm = rqty*(mark - (avgbp if rqty>0 else avgsp))
        #             entries += [[sdate, fund, acc, 'income/trading/%s' % strat, instr.ccy, -mtm],
        #                         [sdate, fund, acc, 'assets/cash', instr.ccy, mtm]]

        #             prevpos.append([sdate, fund, strat, acc, cid, commsccy, rqty, mark])


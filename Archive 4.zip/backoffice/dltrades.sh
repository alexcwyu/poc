#!/bin/bash

source /home/dev/.virtualenv/mmbot/bin/activate

DATE=`date +%Y%m%d`
declare -a arr=("anxpro" "bitmex" "binance")
for i in "${arr[@]}"
do
    ./tradedl "$i" $DATE
done

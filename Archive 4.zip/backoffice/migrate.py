from decimal import Decimal as D
import datetime, time
from collections import defaultdict
import os
import csv
import backoffice
import json

# This file should move all the orders that are no longer active and put them in the database
fillsdir = './trades'
cryptodir = '../coinmktcap/data'
fxdir = '../ecbfx/data'

equivalents = {'anxpro:default1':'anxpro:sensus',
               'bitmex:sensusmarkets':'bitmex:sensus'}

bo = backoffice.BackOffice('sensus.sqlite')

#load transfer file
xfers = json.load(open('transfers.json'))
for xfer in xfers:
    try:
        bo.updateTransfer(xfer)
    except Exception as e:
        print 'failed or duplicated transfer', e, xfer['rmk']

#load tx file
txs = json.load(open('txfile.json'))
for tx in txs:
    bo.updateTransaction(tx)


#Get all FX rates we don't have and insert into database        
#latest_ts = bo.fxlatesttimestamp
for f in os.listdir(fxdir):
    dat = json.load(open('{}/{}'.format(fxdir,f)), parse_float=D)
    assert dat['base'] == 'EUR'
    eurusd = dat['rates']['USD']
    ts = time.mktime(datetime.datetime.strptime(dat['date'], '%Y-%m-%d').timetuple())
    #if ts > latest_ts: #only update things we don't have; assumes chronological
    for ccy,eurrate in dat['rates'].items():
        usdrate = eurrate/eurusd
        bo.updateFX(ts, ccy, 'USD', str(1/usdrate), commit=False)
        print ccy, usdrate
    bo.con.commit()


#Load all coinmktcap USD prices that aren't already in database
for root,sub,files in os.walk(cryptodir):
    if len(files) > 0:
        f = sorted(files)[-1]
        print f
        ratepath='{}/{}'.format(root,f)
        try:
            x = json.load(open(ratepath))
        except:
            print(ratepath, 'error with file')
            continue
            
        for item in x:
            ccy = item['symbol']
            usdvalue = item['price_usd']

            dt = datetime.datetime.strptime(f, '%Y%m%d.%H_%M_%S')
            ts = time.mktime(dt.timetuple())

            #if ts > latest_ts: #only update things we don't have; assumes chronological
            print('updating', ts, ccy, usdvalue)
            bo.updateFX(ts, ccy , 'USD', usdvalue, commit=False)
            #else:
            #    break
    bo.con.commit()
            
#Get all fills and dump into database
_, _, filenames = next(os.walk(fillsdir), (None, None, []))
for f in filenames:
    with open(fillsdir +"/" + f) as csvfile:
        readCSV = csv.reader(csvfile, delimiter=',')
        for row in readCSV:
            #print row
            if len(row) == 12:
                trade = {'physical': row[0],
                         'fillid': row[1],
                         'orderid': row[2],
                         'symbol': row[3], 
                         'side': row[4],
                         'multiplier': float(row[5]), 
                         'cost': float(row[6]),
                         'costccy': row[7], 
                         'ts': float(row[8]), 
                         'qty': float(row[9]),
                         'price': float(row[10]),
                         'handler': row[11]}

                if trade['physical'] in equivalents:
                    trade['physical'] = equivalents[trade['physical']]
        
                bo.updateFill(trade)

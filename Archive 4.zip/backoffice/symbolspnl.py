from decimal import Decimal as D
#This is a stand in file for until we get a symbols system that can generate this info

def avgpx(symbol, openval, numcontracts):
    if symbol in {'XBTUSD','XBTZ17','XBTH18','XBTM18'}:
        return numcontracts/openval
    elif symbol in {'ETHZ17','ETHH18'}:
        return openval/numcontracts

    else:
        raise Exception('contract not recognized')
    
def xbtvalue(symbol, numcontracts, price):
    if symbol in {'XBTUSD','XBTZ17','XBTH18','XBTM18'}:
        return numcontracts/price
    elif symbol in {'ETHZ17','ETHH18'}:
        return numcontracts*price
    else:
        raise Exception('contract not recognized')

def getdelta(symbol, numcontracts, price):
    numcontracts = D(numcontracts)
    price = D(price)
    delta = {'ETHZ17':{'ETH':numcontracts,'BTC':-numcontracts*price},
             'XBTUSD':{'BTC':numcontracts/price},
             'XBTZ17':{'BTC':numcontracts/price},
             'XBTH18':{'BTC':numcontracts/price}}

    return delta[symbol]

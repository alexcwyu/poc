import time
from decimal import Decimal as D
import pandas as pd
import backoffice

TSBUCKET = 10

def roundup2bucket(ts):
    return int(ts/float(TSBUCKET))*TSBUCKET

#Expects UTC timestamps
symsub = {'ETHBTC':'ETH/BTC'} #this needs to be more scalable
dat = pd.read_csv('statements/binance_sensus.csv', parse_dates=[0], dtype={'Price':str, 'Amount':str,'Fee':str})
dat.rename(columns={'Market':'symbol','Type':'side','Price':'fill_p','Amount':'fill_qty','Fee':'comms','Fee Coin':'comms_ccy'}, inplace=True)
dat['symbol'] = [symsub[s0] for s0 in dat.symbol]
dat['fill_ts'] = dat.Date.view('int64')//pd.Timedelta(1,unit='s')
#dat['r_ts'] = [str(roundup2bucket(ts)) for ts in dat.fill_ts]
dat['side'] = [s.lower() for s in dat.side]
theirs = dat[['side','fill_qty','fill_p','symbol']].values.tolist()
dat['key'] = ['|'.join(x) for x in theirs]
theirs = dat

bo=backoffice.BackOffice('sensus.sqlite')
ours = bo.fills('binance:sensus',0,time.time())
#ours['r_ts'] = [str(roundup2bucket(float(ts))) for ts in ours.fill_ts]

keyz = ours[['side','fill_qty','fill_p','symbol']].values.tolist()
ours['key'] = ['|'.join(x) for x in keyz]

oursnottheirs = []

for _,our in ours.iterrows():
    #try to remove from the other list
    if len(theirs[theirs.key == our['key']]) > 0:
        idx = theirs[theirs.key==our['key']].iloc[0].name
        theirs.drop(idx, inplace=True)
    else:
        oursnottheirs.append(our)
        
if len(oursnottheirs) > 0:
    ont = pd.concat(oursnottheirs)
    raise Exception('manually pick it out!')
    
#trades in statement not in ours
for idx,t0 in theirs.iterrows():
    ans = raw_input('insert this trade into the database? {}'.format(t0))
    if ans == 'y':
        #physical, symbol, cost, costccy, ts, qty, price, side, multiplier
        inp = {'physical':'binance:sensus',
               'symbol':t0['symbol'],
               'cost':t0['comms'],
               'costccy':t0['comms_ccy'],
               'ts':t0['fill_ts'],
               'qty':t0['fill_qty'],
               'price':t0['fill_p'],
               'side':t0['side'],
               'multiplier':'1'}
        bo.updateFill(inp)

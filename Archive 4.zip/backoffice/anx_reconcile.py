import datetime
import time
from decimal import Decimal as D
import pandas as pd
import dateutil.parser
import backoffice

tz = '+08:00'

#Expects UTC timestamps
dat=pd.read_csv('statements/anxpro_20171115_20180110.csv', dtype={'Amount':str})
dat.rename(columns={'Currency':'ccy', 'Amount':'amt'}, inplace=True)
dat['amt'] = [D(amt) for amt in dat['amt']]
dat['dt'] = [dateutil.parser.parse(sd+tz) for sd in dat['Processed Date Time']]
dat['ts'] = [time.mktime(d.utctimetuple()) for d in dat.dt]
dat['date'] = [d.date() for d in dat.dt]

dat=dat[dat.date <= datetime.date(2018,1,8)]

trades = dat[dat.Method == 'Order Fill']


delts = trades.groupby(['date','ccy']).agg({'amt':sum}).reset_index()


fiat = dat[dat.Method == 'FX Conversion']
crypto = dat[dat.Method == 'Crypto Transfer']

delts = delts.groupby('ccy').agg({'amt':sum}).reset_index()
fiat = fiat.groupby('ccy').agg({'amt':sum}).reset_index()
crypto = crypto.groupby('ccy').agg({'amt':sum}).reset_index()

print pd.concat([delts,crypto]).groupby('ccy').agg({'amt':sum}).reset_index()

bo=backoffice.BackOffice('sensus.sqlite')
ourtrades = bo.trades2journal(start_ts, end_ts)




# start_ts = trades.ts.min() - 1
# step = 10
# while start_ts < trades.ts.max():
#     end_ts = start_ts + step
#     subset = trades[(trades.ts > start_ts) & (trades.ts <= end_ts)]

#     theirs = subset.groupby('ccy').agg({'amt':sum}).to_dict()['amt']

#     ourtrades = bo.trades2journal(start_ts, end_ts)
#     ourtrades = ourtrades[(ourtrades.physical=='anxpro:sensus') & (ourtrades.account=='assets/cash')]
#     ours = ourtrades.groupby('ccy').agg({'amt':sum}).to_dict()['amt']
#     match = True
#     for ccy in set(ours.keys() + theirs.keys()):
#         diff = ours.get(ccy, D(0)) - theirs.get(ccy, D(0))
#         if diff > D(0):
#             print start_ts, ccy, diff, len(subset)
#             match = False
#     start_ts = end_ts

start_ts = 0
for d0 in pd.date_range(trades.dt.min().date(), datetime.date.today()):
    end_ts = time.mktime(d0.utctimetuple())

    subset = trades[(trades.ts > start_ts) & (trades.ts <= end_ts)]

    theirs = subset.groupby('ccy').agg({'amt':sum}).to_dict()['amt']

    ourtrades = bo.trades2journal(start_ts, end_ts)
    ourtrades = ourtrades[(ourtrades.physical=='anxpro:sensus') & (ourtrades.account=='assets/cash')]
    ours = ourtrades.groupby('ccy').agg({'amt':sum}).to_dict()['amt']

    diffdi = {}
    for ccy in set(ours.keys() + theirs.keys()):
        diff = theirs.get(ccy, D(0)) - ours.get(ccy, D(0))
        if abs(diff) > D(0):
            diffdi[ccy] = diff
            
    if diffdi:
        #use transactions instead of trades since the format is so borked - change this in the future
        tx = {'datetime':'{}T23:59:59+08:00'.format(d0.strftime('%Y-%m-%d')),
              'description':'anx balancing item',
              'entries':[]}
        for ccy, amt in diffdi.iteritems():
            tx['entries'].append(['assets/cash','anxpro:sensus','',str(amt), ccy])
            tx['entries'].append(['fxconv','anxpro:sensus','',str(-amt), ccy])

        ans = raw_input('insert this balancing tx {}?'.format(tx))
        if ans == 'y':
            bo.updateTransaction(tx)
    start_ts = end_ts


#print crypto


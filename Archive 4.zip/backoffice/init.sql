insert into physicals (venue,name) values ("anxpro","sensus");
insert into physicals (venue,name) values ("octagon","sensus");
insert into physicals (venue,name) values ("binance","sensus");
insert into physicals (venue,name) values ("bittrex","sensus");
insert into physicals (venue,name) values ("bitmex","sensus");
insert into physicals (venue,name) values ("kucoin","sensus");
insert into physicals (venue,name) values ("ocbc","sensus");
insert into physicals (venue,name) values ("dbs","sensus");
insert into physicals (venue,name) values ("hot","sensus");
insert into physicals (venue,name) values ("cold","sensus");

insert into accounts (name) values ("assets/cash");
insert into accounts (name) values ("assets/interest_accrued");

insert into accounts (name) values ("liabilities/loan");

insert into accounts (name) values ("income/trading");
insert into accounts (name) values ("income/dividend");
insert into accounts (name) values ("income/interest");

insert into accounts (name) values ("expenses/fee");
insert into accounts (name) values ("expenses/commissions");
insert into accounts (name) values ("expenses/rent");
insert into accounts (name) values ("expenses/data");
insert into accounts (name) values ("expenses/it");

insert into accounts (name) values ("equity/common");
insert into accounts (name) values ("equity/preferred");
insert into accounts (name) values ("equity/retained");

insert into accounts (name) values ("fxconv");


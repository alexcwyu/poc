"""Static data: big dict of precision, max/min size, fees, any limits etc. by exchange
For each exchange:
- dict of pairs (canonical format)
- dict of fees

Pairs:

-id: Pair in exchange format
-symbol: Pair in canonical format
-base: base ccy in exchange format
-quote: quote ccy in exchange format

-precision: dict of:
    -price: price precision amount (max digits after decimal point)
    -amount: size precision amount (max digits after decimal point)

-tick: minimum tick size for this pair (to be cast into Decimal). If this is not supplied, getticksize() should return 10^(-prec_price) for the pair 
-lot: minimum lot size for this pair (to be cast into Decimal). If this is not supplied, getticksize() should return 10^(-prec_amount) for the pair

-limits: min and max amounts for various items (not yet set in stone)

Fees:
-maker fee (to be cast into Decimal)
-taker fee (to be cast into Decimal)
-fee type ('fixed' or 'bps')
-fee ccy ('base' or 'quote')

"""
from cdecimal import Decimal


CANONICALS = {
    #Dict of single symbol mappings by exchange when it doesn't match our canonical symbol.
    #First symbol is the exchange symbol, second is our canonical symbol.
    'binance': {
        'BCC': 'BCH'},
    'bittrex': {
        'BCC': 'BCH'},
}

SYMBOLS = {

    # from ANXPRO website, http://support.anxintl.com/customer/en/portal/articles/1681849-are-there-minimum-order-limits-

    # 'anxpro': {
    #     'BTC/USD': {'id': 'BTCUSD', 'symbol': 'BTC/USD', 'base': 'BTC', 'quote': 'USD', 'lot':'0.01', 'precision': {'price': 5, 'amount': 8}},
    #     'BTC/HKD': {'id': 'BTCHKD', 'symbol': 'BTC/HKD', 'base': 'BTC', 'quote': 'HKD', 'lot':'0.01', 'precision': {'price': 5, 'amount': 8}},
    #     'ETH/BTC': {'id': 'ETHBTC', 'symbol': 'ETH/BTC', 'base': 'ETH', 'quote': 'BTC', 'lot':'0.0001', 'precision': {'price': 8, 'amount': 8}},
    #     'ETH/HKD': {'id': 'ETHHKD', 'symbol': 'ETH/HKD', 'base': 'ETH', 'quote': 'HKD', 'lot':'0.0001', 'precision': {'price': 5, 'amount': 8}},
    #     'ETH/USD': {'id': 'ETHUSD', 'symbol': 'ETH/USD', 'base': 'ETH', 'quote': 'USD', 'lot':'0.0001', 'precision': {'price': 5, 'amount': 8}},
    #     'LTC/BTC': {'id': 'LTCBTC', 'symbol': 'LTC/BTC', 'base': 'LTC', 'quote': 'BTC', 'lot':'0.1', 'precision': {'price': 5, 'amount': 8}}
    # },

    'anxpro': {
        'START/CAD': {'quote': 'CAD', 'symbol': 'START/CAD', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTCAD'},
        'BTC/GBP': {'quote': 'GBP', 'symbol': 'BTC/GBP', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCGBP'},
        'BTC/EUR': {'quote': 'EUR', 'symbol': 'BTC/EUR', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCEUR'},
        'OAX/ETH': {'quote': 'ETH', 'symbol': 'OAX/ETH', 'precision': {'price': 8, 'amount': 8}, 'base': 'OAX', 'lot': '0.01', 'id': 'OAXETH'},
        'ATENC/SGD': {'quote': 'SGD', 'symbol': 'ATENC/SGD', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCSGD'},
        'ATENC/EUR': {'quote': 'EUR', 'symbol': 'ATENC/EUR', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCEUR'},
        'START/BTC': {'quote': 'BTC', 'symbol': 'START/BTC', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTBTC'},
        'START/GBP': {'quote': 'GBP', 'symbol': 'START/GBP', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTGBP'},
        'BTC/SGD': {'quote': 'SGD', 'symbol': 'BTC/SGD', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCSGD'},
        'BTC/CAD': {'quote': 'CAD', 'symbol': 'BTC/CAD', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCCAD'},
        'ETH/USD': {'quote': 'USD', 'symbol': 'ETH/USD', 'precision': {'price': 5, 'amount': 8}, 'base': 'ETH', 'lot': '0.0001', 'id': 'ETHUSD'},
        'START/USD': {'quote': 'USD', 'symbol': 'START/USD', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTUSD'},
        'ATENC/USD': {'quote': 'USD', 'symbol': 'ATENC/USD', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCUSD'},
        'LTC/BTC': {'quote': 'BTC', 'symbol': 'LTC/BTC', 'precision': {'price': 5, 'amount': 8}, 'base': 'LTC', 'lot': '0.1', 'id': 'LTCBTC'},
        'ATENC/CAD': {'quote': 'CAD', 'symbol': 'ATENC/CAD', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCCAD'},
        'START/AUD': {'quote': 'AUD', 'symbol': 'START/AUD', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTAUD'},
        'GNT/ETH': {'quote': 'ETH', 'symbol': 'GNT/ETH', 'precision': {'price': 8, 'amount': 8}, 'base': 'GNT', 'lot': '1.0', 'id': 'GNTETH'},
        'ATENC/GBP': {'quote': 'GBP', 'symbol': 'ATENC/GBP', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCGBP'},
        'STR/BTC': {'quote': 'BTC', 'symbol': 'STR/BTC', 'precision': {'price': 8, 'amount': 8}, 'base': 'STR', 'lot': '500.0', 'id': 'STRBTC'},
        'BTC/JPY': {'quote': 'JPY', 'symbol': 'BTC/JPY', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCJPY'},
        'START/HKD': {'quote': 'HKD', 'symbol': 'START/HKD', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTHKD'},
        'ATENC/JPY': {'quote': 'JPY', 'symbol': 'ATENC/JPY', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCJPY'},
        'ATENC/HKD': {'quote': 'HKD', 'symbol': 'ATENC/HKD', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCHKD'},
        'BTC/HKD': {'quote': 'HKD', 'symbol': 'BTC/HKD', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCHKD'},
        'START/JPY': {'quote': 'JPY', 'symbol': 'START/JPY', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTJPY'},
        'XRP/BTC': {'quote': 'BTC', 'symbol': 'XRP/BTC', 'precision': {'price': 8, 'amount': 8}, 'base': 'XRP', 'lot': '750.0', 'id': 'XRPBTC'},
        'BTC/NZD': {'quote': 'NZD', 'symbol': 'BTC/NZD', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCNZD'},
        'BTC/USD': {'quote': 'USD', 'symbol': 'BTC/USD', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCUSD'},
        'ETH/BTC': {'quote': 'BTC', 'symbol': 'ETH/BTC', 'precision': {'price': 8, 'amount': 8}, 'base': 'ETH', 'lot': '0.0001', 'id': 'ETHBTC'},
        'DOGE/BTC': {'quote': 'BTC', 'symbol': 'DOGE/BTC', 'precision': {'price': 8, 'amount': 8}, 'base': 'DOGE', 'lot': '5000.0', 'id': 'DOGEBTC'},
        'START/SGD': {'quote': 'SGD', 'symbol': 'START/SGD', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTSGD'},
        'ATENC/NZD': {'quote': 'NZD', 'symbol': 'ATENC/NZD', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCNZD'},
        'ATENC/AUD': {'quote': 'AUD', 'symbol': 'ATENC/AUD', 'precision': {'price': 8, 'amount': 8}, 'base': 'ATENC', 'lot': '0.01', 'id': 'ATENCAUD'},
        'START/NZD': {'quote': 'NZD', 'symbol': 'START/NZD', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTNZD'},
        'BTC/AUD': {'quote': 'AUD', 'symbol': 'BTC/AUD', 'precision': {'price': 5, 'amount': 8}, 'base': 'BTC', 'lot': '0.01', 'id': 'BTCAUD'},
        'ETH/HKD': {'quote': 'HKD', 'symbol': 'ETH/HKD', 'precision': {'price': 5, 'amount': 8}, 'base': 'ETH', 'lot': '0.0001', 'id': 'ETHHKD'},
        'START/EUR': {'quote': 'EUR', 'symbol': 'START/EUR', 'precision': {'price': 8, 'amount': 8}, 'base': 'START', 'lot': '0.01', 'id': 'STARTEUR'}},


    'binance': {
        # binance lot size is order price dependent. All orders have to be > 0.001 BTC. Hard-coded something reasonable here first
        'ETH/BTC': {'id': 'ETHBTC', 'symbol': 'ETH/BTC', 'base': 'ETH', 'quote': 'BTC', 'lot':'0.05', 'precision': {'price': 6, 'amount': 3},
                    'limits': {'amount': {'min': 0.001, 'max': None}, 'price': {'min': 0.000001, 'max': None}, 'cost': {'min': 0.001, 'max': None}}},
        'LTC/BTC': {'id': 'LTCBTC', 'symbol': 'LTC/BTC', 'base': 'LTC', 'quote': 'BTC', 'lot':'0.1', 'precision': {'price': 6, 'amount': 2},
                    'limits': {'amount': {'min': 0.01, 'max': None}, 'price': {'min': 0.000001, 'max': None}, 'cost': {'min': 0.001, 'max': None}}},
        'NEO/BTC': {'id': 'NEOBTC', 'symbol': 'NEO/BTC', 'base': 'NEO', 'quote': 'BTC', 'lot':'0.5', 'precision': {'price': 6, 'amount': 2},
                    'limits': {'amount': {'min': 0.01, 'max': None}, 'price': {'min': 0.000001, 'max': None}, 'cost': {'min': 0.001, 'max': None}}},
        'XVG/BTC': {'id': 'XVGBTC', 'symbol': 'XVG/BTC', 'base': 'XVG', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 0}},
        'BNB/BTC': {'id': 'BNBBTC', 'symbol': 'BNB/BTC', 'base': 'BNB', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 0}}
    },
    'bitfinex': {
        'BTC/USD': {'id': 'btcusd', 'symbol': 'BTC/USD', 'base': 'BTC', 'quote': 'USD', 'precision_sf': {'price': 5, 'amount': None}},
        'ETH/USD': {'id': 'ethusd', 'symbol': 'ETH/USD', 'base': 'ETH', 'quote': 'USD', 'precision_sf': {'price': 5, 'amount': None}},
        'IOTA/USD': {'id': 'iotusd', 'symbol': 'IOTA/USD', 'base': 'IOT', 'quote': 'USD', 'precision_sf': {'price': 5, 'amount': None}},
        'BCH/USD': {'id': 'bchusd', 'symbol': 'BCH/USD', 'base': 'BCH', 'quote': 'USD', 'precision_sf': {'price': 5, 'amount': None}},
        'BTG/USD': {'id': 'btgusd', 'symbol': 'BTG/USD', 'base': 'BTG', 'quote': 'USD', 'precision_sf': {'price': 5, 'amount': None}}
    },
    'bitmex': {
        'XBTZ17': {'id': 'XBTZ17', 'symbol': 'XBTZ17', 'base':'BTC','quote':'USD', 'tick':'0.5', 'lot':'1', 'precision': {'price': 1, 'amount': 0}, 'initMargin':0.01},
        'XBTH18': {'id': 'XBTH18', 'symbol': 'XBTH18', 'base':'BTC','quote':'USD', 'tick':'0.5', 'lot':'1', 'precision': {'price': 1, 'amount': 0}, 'initMargin':0.01},
        'XBTUSD': {'id': 'XBTUSD', 'symbol': 'XBTUSD', 'base': 'BTC', 'quote':'USD', 'tick':'0.5', 'lot':'1', 'precision': {'price': 1, 'amount': 0}, 'initMargin':0.01},
        'ETHZ17': {'id': 'ETHZ17', 'symbol': 'ETHZ17', 'base':'ETH','quote':'USD', 'tick':'0.5', 'lot':'1', 'precision': {'price': 1, 'amount': 0}, 'initMargin':0.01},
        '.BXBT': {'id': '.BXBT', 'symbol': '.BXBT'},
    },
    'bitstamp': {
        'BTC/USD': {'id': 'btcusd', 'symbol': 'BTC/USD', 'base': 'BTC', 'quote': 'USD', 'precision': {'price': 2, 'amount': 8}},
        'BTC/EUR': {'id': 'btceur', 'symbol': 'BTC/EUR', 'base': 'BTC', 'quote': 'EUR', 'precision': {'price': 2, 'amount': 8}},
        'ETH/USD': {'id': 'ethusd', 'symbol': 'ETH/USD', 'base': 'ETH', 'quote': 'USD', 'precision': {'price': 2, 'amount': 8}},
        'ETH/BTC': {'id': 'ethbtc', 'symbol': 'ETH/BTC', 'base': 'ETH', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}}
    },
    # TODO precision information needs work
    'bittrex': {
        'BTG/BTC': {'id': 'BTC-BTG', 'symbol': 'BTG/BTC', 'base': 'BTG', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}},
        'POWR/BTC': {'id': 'BTC-POWR', 'symbol': 'POWR/BTC', 'base': 'POWR', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}},
        'BTC/USDT': {'id': 'USDT-BTC', 'symbol': 'BTC/USDT', 'base': 'BTC', 'quote': 'USDT', 'precision': {'price': 8, 'amount': 8}},
        'BCC/BTC': {'id': 'BTC-BCC', 'symbol': 'BCC/BTC', 'base': 'BCC', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}},
        'NXT/BTC': {'id': 'BTC-NXT', 'symbol': 'NXT/BTC', 'base': 'NXT', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}},
        'ETH/BTC': {'id': 'BTC-ETH', 'symbol': 'ETH/BTC', 'base': 'ETH', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}},
        'LTC/BTC': {'id': 'BTC-LTC', 'symbol': 'LTC/BTC', 'base': 'LTC', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}},
        'NEO/BTC': {'id': 'BTC-NEO', 'symbol': 'NEO/BTC', 'base': 'NEO', 'quote': 'BTC', 'precision': {'price': 8, 'amount': 8}}
    },
    'gdax': {
        'BTC/USD': {'id': 'BTC-USD', 'symbol': 'BTC/USD', 'base': 'BTC', 'quote': 'USD', 'precision': {'price': 2, 'amount': 8}},
        'ETH/USD': {'id': 'ETH-USD', 'symbol': 'ETH/USD', 'base': 'ETH', 'quote': 'USD', 'precision': {'price': 2, 'amount': 8}},
        'LTC/USD': {'id': 'LTC-USD', 'symbol': 'LTC/USD', 'base': 'LTC', 'quote': 'USD', 'precision': {'price': 2, 'amount': 8}},
        'BTC/EUR': {'id': 'BTC-EUR', 'symbol': 'BTC/EUR', 'base': 'BTC', 'quote': 'EUR', 'precision': {'price': 2, 'amount': 8}},
        'ETH/BTC': {'id': 'ETH-BTC', 'symbol': 'ETH/BTC', 'base': 'ETH', 'quote': 'BTC', 'precision': {'price': 5, 'amount': 8}}
    },
    'kraken': {
        'BTC/EUR': {'id': 'XXBTZEUR', 'symbol': 'BTC/EUR', 'base': 'XXBT', 'quote': 'ZEUR', 'precision': {'price': 1, 'amount': 8}},
        'BTC/USD': {'id': 'XXBTZUSD', 'symbol': 'BTC/USD', 'base': 'XXBT', 'quote': 'ZUSD', 'precision': {'price': 1, 'amount': 8}},
        'ETH/EUR': {'id': 'XETHZEUR', 'symbol': 'LTC/USD', 'base': 'XETH', 'quote': 'ZEUR', 'precision': {'price': 2, 'amount': 8}},
    },
    'kucoin': {
            'KCS/BTC': {'id': 'KCSBTC', 'symbol': 'KCS/BTC', 'base': 'KCS', 'quote': 'BTC', 'lot': '0.05',
                        'precision': {'price': 6, 'amount': 3},
                        'limits': {'amount': {'min': 0.001, 'max': None}, 'price': {'min': 0.000001, 'max': None},
                                   'cost': {'min': 0.001, 'max': None}}},
            'DBC/BTC': {'id': 'DBCBTC', 'symbol': 'DBC/BTC', 'base': 'DBC', 'quote': 'BTC', 'lot': '0.05',
                        'precision': {'price': 6, 'amount': 3},
                        'limits': {'amount': {'min': 0.001, 'max': None}, 'price': {'min': 0.000001, 'max': None},
                                   'cost': {'min': 0.001, 'max': None}}},
            'RPX/BTC': {'id': 'RPXBTC', 'symbol': 'RPX/BTC', 'base': 'RPX', 'quote': 'BTC', 'lot': '0.05',
                        'precision': {'price': 6, 'amount': 3},
                        'limits': {'amount': {'min': 0.001, 'max': None}, 'price': {'min': 0.000001, 'max': None},
                                   'cost': {'min': 0.001, 'max': None}}},
    },
    'okex': {
        'ETH0330': {'id': 'ETH0330', 'symbol': 'ETH0330', 'base': 'ETH', 'quote': 'USD', 'tick': '0.001', 'lot': '1',
                   'precision': {'price': 1, 'amount': 0}, 'initMargin': 0.01},

    },
    }


FEES = {
    'anxpro': {'maker': '0', 'taker': '0', 'type': 'bps', 'ccy':'base'},
    'binance': {'maker': '5', 'taker': '5', 'type': 'bps', 'ccy':'BNB'},
    'bittrex': {'maker': '35', 'taker': '35', 'type': 'bps', 'ccy':'base'}

    }


#TODO: migrate isCCYPair here from utils
def canonical(exchange, ccy):
    ccy = ccy.upper()
    if exchange in CANONICALS and ccy in CANONICALS[exchange]:
        return CANONICALS[exchange][ccy]
    else:
        return ccy

def venuesym(venue, sym):
    try:
        return SYMBOLS[venue][sym]['id']
    except:
        return None

def canonicalsym(venue, venuesym):
    if venue not in SYMBOLS: return None
    cands = [x['symbol'] for x in SYMBOLS[venue].values() if x['id'] == venuesym]
    if len(cands) == 1:
        return cands[0]
    return None
    
def getlotsize(exchange, symbol):
    if (exchange in SYMBOLS) and (symbol in SYMBOLS[exchange]):
        if 'lot' in SYMBOLS[exchange][symbol]:
            return Decimal(SYMBOLS[exchange][symbol]['lot'])
        else:
            return Decimal('10')**-SYMBOLS[exchange][symbol]['precision']['amount']
    else:
        raise Exception('no info for {} on {}'.format(symbol, exchange))

def getticksize(exchange, symbol):
    if (exchange in SYMBOLS) and (symbol in SYMBOLS[exchange]):
        if 'tick' in SYMBOLS[exchange][symbol]:
            return Decimal(SYMBOLS[exchange][symbol]['tick'])
        else:
            return Decimal('10')**-SYMBOLS[exchange][symbol]['precision']['price']
    else:
        raise Exception('no info for {} on {}'.format(symbol, exchange))

def getbaseccy(exchange, symbol):    
    if (exchange in SYMBOLS) and (symbol in SYMBOLS[exchange]):
        return SYMBOLS[exchange][symbol]['base']
    else:
        raise Exception('no info for {} on {}'.format(symbol, exchange))

def getquoteccy(exchange, symbol):    
    if (exchange in SYMBOLS) and (symbol in SYMBOLS[exchange]):
        return SYMBOLS[exchange][symbol]['quote']
    else:
        raise Exception('no info for {} on {}'.format(symbol, exchange))

#Returns tuple of CCY,decimalAmt                                                                                                                     
def balrequired(exchange, symbol, side, amt, price):
    assert utils.isfloat(amt)
    assert utils.isfloat(price)

    info = SYMBOLS[exchange][symbol]
    if exchange in ['bitmex']:
        if info['quote'] == 'USD' and info['base'] == 'BTC':
            btcrequired = Decimal(amt)/Decimal(price)
        else:
            assert info['quote'] == 'BTC'
            btcrequired = Decimal(amt)*Decimal(price)
        return 'BTC', utils.dec_to_str(btcrequired*Decimal(SYMBOLS[exchange][symbol]['initMargin'])) #TODO: populate initMargin via request from BitMEX

    elif utils.isCCYPair(symbol):
        if side == 'buy':
            return info['quote'], utils.dec_to_str(Decimal(amt)*Decimal(price))
        else:
            assert side == 'sell'
            return info['base'], utils.dec_to_str(Decimal(amt))
    else:
        raise Exception('symbol is not a ccy pair, need to subclass this function')

def getfees(exchange):
    return FEES[exchange]

def round_dn(exchange, symbol, dprice):
    if dprice is None: return dprice
    ticksize = getticksize(exchange, symbol)
    return (dprice//ticksize)*ticksize

def round_up(exchange, symbol, dprice):
    if dprice is None: return dprice
    ticksize = getticksize(exchange, symbol)
    return (dprice//ticksize + 1)*ticksize

def round_lot(exchange, symbol, dsize):
    if dsize is None: return dsize
    lotsize = getlotsize(exchange, symbol)
    return (dsize//lotsize)*lotsize

CREATE TABLE physicals
(id INTEGER PRIMARY KEY AUTOINCREMENT,
venue TEXT,
name TEXT,
UNIQUE(venue, name) ON CONFLICT ABORT
);

CREATE TABLE accounts
(id INTEGER PRIMARY KEY AUTOINCREMENT,
name TEXT UNIQUE
);

CREATE TABLE fills
(id INTEGER PRIMARY KEY AUTOINCREMENT,
physical_id INTEGER,
fillid TEXT UNIQUE,
orderid TEXT,
symbol TEXT NOT NULL,
side TEXT NOT NULL,
multiplier TEXT NOT NULL,
comms TEXT,
comms_ccy TEXT,
fill_ts TEXT NOT NULL,
fill_qty TEXT NOT NULL,
fill_p TEXT NOT NULL,
handler TEXT,
FOREIGN KEY(physical_id) REFERENCES physicals(id));

CREATE TABLE ledger
(id INTEGER PRIMARY KEY AUTOINCREMENT,
ts TEXT,
description TEXT,
account_id INTEGER,
physical_id INTEGER,
fund TEXT,
amt TEXT,
ccy TEXT,
FOREIGN KEY(physical_id) REFERENCES physicals(id),
FOREIGN KEY(account_id) REFERENCES accounts(id));

CREATE TABLE fx
(id INTEGER PRIMARY KEY AUTOINCREMENT,
ts TEXT,
base TEXT,
quote TEXT,
rate TEXT,
UNIQUE(ts, base, quote) ON CONFLICT REPLACE
);

CREATE TABLE marks
(id INTEGER PRIMARY KEY AUTOINCREMENT,
ts TEXT,
symbol TEXT,
marks TEXT,
UNIQUE(ts, symbol) ON CONFLICT REPLACE
);

CREATE TABLE transfers
(id INTEGER PRIMARY KEY AUTOINCREMENT,
src_id INTEGER,
src_acc_id INTEGER,
dest_id INTEGER,
dest_acc_id INTEGER,
ts_requested TEXT,
ts_leftsrc TEXT,
ts_arrdest TEXT NOT NULL,
fee_withdraw TEXT,
fee_withdraw_ccy TEXT,
fee_transport TEXT,
fee_transport_ccy TEXT,
fee_deposit TEXT,
fee_deposit_ccy TEXT,
amt TEXT,
ccy TEXT,
rmk TEXT,
UNIQUE(ts_arrdest, src_id, dest_id) ON CONFLICT REPLACE,
FOREIGN KEY(src_id) REFERENCES physicals(id),
FOREIGN KEY(src_acc_id) REFERENCES accounts(id),
FOREIGN KEY(dest_id) REFERENCES physicals(id),
FOREIGN KEY(dest_acc_id) REFERENCES accounts(id)
);


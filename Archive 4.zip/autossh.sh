#!/bin/bash
autossh -M 0 -o "ServerAliveInterval 30" -i "ServerAliveCountMax 3" -L 8888:127.0.0.1:8888 dev@dev.sensusmarkets.com

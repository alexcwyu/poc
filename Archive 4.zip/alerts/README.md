
Instructions:

1) create a file called config.py in this directory

2) example data structure:

cfg = {'host':'prod',
       'bots': {
           'telegrambot': {'channels': {'-299908967':['system']},
                           'transport':'telegram', 
                           'token':'564277059:AAEANJkskoXGrr2GlaPFN-ExpbK2AJMkjyk'},
           'slackbot': {'channels': {'scanners':['premon'],
                                     'fills':['production_fills'],
                                     'system':['default','system'],
                                     'orders':['production_orders'],
                                     'algos':['production_algos']},
                        'transport':'slack',
                        'token':'xoxp-337573215495-335818116512-360444139984-cb1da042374ace3f19eed44dcd40ae13'}}
}

# Channels have topics; alertserver will route the topics to the appropriate channels
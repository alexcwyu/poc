import smtplib
import xmlrpclib
from email.mime.text import MIMEText
import logging

x=xmlrpclib.ServerProxy('http://localhost:5959', allow_none=True)
lastmsg = None
def alert(msg, topic='system'):
    global lastmsg
    if lastmsg != msg:
        try:
            x.send_alert(msg, topic)
            lastmsg = msg
        except:
            logging.error(str(msg))
            logging.error('Exception occured, is alertserver running?', exc_info=True)
    else:
        pass


def email(recipients, subject, smsg):
    try:
        msg = MIMEText(smsg)
        msg['Subject'] = subject
        msg['From'] = 'alerts@sensusmarkets.com'
        msg['To'] = ', '.join(recipients)
        s = smtplib.SMTP('localhost')
        s.sendmail('alerts@sensusmarkets.com', recipients, msg.as_string())
        s.quit()
    except:
        logging.error('Failed to email')
    


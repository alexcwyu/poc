
#Installation

0) requirements: install redis (sudo apt install redis)

1) install python packages: pip install -r requirements.txt (use sudo as necessary)

2) create data/marks directory

3) setup ~/.bashrc to source envsetup.sh

4) setup mysettings.py


# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, April 2018
#cparams.py: live contract trade parameters
from cdecimal import Decimal as D
import redis
import settings
import utils
import time
import logging
import pubsub

CONFIG = {'bitmex': {'XBTH18': {'basis': D(1)},
                     'XBTM18': {'basis': D(1)},
                     'XBTUSD': {'basis': D(1)},
                     },
          'okexfut': {'BTC20180323': {'basis': D(1)},
                      'BTC20180330': {'basis': D(1)},
                      },
          }

CHECK_INTERVAL = 1
NS = 'cp:'
CONTRACTS = 'contracts'
BASIS = 'basis'
FIELDS = [BASIS]

class ContractParams(object):
    
    def __init__(self):
        self.pub = pubsub.Publisher()
        self.r = redis.StrictRedis(settings.REDIS_HOST, settings.REDIS_PORT)
        self.basis = {}
        self.lastupdatets = time.time()
        self.update()

    def __ckey(self, venue, contract):
        return "{}@{}".format(contract, venue)
    
    #Clear all contract params
    def reset(self):
        for f in FIELDS:
            hashname = NS+f
            for c in self.r.hkeys(hashname):
                self.r.hdel(hashname, c)
            self.r.delete(hashname)
        self.r.delete(NS+CONTRACTS)
        self.update()

    def get_non_default_basis(self):
        keys = self.r.smembers(NS+CONTRACTS)
        result = {}
        if len(keys) > 0:
            result = self.r.hmget(NS+BASIS, *list(keys))
            result = {k:v for k,v in zip(keys, result)}
        return result
        
    def setbasis(self, venue, contract, basis):
        try: strbasis = utils.dec_to_str(basis)
        except: return False
        key = self.__ckey(venue, contract)
        self.basis[key] = basis #cache it
        self.r.hset(NS+BASIS, key, strbasis)
        self.r.sadd(NS+CONTRACTS, key)
        self.pub.publish_basis(venue, contract, strbasis)
        return True

    def getbasis(self, venue, contract):
        timenow = time.time()
        if timenow - self.lastupdatets > CHECK_INTERVAL:
            self.update()
        key = self.__ckey(venue, contract)
        if key in self.basis:
            return self.basis[key]
        else:
            return D(1)

    def remove_contract(self, venue, contract):
        key = self.__ckey(venue, contract)
        self.r.srem(NS+CONTRACTS, key)
        for f in FIELDS:
            hashname = NS+f
            self.r.hdel(hashname, key)

    def update(self):
        basisdict = self.get_non_default_basis()
        self.basis = {k:D(v) for k,v in basisdict.items()}
        self.lastupdatets = time.time()

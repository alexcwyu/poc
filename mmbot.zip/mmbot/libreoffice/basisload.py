import uno
import sys
import redis
#import zmq

FLAGS = ["VALUE", "DATETIME", "STRING", "ANNOTATION", "FORMULA", "HARDATTR", "STYLES", "OBJECTS", "EDITATTR"]
NA = u"N/A"
RED = 16711680
GREEN = 65280
NOFILL = -1

EPBASIS = 'basis'
NS = "cp:"
CONTRACTS = 'contracts'
BASIS = 'basis'
FIELDS = [BASIS]

BASIS_RANGES = ['bmxbasis', 'okfbasis', 'cfbasis']
FUTURES_CODES = ['F', 'G', 'H', 'J', 'K', 'M', 'N', 'Q', 'U', 'V', 'X', 'Z']

class ContractParams(object):
    def __init__(self, r, pubport, sshstring):
        self.r = r
        #self.context = zmq.green.Context()
        #self.socket = self.context.socket(zmq.green.PUB)
        #zmq.ssh.tunnel_connection(self.socket, "tcp://localhost:{}".format(pubport), sshstring)

    def setbasis(self, contract, basis, pipe=None):
        redisexec = self.r
        if pipe: redisexec = pipe
        #(symbol, venue) = '@'.split(contract)
        if basis == "1":
            redisexec.hdel(NS+BASIS, contract)
            redisexec.srem(NS+CONTRACTS, contract)
        else:
            redisexec.hset(NS+BASIS, contract, basis)
            redisexec.sadd(NS+CONTRACTS, contract)
        #self.publish_basis(venue, symbol, basis)

    def multisetbasis(self, lstbasis):
        pipe=self.r.pipeline()
        for params in lstbasis:
            contract = params[0]
            basis = params[1]
            self.setbasis(contract, basis, pipe)
        values=pipe.execute()

    def getbasis(self, contract):
        result = self.r.hget(NS+BASIS, contract)
        if result: 
            return float(result)
        else:
            return 1

    def getallbasis(self):
        result = self.r.hgetall(NS+BASIS)
        basisdict = {}
        for c in result:
            basisdict[c] = float(result[c])
        return basisdict

    #def publish_basis(self, venue, symbol, basis):
    #    self.socket.send("{} {}".format(EPBASIS, json.dumps({'venue': venue, 'symbol': symbol, 'basis': basis})))

class MakerParams(object):
    def __init__(self, r):
        self.r = r

    def getavailmodels(self):
        return self.r.smembers('makermodels')

    def getavailparams(self, makername, pipe=None):
        redisexec = self.r
        if pipe:
            redisexec = pipe
        return redisexec.hgetall('makerparams:{}'.format(makername))

    def multigetavailparams(self, lstmakernames):
        pipe = self.r.pipeline()
        params = {}
        for makername in lstmakernames:
            params[makername.encode("utf-8")] = self.getavailparams(makername, pipe)
        pipe.execute()
        return params

    def getparam(self, makername, key):
        return self.r.hget('makerparams:{}'.format(makername), key)

    def setparam(self, makername, key, value, pipe=None):
        redisexec = self.r
        if pipe: 
            redisexec = pipe
        redisexec.sadd('makermodels', makername)
        redisexec.hset('makerparams:{}'.format(makername), key, value)

    def multisetparams(self, lstparams):
        pipe=self.r.pipeline()
        for params in lstparams:
            makername = params[0]
            key = params[1]
            value = params[2]
            self.setparam(makername, key, value, pipe)
        values=pipe.execute()

    def removeparam(self, makername, key):
        self.r.hdel('makerparams:{}'.format(makername), key)

    def removemaker(self, makername):
        self.r.srem('makermodels', makername)
        for k,v in self.r.hgetall('makerparams:{}'.format(makername)).items():
            self.r.hdel('makerparams:{}'.format(makername), k)

    def removeall(self):
        for model in self.getavailmodels():
            self.removemaker(model)



desktop = XSCRIPTCONTEXT.getDesktop()
model = desktop.getCurrentComponent()
basissheet = model.Sheets.getByName("Basis")
logsheet = model.Sheets.getByName("Log")
makersheet = model.Sheets.getByName("Maker")
settingssheet = model.Sheets.getByName("Settings")
settings = settingssheet.getCellRangeByName("settings")

REDIS_HOST = settings.getCellByPosition(1, 0).getString()
REDIS_PORT = settings.getCellByPosition(1, 1).getString()
MD_PUBPORT = settings.getCellByPosition(1, 2).getString()
ZMQ_SSHTUNNEL = settings.getCellByPosition(1, 3).getString()

r = redis.StrictRedis(REDIS_HOST, REDIS_PORT)
cp = ContractParams(r, MD_PUBPORT, ZMQ_SSHTUNNEL)
mp = MakerParams(r)

def gensym(coin, venue, expiry):
    if venue == 'okexfut':
        symbol = coin + expiry
    elif venue == 'cf':
        symbol = 'FI_' + coin + 'USD_' + expiry[-6:]
    elif venue == 'bitmex':
        coin0 = coin
        if coin0 == 'BTC': coin0 = 'XBT'
        year = expiry[2:4]
        month = int(expiry[4:6])
        symbol = coin0 + FUTURES_CODES[month-1] + year
    else:
        symbol = "No symbol"
    return symbol

def loadbasiscontracts(args):
    redisvalues = basissheet.getCellRangeByName("redisvalues")
    basisdict = cp.getallbasis()

    allflags = sum([uno.getConstantByName("com.sun.star.sheet.CellFlags."+x) for x in FLAGS])
    redisvalues.clearContents(allflags)

    basisdata = [("Symbol", "Current Value", "Desired Value")]
    for namedrange in BASIS_RANGES:
        data = basissheet.getCellRangeByName(namedrange).DataArray
        venue = data[0][0]
        for col in range(1, len(data[0])):
            coin = data[0][col]
            for row in range(1, len(data)):
                expiry = str(int(data[row][0]))
                symbol = gensym(coin, venue, expiry)

                key = (symbol + "@" + venue).encode('utf-8')
                if key in basisdict:
                    basis = float(basisdict[key])
                else:
                    basis = 1

                newbasis = basis
                if args == "check":
                    newbasis = data[row][col]
                else:
                    newbasis = basis
                    basissheet.getCellRangeByName(namedrange).getCellByPosition(col, row).setValue(basis)
                basisdata.append(tuple([key, basis, newbasis]))

    contractdata = list(redisvalues.DataArray)
    for i in range(len(basisdata)):
        contractdata[i] = basisdata[i]
    redisvalues.setDataArray(tuple(contractdata))

    if args == "check":
        contractdata = redisvalues.DataArray
        for row in range(1, len(contractdata)):
            if len(contractdata[row][0]) == 0: break
            oldbasis = contractdata[row][1]
            newbasis = contractdata[row][2]
            colour = NOFILL
            if oldbasis == newbasis:
                colour = NOFILL
            elif abs(newbasis/oldbasis - 1) <= 0.01:
                colour = GREEN
            else:
                colour = RED
            basissheet.getCellRangeByName("redisvalues").getCellByPosition(0, row).CellBackColor=colour
            basissheet.getCellRangeByName("redisvalues").getCellByPosition(1, row).CellBackColor=colour
            basissheet.getCellRangeByName("redisvalues").getCellByPosition(2, row).CellBackColor=colour

def checkbasiscontracts(args):
    loadbasiscontracts("check")
        

def savebasiscontracts(args):
    redisvalues = basissheet.getCellRangeByName("redisvalues")
    contractdata = redisvalues.DataArray
    basistoset = []
    for row in range(1, len(contractdata)):
        contract = contractdata[row][0]
        oldbasis = contractdata[row][1]
        newbasis = contractdata[row][2]
        if oldbasis != newbasis:
            basistoset.append((contract.encode('utf-8'), str(newbasis).encode('utf-8')))
    cp.multisetbasis(basistoset)

def loadmakerparams(args):
    makerfields = list(makersheet.getCellRangeByName("makerfields").DataArray)[0]
    makerparams = makersheet.getCellRangeByName("makerparams")

    newparamdata = []

    allflags = sum([uno.getConstantByName("com.sun.star.sheet.CellFlags."+x) for x in FLAGS])
    makerparams.clearContents(allflags)
    paramdata = list(makerparams.DataArray)

    models = map(lambda x: x.decode("utf-8"), sorted(mp.getavailmodels()))
    modelparams = mp.multigetavailparams(models)
    #logsheet.getCellByPosition(1, 1).setString(str(modelparams))
    
    for model in sorted(modelparams.keys()):
        newdata = [model.decode("utf-8")]
        params = modelparams[model]
        for field in makerfields:
            field0 = field.encode("utf-8")
            if field0 in params:
                newdata.append(params[field0].decode("utf-8"))
            else:
                newdata.append(NA)
        newparamdata.append(tuple(newdata)) 
    for i in range(len(newparamdata)):
        paramdata[i] = newparamdata[i]

    makerparams.setDataArray(tuple(paramdata))

def checkmakerparams(args, save=False):
    makerfields = list(makersheet.getCellRangeByName("makerfields").DataArray)[0]
    makerparams = list(makersheet.getCellRangeByName("makerparams").DataArray)

    paramstoset = []
    models = []
    for i in range(len(makerparams)):
        row = makerparams[i]
        model = row[0]
        if len(model) == 0: 
            break
        else:
            models.append(model)

    modelparams = mp.multigetavailparams(models)
    #logsheet.getCellByPosition(1, 1).setString(str(modelparams))
    for i in range(len(makerparams)):
        row = makerparams[i]
        model = row[0]
        if len(model) == 0: 
            break
        else:
            params = modelparams[model.encode("utf-8")]

        for j in range(1, len(row)):
            field = makerfields[j-1].encode("utf-8")
            if row[j] == "" or row[j] == NA or field not in params.keys():
                makersheet.getCellRangeByName("makerparams").getCellByPosition(j, i).CellBackColor=RED
            else:
                oldvalue = params[field].decode("utf-8")
                if oldvalue == row[j]:
                    makersheet.getCellRangeByName("makerparams").getCellByPosition(j, i).CellBackColor=NOFILL
                else:
                    makersheet.getCellRangeByName("makerparams").getCellByPosition(j, i).CellBackColor=GREEN
                    if save:
                        paramstoset.append((model, makerfields[j-1], str(row[j])))

    if len(paramstoset) > 0:
        mp.multisetparams(paramstoset)

def savemakerparams(args):
    checkmakerparams(args, save=True)

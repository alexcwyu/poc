To run the spreadsheet macro:
NOTE that Ubuntu paths here are untested and based on internet search only

LibreOffice python script directory (psd) location is:
 - MacOSX: /Applications/LibreOffice.app/Contents/Resources/Scripts/python
 - Ubuntu: /usr/lib/libreoffice/share/Scripts/python

1. sudo apt-get install libreoffice-script-provider-python
2. Install a python3 environment, pip3 install redis and locate the redis package directory
3. Symlink the redis package into the psd: ln -s <python 3 redis directory> <LibreOffice python script directory>/pythonpath/redis
4. Symlink basisload.py into the psd
5. SSH tunnel into prod redis via: ssh -L 6379:localhost:6379 prod@prod.sensusmarkets.com
6. cd to the psd, then run libreoffice <path to TradeParams.ods>

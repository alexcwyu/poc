import time
import threading
import uno



def refresh():
    oDoc = XSCRIPTCONTEXT.getDocument()
    oSheet = oDoc.CurrentController.ActiveSheet
    oCell = oSheet.getCellByPosition(0,0)
    i = 0
    while hasattr(oDoc, 'calculateAll'):
        oCell.setValue(str(i))
        i += 1
        time.sleep(0.1)

def start_thread():
    t = threading.Thread(target = refresh)
    t.start()


import subprocess
import pandas as pd
import re

hosts = ['www.google.com', 'api.bitfinex.com', 'anxpro.com', 'stream.binance.com', 'www.bitmex.com', 'socket.bittrex.com', 'real.okex.com', '203.126.56.18']

def work(host):
    #get the last line of traceroute
    out = subprocess.check_output(['traceroute', host])
    latency, hops = parse_result(out.split('\n'))
    return {'host':host, 'avglatency':latency, 'hops':hops}


def parse_result(x):
    host_latency = None
    hops = 0
    for i, line in enumerate(x):
        latencies = re.findall(r'\d+\.\d* ms', line)
        ll = []
        for latency in latencies:
            l0 = latency.split()[0]
            ll.append(float(l0))
        if len(ll) > 0:
            hops += 1
            host_latency = sum(ll)/len(ll)
#        if '* * *' in line: #unreachable host
#            if host_latency:
#                host_latency = '{}+'.format(host_latency)
#                hops = '{}+'.format(hops)
    return host_latency, hops
        
if __name__ == '__main__':
    results = []
    for host in hosts:
        results.append(work(host))

    dat = pd.DataFrame(results)

    print dat

    

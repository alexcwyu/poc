import matplotlib
matplotlib.use('Agg')
import pandas as pd
import matplotlib.pyplot as plt


def main():
    dat = pd.read_csv('data/book.quality', names=['time','venue','sym','accuracy'])

    for venue, data in dat.groupby('venue'):
        bysym = data.pivot(index='time',columns='sym',values='accuracy')
        bysym = bysym.ffill()
        bysym.plot()
        plt.savefig('data/{}.png'.format(venue))

if __name__ == '__main__':
    main()

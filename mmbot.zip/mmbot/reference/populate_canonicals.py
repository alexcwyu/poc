import requests as r
import sqlite3
from bs4 import BeautifulSoup

REFERENCE_DB = 'reference.db'

CANONICAL_OVERRIDE = {'bitfinex': [('QTM','qtum'),('DSH','dash'),('IOT','iota'),('QSH','qash'),('IOS','iostoken'),('SNG','singulardtv'),('AIO','aion')],
                      'bitmex': [('XBT','bitcoin')],
                      'bitmextest': [('XBT','bitcoin')],
                      'hitbtc2': [('USD','tether')],
                      'kraken': [('XBT','bitcoin')],
                      'itbit': [('XBT','bitcoin')],
                      'cf': [('XBT','bitcoin')],
                      'bitflyer': [('FX_BTC','bitcoin')]}


def populate_exchange(venue, url):
    print 'venue: {}'.format(venue)
    conn = sqlite3.connect(REFERENCE_DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    resp = r.get(url)
    soup = BeautifulSoup(resp.content, 'html.parser')

    res = c.execute('SELECT * FROM currencies')
    currencies = {}  # maps coinmarketcap_id to a row in currencies table

    for row in res:
        currencies[row['coinmarketcap_id']] = row

    venue_id = c.execute('SELECT id FROM venues '
                         'WHERE name = ?', (venue,)).fetchone()['id']

    insert_set = set()

    for row in soup.find('div', id='markets').find_all('tr')[1:]:
        cells = row.find_all('td')
        coinmarketcap_id = cells[1].a['href'].split('/')[2]
        exchange_symbol = cells[2].a.string.split('/')[0]

        if coinmarketcap_id in currencies and exchange_symbol != currencies[coinmarketcap_id]['ccy']:
            insert_set.add((venue_id, exchange_symbol, coinmarketcap_id))

    for row in insert_set:
        try:
            c.execute('INSERT OR REPLACE INTO canonicals (venue_id, exchange_ccy, canonical_ccy_id) '
                      'VALUES(?,?,?)',
                      (row[0], row[1], currencies[row[2]]['id']))
        except sqlite3.IntegrityError:
            print row[0], row[1], currencies[row[2]]['ccy'], 'already in DB.'

    conn.commit()

def populate_overrides():
    conn = sqlite3.connect(REFERENCE_DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    for venue in CANONICAL_OVERRIDE:
        venue_id = c.execute('SELECT id from venues WHERE name = ?', (venue,)).fetchone()['id']
        for exchange_symbol, cmc_id in CANONICAL_OVERRIDE[venue]:
            try:
                ccy_id = c.execute('SELECT id from currencies where coinmarketcap_id = ?', (cmc_id,)).fetchone()['id']
            except KeyError as ke:
                print ('Cannot find cmc_id {} in DB'.format(cmc_id, 'already in DB.'))
            try:                                         
                c.execute('INSERT OR REPLACE INTO canonicals (venue_id, exchange_ccy, canonical_ccy_id) VALUES(?,?,?)',
                          (venue_id, exchange_symbol, ccy_id,))
            except sqlite3.IntegrityError:
                print '{} {} {} already in DB'.format(venue, exchange_symbol, cmc_id)

    conn.commit()


def main():
    with sqlite3.connect(REFERENCE_DB) as conn:
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        venues = c.execute('SELECT * FROM venues').fetchall()

    for venue in venues:
        if venue['coinmarketcap_url'] is not None:
            populate_exchange(venue['name'], venue['coinmarketcap_url'])

    populate_overrides()

if __name__ == '__main__':
    main()

import requests
import sqlite3
import fixerio
from fixerio import Fixerio

CCY_OVERRIDE = [('IOTA', 'IOTA', 'iota'),
                ('WEUR', 'Waves EUR', 'weur'),
                ('WUSD', 'Waves USD', 'wusd'),
                ('XRB', 'Nano', 'nano'),
                ('LOOM', 'LOOM', 'loom'),
                ('RRT', 'Rrt', 'rrt'),
                ('YYW', 'Yyw', 'yyw'),
                ('MNA', 'Mna', 'mna'),
                ('XID1', 'International Diamond', 'international-diamond')]

#This populates all currencies from coinmarketcap and ecbfx.
#Any manual additions for new coins can be inserted here as well.
def main():
    dbfile = 'reference.db'
    url = 'https://api.coinmarketcap.com/v1/ticker/?limit=0'

    resp = requests.get(url)
    currencies = resp.json()

    conn = sqlite3.connect(dbfile)
    c = conn.cursor()

    for ccy in currencies:
        try:
            c.execute('INSERT OR REPLACE INTO currencies (id, ccy, name, coinmarketcap_id) VALUES ((SELECT id from CURRENCIES WHERE coinmarketcap_id=?), ?, ?, ?)',
                      (ccy['id'], ccy['symbol'], ccy['name'], ccy['id']))
        except Exception as e:
            print e.message, (ccy['symbol'], ccy['name'], ccy['id'])

    fiat_ccy = []
    try:
        ecbfx = Fixerio().latest()
        fiat_ccy = ecbfx['rates'].keys() + [ecbfx['base']]
    except fixerio.exceptions.FixerioException as e:
        fiat_ccy = ['USD', 'HKD', 'EUR', 'JPY']

    for ccy in fiat_ccy:
        try:
            c.execute('INSERT OR REPLACE INTO currencies (id, ccy, name, coinmarketcap_id) VALUES ((SELECT id from CURRENCIES WHERE coinmarketcap_id=?), ?, ?, ?)',
                      (ccy, ccy, ccy, ccy))
        except Exception as e:
            print e.message

    for ccy, name, cmc_id in CCY_OVERRIDE:
        try:
            c.execute('INSERT OR REPLACE INTO currencies (id, ccy, name, coinmarketcap_id) VALUES ((SELECT id from CURRENCIES WHERE coinmarketcap_id=?), ?, ?, ?)',
                      (cmc_id, ccy, name, cmc_id))
        except Exception as e:
            print e.message, ccy

    conn.commit()
    conn.close()


if __name__ == '__main__':
    main()

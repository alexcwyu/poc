import requests as r
import sqlite3
from datetime import datetime
import json
import math


import arrow
from cdecimal import Decimal as D

# base, quote, position_currency and settlement_currency are canonical names
class SymbolsReference(object):
    def __init__(self, name, exchange_name, base, quote, lot, precision, precision_sf, instrument_type,
                 tick, exchange_id_1=None, exchange_id_2 = None, position_ccy=None, settlement_ccy=None, contract_multiplier=None, is_inverse=None,
                 is_quanto=None, maturity=None, last_trading_day=None, settlement_index=None):

        self.name = name
        self.exchange_name = exchange_name
        self.base = base
        self.quote = quote
        self.lot = lot
        self.precision = precision
        self.precision_sf = precision_sf
        self.instrument_type = instrument_type
        self.position_ccy = position_ccy
        self.settlement_ccy = settlement_ccy
        self.contract_multiplier = contract_multiplier
        self.is_inverse = is_inverse
        self.is_quanto = is_quanto
        self.maturity = maturity
        self.settlement_index = settlement_index
        self.tick = tick
        self.exchange_id_1 = exchange_id_1
        self.exchange_id_2 = exchange_id_2
        self.last_trading_day = last_trading_day

    def __repr__(self):
        return '{} {} {}'.format(self.instrument_type, self.name, self.exchange_id_1)

# TODO create function to initialize empty DB


def get_canonicial_dict():
    db_conn = sqlite3.connect('reference.db')
    db_conn.row_factory = sqlite3.Row
    cursor = db_conn.cursor()

    cursor.execute('SELECT venues.name, canonicals.exchange_ccy, currencies.ccy '
                   'FROM canonicals '
                   'INNER JOIN venues on canonicals.venue_id = venues.id '
                   'INNER JOIN currencies ON canonicals.canonical_ccy_id = currencies.id')

    res = dict()

    for row in cursor:
        res[(row['name'], row['exchange_ccy'])] = row['ccy']

    return res


canonicals = get_canonicial_dict()


def get_canonical(venue, ccy):
    ccy = ccy.upper()
    if (venue, ccy) in canonicals:
        return canonicals[(venue, ccy)]
    else:
        return ccy


def get_dp_precision(s):
    """Get the decimal precision of a string like '0.0001' or '1.0'

    :param s:
    :return:
    """

    if type(s) <> str:
        s = str(s)

    splitted = s.split('.')
    if len(splitted) == 1:
        return 0
    else:
        integer = splitted[0]
        fractional = splitted[1]

        if '1' in integer:
            return 0
        else:
            return len(fractional.split('1')[0]) + 1


def anxpro():
    resp = r.get('https://anxpro.com/api/3/currencyStatic')
    data = resp.json()

    currency_pairs = data['currencyStatic']['currencyPairs']
    currencies = data['currencyStatic']['currencies']

    # https://anxv3.docs.apiary.io/reference/trading/ordernew
    symbols = []

    for id, pair_info in currency_pairs.iteritems():
        base = get_canonical('anxpro', pair_info['tradedCcy'])
        quote = get_canonical('anxpro', pair_info['settlementCcy'])

        var = SymbolsReference(name=base + '/' + quote,
                               exchange_name=id,
                               base=base,
                               quote=quote,
                               lot=str(currencies[pair_info['tradedCcy']]['minOrderSize']),
                               precision={'price': pair_info['priceDecimals'],
                                          'amount': 8},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(D(10)**(D(-1) * D(pair_info['priceDecimals']))))

        symbols.append(var)

    return 'anxpro', symbols


def binance():
    resp = r.get('https://api.binance.com/api/v1/exchangeInfo')
    data = resp.json()['symbols']

    symbols = []

    for pair in data:
        filters = pair['filters']
        lot_filter = filter(lambda x: x['filterType'] == 'LOT_SIZE', filters)[0]
        price_filter = filter(lambda x: x['filterType'] == 'PRICE_FILTER', filters)[0]

        base = get_canonical('binance', pair['baseAsset'])
        quote = get_canonical('binance', pair['quoteAsset'])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['symbol'],
                               base=base,
                               quote=quote,
                               lot=str(lot_filter['stepSize']),
                               precision={'price': get_dp_precision(price_filter['tickSize']),
                                          'amount': get_dp_precision(lot_filter['stepSize'])},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = price_filter['tickSize'])

        symbols.append(res)

    return 'binance', symbols


def bitstamp():
    resp = r.get('https://www.bitstamp.net/api/v2/trading-pairs-info/')
    data = resp.json()

    symbols = []

    for pair in data:
        base = get_canonical('bitstamp', pair['name'].split('/')[0])
        quote = get_canonical('bitstamp', pair['name'].split('/')[1])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['url_symbol'],
                               base=base,
                               quote=quote,
                               lot=str('0.' + '0' * (pair['base_decimals'] - 1) + '1'),
                               precision={'price': pair['counter_decimals'],
                                          'amount': pair['base_decimals']},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(D(10)**(D(-1)*D(pair['counter_decimals']))))

        symbols.append(res)

    return 'bitstamp', symbols


def bittrex():
    resp = r.get('https://bittrex.com/api/v1.1/public/getmarkets')
    data = resp.json()['result']

    symbols = []

    for pair in data:
        base = get_canonical('bittrex', pair['MarketCurrency'])
        quote = get_canonical('bittrex', pair['BaseCurrency'])
        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['MarketName'],
                               base=base,
                               quote=quote,
                               lot=str(D(10)**D(-8)),
                               precision={'price': 8,
                                          'amount': 8},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick=str(D(10)**D(-8)))

        symbols.append(res)

    return 'bittrex', symbols


def gdax():
    resp = r.get('https://api.gdax.com/products')
    data = resp.json()

    symbols = []

    for pair in data:
        base = get_canonical('gdax', pair['base_currency'])
        quote = get_canonical('gdax', pair['quote_currency'])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['id'],
                               base=base,
                               quote=quote,
                               lot=pair['base_min_size'],
                               precision={'price': get_dp_precision(pair['quote_increment']),
                                          'amount': 8},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = pair['quote_increment'])

        symbols.append(res)

    return 'gdax', symbols


def bitfinex():
    resp = r.get('https://api.bitfinex.com/v1/symbols_details')
    data = resp.json()

    symbols = []

    for pair in data:
        if len(pair['pair']) != 6:
            print 'Length of {0} is not 6.  Skipping'.format(pair['pair'])
            continue

        base = get_canonical('bitfinex', pair['pair'][0:3].upper())
        quote = get_canonical('bitfinex', pair['pair'][-3:].upper())

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['pair'],
                               base=base,
                               quote=quote,
                               lot=pair['minimum_order_size'],
                               precision={'price': None,
                                          'amount': 4},
                               precision_sf={'price': pair['price_precision'],
                                             'amount': None},
                               instrument_type='spot',
                               tick=None)

        symbols.append(res)

        res2 = SymbolsReference(name=base + quote,
                               exchange_name=base + quote,
                               base=base,
                               quote=quote,
                               lot=pair['minimum_order_size'],
                               precision={'price': None,
                                          'amount': 4},
                               precision_sf={'price': pair['price_precision'],
                                             'amount': None},
                               instrument_type='swap',
                               tick=None,  
                               position_ccy=base,
                               settlement_ccy=quote,
                               contract_multiplier=1,
                               is_inverse=False,
                               is_quanto=False)

        symbols.append(res2)
    return 'bitfinex', symbols


def kraken():
    resp = r.get('https://api.kraken.com/0/public/AssetPairs')
    data = resp.json()['result']

    resp = r.get('https://api.kraken.com/0/public/Assets')
    assets = resp.json()['result']

    resp = r.get('https://support.kraken.com/hc/en-us/articles/205893708-What-is-the-minimum-order-size-')
    #soup = BeautifulSoup(resp.content, 'html.parser')

    symbols = []

    for pair_name, pair in data.items():

        base = get_canonical('kraken', assets[pair['base']]['altname'])
        quote = get_canonical('kraken', assets[pair['quote']]['altname'])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair_name,
                               base=base,
                               quote=quote,
                               lot=None,  # TODO scrape with beautifulsoup
                               precision={'price': pair['pair_decimals'],
                                          'amount': pair['lot_decimals']},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick=None)

        symbols.append(res)

    return 'kraken', symbols

def btcbox():
    venue = 'btcbox'
    syms = ['btc_jpy', 'ltc_jpy', 'eth_jpy', 'bch_jpy']
    symbols = []

    for pair in syms:
        base, quote = pair.upper().split('_')

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair,
                               base=base,
                               quote=quote,
                               lot=str(0.0001),
                               precision={'price': int(0),
                                          'amount': int(4)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(1))

        symbols.append(res)

    return venue, symbols

def bitflyer():
    venue = 'bitflyer'
    resp = r.get('https://api.bitflyer.jp/v1/getmarkets')
    data = json.loads(resp.content)
    symbols = []

    for item in data:
        name = item['product_code']
        names = name.split('_')

        expiry = None
        isinverse = False
        isquanto = False
        # must be a future contract
        if len(names) == 1:
            pcode = names[0]
            base = pcode[0:3]
            quote = pcode[3:6]
            instype = 'future'
            expiry = datetime.strptime(pcode[6:], '%d%b%Y')
        # spot pairs
        elif len(names) == 2:
            base = names[0]
            quote = names[1]
            instype = 'spot'
        # swap
        else:
            base = '{}'.format(names[1])
            quote = names[2]
            instype = 'swap'

        if base == 'BTC':
            ticksize = 1
            lotsize = 0.001
            precision_price = 1
            precision_amount = 0
        else:
            ticksize = 0.00001
            lotsize = 0.01
            precision_price = 5
            precision_amount = 0

        if expiry is None:
            maturity = None
        else:
            maturity = arrow.get(expiry).format('YYYY-MM-DDTHH:mm:ss') + 'Z'
            
        res = SymbolsReference(name=name,
                               exchange_name=name,
                               base=base,
                               quote=quote,
                               lot=lotsize,
                               precision={'price': precision_price,
                                          'amount': precision_amount},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type=instype,
                               tick=ticksize,
                               position_ccy='JPY',
                               settlement_ccy='JPY',
                               contract_multiplier=1,
                               is_inverse=isinverse,
                               is_quanto=isquanto,
                               maturity=maturity)

        symbols.append(res)

    return venue, symbols


def bitmex():
    resp = r.get('https://www.bitmex.com/api/v1/instrument/active')
    data = json.loads(resp.content, parse_float=D)
    symbols = []

    for pair in data:
        tick_size = '{0:f}'.format(pair['tickSize'])

        try:
            precision_price = len(tick_size.split('.')[1])
        except IndexError:
            precision_price = 0

        try:
            precision_amount = len(str(pair['lotSize']).split('.')[1])
        except IndexError:
            precision_amount = 0

        base = get_canonical('bitmex', pair['underlying'])
        quote = get_canonical('bitmex', pair['quoteCurrency'])

        # ignoring options
        if pair['typ'] in ['OPECCS','OCECCS']:
            continue

        if pair['expiry'] is None:
            maturity = None
        else:
            maturity = arrow.get(pair['expiry']).format('YYYY-MM-DDTHH:mm:ss') + 'Z'

        res = SymbolsReference(name=pair['symbol'],
                               exchange_name=pair['symbol'],
                               base=base,
                               quote=quote,
                               lot=pair['lotSize'],
                               precision={'price': precision_price,
                                          'amount': precision_amount},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='swap' if pair['expiry'] is None else 'future',
                               tick=tick_size,
                               position_ccy=get_canonical('bitmex', pair['positionCurrency']),
                               settlement_ccy='BTC',
                               contract_multiplier=abs(pair['multiplier'] / 100000000),
                               is_inverse=pair['isInverse'],
                               is_quanto=pair['isQuanto'],
                               maturity=maturity,
                               settlement_index=pair['referenceSymbol'])

        symbols.append(res)

    return 'bitmex', symbols

def bitmextest():
    venue = 'bitmextest'
    resp = r.get('https://www.bitmex.com/api/v1/instrument/active')
    data = json.loads(resp.content, parse_float=D)
    symbols = []

    for pair in data:
        tick_size = '{0:f}'.format(pair['tickSize'])

        try:
            precision_price = len(tick_size.split('.')[1])
        except IndexError:
            precision_price = 0

        try:
            precision_amount = len(str(pair['lotSize']).split('.')[1])
        except IndexError:
            precision_amount = 0

        base = get_canonical(venue, pair['underlying'])
        quote = get_canonical(venue, pair['quoteCurrency'])

        # ignoring options
        if pair['typ'] in ['OPECCS','OCECCS']:
            continue

        if pair['expiry'] is None:
            maturity=None
        else:
            maturity = arrow.get(pair['expiry']).format('YYYY-MM-DDTHH:mm:ss') + 'Z'

        #NOTE: Hackiness because XBJH18 was returning blank position currency in testnet
        positionCcy = pair['positionCurrency']
        if pair['positionCurrency'] == '':
            positionCcy = quote
            
        res = SymbolsReference(name=pair['symbol'],
                               exchange_name=pair['symbol'],
                               base=base,
                               quote=quote,
                               lot=pair['lotSize'],
                               precision={'price': precision_price,
                                          'amount': precision_amount},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='swap' if pair['expiry'] is None else 'future',
                               tick=tick_size,
                               position_ccy=positionCcy,
                               settlement_ccy='BTC',
                               contract_multiplier=abs(pair['multiplier'] / 100000000),
                               is_inverse=pair['isInverse'],
                               is_quanto=pair['isQuanto'],
                               maturity=maturity,
                               settlement_index=pair['referenceSymbol'])

        symbols.append(res)

    return venue, symbols

def bitz():
    venue = 'bit-z'
    symbols = []

    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    resp = r.get('https://www.bit-z.com/api_v1/tickerall', headers=headers)
    data = json.loads(resp.content, parse_float=D, parse_int=D)

    for symbol in data['data'].keys():
        base, quote = symbol.upper().split('_')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=symbol,
                               base=base,
                               quote=quote,
                               lot=str(0.0001),
                               precision={'price': int(8),
                                          'amount': int(4)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(0.00000001))

        symbols.append(res)

    return venue, symbols


def okexspot():
    venue = 'okexspot'
    symbols = []

    resp = r.get('https://www.okex.com/api/spot/v3/products')
    data = json.loads(resp.content, parse_float=D, parse_int=D)

    for info in data:
        pair = info['product_id']
        base, quote = pair.split('-')
        exchange_name = '{}_{}'.format(base.lower(), quote.lower())
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        lotsize = str(info['base_min_size'])
        ticksize = str(info['quote_increment'])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=exchange_name,
                               base=base,
                               quote=quote,
                               lot=lotsize,
                               precision={'price': None,
                                          'amount': None},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick=ticksize)

        symbols.append(res)

    return venue, symbols


def okexfut():
    venue = 'okexfut'
    symbols = []

    ccys = ['BCH', 'BTC', 'BTG', 'EOS', 'ETC', 'ETH', 'LTC', 'XRP']
    THIS_WEEK = 'this_week'
    NEXT_WEEK = 'next_week'
    QUARTER = 'quarter'
    timeframes = [THIS_WEEK, NEXT_WEEK, QUARTER]

    expiries = [('20180727', THIS_WEEK),
                ('20180803', NEXT_WEEK),
                ('20180928', QUARTER)]

    for base in ccys:

        quote='USD'
        data_symbol = '{}_{}'.format(base, quote).lower()
        canonicalbase = get_canonical(venue, base)
        index='OKEX{}'.format(canonicalbase)

        lot_size = 1
        precision_price = 2 if base == 'BTC' else 3
        contract_multiplier = 100 if base == 'BTC' else 10

        # future
        for ymd, timeframe in expiries:

            maturity = arrow.get(ymd + ' 08:00', 'YYYYMMDD HH:mm')

            res = SymbolsReference(name=canonicalbase + ymd,
                                   exchange_name=base+ymd[-4:],
                                   base=canonicalbase,
                                   quote=quote,
                                   lot=lot_size,
                                   precision={'price': precision_price,
                                              'amount': 8},
                                   precision_sf={'price': None,
                                                 'amount': None},
                                   instrument_type='future',
                                   position_ccy='USD',
                                   settlement_ccy=canonicalbase,
                                   contract_multiplier=contract_multiplier,
                                   is_inverse=True,
                                   is_quanto=False,
                                   maturity=maturity.format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                                   settlement_index=index,
                                   tick=str(D(10)**(D(-1)*D(precision_price))),
                                   exchange_id_1="{}:{}".format(data_symbol, timeframe),
                                   exchange_id_2=None)

            symbols.append(res)

    return 'okexfut', symbols

def poloniex():
    venue = 'poloniex'
    resp = r.get('https://poloniex.com/public?command=returnTicker')
    data = json.loads(resp.content)
    symbols = []

    for pair, v in data.items():
        quote, base = pair.upper().split('_')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair,
                               base=base,
                               quote=quote,
                               lot=None,
                               precision={'price': 8,
                                          'amount': 8},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(D(10)**D(-8)))
        symbols.append(res)

    return venue, symbols

def huobipro():
    venue = 'huobipro'
    resp = r.get('https://api.huobi.pro/v1/common/symbols')
    data = json.loads(resp.content)['data']

    symbols = []
    for item in data:
        base = get_canonical(venue, item['base-currency'])
        quote = get_canonical(venue, item['quote-currency'])
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)
        px_prec = str(item['price-precision'])
        qty_prec = str(item['amount-precision'])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=base + '/' + quote,
                               base=base,
                               quote=quote,
                               lot=None,
                               precision={'price': px_prec,
                                          'amount': qty_prec},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(D(10)**(D(-1)*D(px_prec))))

        symbols.append(res)

    return venue, symbols

def kucoin():
    resp = r.get('https://api.kucoin.com/v1/market/open/coins')
    data = json.loads(resp.content)['data']
    price_precision = {}

    for item in data:
        coin = get_canonical('kucoin', item['coin'])
        price_precision[coin] = item['tradePrecision']

    resp = r.get('https://api.kucoin.com/v1/market/open/symbols')
    data = json.loads(resp.content)['data']
    symbols = []

    for pair in data:
        base = get_canonical('kucoin', pair['coinType'])
        quote = get_canonical('kucoin', pair['coinTypePair'])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['symbol'],
                               base=base,
                               quote=quote,
                               lot=str(D(10)**(D(-1)*D(price_precision[base]))),
                               precision={'price': price_precision[quote],
                                          'amount': price_precision[base]},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(D(10)**(D(-1)*D(price_precision[quote]))))

        symbols.append(res)

    return 'kucoin', symbols

def hitbtc2():
    resp = r.get('https://api.hitbtc.com/api/2/public/currency')
    data = json.loads(resp.content)
    delisted = {}

    for item in data:
        coin = item['id']
        delisted[coin] = item['delisted']

    resp = r.get('https://api.hitbtc.com/api/2/public/symbol')
    data = json.loads(resp.content)
    symbols = []

    venue = 'hitbtc2'
    for pair in data:
        base = get_canonical(venue, pair['baseCurrency'])
        quote = get_canonical(venue, pair['quoteCurrency'])
        if quote == 'USD': quote = 'USDT'
        lotsize = pair['quantityIncrement']
        ticksize = pair['tickSize']
        takerfee = pair['takeLiquidityRate']
        makerfee = pair['provideLiquidityRate']
        feeccy = get_canonical(venue, pair['feeCurrency'])

        amt = D(lotsize)
        tup = amt.as_tuple()
        amt_prec = tup.exponent
        if amt_prec >= 0:
            amt_prec = 0
        else:
            amt_prec = -amt_prec

        px = D(ticksize)
        tup = px.as_tuple()
        px_prec = tup.exponent
        if px_prec >= 0:
            px_prec = 0
        else:
            px_prec = -px_prec

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['id'],
                               base=base,
                               quote=quote,
                               lot=lotsize,
                               precision={'price': int(px_prec),
                                          'amount': int(amt_prec)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = ticksize)

        symbols.append(res)

    return venue, symbols

def gateio():
    venue = 'gateio'
    symbols = []

    resp = r.get('https://data.gate.io/api2/1/marketinfo')
    data = json.loads(resp.content, parse_float=D, parse_int=D)

    for symbol in data['pairs']:
        for pair, info in symbol.items():
            base, quote = pair.upper().split('_')
            base = get_canonical(venue, base)
            quote = get_canonical(venue, quote)

            dec_pl = info['decimal_places']
            min_amount = info['min_amount']
            fee = info['fee']

            lotsize = min_amount
            ticksize = str(D(10)**(D(-1)*dec_pl))
            takerfee = fee
            makerfee = fee
            feeccy = quote


            amt = D(min_amount)
            tup = amt.as_tuple()
            amt_prec = tup.exponent
            if amt_prec >= 0:
                amt_prec = 0
            else:
                amt_prec = -amt_prec

            res = SymbolsReference(name=base + '/' + quote,
                                   exchange_name=pair,
                                   base=base,
                                   quote=quote,
                                   lot=str(lotsize),
                                   precision={'price': int(dec_pl),
                                              'amount': int(amt_prec)},
                                   precision_sf={'price': None,
                                                 'amount': None},
                                   instrument_type='spot',
                                   tick = str(ticksize))

            symbols.append(res)

    return venue, symbols

def lbank():
    venue = 'lbank'
    symbols = []

    resp = r.get('https://api.lbank.info/v1/ticker.do?symbol=all')
    data = json.loads(resp.content, parse_float=D, parse_int=D)

    for d in data:
        symbol = d['symbol']

        base, quote = symbol.upper().split('_')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        priceprec = 2 if quote == 'USDT' else 8
        ticksize = 0.01 if quote == 'USDT' else 0.00000001

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=symbol,
                               base=base,
                               quote=quote,
                               lot=str(0.001),
                               precision={'price': int(priceprec),
                                          'amount': int(3)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(ticksize))

        symbols.append(res)

    return venue, symbols

def default_venue(venue, data):
    symbols = []

    for pair, info in data['pairs'].items():
        base, quote = pair.upper().split('/')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        dec_pl = info['decimal_places']
        tick = info['tick']
        fee = info['fee']

        lotsize = str(D(10)**(D(-1)*dec_pl))
        ticksize = str(tick)
        takerfee = fee
        makerfee = fee
        feeccy = quote

        tup = tick.as_tuple()
        px_prec = tup.exponent
        if px_prec >= 0:
            px_prec = 0
        else:
            px_prec = -px_prec

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair,
                               base=base,
                               quote=quote,
                               lot=str(lotsize),
                               precision={'price': int(px_prec),
                                          'amount': int(dec_pl)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(ticksize))

        symbols.append(res)
                     
    return venue, symbols

def coinexchange():
    venue = 'coinexchange'
    symbols = []

    resp = r.get('https://www.coinexchange.io/api/v1/getmarkets')
    data = json.loads(resp.content, parse_float=D, parse_int=D)
    #print data
    for symbol in data['result']:
        base = get_canonical('coinexchange', symbol['MarketAssetCode'])
        quote = get_canonical('coinexchange', symbol['BaseCurrencyCode'])

        dec_pl = D(8)
        lotsize = str(D(10)**(D(-1)*dec_pl))
        ticksize = str(D(10)**(D(-1)*dec_pl))
        feeccy = quote

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name= base + '/' + quote,
                               base=base,
                               quote=quote,
                               lot=str(lotsize),
                               precision={'price': int(dec_pl),
                                          'amount': int(dec_pl)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(ticksize))

        symbols.append(res)

    return venue, symbols

def cryptopia():
    venue = 'cryptopia'
    symbols = []

    resp = r.get('https://www.cryptopia.co.nz/api/GetTradePairs')
    data = json.loads(resp.content, parse_float=D, parse_int=D)
    #print data
    symlist = []
    if len(data) > 0:
        symlist = data['Data']
    for symbol in symlist:
        base = get_canonical(venue, symbol['Symbol'])
        quote = get_canonical(venue, symbol['BaseSymbol'])

        dec_pl = D(8)
        lotsize = str(D(10)**(D(-1)*dec_pl))
        ticksize = str(D(10)**(D(-1)*dec_pl))
        feeccy = quote

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name= base + '/' + quote,
                               base=base,
                               quote=quote,
                               lot=str(lotsize),
                               precision={'price': int(dec_pl),
                                          'amount': int(dec_pl)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(ticksize))

        symbols.append(res)

    return venue, symbols

def fixmaker():
    #'BTC/USD','BTC/JPY','XRP/USD','XRP/JPY','ETH/JPY', 'BCH/JPY', 'LTC/JPY', 'EOS/JPY','ADA/JPY'
    data = {'pairs':{'ADA/JPY': {'decimal_places':D(2),
                                 'tick': D("0.01"),
                                 'fee': D("0.1")},
                     'ADA/USD': {'decimal_places':D(4),
                                 'tick': D("0.0001"),
                                 'fee': D("0.1")},
                     'BCH/JPY': {'decimal_places':D(2),
                                  'tick': D("1"),
                                  'fee': D("0.1")},
                     'BCH/USD': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'BTC/JPY': {'decimal_places':D(2),
                                  'tick': D("1"),
                                  'fee': D("0.1")},
                     'BTC/USD': {'decimal_places':D(0),
                                 'tick': D("1"),
                                 'fee': D("0.1")},
                     'DASH/JPY': {'decimal_places':D(2),
                                  'tick': D("1"),
                                  'fee': D("0.1")},
                     'DASH/USD': {'decimal_places':D(2),
                                  'tick': D(".01"),
                                  'fee': D("0.1")},
                     'EOS/JPY': {'decimal_places':D(2),
                                  'tick': D("0.1"),
                                  'fee': D("0.1")},
                     'EOS/USD': {'decimal_places':D(3),
                                  'tick': D("0.001"),
                                  'fee': D("0.1")},
                     'ETH/JPY': {'decimal_places':D(2),
                                  'tick': D("1"),
                                  'fee': D("0.1")},
                     'ETH/USD': {'decimal_places':D(1),
                                  'tick': D("0.1"),
                                  'fee': D("0.1")},
                     'ETH/BTC': {'decimal_places':D(4),
                                 'tick': D('0.0001'),
                                 'fee': D('0.1')},
                     'ETC/JPY': {'decimal_places':D(2),
                                  'tick': D("0.1"),
                                  'fee': D("0.1")},
                     'ETC/USD': {'decimal_places':D(3),
                                  'tick': D("0.001"),
                                  'fee': D("0.1")},
                     'EUR/USD': {'decimal_places':D(4),
                                 'tick': D('0.0001'),
                                 'fee': D('0')},
                     'IOTA/JPY': {'decimal_places':D(2),
                                  'tick': D("0.001"),
                                  'fee': D("0.1")},
                     'IOTA/USD': {'decimal_places':D(5),
                                  'tick': D("0.00001"),
                                  'fee': D("0.1")},
                     'LTC/JPY': {'decimal_places':D(2),
                                  'tick': D("1"),
                                  'fee': D("0.1")},
                     'LTC/USD': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'NEO/JPY': {'decimal_places':D(2),
                                  'tick': D("1"),
                                  'fee': D("0.1")},
                     'NEO/USD': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'QTUM/JPY': {'decimal_places':D(2),
                                  'tick': D("1"),
                                  'fee': D("0.1")},
                     'QTUM/USD': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'XEM/JPY': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'XEM/USD': {'decimal_places':D(4),
                                  'tick': D("0.0001"),
                                  'fee': D("0.1")},
                     'XLM/JPY': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'XLM/USD': {'decimal_places':D(4),
                                  'tick': D("0.0001"),
                                  'fee': D("0.1")},
                     'XMR/JPY': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'XMR/USD': {'decimal_places':D(4),
                                  'tick': D("0.0001"),
                                  'fee': D("0.1")},
                     'XRP/JPY': {'decimal_places':D(2),
                                  'tick': D("0.01"),
                                  'fee': D("0.1")},
                     'XRP/USD': {'decimal_places':D(4),
                                  'tick': D("0.0001"),
                                  'fee': D("0.1")},
                     }
            }

    return default_venue('fixmaker', data)


def liqui():
    venue = 'liqui'
    symbols = []

    resp = r.get('https://api.liqui.io/api/3/info')
    data = json.loads(resp.content, parse_float=D, parse_int=D)
        
    for pair, info in data[u'pairs'].items():
        base, quote = pair.upper().split('_')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        dec_pl = info['decimal_places']
        min_amount = info['min_amount']
        fee = info['fee']

        lotsize = min_amount
        ticksize = str(D(10)**(D(-1)*dec_pl))
        takerfee = fee
        makerfee = fee
        feeccy = quote


        amt = D(min_amount)
        tup = amt.as_tuple()
        amt_prec = tup.exponent
        if amt_prec >= 0:
            amt_prec = 0
        else:
            amt_prec = -amt_prec

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair,
                               base=base,
                               quote=quote,
                               lot=str(lotsize),
                               precision={'price': int(dec_pl),
                                          'amount': int(amt_prec)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(ticksize))
        
        symbols.append(res)

    return venue, symbols

def itbit():
    venue = 'itbit'
    symbols = []
    pair = 'XBTUSD'
    base = 'BTC'
    quote = 'USD'
    res = SymbolsReference(name=base + '/' + quote,
                           exchange_name=pair,
                           base=base,
                           quote=quote,
                           lot=str(0.0001),
                           precision={'price': int(2),
                                      'amount': int(4)},
                           precision_sf={'price': None,
                                         'amount': None},
                           instrument_type='spot',
                           tick=str(0.01))

    symbols.append(res)
    return venue, symbols

def wex():
    venue = 'wex'
    symbols = []

    resp = r.get('https://wex.nz/api/3/info')
    data = json.loads(resp.content, parse_float=D, parse_int=D)


    for symbol, info in data['pairs'].items():
        base, quote = symbol.upper().split('_')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        minprice = info['min_price']
        prec = D(get_dp_precision(minprice))
        decpl = D(info['decimal_places'])

        pxprec = max(prec, decpl)
        ticksize = D(10) ** (D(-1) * pxprec)

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=symbol,
                               base=base,
                               quote=quote,
                               lot=str(0.00000001),
                               precision={'price': str(pxprec),
                                          'amount': str(8)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick=str(ticksize))

        symbols.append(res)

    return venue, symbols


def yobit():
    venue = 'yobit'
    symbols = []

    resp = r.get('https://yobit.net/api/3/info')
    data = json.loads(resp.content, parse_float=D, parse_int=D)['pairs']
    
    for symbol in data.keys():
        base, quote = symbol.upper().split('_')

        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        prec = D(data[symbol]['decimal_places'])
        lotsize = D(data[symbol]['min_amount'])
        ticksize = D(data[symbol]['min_price'])

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=symbol,
                               base=base,
                               quote=quote,
                               lot=str(lotsize),
                               precision={'price': int(prec),
                                          'amount': int(prec)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(ticksize))

        symbols.append(res)

    return venue, symbols

def zb():
    venue = 'zb'
    symbols = []

    resp = r.get('http://api.zb.com/data/v1/markets')
    data = json.loads(resp.content, parse_float=D, parse_int=D)

    for symbol in data.keys():
        base, quote = symbol.upper().split('_')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        amtprec = D(data[symbol]['amountScale'])
        pxprec = D(data[symbol]['priceScale'])
        lotsize = D(10) ** (D(-1) * amtprec)
        ticksize = D(10) ** (D(-1) * pxprec)

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=symbol,
                               base=base,
                               quote=quote,
                               lot=str(lotsize),
                               precision={'price': int(pxprec),
                                          'amount': int(amtprec)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = str(ticksize))

        symbols.append(res)

    return venue, symbols

def deribit():
    venue = 'deribit'
    symbols = []

    resp = r.get('https://www.deribit.com/api/v1/public/getinstruments')
    data = json.loads(resp.content, parse_float=D, parse_int=D)
    for symbol in data['result']:
        if symbol['kind'] in ['future', 'option']:

            name = symbol['instrumentName']
            base = get_canonical(venue, symbol['baseCurrency'])
            quote = get_canonical(venue, symbol['currency'])
            minsize = D(symbol['minTradeSize'])
            amtprec = D(1)
            pxprec = D(symbol['pricePrecision'])
            lotsize = minsize
            ticksize = D(symbol['tickSize'])
            contract_multiplier = 10 if symbol['kind'] == 'future' else 1
            maturity = arrow.get(symbol['expiration'], 'YYYY-MM-DD HH:mm:ss')
            index="DeribitBTCUSD"

            res = SymbolsReference(name=name,
                                   exchange_name=name,
                                   base=base,
                                   quote=quote,
                                   lot=str(lotsize),
                                   precision={'price': int(pxprec),
                                              'amount': int(amtprec)},
                                   precision_sf={'price': None,
                                                 'amount': None},
                                   instrument_type='future',
                                   position_ccy='USD',
                                   settlement_ccy=base,
                                   contract_multiplier=contract_multiplier,
                                   is_inverse=True,
                                   is_quanto=False,
                                   maturity=maturity.format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                                   settlement_index=index,
                                   tick = str(ticksize),
                                   exchange_id_1=symbol['settlement'],
                                   exchange_id_2=None)

            symbols.append(res)

    return venue, symbols


def cf():
    venue = 'cf'
    symbols = []

    resp = r.get('https://www.cryptofacilities.com/derivatives/api/v3/instruments')
    data = json.loads(resp.content, parse_float=D)#, parse_int=D)
    if data['result'] == 'success':
        for symbol in data['instruments']:
            name = symbol['symbol'].upper()
            type_ = symbol['type'] #futures_inverse, futures_vanilla, turbo_inverse, spot index, volatility index
            if symbol['tradeable']: #ignore indices for now
                futsym = name.split('_')[1]
                assert len(futsym) == 6 #expecting CCYCCY
                base = get_canonical(venue, futsym[:3])
                quote = get_canonical(venue, futsym[-3:])

                #amtprec = D(1)
                #pxprec = D(symbol['pricePrecision'])
                #ticksize = D(10) ** (D(-1) * pxprec)
                #contract_multiplier = 50
                
                if type_ in ['futures_inverse', 'futures_vanilla']:
                    isinverse = type_ == 'futures_inverse'
                    
                    maturity = arrow.get(symbol['lastTradingTime'], 'YYYY-MM-DDTHH:mm:ss.Z')
                    ticksize = symbol['tickSize']
                    lotsize = symbol['contractSize']
                    index=symbol['underlying']
                    minsize = lotsize

                    print base, quote, futsym, maturity, ticksize, lotsize, index

                    res = SymbolsReference(name=name,
                                           exchange_name=name,
                                           base=base,
                                           quote=quote,
                                           lot=str(lotsize),
                                           precision={'price': None,
                                                      'amount': None},
                                           precision_sf={'price': None,
                                                         'amount': None},
                                           instrument_type='future',
                                           position_ccy=quote,
                                           settlement_ccy=base if isinverse else quote,
                                           contract_multiplier=str(1),
                                           is_inverse=isinverse,
                                           is_quanto=False,
                                           maturity=maturity.format('YYYY-MM-DDTHH:mm:ss') + 'Z',
                                           settlement_index=index,
                                           tick = str(ticksize),
                                           exchange_id_1=None,
                                           exchange_id_2=None)

                    symbols.append(res)
                    
                else:
                    print name, type_, 'Not recognized'
                    continue

    return venue, symbols

def bitforex():
    venue = 'bitforex'
    symbols = []

    resp = r.get('https://www.bitforex.com/api/v1/market/symbols')
    data = json.loads(resp.content, parse_float=D, parse_int=D)['data']

    for info in data:
        pair = info['symbol']
        prefix, quote, base = pair.upper().split('-')
        base = get_canonical(venue, base)
        quote = get_canonical(venue, quote)

        px_prec = str(info['pricePrecision'])
        qty_prec = str(info['amountPrecision'])
        lotsize = str(D(10)**(D(-1)*D(qty_prec)))
        ticksize = str(D(10)**(D(-1)*D(px_prec)))

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair,
                               base=base,
                               quote=quote,
                               lot=lotsize,
                               precision={'price': px_prec,
                                          'amount': qty_prec},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = ticksize)

        symbols.append(res)

    return venue, symbols

def coinmex():
    resp = r.get('https://www.coinmex.com/api/v1/spot/public/products')
    data = json.loads(resp.content)
    symbols = []

    venue = 'coinmex'
    for pair in data:
        base = get_canonical(venue, pair['baseCurrency'])
        quote = get_canonical(venue, pair['quoteCurrency'])
        if quote == 'USDT':
            px_prec = D(4)
        else:
            px_prec = D(8)

        amt_prec = D(pair['quoteIncrement'])
        #This hackiness is because the BCH symbol listed 0 as the precision even though it isn't
        if amt_prec == D(0):
            amt_prec = D(8)
        elif amt_prec < D(1):
            #This hackiness is for 0.0001 quoteIncrement for GNX/ETH
            amt_prec = D(-1)*D(int(math.log10(float(amt_prec))))
        lotsize = str(D(10)**(D(-1)*amt_prec))
        ticksize = str(D(10)**(D(-1)*px_prec))

        res = SymbolsReference(name=base + '/' + quote,
                               exchange_name=pair['code'],
                               base=base,
                               quote=quote,
                               lot=lotsize,
                               precision={'price': int(px_prec),
                                          'amount': int(amt_prec)},
                               precision_sf={'price': None,
                                             'amount': None},
                               instrument_type='spot',
                               tick = ticksize)

        symbols.append(res)

    return venue, symbols


VENUES = [anxpro,
          binance,
          bitstamp,
          bittrex,
          bitfinex,
          bitforex,
          bitmex,
          bitmextest,
          coinexchange,
          coinmex,
          deribit,
          cf,
          gateio,
          gdax,
          kraken,
          kucoin,
          hitbtc2,
          okexspot,
          okexfut,
          poloniex,
          huobipro,
          bitflyer,
          lbank,
          bitz,
          btcbox,
          wex,
          zb,
          itbit,
          yobit,
          cryptopia,
          liqui,
          fixmaker]

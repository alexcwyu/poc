# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, April 2018

"""Static data: big dict of precision, max/min size, fees, any limits etc. by exchange
For each exchange:
- dict of pairs (canonical format)
- dict of fees

Pairs:

-id: Pair in exchange format
-symbol: Pair in canonical format
-base: base ccy in canonical format
-quote: quote ccy in canonical format

-precision: dict of:
    -price: price precision amount (max digits after decimal point)
    -amount: size precision amount (max digits after decimal point)

-tick: minimum tick size for this pair (to be cast into Decimal). If this is not supplied, getticksize() should return 10^(-prec_price) for the pair 
-lot: minimum lot size for this pair (to be cast into Decimal). If this is not supplied, getticksize() should return 10^(-prec_amount) for the pair

-limits: min and max amounts for various items (not yet set in stone)

Fees:
-maker fee (to be cast into Decimal)
-taker fee (to be cast into Decimal)
-fee type ('fixed' or 'bps')
-fee ccy ('base' or 'quote')

"""
import sqlite3
import datetime
from collections import defaultdict
from cdecimal import Decimal
import time
import mmbot.utils as utils
import os
from sortedcontainers import SortedSet

REFERENCE_DB = os.environ['REFERENCEDB']
FIATCCYS = ['USD', 'GBP', 'JPY', 'HKD', 'AUD', 'SGD', 'EUR']

class Symbols(object):

    SPOT = 'spot'
    FUTURE = 'future'
    OPTION = 'option'
    CALL = 'call'
    PUT = 'put'
    SWAP = 'swap'
    INDEX = 'index'
    
    def __init__(self, db=REFERENCE_DB):
        self.db = db

        self.VENUES = defaultdict()
        self.INSTRUMENT_TYPES = defaultdict()
        self.CURRENCIES = defaultdict()
        self.CCYNAMES = []
        self.SYMBOLS = defaultdict()
        self.CONTRACT_PARAMS = defaultdict()
        self.CANONICALS = defaultdict()
        self.ALIAS = defaultdict(dict)

        #TODO: refactor fees into db
        self.FEES = {
            'anxpro': {'maker': '0', 'taker': '0', 'type': 'bps', 'ccy': 'base'},
            'binance': {'maker': '5', 'taker': '5', 'type': 'bps', 'ccy': 'BNB'},
            'bittrex': {'maker': '35', 'taker': '35', 'type': 'bps', 'ccy': 'base'}
            }

        self.load_venues()
        self.load_instrument_types()
        self.load_currencies()
        self.load_canonicals()
        self.load_symbols()
        self.load_contract_params()
        self.build_alias()

    def load_venues(self):
        res = defaultdict(dict)
        
        conn = sqlite3.connect(self.db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        venues = c.execute('SELECT * FROM VENUES').fetchall()

        for venue in venues:
            res[venue['id']] = {'name':venue['name']}

        self.VENUES = res


    def load_instrument_types(self):
        res = defaultdict(dict)

        conn = sqlite3.connect(self.db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        itypes = c.execute('SELECT * FROM INSTRUMENT_TYPES').fetchall()
        for itype in itypes:
            res[itype['id']] = {'type':itype['type']}

        self.INSTRUMENT_TYPES = res

    def load_currencies(self):
        res = defaultdict(dict)

        conn = sqlite3.connect(self.db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        ccys = c.execute('SELECT * FROM CURRENCIES').fetchall()
        for ccy in ccys:
            res[ccy['id']] = {'ccy':ccy['ccy'],
                              'coinmarketcap_id':ccy['coinmarketcap_id']}

        self.CURRENCIES = res
        self.CCYNAMES = [v['ccy'] for v in self.CURRENCIES.values()]

    def load_canonicals(self):
        conn = sqlite3.connect(self.db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        canon = defaultdict(dict)

        res = c.execute('SELECT venues.name as venue, canonicals.exchange_ccy, currencies.ccy FROM canonicals '
                        'INNER JOIN currencies on canonicals.canonical_ccy_id = currencies.id '
                        'INNER JOIN venues on venues.id = canonicals.venue_id')

        for row in res:
            canon[row['venue']][row['exchange_ccy']] = row['ccy']

        self.CANONICALS = canon

    def load_symbols(self):
        res = defaultdict(dict)

        conn = sqlite3.connect(self.db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()

        for venue_id in self.VENUES:
            symbols = c.execute('SELECT * FROM symbols '
                                'WHERE symbols.venue_id = ?', (venue_id,))

            venue = self.VENUES[venue_id]['name']
    
            for sym in symbols:
                precision_price = None
                precision_amount = None
                if sym['precision_price_sf'] is not None:
                    precision_price = sym['precision_price_sf']
                    precision_amount = sym['precision_amount']

                res[venue][sym['name']] = {'id': sym['exchange_name'],
                                           'symbol': sym['name'],
                                           'base': self.canonical(venue, sym['base']),
                                           'quote': self.canonical(venue, sym['quote']),
                                           'precision': {'price': precision_price,
                                                         'amount': precision_amount},
                                           'tick': sym['tick'],
                                           'lot': sym['lot'],
                                           'instrument_type_id': sym['instrument_type_id'],
                                           'exchange_id_1': sym['exchange_id_1'],
                                           'exchange_id_2': sym['exchange_id_2'],
                                           'active': sym['active']}

        self.SYMBOLS = res

    def load_contract_params(self):
        res = defaultdict(dict)

        conn = sqlite3.connect(self.db)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        
        cparams = c.execute('SELECT v.name as venue, s.name as symbol, cp.* from VENUES v INNER JOIN SYMBOLS s on v.id=s.venue_id INNER JOIN CONTRACT_PARAMS cp on cp.symbols_id=s.id').fetchall()
        for sym in cparams:
            if sym['maturity']:
                maturity = datetime.datetime.strptime(sym['maturity'], "%Y-%m-%dT%H:%M:%SZ")
            else:
                maturity = None
            res[sym['venue']][sym['symbol']] = {'position_ccy_id': sym['position_ccy_id'],
                                                'settlement_ccy_id': sym['settlement_ccy_id'],
                                                'contract_multiplier': Decimal(str(sym['contract_multiplier'])),
                                                'is_inverse': sym['is_inverse'],
                                                'is_quanto': sym['is_quanto'],
                                                'maturity': maturity,
                                                'last_trading_day': sym['last_trading_day'],
                                                'settlement_index': sym['settlement_index']}
        self.CONTRACT_PARAMS = res

    def generate_manifest(self, venues, currencies, indices):
        """ Generate manifest file from a list of venues and currencies

        Subscribe to all currency pairs when if the base ccy is in the currencies list

        :param venues: list of venues we want to subscribe to
        :param currencies: list of BASE currencies we want to subscribe to
        :return:
        """
        manifest = defaultdict(dict)
        now = time.time()
        for venue in venues:
            sub_syms = set()
            if venue in self.SYMBOLS:
                for sym in self.SYMBOLS[venue]:
                    if self.canonical(venue, self.SYMBOLS[venue][sym]['base']) in currencies:
                        sub_syms.add(sym)
            elif venue in self.CONTRACT_PARAMS:
                for sym in self.CONTRACT_PARAMS[venue]:
                    if self.CONTRACT_PARAMS[venue][sym]['settlement_index'] in indices:
                        if self.CONTRACT_PARAMS[venue][sym]['maturity'] > now:
                            sub_syms.add(sym)

            manifest[venue]['defaultsyms'] = [s for s in list(sub_syms) if self.SYMBOLS[venue][s]['active']]
            manifest[venue]['credentials'] = []

        return manifest

    def isactive(self, venue, sym):
        return self.SYMBOLS[venue][sym]['active']
    
    def isccypair(self, sym):
        return '/' in sym #TODO: do something more intelligent in the future

    def canonical(self, venue, ccy):
        ccy = ccy.upper()
        if venue in self.CANONICALS and ccy in self.CANONICALS[venue]:
            return self.CANONICALS[venue][ccy]
        else:
            return ccy

    def isccy(self, ccy):
        ccy = ccy.upper()
        return ccy in self.CCYNAMES
        
    def venueccy(self, venue, canonical):
        ccy = canonical.upper()
        venueccy = ccy
        if venue in self.CANONICALS:
            for ccy0 in self.CANONICALS[venue]:
                if self.CANONICALS[venue][ccy0] == ccy:
                    venueccy = ccy0
                    break
        return venueccy

    def venuesym(self, venue, sym):
        try:
            return self.SYMBOLS[venue][sym]['id']
        except Exception as e:
            return None

    def canonicalsym(self, venue, venuesym):
        if venue not in self.SYMBOLS: return None
        cands = [x['symbol'] for x in self.SYMBOLS[venue].values() if x['id'] == venuesym]
        if len(cands) == 1:
            return cands[0]
        return None

    def instrumenttype(self, venue, canonicalsym):
        itype = None
        if venue in self.SYMBOLS and canonicalsym in self.SYMBOLS[venue]:
            itype_id = self.SYMBOLS[venue][canonicalsym]['instrument_type_id']
            if itype_id in self.INSTRUMENT_TYPES:
                itype = self.INSTRUMENT_TYPES[itype_id]['type']
        return itype    

    def getlotsize(self, venue, symbol):
        if (venue in self.SYMBOLS) and (symbol in self.SYMBOLS[venue]):
            if 'lot' in self.SYMBOLS[venue][symbol] and self.SYMBOLS[venue][symbol]['lot'] is not None:
                return Decimal(self.SYMBOLS[venue][symbol]['lot'])
            else:
                return Decimal('10') ** -self.SYMBOLS[venue][symbol]['precision']['amount']
        else:
            return None
            #raise Exception('no lot size info for {} on {}'.format(symbol, venue))

    def getticksize(self, venue, symbol, price=None, up=True):
        if (venue in self.SYMBOLS) and (symbol in self.SYMBOLS[venue]):
            if 'tick' in self.SYMBOLS[venue][symbol] and self.SYMBOLS[venue][symbol]['tick'] is not None:
                return Decimal(self.SYMBOLS[venue][symbol]['tick'])
            elif self.SYMBOLS[venue][symbol]['precision']['price'] is not None:
                sym_base = self.getbaseccy(venue, symbol)
                sym_quote = self.getquoteccy(venue, symbol)
                if price:
                    sym_price = Decimal(price)
                else:
                    return None
                # cannot be lower than 10^-8
                uptick = max(utils.sf_increment(self.SYMBOLS[venue][symbol]['precision']['price'], sym_price), Decimal('10') ** -8)
                if up:
                    return uptick
                else:
                    dn_price = sym_price - uptick
                    while dn_price < sym_price:
                        penultimate = dn_price #penultimate is guaranteed to exist
                        uptick = self.getticksize(venue, symbol, dn_price, True)
                        dn_price += uptick
                    return sym_price - penultimate
        
        return None
    #raise Exception('no tick size info for {} on {}'.format(symbol, venue))

    def getbaseccy(self, venue, symbol):
        if venue in ['cfdex', 'internal'] and '/' in symbol:
            return symbol.split('/')[0]
        if venue not in self.SYMBOLS and '/' in symbol:
            return symbol.split('/')[0]
        
        if (venue in self.SYMBOLS) and (symbol in self.SYMBOLS[venue]):
            return self.SYMBOLS[venue][symbol]['base']
        else:
            return None
            #raise Exception('no base ccy info for {} on {}'.format(symbol, venue))

    def getquoteccy(self, venue, symbol):
        if venue in ['cfdex', 'internal'] and '/' in symbol:
            return symbol.split('/')[1]
        if venue not in self.SYMBOLS and '/' in symbol:
            return symbol.split('/')[1]
        
        if (venue in self.SYMBOLS) and (symbol in self.SYMBOLS[venue]):
            return self.SYMBOLS[venue][symbol]['quote']
        else:
            return None
            #raise Exception('no quote ccy info for {} on {}'.format(symbol, venue))

    def getccys(self, venue, symbol):
        try:
            return [self.getbaseccy(venue, symbol), self.getquoteccy(venue, symbol)]
        except Exception as e:
            return []

    def isfiat(self, ccy):
        return ccy.upper() in FIATCCYS

    def getfees(self, venue):
        return self.FEES[venue]

    def getmultiplier(self, venue, symbol):
        if (venue in self.CONTRACT_PARAMS) and (symbol in self.CONTRACT_PARAMS[venue]):
            return self.CONTRACT_PARAMS[venue][symbol]['contract_multiplier']
        else:
            return Decimal(1)

    def getbaseindex(self, venue, symbol):
        base_idx = None
        if self.instrumenttype(venue, symbol) not in [Symbols.SPOT]:
            if (venue in self.CONTRACT_PARAMS) and (symbol in self.CONTRACT_PARAMS[venue]):
                base_idx = self.CONTRACT_PARAMS[venue][symbol]['settlement_index']
                if 'bitmex' in venue and '30M' in base_idx:
                    base_idx = base_idx[0:-3] #remove the 30M from the settlement index
        return base_idx

    def getsettlementccy(self, venue, symbol):
        settleccy = None
        if self.instrumenttype(venue, symbol) != Symbols.SPOT:
            if (venue in self.CONTRACT_PARAMS) and (symbol in self.CONTRACT_PARAMS[venue]):
                settleccyid = self.CONTRACT_PARAMS[venue][symbol]['settlement_ccy_id']
                if settleccyid in self.CURRENCIES:
                    settleccy = self.CURRENCIES[settleccyid]['ccy']
        return settleccy
    
    def getexchange_id_1(self, venue, symbol):
        exchange_id_1 = None
        if (venue in self.SYMBOLS) and (symbol in self.SYMBOLS[venue]):
            exchange_id_1 = self.SYMBOLS[venue][symbol]['exchange_id_1']
        return exchange_id_1

    def getsymfromexchange_id_1(self, venue, exchange_id):
        sym = None
        if venue in self.SYMBOLS:
            for symbol in self.SYMBOLS[venue]:
                if self.SYMBOLS[venue][symbol]['exchange_id_1'] == exchange_id:
                    sym = symbol
                    break
        return sym

    def getexchange_id_2(self, venue, symbol):
        exchange_id_2 = None
        if (venue in self.SYMBOLS) and (symbol in self.SYMBOLS[venue]):
            exchange_id_2 = self.SYMBOLS[venue][symbol]['exchange_id_2']
        return exchange_id_2

    def getsymfromexchange_id_2(self, venue, exchange_id):
        sym = None
        if venue in self.SYMBOLS:
            for symbol in self.SYMBOLS[venue]:
                if self.SYMBOLS[venue][symbol]['exchange_id_2'] == exchange_id:
                    sym = symbol
                    break
        return sym

    def isinverse(self, venue, symbol):
        if (venue in self.CONTRACT_PARAMS) and (symbol in self.CONTRACT_PARAMS[venue]):
            return self.CONTRACT_PARAMS[venue][symbol]['is_inverse'] == 1
        else:
            return False

    def contract_pl_ccy(self, venue, symbol):
        #TODO: need to check if quanto as well but no function for now
        if self.isinverse(venue, symbol):
            return self.getbaseccy(venue, symbol)
        else:
            return self.getquoteccy(venue, symbol)
        
    def round_dn(self, venue, symbol, dprice):
        if dprice is None: return dprice
        ticksize = self.getticksize(venue, symbol, dprice)
        return (dprice // ticksize) * ticksize

    def round_up(self, venue, symbol, dprice):
        if dprice is None: return dprice
        ticksize = self.getticksize(venue, symbol, dprice)
        result = self.round_dn(venue, symbol, dprice)
        if result == dprice: return result
        else: return result + ticksize

    def round_lot(self, venue, symbol, dsize):
        if dsize is None: return dsize
        lotsize = self.getlotsize(venue, symbol)
        return (dsize // lotsize) * lotsize

    # return available futures/options contracts that have not expired
    def get_avail_derivs(self, excludevenues=None):
        presentcontracts = {} # {venue: (contract name, contract param)}
        contracts = self.CONTRACT_PARAMS
        for k, v in contracts.iteritems():
            if excludevenues and (k in excludevenues): continue
            if presentcontracts.get(k) is None:
                presentcontracts[k] = []
            for fut, params in v.iteritems():
                if self.isactive(k, fut):
                    maturity = params['maturity']
                    if maturity is None:
                        presentcontracts[k].append((fut, params))
                    else:
                        maturityts = time.mktime(maturity.timetuple())
                        if maturityts > time.time():
                            presentcontracts[k].append((fut, params))
        return presentcontracts

    # maturity has to be in %Y%m%d format
    def get_derivs_with_maturity(self, maturity, excludevenues=None):
        matdate = datetime.datetime.strptime(maturity, '%Y%m%d')
        derivs = {} # venue: (contract names)
        contracts = self.CONTRACT_PARAMS
        for k, v in contracts.iteritems():
            if excludevenues and (k in excludevenues): continue
            if derivs.get(k) is None:
                derivs[k] = SortedSet()
            for fut, params in v.iteritems():
                if self.isactive(k, fut):
                    mat = params['maturity']
                    if mat is not None:
                        if mat.year == matdate.year and mat.month == matdate.month and mat.day == matdate.day:
                            derivs[k].add(fut)
        return derivs

    def get_symbols(self, venue, inst_types=[]):
        syms = []
        if venue in self.SYMBOLS:
            for sym in self.SYMBOLS[venue]:
                if not inst_types or self.instrumenttype(venue, sym) in inst_types:
                    syms.append(sym)
        return syms
   
    def build_alias(self):
        cfdict = {}
        okfdict = {}
        for sym in self.SYMBOLS['cf']:
            # only care abt the FIs (USD inverse contracts)
            if sym[0:2] == 'FV': continue
            ccy = sym[3:6]
            if ccy == 'XBT': ccy = 'BTC'
            alias = '{}{}'.format(ccy, sym[-4:])
            cfdict[alias] = sym
        self.ALIAS['cf'] = cfdict   
      
        for sym in self.SYMBOLS['okexfut']:
            alias = '{}{}'.format(sym[0:3], sym[-4:])
            okfdict[alias] = sym
        self.ALIAS['okexfut'] = okfdict

    def convsym(self, venue, alias):
        sym = alias
        symdict = self.ALIAS.get(venue, None)
        if symdict is not None:
            sym = symdict.get(alias, alias)
        return sym 

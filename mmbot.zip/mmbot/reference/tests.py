from cdecimal import Decimal as D
import unittest
import symbols

class TestRounding(unittest.TestCase):
    def test_round_dn(self):
        s = symbols.Symbols()
        result = s.round_dn('bitmex','XBTUSD',D('10000.1'))
        self.assertEqual(result, D('10000'))

    def test_dbl_round_dn(self):
        s = symbols.Symbols()
        result = s.round_dn('bitmex','XBTUSD',D('10000.1'))
        result = s.round_dn('bitmex','XBTUSD',result)
        self.assertEqual(result, D('10000'))

    def test_round_up(self):
        s = symbols.Symbols()
        result = s.round_up('bitmex','XBTUSD',D('10000.1'))
        self.assertEqual(result, D('10000.5'))

    def test_dbl_round_up(self):
        s = symbols.Symbols()
        result = s.round_up('bitmex','XBTUSD',D('10000.1'))
        result = s.round_up('bitmex','XBTUSD',result)
        self.assertEqual(result, D('10000.5'))


    def test_uptick(self):
        s = symbols.Symbols()
        uptick = s.getticksize('bitfinex', 'BTCUSD', D('10000.0'), up=True)
        self.assertEqual(uptick, D('1'))

    def test_dntick(self):
        s = symbols.Symbols()
        dntick = s.getticksize('bitfinex', 'BTCUSD', D('10000.0'), up=False)
        self.assertEqual(dntick, D('0.1'))
        
if __name__ == '__main__':
    unittest.main()

import requests as r
import sqlite3
import sys
import json
from pprint import pprint
from collections import namedtuple

import arrow
#from bs4 import BeautifulSoup
from cdecimal import Decimal as D

import venue_parsers

class SymbolUpdater(object):
    def __init__(self):
        self.db_conn = sqlite3.connect('reference.db')
        self.db_conn.row_factory = sqlite3.Row
        self.cursor = self.db_conn.cursor()
        self.venue_id = None

        self.instrument_types = None  # maps instrument types to instrument_types_id
        self.currencies = None  # maps canonical currencies names in currencies_id

    def get_currencies_table(self):
        self.cursor.execute('SELECT * FROM currencies')

        res = {}

        for row in self.cursor:
            res[row['ccy']] = row['id']

        return res

    def get_instrument_types(self):
        self.cursor.execute('SELECT * FROM instrument_types')

        res = {}

        for row in self.cursor:
            res[row['type']] = row['id']

        return res

    def get_currency_id(self, symbol, exchange_name):
        symbol = symbol.upper()
        c = self.db_conn.cursor()
        res = c.execute('SELECT * FROM currencies WHERE symbol = ?', (symbol,)).fetchall()

        if len(res) == 0:
            raise sqlite3.DataError('{0} not found in currencies table'.format(symbol))
        elif len(res) == 1:
            return res[0]['id']
        else:
            for i, row in enumerate(res):
                print i + 1, row

            user_selection = raw_input(
                'Multiple results found for {0} - please select # for correct one '.format(symbol))
            return res[int(user_selection)]['id']

    def run(self, venue, symbols):
        resp = raw_input(
            'Is the Canonical table for {0} up to date?  If not, you will mess up the symbols table (y to continue)'.format(venue))

        if resp.lower() == 'y':
            pass
        else:
            sys.exit()

        try:
            self.cursor.execute('INSERT OR IGNORE INTO venues (name) VALUES (?)', (venue,))
        except sqlite3.IntegrityError:
            pass

        self.cursor.execute('SELECT * FROM venues WHERE name = ?', (venue,))
        self.venue_id = self.cursor.fetchone()['id']

        self.instrument_types = self.get_instrument_types()
        self.currencies = self.get_currencies_table()

        #self.cursor.execute('DELETE FROM contract_params WHERE symbols_id in (SELECT id from symbols where venue_id = ?)', (self.venue_id,))
        #self.cursor.execute('DELETE FROM symbols WHERE venue_id = ?', (self.venue_id,))
        self.cursor.execute('UPDATE symbols SET active=0 WHERE venue_id = ?', (self.venue_id,))
        if venue == 'okexfut':
            self.cursor.execute('UPDATE symbols SET exchange_id_1=\'\' WHERE venue_id = ?', (self.venue_id,))

        for symbol in symbols:
            symbols_row_insert = {}

            symbols_row_insert['name'] = symbol.name
            symbols_row_insert['exchange_name'] = symbol.exchange_name
            symbols_row_insert['venue_id'] = self.venue_id
            symbols_row_insert['base'] = symbol.base
            symbols_row_insert['quote'] = symbol.quote
            symbols_row_insert['lot'] = symbol.lot
            symbols_row_insert['precision_price'] = symbol.precision['price']
            symbols_row_insert['precision_amount'] = symbol.precision['amount']
            symbols_row_insert['precision_price_sf'] = symbol.precision_sf['price']
            symbols_row_insert['precision_amount_sf'] = symbol.precision_sf['amount']
            symbols_row_insert['instrument_type_id'] = self.instrument_types[symbol.instrument_type]
            symbols_row_insert['tick'] = symbol.tick
            symbols_row_insert['exchange_id_1'] = symbol.exchange_id_1
            symbols_row_insert['exchange_id_2'] = symbol.exchange_id_2
            symbols_row_insert['active'] = 1

            columns = ', '.join(symbols_row_insert.keys())
            placeholders = ':' + ', :'.join(symbols_row_insert.keys())
            insert_query = 'INSERT OR REPLACE INTO symbols (id, {0}) VALUES ((SELECT id from symbols where name = \'{2}\' and venue_id = {3}), {1})'.format(columns, placeholders, symbols_row_insert['name'], self.venue_id)

            try:
                self.cursor.execute(insert_query, symbols_row_insert)
            except sqlite3.IntegrityError as e:
                print e, 'skipping', symbols_row_insert['exchange_name']

        self.db_conn.commit()

        for symbol in symbols:
            # Insert contract params if symbol is not a spot pair (e.g. it's a future or swap)
            if symbol.instrument_type != 'spot':
                self.cursor.execute('SELECT id FROM symbols WHERE name = ? AND venue_id = ?', (symbol.name, self.venue_id))
                symbols_id = self.cursor.fetchone()['id']

                # insert contract_params
                contract_param_row_insert = {}

                contract_param_row_insert['symbols_id'] = symbols_id
                contract_param_row_insert['position_ccy_id'] = self.currencies[symbol.position_ccy]
                contract_param_row_insert['settlement_ccy_id'] = self.currencies[symbol.settlement_ccy]
                contract_param_row_insert['contract_multiplier'] = symbol.contract_multiplier
                contract_param_row_insert['is_inverse'] = symbol.is_inverse
                contract_param_row_insert['is_quanto'] = symbol.is_quanto
                contract_param_row_insert['maturity'] = symbol.maturity
                contract_param_row_insert['settlement_index'] = symbol.settlement_index
                contract_param_row_insert['last_trading_day'] = symbol.last_trading_day

                columns = ', '.join(contract_param_row_insert.keys())
                placeholders =  ':' + ', :'.join(contract_param_row_insert.keys())
                insert_query = 'INSERT OR REPLACE INTO contract_params (id, {0}) VALUES ((SELECT id from contract_params where symbols_id = {2}), {1})'.format(columns, placeholders, symbols_id)
                try:
                    self.cursor.execute(insert_query, contract_param_row_insert)
                except sqlite3.IntegrityError as e:
                    print e, 'skipping contract_params', symbols_row_insert['exchange_name']

        # TODO print summary of how many inserted and how many skipped

        self.db_conn.commit()


if __name__ == '__main__':
    if sys.argv[1] == 'all':
        parsers = venue_parsers.VENUES
    else:
        method_name = sys.argv[1]  # set by the command line options
        possibles = venue_parsers.VENUES
        method = None
        for f in possibles:
            if f.__name__ == method_name:
                method = f
                break
        if not method:
            raise NotImplementedError("Method %s not implemented" % method_name)

        parsers = [method]

    for parser in parsers:
        venue, symbols = parser()
        updater = SymbolUpdater()
        updater.run(venue, symbols)

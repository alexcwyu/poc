# TODO below is just a skeleton

# This script should be used for the initial setup of a new reference DB

# 1) Execute schema.sql (look at this to do it in python https://pagehalffull.wordpress.com/2013/03/05/simple-python-script-that-runs-sql-scripts-against-a-given-sqlite-database/)
# sqlite3 reference.db and then .read schema.sql
# 2) Run populate_venues.py
# 3) Run populate currencies
# 4) Run populate canonicals
# 5) (Optional) Run symbols_updater

# To add a new venue:
# 1) Add venue to populate_venues.py and run
# 2) Add canonical mappings to populate_canonicals.py if needed
# 3) Add a new symbols updating function in venue_parsers.py and run via symbols_updater
# 4) Update cored

import requests
import sqlite3

VENUES = [('anxpro', None),
          ('binance','https://coinmarketcap.com/exchanges/binance/'),
          ('bitstamp','https://coinmarketcap.com/exchanges/bitstamp/'),
          ('bittrex','https://coinmarketcap.com/exchanges/bittrex/'),
          ('gdax','https://coinmarketcap.com/exchanges/gdax/'),
          ('bitfinex','https://coinmarketcap.com/exchanges/bitfinex/'),
          ('kraken','https://coinmarketcap.com/exchanges/kraken/'),
          ('bitmex', None),
          ('bitmextest', None),
          ('okexspot', 'https://coinmarketcap.com/exchanges/okex/'),
          ('okexfut', 'https://coinmarketcap.com/exchanges/okex/'),
          ('kucoin', 'https://coinmarketcap.com/exchanges/kucoin/'),
          ('hitbtc2', 'https://coinmarketcap.com/exchanges/hitbtc/'),
          ('gateio', 'https://coinmarketcap.com/exchanges/gate-io/'),
          ('coinexchange', 'https://coinmarketcap.com/exchanges/coinexchange/'),
          ('poloniex', 'https://coinmarketcap.com/exchanges/poloniex/'),
          ('huobipro', 'https://coinmarketcap.com/exchanges/huobi/'),
          ('bitflyer', 'https://coinmarketcap.com/exchanges/bitflyer/'),
          ('lbank', 'https://coinmarketcap.com/exchanges/lbank/'),
          ('bit-z', 'https://coinmarketcap.com/exchanges/bit-z/'),
          ('btcbox', 'https://coinmarketcap.com/exchanges/btcbox/'),
          ('zb', 'https://coinmarketcap.com/exchanges/zb-com/'),
          ('wex', 'https://coinmarketcap.com/exchanges/wex/'),
          ('yobit', 'https://coinmarketcap.com/exchanges/yobit/'),
          ('cryptopia', 'https://coinmarketcap.com/exchanges/cryptopia/'),
          ('liqui', 'https://coinmarketcap.com/exchanges/liqui/'),
          ('itbit', 'https://coinmarketcap.com/exchanges/itbit/'),
          ('cf', None),
          ('fixmaker', None)]

def main():
    dbfile = 'reference.db'

    conn = sqlite3.connect(dbfile)
    c = conn.cursor()

    for venue in VENUES:
        try:
            c.execute('INSERT OR REPLACE INTO VENUES (id, name, coinmarketcap_url) VALUES ((SELECT id from VENUES WHERE name=?), ?, ?)',
                      (venue[0], venue[0], venue[1]))
        except Exception as e:
            print "1", e.message, (venue[0], venue[1])
    #conn.commit()

    #for venue in VENUES:
    ##    try:
    #        c.execute('UPDATE VENUES SET coinmarketcap_url=? WHERE name=?',
    #                  (venue[1], venue[0]))
    #    except Exception as e:
    #        print "2", e.message, (venue[0], venue[1])

    conn.commit()
    conn.close()


if __name__ == '__main__':
    main()

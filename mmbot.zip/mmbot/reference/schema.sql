CREATE TABLE currencies(
id INTEGER PRIMARY KEY,
ccy TEXT UNIQUE,
name TEXT,
coinmarketcap_id TEXT UNIQUE
);

CREATE TABLE venues(
id INTEGER PRIMARY KEY,
name TEXT UNIQUE,
coinmarketcap_url TEXT
);

CREATE TABLE canonicals(
id INTEGER PRIMARY KEY,
venue_id INTEGER,
exchange_ccy TEXT,
canonical_ccy_id INTEGER,
UNIQUE(venue_id, exchange_ccy),
FOREIGN KEY(venue_id) REFERENCES venues(id),
FOREIGN KEY(canonical_ccy_id) REFERENCES currencies(id)
);

CREATE TABLE symbols(
id INTEGER PRIMARY KEY,
name TEXT, --our internal name of pair e.g. ETH/BTC
exchange_name TEXT, -- exchange name of pair e.g. ETHBTC
venue_id INTEGER,
base TEXT, -- canonical name for base ccy
quote TEXT, -- canonical name for quote ccy
lot TEXT,
precision_price INTEGER,
precision_amount INTEGER,
precision_price_sf INTEGER,
precision_amount_sf INTEGER,
instrument_type_id INTEGER,
tick TEXT,
exchange_id_1 TEXT,
exchange_id_2 TEXT,
active INTEGER,
UNIQUE(venue_id, name),
UNIQUE(venue_id, exchange_name),
FOREIGN KEY(venue_id) REFERENCES venues(id),
FOREIGN KEY (instrument_type_id) REFERENCES instrument_types(id)
);

CREATE TABLE contract_params(
id INTEGER PRIMARY KEY,
symbols_id INTEGER,
position_ccy_id INTEGER,
settlement_ccy_id INTEGER,
contract_multiplier INTEGER,
is_inverse INTEGER NOT NULL,
is_quanto INTEGER NOT NULL,
maturity TEXT,
last_trading_day TEXT,
settlement_index TEXT,
UNIQUE(symbols_id),
FOREIGN KEY(symbols_id) REFERENCES symbols(id),
FOREIGN KEY(position_ccy_id) REFERENCES currencies(id),
FOREIGN KEY(settlement_ccy_id) REFERENCES currencies(id)
);

CREATE TABLE instrument_types(
id INTEGER PRIMARY KEY,
type TEXT,
UNIQUE(type)
);

-- probably needs more thought on what data we need
CREATE TABLE fees(
id INTEGER PRIMARY KEY,
venue_id INTEGER,
maker TEXT,
taker TEXT,
type TEXT,
ccy_id INTEGER,
FOREIGN KEY(ccy_id) REFERENCES currencies(id)
);

INSERT OR IGNORE INTO instrument_types (type) VALUES
('spot'),
('future'),
('swap');

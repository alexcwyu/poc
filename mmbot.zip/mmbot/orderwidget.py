# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, April 2018

import urwid
from cdecimal import Decimal as D
import reference
import utils
from utils import OrderMsg
import re

SIZE_INCREMENT = 0.05
PRICE_INCREMENT = 0.0005

INPUT_WIDTH = 16

class NumInputBox(urwid.Edit):

    def __init__(self, initnum, increment, min_incr):
        self.num = initnum
        self.increment = max(min_incr, ((self.num * increment) // min_incr) * min_incr)
        self.min_incr = min_incr

        self.regex = re.compile(r"^\d*[.]?\d*$")
        super(NumInputBox, self).__init__("", utils.norm_str(initnum))


    def keypress(self, size, key):
        if key == 'down':
            if self.num > self.increment:
                self.num -= self.increment
                self.set_edit_text(utils.norm_str(self.num))
        elif key == 'up':
            self.num += self.increment
            self.set_edit_text(utils.norm_str(self.num))
        elif key == 'shift down':
            if self.num > self.min_incr:
                self.num -= self.min_incr
                self.set_edit_text(utils.norm_str(self.num))
        elif key == 'shift up':
            self.num += self.min_incr
            self.set_edit_text(utils.norm_str(self.num))
        else:
            return super(NumInputBox, self).keypress(size, key)

    def validchar(self, ch):
        return ch == '.' or ch.isdigit()

    def isvalidnum(self):
        text = self.edit_text.strip()
        return text != "" and self.regex.match(text) and utils.isfloat(text) and D(text) % self.min_incr == 0


class OrderEntryListBox(urwid.ListBox):
    __metaclass__ = urwid.MetaSignals
    signals = ["send_order", "price_fail", "size_fail"]

    def __init__(self, price, size, ticksize, lotsize):

        self.price = price
        self.size = size

        self.ticksize = ticksize
        self.lotsize = lotsize

        self.priceedit = NumInputBox(D(self.price), D(PRICE_INCREMENT), self.ticksize)
        self.sizeedit = NumInputBox(D(self.size), D(SIZE_INCREMENT), self.lotsize)
        self.body = urwid.SimpleFocusListWalker([
                urwid.Padding(urwid.Columns([
                        urwid.Padding(urwid.AttrMap(self.priceedit, 'pricecol', focus_map={'pricecol': 'reversed'}), align = 'right', width=INPUT_WIDTH),
                        urwid.Padding(urwid.AttrMap(self.sizeedit, 'sizecol', focus_map={'sizecol': 'reversed'}), align='right', width=INPUT_WIDTH)],       
                                  dividechars=3), width=INPUT_WIDTH*2 + 3)])
        super(OrderEntryListBox, self).__init__(self.body)


    def keypress(self, size, key):
        if key == 'tab':
            focus_widget, idx = self.body.get_focus()
            if idx == len(self.body) - 1:
                self.body.set_focus(0)
            else:
                self.body.set_focus(idx + 1)
        elif key == 'enter':
            if not self.priceedit.isvalidnum():
                urwid.emit_signal(self, "price_fail", self.priceedit.edit_text, utils.dec_to_str(self.priceedit.min_incr))
            elif not self.sizeedit.isvalidnum():
                urwid.emit_signal(self, "size_fail", self.sizeedit.edit_text, utils.dec_to_str(self.sizeedit.min_incr))
            else:
                urwid.emit_signal(self, "send_order", self.priceedit.edit_text, self.sizeedit.edit_text)

        else:
            super(OrderEntryListBox, self).keypress(size, key)
        return None

            

        

class OrderEntryWidget(urwid.Pile):
    __metaclass__ = urwid.MetaSignals
    signals = ["send_order"]

    WIDTH = INPUT_WIDTH*2+3

    def __init__(self, account, symbol, side, price, size):
        self.account = account
        self.venue = account.split(":")[0]
        self.symbol = symbol
        self.side = side
        self.price = price
        self.size = size

        self.symbols = reference.Symbols()
        ticksize = self.symbols.getticksize(self.venue, self.symbol, self.price)
        lotsize = self.symbols.getlotsize(self.venue, self.symbol)

        multiplier = self.symbols.getmultiplier (self.venue, self.symbol)
        self.multipliertext = urwid.Text("Multiplier {}".format(utils.norm_str(multiplier)))

        self.sidetext = urwid.Text("{} {} on {}".format(self.side.upper(), self.symbol, self.account))
        self.statustext = urwid.Text("")

        self.sizetext = urwid.Text("Size")
        self.pricetext = urwid.Text("Price")

        self.titlecolumns = urwid.Padding(urwid.Columns([self.pricetext, self.sizetext], dividechars = 3), width=OrderEntryWidget.WIDTH)
        self.editbox = OrderEntryListBox(self.price, self.size, ticksize, lotsize)
        super(OrderEntryWidget, self).__init__([('pack', self.sidetext),
                                                ('pack', self.multipliertext),
                                                ('pack', self.titlecolumns),
                                                ('pack', urwid.BoxAdapter(self.editbox, 20)),
                                                ('pack', urwid.Padding(self.statustext, width=OrderEntryWidget.WIDTH))])

        urwid.connect_signal(self.editbox, "send_order", self.sendorder)
        urwid.connect_signal(self.editbox, "price_fail", self.pricefail)
        urwid.connect_signal(self.editbox, "size_fail", self.sizefail)


    def sendorder(self, price, size):
        self.statustext.set_text("Sending order")
        urwid.emit_signal(self, "send_order", self.venue, self.symbol, self.side, size, price)

    def pricefail(self, price, ticksize):
        self.statustext.set_text("Price invalid {}, min tick {}".format(price, ticksize))

    def sizefail(self, size, lotsize):
        self.statustext.set_text("Size invalid {}, min lot {}".format(size, lotsize))


    def exit_program(self, key):
        raise urwid.ExitMainLoop()

    def run(self):
        urwid.MainLoop(self, unhandled_input = self.exit_program).run()


if __name__ == '__main__':

    app = OrderEntryWidget('anxpro:default1', "ETH/BTC", OrderMsg.BUY, "0.0532", "1.3")
    try:
        app.run()
    except Exception as inst:
        print (inst)


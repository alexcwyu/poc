# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from gevent import monkey
monkey.patch_all()
from collections import defaultdict
from itertools import dropwhile
import cPickle
import redis
import socket
import time
import uuid
import utils
from utils import OrderMsg, Fill, Book, customloglevel
from cdecimal import Decimal
import json
import threading
import logging
import logging.handlers
import zmq.green as zmq

import oms
import cparams
import reference
import settings
import alerts

EPGREFP = 'globalrefprice'
EPBASIS = 'basis'
EPFULLBOOK = 'fullbook'
EPBOOK = 'book_update'
EPTRADE = 'trade'

EPTIMER = 'timer'

EPLIQ = 'liquidation'
EPCHAT = 'chat'

MD_ONLY = 1
OMS_ONLY = 2
MD_OMS = 3

ALERT_SERVER = settings.ALERTSERVER_HOST

HBPERIOD = settings.ALERT_HBPERIOD

PRUNE_SECS = 30  # prune inactive orders older than (no guarantee of when this happens)

FULLBOOK_DEADTIME = 1  # time between fullbook triggers


TIMEOUT_CHECK_PERIOD = 0.2
TIMEOUT_PENDING_NEW = getattr(settings, 'TIMEOUT_PENDING_NEW', 3) #allow override
TIMEOUT_CANCEL = getattr(settings, 'TIMEOUT_CANCEL', 3)
TIMEOUT_MODIFY = getattr(settings, 'TIMEOUT_MODIFY', 3)
PENDING_NEW_TIMEDOUT = 'pending new timedout'
CANCEL_GETSTATE = 'cancel getstate'
CANCEL_TIMEDOUT = 'cancel timedout'

PIVOTCCY = 'USD'


def keygen(exchange, symbol, channel):
    return '{0}:{1}'.format(exchange, symbol) + ':' + channel


def keyparse(sKey):
    exchange = ""
    symbol = ""
    channel = ""
    try:
        exchange, symbol, channel = sKey.split(':')
    except:
        pass
    return (exchange, symbol, channel)


#
# Keeps track of subscription state
#
class MDState(object):
    def __init__(self):
        self.r = redis.StrictRedis(settings.REDIS_HOST, settings.REDIS_PORT)

    def clear_subscriptions(self, venue):
        self.r.delete('subs:{}'.format(venue))

    def register_subscription(self, venue, sym):
        self.r.sadd('subs:{}'.format(venue), sym)

    def update_lastbook_ts(self, venue, sym):
        self.r.hset('subs:{}:{}'.format(venue, sym), 'lastbookts', time.time())

    def update_lasttrade_ts(self, venue, sym, exchts):
        self.r.hset('subs:{}:{}'.format(venue, sym), 'lasttradets', float(exchts))
        lag = time.time() - float(exchts)
        self.r.hset('subs:{}:{}'.format(venue, sym), 'tradelag', lag)
        
    def is_subscribed(self, venue, sym):
        return self.r.sismember('subs:{}'.format(venue), sym)

#
# Commands gateways
#
class Commander(object):
    def __init__(self):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.connect("tcp://localhost:{}".format(settings.CMD_PUBPORT))
        self.lock = threading.Lock()
        
    def connect(self, venue):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'connect', 'args':[]})))

    def disconnect(self, venue):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'disconnect'})))

    def exit(self, venue):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'exit'})))

    def place(self, venue, internalid, omsg):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'place', 'args':[internalid, cPickle.dumps(omsg)]})))

    def cancel(self, venue, internalid):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'cancel', 'args':[internalid]})))

    def requeststate(self, venue, account, orderid):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'requeststate', 'args':[account, orderid]})))        
            
    def getfullbook(self, venue, sym):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'fullbook', 'args':[sym]})))

    def subscribe(self, venue, sym):
        with self.lock:
            self.socket.send("cmd:{} {}".format(venue, json.dumps({'cmd':'subscribe', 'args':[sym]})))


#TimerThread: Only used with fn=publish timer message function in TradingApp for recurring timer messages,
#Not intended for use to directly call other functions (thread safety)
class TimerThread(threading.Thread):
    def __init__(self, seconds, fn, event):
        threading.Thread.__init__(self)
        self.seconds = seconds
        self.stopped = event
        self.fn = fn

    def run(self):
        while not self.stopped.wait(self.seconds):
            self.fn()
#
# Thread safe implementation
#
class Publisher(object):
    def __init__(self):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.connect("tcp://localhost:{}".format(settings.MD_PUBPORT))
        self.lock = threading.Lock()
        #time.sleep(1) #Hack to wait for socket to connect; TODO: should use something else

    def _keygen(self, exchange, symbol, channel):
        return keygen(exchange, symbol, channel)

    def publish_fullbook(self, sVenue, sSym, lstbids, lstasks, iseq):
        # check against symbols.py
        key = self._keygen(sVenue, sSym, EPFULLBOOK)
        msg = {'bids': lstbids, 'asks': lstasks, 'seq': iseq}
        with self.lock:
            self.socket.send("{} {}".format(key, json.dumps(msg, separators=(',', ':'))))

    def publish_bookdiffs(self, sVenue, sSym, lstbids, lstasks, iSeq):
        # check against symbols.py
        key = self._keygen(sVenue, sSym, EPBOOK)
        msg = {'bids': lstbids, 'asks': lstasks, 'seq': iSeq}
        with self.lock:
            self.socket.send("{} {}".format(key, json.dumps(msg, separators=(',', ':'))))

    def publish_trade(self, sVenue, sSymbol, sPrice, sQty, sSide, fExchangeTimestamp):
        assert sSymbol.upper() == sSymbol
        key = self._keygen(sVenue, sSymbol, EPTRADE)
        msg = {}
        msg['ts'] = fExchangeTimestamp
        msg['price'] = sPrice
        msg['side'] = sSide
        msg['venue'] = sVenue
        msg['symbol'] = sSymbol
        msg['qty'] = sQty
        json_values = json.dumps(msg, separators=(',', ':'))
        with self.lock:
            self.socket.send("{} {}".format(key, json_values))

    def publish_refprice(self, symbol, price, ts):
        with self.lock:
            self.socket.send("{} {}".format(EPGREFP, json.dumps({'symbol': symbol, 'price': price, 'ts':ts})))

            
    #TODO: use publish_event and use another forwarder / split into MDPublisher and EventPublisher
    def publish_basis(self, venue, symbol, basis):
        with self.lock:
            self.socket.send("{} {}".format(EPBASIS, json.dumps({'venue': venue, 'symbol': symbol, 'basis': basis})))

    def publish_liquidation(self, sVenue, liqinfojson):
        channel = '{}:{}'.format(sVenue, EPLIQ)
        with self.lock:
            self.socket.send("{} {}".format(channel, liqinfojson))

    def publish_chat(self, chatinfo):
        with self.lock:
            self.socket.send("{} {}".format(EPCHAT, chatinfo))

    def publish_timer(self, name):
        with self.lock:
            self.socket.send("{} {}".format(EPTIMER, json.dumps({'name':name})))

# Clients can inherit this object or create one on their own
class TradingApp(object):
    def __init__(self, on_trade=None, on_book=None, on_wallet=None, on_fill=None, on_tvupdate=None, on_error=None, name=None, hb=False):
        if name:
            self.name = name
        else:
            self.name = str(uuid.uuid4())

        self.oms = oms.RedisOMS()
        self.symbols = reference.Symbols()
        self.cp = cparams.ContractParams()

        logging.addLevelName(customloglevel.HB, customloglevel.NAMEMAP[customloglevel.HB])
        logging.addLevelName(customloglevel.FILL, customloglevel.NAMEMAP[customloglevel.FILL])
        logging.addLevelName(customloglevel.ALERT, customloglevel.NAMEMAP[customloglevel.ALERT])

        self.logger = logging.getLogger(self.name)

        self.hb = hb
        self.lastmsg = 0

        if self.hb:
            self.logger.setLevel(customloglevel.HB)  # default root logger level is WARN
            sh = logging.handlers.SocketHandler(ALERT_SERVER, logging.handlers.DEFAULT_TCP_LOGGING_PORT)
            sh.setLevel(customloglevel.HB)
            self.logger.addHandler(sh)
            self.logger.log(customloglevel.HB, 'start')
            if name is None:
                self.logger.error('should use a custom name')

        self._order_lock = threading.Lock()
        self._wallet_lock = threading.Lock()
        self._book_lock = threading.Lock()
        self._fill_lock = threading.Lock()
        self._trade_lock = threading.Lock()

        self.__wallets = {}

        self.__grefp = {}
        self.__grefp_lastupdated = {}
        
        self.__on_trade = on_trade
        self.__on_book = on_book
        self.__on_fill = on_fill
        self.__on_wallet = on_wallet
        self.__on_tvupdate = on_tvupdate
        self.__on_error = on_error

        self.__redis = redis.StrictRedis(settings.REDIS_HOST, settings.REDIS_PORT)
        self.__cmd = Commander()
        
        self.__myids = set()
        self.__allorders = {}
        self._timeouts = {}
        
        self.reset()

        self.pub = Publisher()

    def start(self, mode=MD_OMS):
        t = threading.Thread(target=self.run_event_loop, kwargs={'mode':mode})
        t.daemon = True
        t.start()

        t = threading.Thread(target=self.checktimeoutthread)
        t.daemon = True
        t.start()

    def check_hb(self):
        if self.hb:
            timenow = time.time()
            if timenow - self.lastmsg > HBPERIOD:
                self.logger.log(customloglevel.HB, 'continue')
                self.lastmsg = timenow

    def stop_hb(self):
        if self.hb:
            self.logger.log(customloglevel.HB, 'shutdown')

    def settimer(self, seconds, periodic=False):
        seconds = max(0, seconds)

        def pub_timer_msg():
            self.pub.publish_timer(self.name)

        if periodic:
            self.stop_timer_flag = threading.Event()
            t = TimerThread(seconds, pub_timer_msg, self.stop_timer_flag)
        else:
            t = threading.Timer(seconds, pub_timer_msg)
        t.daemon = True
        t.start()

    def lmtorder(self, account, symbol, side, amount, price, cancross=False, mid_envelope=0.01, overridechecks=False,
                 proposed_id=None, strategy='/'):
        '''
        Parameters
        ----------
        account: str
                 Account name in venue:alias format
        symbol: str
                Symbol name
        side: OrderMsg.BUY or OrderMsg.SELL
              buy or sell
        amount: str
                absolute order amount as a string
        price: str
               price as a string
        cancross: bool
                  determines if we can cross the book
        mid_envelope: float
                      percentage excursion on allowed from mid
        overridechecks: bool
                        skip order checking
        proposed_id: str
                     apps can propose their own internalids
        Return
        ------
        str: internalid or None
             None means order was rejected internally either due to duplicated internalid, failed price checks, or insufficient balance
             internalid means the order was submitted to the connector/gateway
        '''

        if not overridechecks:
            ok = True
            exchange, alias = account.split(':')

            # Precision check
            ticksz = self.symbols.getticksize(exchange, symbol, price)
            lotsz = self.symbols.getlotsize(exchange, symbol)

            if ticksz is None or lotsz is None:
                self.logger.error('Precision info not available for {} at {}'.format(symbol, exchange))
                ok = False

            elif Decimal(price) % ticksz > Decimal('0') or Decimal(amount) % lotsz > Decimal('0'):
                self.logger.error(
                    'Precision error, {} only supports {} for price and {} for amount'.format(exchange, ticksz, lotsz))
                ok = False

            # Data check -> data needs to be subscribed
            book = self.getbook(exchange, symbol)
            # last = self.getlasttrade(exchange, symbol)
            if book is None:
                self.logger.error('Book data not available for {} {}'.format(exchange, symbol))
                ok = False
            else:
                bookbest_bid = book.best_bid
                bookbest_ask = book.best_ask

                # If one side of the book is empty then cannot cross more than this amount away from the available side.
                no_book_envelope = 2 * mid_envelope

                # Do envelope check if book is empty on one side
                if bookbest_bid is None and bookbest_ask is None:
                    ok = False
                    self.logger.error('Order not allowed, book is empty for {} {}'.format(exchange, symbol))
                elif bookbest_bid == None:
                    bestask = Decimal(bookbest_ask[0])
                    bestbid = bestask * Decimal(1 - no_book_envelope)
                    if side == OrderMsg.SELL and Decimal(price) < bestbid:
                        ok = False
                        self.logger.error('Sell limit crosses envelope threshold on book with no bids')
                elif bookbest_ask == None:
                    bestbid = Decimal(bookbest_bid[0])
                    bestask = bestbid * Decimal(1 + no_book_envelope)
                    if side == OrderMsg.BUY and Decimal(price) > bestask:
                        ok = False
                        self.logger.error('Buy limit crosses envelope threshold on book with no asks')
                else:
                    bestbid, bestask = Decimal(book.best_bid[0]), Decimal(book.best_ask[0])

                    # Another fat finger check - this is independent of the one above and may actually disallow placements in a wide market
                    midprice = (bestbid + bestask) / Decimal(2)
                    if side == OrderMsg.BUY and Decimal(price) > midprice * Decimal(1 + mid_envelope):
                        ok = False
                        self.logger.error('Buy limit exceeds {} percent of mid, ok = {}'.format(mid_envelope * 100, ok))
                    if side == OrderMsg.SELL and Decimal(price) < midprice * Decimal(1 - mid_envelope):
                        ok = False
                        self.logger.error(
                            'Sell limit exceeds {} percent of mid, ok = {}'.format(mid_envelope * 100, ok))

                    if not cancross:
                        # Book cross check for maker orders - this acts also as fat finger check
                        if side == OrderMsg.BUY and Decimal(price) > bestask:
                            ok = False
                            self.logger.error('Buy limit crosses bestask')
                        if side == OrderMsg.SELL and Decimal(price) < bestbid:
                            ok = False
                            self.logger.error('Sell limit crosses bestbid')

            if not ok: return None

        else:
            self.logger.warning('Order check override - do you know what you are doing?')

        if proposed_id is None:
            proposed_id = str(uuid.uuid4())

        # Check that proposed id doesn't already clash with something we have
        with self._order_lock:
            if proposed_id in self.__myids:
                return None

            # need to add it to my orders now so we accept and rejected or pending new callback
            self.__myids.add(proposed_id)

        # NB: this line needs to be outside the lock as we may be accepting callbacks while in this function
        success = self.oms.placeorder(proposed_id, account, symbol, side, OrderMsg.LMT, amount, price, strategy, not cancross)
        self.__allorders[proposed_id] = self.oms.getorderstatebyid(proposed_id)
        
        with self._order_lock:
            # needed to stop listening to callbacks that may have happened during placeorder
            if not success:
                self.__myids.discard(proposed_id)
                return None
            else:
                self.settimeout(proposed_id, time.time() + TIMEOUT_PENDING_NEW, PENDING_NEW_TIMEDOUT)

        return proposed_id

    def cancelorder(self, internalid):
        wait_until, action = self._timeouts.get(internalid, (None, None))
        #Don't do anything if order is currently in timeout jail
        if action == CANCEL_GETSTATE and wait_until > time.time():
            return False

        #We set the timeout first as the gateway can be so fast that it updates the orderstate during the function call, remove it from timeout if cancel did not succeed as we don't want to trigger the downstream actions
        self.settimeout(internalid, time.time() + TIMEOUT_CANCEL, CANCEL_GETSTATE)
        success = self.oms.cancel(internalid)
        if not success:
            self.cleartimeout(internalid)

        return success

    def reset(self):
        self.__localsubs = defaultdict(set)

        self.__loadwallets()
        self.__loadorders_and_fills()
        with self._book_lock:
            self.__books = defaultdict(lambda: defaultdict(lambda: None))  # current book state
            self.__lastfullbookrequest = defaultdict(lambda: defaultdict(float))  # mechanism to limit calls

        with self._trade_lock:
            self.__trades = defaultdict(lambda: defaultdict(list))

        self._timeouts = {}

    def __loadwallets(self):
        wallets = {}
        for name in self.oms.walletnames():
            self.logger.info(name)
            acc, wal = name.split('#')
            if acc not in wallets:
                wallets[acc] = {}
            wallets[acc][wal] = self.oms.getwallet(acc, wal)
        with self._wallet_lock:
            self.__wallets = wallets

    def __loadorders_and_fills(self):
        open_orders = self.oms.open_orders()  # get all open

        with self._order_lock:
            for order0 in open_orders:
                self.__allorders[order0.internalid] = order0

        # allfills = [cPickle.loads(f) for f in []]:

        self.__myfills = []
        # with self._fill_lock:
        #     for f0 in allfills:
        #         if (f0.account, f0.orderid) in mine:
        #             self.__myfills.append(f0)


    def subscribe(self, exchange, symbol):
        vsym = self.symbols.venuesym(exchange, symbol)
        if vsym is None:
            self.logger.error('{} {} not supported'.format(exchange, symbol))
            return

        self.__localsubs[symbol].add(exchange)
        
        if self.__books[symbol][exchange] is not None:
            self.logger.info('Already subscribed to this {} on {}'.format(symbol, exchange))
            return
        
        if symbol not in self.subscriptions.get(exchange, []):
            self.__cmd.subscribe(exchange, symbol)

        self.__trigger_fullbook(exchange, symbol)
            
    def unsubscribe(self, exchange, symbol):
        self.__localsubs[symbol].discard(exchange)

    def __trigger_fullbook(self, exchange, symbol):
        if time.time() > self.__lastfullbookrequest[exchange][symbol] + FULLBOOK_DEADTIME:
            self.__cmd.getfullbook(exchange, symbol)

        self.__lastfullbookrequest[exchange][symbol] = time.time()

    def ourmktbids(self, venue, symbol):
        return [(orderstate.price, orderstate.remaining) for orderstate in self.allorders.values() if
                orderstate.symbol == symbol and orderstate.venue == venue and orderstate.status in OrderMsg.LIVESTATES and orderstate.status != OrderMsg.PENDING_NEW and orderstate.price is not None and orderstate.remaining is not None and orderstate.side == OrderMsg.BUY]

    def ourmktasks(self, venue, symbol):
        return [(orderstate.price, orderstate.remaining) for orderstate in self.allorders.values() if
                orderstate.symbol == symbol and orderstate.venue == venue and orderstate.status in OrderMsg.LIVESTATES and orderstate.status != OrderMsg.PENDING_NEW and orderstate.price is not None and orderstate.remaining is not None and orderstate.side == OrderMsg.SELL]

    # getters
    @property
    def subscriptions(self): #global subscriptions - everyone gets all books
        subs = {}
        activegws = self.__redis.smembers('activegws')
        for gw in activegws:
            subs[gw] = list(self.__redis.smembers('subs:{}'.format(gw)))
        return subs

    @property
    def accounts(self):
        return self.oms.accounts()

    @property
    def wallets(self):
        with self._wallet_lock: return self.__wallets

    @property
    def orders(self):
        with self._order_lock:
            return {k:v for k,v in self.__allorders.items() if self.ismyorder(k)}

    @property
    def allorders(self):
        with self._order_lock: return self.__allorders

    @property
    def fills(self):
        with self._fill_lock: return self.__myfills

    # assume there is only one spot wallet per account
    def getspottradable(self, account):
        waldict = self.wallets.get(account, None)
        if waldict:
            for wal in waldict:
                wallet = waldict[wal]
                if wallet.spot:
                    return wallet.tradable

        return None 

    # All prices are in decimals
    # TODO: instead of returning decimal should return price object along with timestamp
    def getgrefp(self, refsym):
        if refsym in self.__grefp:
            return self.__grefp[refsym]
        elif self.symbols.isccypair(refsym):
            base, quote = refsym.split('/')
            baseref = '{}/{}'.format(base, PIVOTCCY)
            quoteref = '{}/{}'.format(quote, PIVOTCCY)
            try:
                b = self.__grefp[baseref]
                q = self.__grefp[quoteref]
                return b / q
            except:
                return None
        else:
            return None

    def getgrefp_lastupdated(self, refsym):
        if refsym in self.__grefp_lastupdated:
            return self.__grefp_lastupdated[refsym]
        elif self.symbols.isccypair(refsym):
            base, quote = refsym.split('/')
            baseref = '{}/{}'.format(base, PIVOTCCY)
            quoteref = '{}/{}'.format(quote, PIVOTCCY)
            try: b = self.__grefp_lastupdated[baseref]
            except: b = 0
            try: q = self.__grefp_lastupdated[quoteref]
            except: q = 0
            return min(b, q)
        return 0
        
    def gettv(self, venue, sym):
        idx = self.symbols.getbaseindex(venue, sym)
        basis = self.cp.getbasis(venue, sym)
        tv = None
        if self.symbols.isccypair(sym):
            base = self.symbols.getbaseccy(venue, sym)
            quote = self.symbols.getquoteccy(venue, sym)
            if not base or not quote: return None
            refpair = '{}/{}'.format(base, quote)
            gref = self.getgrefp(refpair)
            if gref and basis:
                tv = gref * basis
        elif idx:
            gref = self.getgrefp(idx)
            if gref and basis:
                tv = gref * basis
        return tv

    def gettv_lastupdated(self, venue, sym):
        idx = self.symbols.getbaseindex(venue, sym)
        if self.symbols.isccypair(sym):
            base = self.symbols.getbaseccy(venue, sym)
            quote = self.symbols.getquoteccy(venue, sym)
            if not base or not quote: return 0
            refpair = '{}/{}'.format(base, quote)
            return self.getgrefp_lastupdated(refpair)
        elif idx:
            return self.getgrefp_lastupdated(idx)
        return 0
    
    def getbook(self, exchange, symbol):
        #with self._book_lock: #causing deadlock?
        return self.__books[symbol].get(exchange, None)

    def getlasttrade(self, exchange, symbol):
        with self._trade_lock:
            trades = self.__trades[exchange][symbol]
            if trades:
                return trades[-1]
            else:
                return None
    
    def getalltrades(self, exchange, symbol):
        with self._trade_lock:
            trades = [t for t in self.__trades[exchange][symbol]]
            return trades

    def gettrades(self, exchange, symbol, secsBack):
        with self._trade_lock:
            ts = Decimal(time.time())
            trades = [t for t in self.__trades[exchange][symbol] if ts - t['ts'] < secsBack]
            return trades

    def prune_old_orders(self):
        timenow = time.time()
        with self._order_lock:
            prunelist = []
            for id0, order0 in self.__allorders.iteritems():
                if order0.status not in OrderMsg.LIVESTATES and timenow - order0.lastupdated > PRUNE_SECS:
                    prunelist.append(id0)
            for id0 in prunelist:
                del self.__allorders[id0]

    def settimeout(self, internalid, timeout_ts, timeout_type):
        assert timeout_type in {PENDING_NEW_TIMEDOUT, CANCEL_GETSTATE, CANCEL_TIMEDOUT}
        self._timeouts[internalid] = (timeout_ts, timeout_type)

    def cleartimeout(self, internalid):
        if internalid in self._timeouts:
            del self._timeouts[internalid]

    def checktimeoutthread(self):
        while True:
            timenow = time.time()
            cleartimeouts = []
            for internalid, values in self._timeouts.items():
                ts, action = values
                if timenow >= ts:
                    ostate = self.oms.getorderstatebyid(internalid)
                    self.logger.info('{} for {} timeoutat:{}, currtime:{}'.format(action, ostate, ts, timenow))
                    alerts.alert('{} for {}'.format(action, ostate))
                    
                    if action == PENDING_NEW_TIMEDOUT:
                        cleartimeouts.append(internalid)
                        self.oms.timeout(internalid)
                    elif action == CANCEL_GETSTATE:
                        self.oms.timeout(internalid)
                        self.settimeout(internalid, time.time() + TIMEOUT_CANCEL, CANCEL_TIMEDOUT)
                    else:
                        assert action == CANCEL_TIMEDOUT
                        cleartimeouts.append(internalid)

            for internalid in cleartimeouts:
                self.cleartimeout(internalid)
            time.sleep(TIMEOUT_CHECK_PERIOD)

    def run_event_loop(self, mode):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.SUB)
        if mode in [MD_ONLY, MD_OMS]:
            self.socket.connect("tcp://localhost:{}".format(settings.MD_SUBPORT))
        if mode in [OMS_ONLY, MD_OMS]:
            self.socket.connect("tcp://localhost:{}".format(settings.OMS_SUBPORT))
        topicfilter = ""
        self.socket.setsockopt(zmq.SUBSCRIBE, topicfilter)
        
        while True:
            try:    
                msg = self.socket.recv()
                channel, msg = msg.split(None, 1) #splits first space only

                self.check_hb()
                self.prune_old_orders()

                # if EPFULLBOOK in item['channel']:
                #     exchange, symbol, _ = keyparse(item['channel'])
                #     self.__trigger_fullbook(exchange, symbol)
                #     continue

                keycand = channel
                if keycand == EPTIMER:
                    if self.name == json.loads(msg).get('name',None):
                        self.on_timer()

                elif keycand == EPCHAT:
                    pass

                elif EPLIQ in keycand:
                    pass
                    
                elif keycand == EPGREFP:
                    data = json.loads(msg)
                    refsym = data['symbol']
                    lastupdate = data.get('ts',time.time())

                    try:
                        refp = Decimal(data['price'])
                    except:
                        continue

                    self.__grefp_lastupdated[refsym] = lastupdate
                    if self.__grefp.get(refsym, None) == refp: continue
                    
                    # Prevent storing refprice if the ref price is a ccy pair with quote ccy not equal to our pivot ccy.
                    if self.symbols.isccypair(refsym):
                        base, quote = refsym.split('/')
                        if quote == PIVOTCCY:
                            self.__grefp[refsym] = refp
                    else:
                        self.__grefp[refsym] = refp

                    if self.__on_tvupdate:
                        #see which one this refp update affects

                        for sym in self.__localsubs.keys():
                            for venue in self.__localsubs[sym]:
                                idx = self.symbols.getbaseindex(venue, sym)
                                if self.symbols.isccypair(refsym) and idx is None:
                                    base = self.symbols.getbaseccy(venue, sym)
                                    quote = self.symbols.getquoteccy(venue, sym)
                                    if not base or not quote: continue
                                    refbase, refquote = refsym.split('/')
                                    if refbase in [base, quote]:
                                        price = self.gettv(venue, sym)
                                        self.__on_tvupdate(venue, sym, price, lastupdate)
                                elif idx and refsym == idx:
                                    price = self.gettv(venue, sym)
                                    self.__on_tvupdate(venue, sym, price, lastupdate)
                                else:
                                    pass

                elif keycand == EPBASIS:
                    #EPBASIS is to make sure that on_tvupdate gets called when the basis changes so that the new tv gets
                    #reflected in the trading logic.
                    data = json.loads(msg)
                    venue = data['venue']
                    sym = data['symbol']
                    lastupdate = data.get('ts',time.time())
                    
                    if self.__on_tvupdate:
                        price = self.gettv(venue, sym)
                        if price:
                            self.__on_tvupdate(venue, sym, price, lastupdate)

                elif keycand == oms.OMS_EVENTS:
                    oms_msg = json.loads(msg)

                    if oms_msg['type'] == 'order':
                        evt = oms_msg['event']
                        intid = oms_msg['internalid']
                        ismyorder = self.ismyorder(intid)

                        evt_func_map = {OrderMsg.PENDING_NEW: self.on_pending_new,
                                        OrderMsg.NEW: self.on_new,
                                        OrderMsg.PARTIALLY_FILLED: self.on_partial_fill,
                                        OrderMsg.FILLED: self.on_full_fill,
                                        OrderMsg.DONE_FOR_DAY: self.on_expired,
                                        OrderMsg.CANCELED: self.on_canceled,
                                        OrderMsg.PENDING_CANCEL: self.on_pendingcancel,
                                        OrderMsg.REPLACED: self.on_replaced,
                                        OrderMsg.REJECTED: self.on_rejected,
                                        OrderMsg.STOPPED: self.on_stopped
                                        }

                        with self._order_lock:
                            self.__allorders[intid] = oms.RedisOrderState(self.__redis, intid)

                        if ismyorder: 
                            if intid in self._timeouts.keys():
                                #Should clear the timeout regardless of state it is in
                                # any order update would have come from a definitive source so we are confident that this is the final state; by clearing the timeout we stop any subsequent action from possibly happening and free up the app to cancel the order again if required
                                self.cleartimeout(intid)

                            evt_func_map[evt](intid)
                            
                    elif oms_msg['type'] == 'wallet':
                        with self._wallet_lock:
                            acc = oms_msg['acc']
                            wal = oms_msg['wallet']
                            wallet = self.oms.getwallet(acc, wal)
                            if wallet is None:
                                if acc in self.__wallets:
                                    self.__wallets[acc].pop(wal, None)
                                    self.__wallets.pop(acc)
                            else:
                                if acc not in self.__wallets:
                                    self.__wallets[acc] = {}
                                self.__wallets[acc][wal] = wallet

                        if self.__on_wallet is not None:
                            self.__on_wallet(acc, wal)

                    elif oms_msg['type'] == 'fill':
                        fillobj = cPickle.loads(str(oms_msg['fillobj']))
                        if self.ismyorder(fillobj.internalid):
                            with self._fill_lock:
                                self.__myfills.append(fillobj)
                            if self.__on_fill is not None:
                                self.__on_fill(fillobj)
                    else:
                        self.logger.error('Unknown msg {}'.format(oms_msg))

                else:
                    exchange, symbol, channel = keyparse(channel)
                    if channel == EPTRADE:
                        tradedata = json.loads(msg, parse_float=Decimal, parse_int=Decimal)
                        # Cache recent trades
                        with self._trade_lock:
                            ts = Decimal(time.time())  # What if exchange clock is off?
                            self.__trades[exchange][symbol].append(tradedata)
                            if self.__trades[exchange][symbol]:
                                self.__trades[exchange][symbol] = list(
                                    dropwhile(lambda x: ts - x['ts'] > settings.MD_TRADE_CACHE_SECS,
                                              self.__trades[exchange][symbol]))

                        if self.__on_trade is not None:
                            self.__on_trade(exchange, symbol, tradedata)

                    elif channel == EPFULLBOOK:
                        fullbook = json.loads(msg, parse_float=Decimal, parse_int=Decimal)

                        if int(fullbook['seq']) != -1:
                            
                            with self._book_lock:
                                self.__books[symbol][exchange] = Book(fullbook['bids'], fullbook['asks'],
                                                                      int(fullbook['seq']), strictseqcheck=True,
                                                                      name='{}{}'.format(symbol, exchange))
                            if self.__on_book is not None:
                                self.__on_book(exchange, symbol, self.__books[symbol][exchange])

                    elif channel == EPBOOK:

                        if self.__books[symbol][exchange] is None:
                            # this is rate limited in the function so it doesn't get triggered many times
                            self.__trigger_fullbook(exchange, symbol)
                            continue  # book not ready yet

                        bookdiff = json.loads(msg, parse_float=Decimal, parse_int=Decimal)
                        bdiffs, adiffs, dseqnum = bookdiff['bids'], bookdiff['asks'], int(bookdiff['seq'])

                        with self._book_lock:
                            self.__books[symbol][exchange].applyupdates(bdiffs, adiffs, dseqnum)

                        # if self.__books[symbol][exchange].droppedmsgs:
                        #                            #TODO: deal with this later
                        #                            self.__trigger_fullbook(exchange, symbol) #may get triggered multiple

                        if self.__on_book is not None:
                            self.__on_book(exchange, symbol, self.__books[symbol][exchange])
                    else:
                        self.logger.error('Unknown msg {} {}'.format(channel, msg))
            except:
                self.logger.error('Encountered error', exc_info=True)

    def force_oms_resync(self):
        with self._order_lock:
            for internalid in self.__allorders.keys():
                self.__allorders[internalid] = oms.RedisOrderState(self.__redis, internalid)
                
    # Override functions for trading:
    def ismyorder(self, internalid):
        '''Determines whether the internalid pertains to an order that the app cares about, set to True or some regex for fanciness'''
        return internalid in self.__myids

    def on_timer(self):
        self.print0("on_timer not implemented - need to override!")

    def on_pending_new(self, internalid):
        self.print0("on_pending_new not implemented - need to override! {}".format(internalid))

    def on_new(self, internalid):
        self.print0("on_new not implemented - need to override! {}".format(internalid))

    def on_partial_fill(self, internalid):
        self.print0("on_partial_fill not implemented - need to override! {}".format(internalid))

    def on_full_fill(self, internalid):
        self.print0("on_full_fill not implemented - need to override! {}".format(internalid))

    def on_expired(self, internalid):
        self.print0("on_expired not implemented - need to override! {}".format(internalid))

    def on_canceled(self, internalid):
        self.print0("on_canceled not implemented - need to override! {}".format(internalid))

    def on_pendingcancel(self, internalid):
        self.print0("on_pendingcancel not implemented - need to override! {}".format(internalid))

    def on_replaced(self, internalid):
        self.print0("on_replaced not implemented - need to override! {}".format(internalid))

    def on_rejected(self, internalid):
        self.print0("on_rejected not implemented - need to override! {}".format(internalid))

    def on_stopped(self, internalid):
        self.print0("on_stopped not implemented - need to override! {}".format(internalid))

    # ability to override print function
    def print0(self, *args):
        print(' '.join([str(x) for x in args]))



from gevent import monkey
monkey.patch_all()
import threading
import logging
import time
import gateways
import settings
import sys


BOOKGOT = False

if __name__ == '__main__':
    vut = sys.argv[1]#'anxpro' #venue under test
    print 'testing', vut
    
    logging.basicConfig(level=logging.INFO)

    creds = settings.manifest[vut]['credentials']

    account = None
    if len(creds) == 1:
        account = '{}:{}'.format(vut, creds[0]['alias'])

    def on_connect(*args, **kwargs):
        for sym in settings.manifest[vut]['defaultsyms']:
            print sym, bm.subscribe(sym)

    def bookupdate(*args, **kwargs):
        global BOOKGOT
        BOOKGOT = True

    bm = getattr(gateways, vut)(creds)
    bm.register_callback('connected', on_connect)
    bm.register_callback('book', bookupdate)
        
    for x in xrange(10):
        print 'RUN # {}'.format(x)
        bm.connect(account, [])
        print threading.active_count(), 'just got connected, threads running'
        for z in xrange(60):
            time.sleep(1)
        print BOOKGOT, '<<<<<'
        print threading.active_count(), 'threads running'
        bm.disconnect()
        BOOKGOT = False
        print threading.active_count(), 'after disconnect, threads running'
        for t in threading.enumerate():
            print t
        for y in xrange(15):
            time.sleep(1)
        print('='*8)
    print('done...')

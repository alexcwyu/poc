import time
import json
from utils import Book
from collections import defaultdict

books = defaultdict(dict)

for line in open('data/20171214.data'):
    ts,msgtype,venue,symbol,msg = line.split(';')
 #   print ts, msgtype


    if msgtype == 'fb':
        msg = json.loads(msg)
        print venue, symbol, len(msg['bids']), len(msg['asks'])
        if venue == 'gdax' and symbol == 'BTC/USD':
            largebook = Book(msg['bids'], msg['asks'], msg['iseq'])
            break

start_t = time.time()
for i in xrange(1000):
    x = largebook.bids, largebook.asks
print time.time() - start_t, 'secs'



start_t = time.time()
for i in xrange(1000):
    x = largebook.best_bids(3), largebook.best_asks(3)
print x
print time.time() - start_t, 'secs', 'hp version'

print largebook.best_bid, largebook.best_ask

print largebook.bids[0]

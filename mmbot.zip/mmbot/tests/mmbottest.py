import unittest
import sys
import pubsub
import time
import utils
from utils import OrderMsg
from utils import Decimal as D
from collections import defaultdict
import logging
import uuid
from xmlrpclib import Fault

logger = logging.getLogger()
logger.level = logging.DEBUG
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)

class TestTradingApp(pubsub.TradingApp):
    def __init__(self):
        super(TestTradingApp, self).__init__()
        self.event_called = defaultdict()
        for event in OrderMsg.STATES.keys():
            self.event_called[event] = defaultdict()

    def reset_test(self):
        for event in self.event_called:
            self.event_called[event] = {}

    def on_pending_new(self, internalid):
        self.event_called[OrderMsg.PENDING_NEW][internalid] = True

    def on_new(self, internalid):
        self.event_called[OrderMsg.NEW][internalid] = True

    def on_partial_fill(self, internalid):
        self.event_called[OrderMsg.PARTIALLY_FILLED][internalid] = True

    def on_full_fill(self, internalid):
        self.event_called[OrderMsg.FILLED][internalid] = True

    def on_canceled(self, internalid):
        self.event_called[OrderMsg.CANCELED][internalid] = True

    def on_expired(self, internalid):
        self.event_called[OrderMsg.DONE_FOR_DAY][internalid] = True

    def on_replaced(self, internalid):
        self.event_called[OrderMsg.REPLACED][internalid] = True

    def on_rejected(self, internalid, msg):
        self.event_called[OrderMsg.REJECTED][internalid] = msg

    def on_stopped(self, internalid):
        self.event_called[OrderMsg.STOPPED][internalid] = True


class MMBotTest(unittest.TestCase):
    A_REALLY_LARGE_NUMBER = D(sys.maxint)
    EXCHANGE = 'binance'
    PAIR = 'LTC/BTC'

    def setUp(self):
        self.app = TestTradingApp()
        self.app.subscribe(MMBotTest.EXCHANGE, MMBotTest.PAIR)

        acc_cands = [a for a in self.app.accounts if MMBotTest.EXCHANGE in a]
        if len(acc_cands) > 0:
            self.account = acc_cands[0]
        else:
            raise Exception('Account on %s not available' % MMBotTest.EXCHANGE)

        lotsize = self.app.symbols.getlotsize(MMBotTest.EXCHANGE, MMBotTest.PAIR)

        # bitmex considers min lotsize as spams, so need to have bigger size
        if MMBotTest.EXCHANGE == 'bitmex':
            self.minordersize = utils.norm_str(lotsize * D(100))
        else:
            self.minordersize = utils.norm_str(lotsize)

    def getFreeBal(self, side):
        if MMBotTest.EXCHANGE != 'bitmex':
            [ccy1, ccy2] = MMBotTest.PAIR.split('/')
            if side == OrderMsg.BUY:
                return self.app.free.get(self.account).get(ccy2)
            else:
                return self.app.free.get(self.account).get(ccy1)


    def placeAndCancel(self, side, qty, price, nTimes):
        for i in range(0, nTimes):
            freebalbefore = self.getFreeBal(side)
            internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, side, qty, price)
            self.assertNotEqual(internalid, None)

            maxWaitTime = 15
            while True:
                try:
                    self.assertEqual(self.app.event_called.get(OrderMsg.PENDING_NEW).get(internalid, False), True)
                    self.assertEqual(self.app.event_called.get(OrderMsg.NEW).get(internalid, False), True)
                    break
                except AssertionError:
                    time.sleep(1)
                    maxWaitTime = maxWaitTime - 1
                    if maxWaitTime == 0:
                        raise

            freebalafter = self.getFreeBal(side)

            if side == OrderMsg.BUY:
                freebalaftertheo = D(freebalbefore) - (D(qty) * D(price))
            else:
                freebalaftertheo = D(freebalbefore) - D(qty)

            self.assertEqual(freebalafter, freebalaftertheo)

            try:
                self.assertEqual(self.app.event_called.get(OrderMsg.FILLED).get(internalid, False), True)
                canBeCxlled = False
            except AssertionError:
                try:
                    self.assertEqual(self.app.event_called.get(OrderMsg.PARTIALLY_FILLED).get(internalid, False), True)
                    canBeCxlled = True
                except AssertionError:
                    canBeCxlled = True

            self.app.cancelorder(internalid)

            maxWaitTime = 15
            while True:
                try:
                    if canBeCxlled:
                        self.assertEqual(self.app.event_called.get(OrderMsg.CANCELED).get(internalid, False), True)
                    else:
                        self.assertEqual(self.app.event_called.get(OrderMsg.FILLED).get(internalid, False), True)
                    break
                except AssertionError:
                    time.sleep(1)
                    maxWaitTime = maxWaitTime - 1
                    if maxWaitTime == 0:
                        raise


    def getBook(self):
        while True:
            book = self.app.getbook(MMBotTest.EXCHANGE, MMBotTest.PAIR)
            if book is None:
                time.sleep(0.1)
            else:
                return book

    def checkInvalidOrder(self, internalid, rejectmsg):
        self.assertEqual(internalid, None)

        maxWaitTime = 15
        while True:
            try:
                self.assertEqual(self.app.event_called.get(OrderMsg.REJECTED).get(internalid, False), rejectmsg)
                break
            except AssertionError:
                time.sleep(1)
                maxWaitTime = maxWaitTime - 1
                if maxWaitTime == 0:
                    raise

    def findPassiveBidAndAsk(self, useCorrectTick=True):
        book = self.getBook()
        bestBid = D(book.best_bid[0]) * D('0.95')
        bestAsk = D(book.best_ask[0]) * D('1.05')

        ticksize = self.app.symbols.getticksize(MMBotTest.EXCHANGE, MMBotTest.PAIR)
        intcheckbid = bestBid // ticksize
        intcheckask = bestAsk // ticksize

        if useCorrectTick:
            bestBidPrice = (intcheckbid) * ticksize
            bestAskPrice = (intcheckask + 1) * ticksize
        else:
            bestBidPrice = (intcheckbid) * (ticksize * D('0.999'))
            bestAskPrice = (intcheckask + 1) * (ticksize * D('1.001'))

        return utils.norm_str(bestBidPrice), utils.norm_str(bestAskPrice)

    def findAggressiveBidAndAsk(self):
        book = self.getBook()
        aggAsk = D(book.best_bid[0])
        aggBid = D(book.best_ask[0])
        return utils.norm_str(aggBid), utils.norm_str(aggAsk)

    def test_account(self):
        acc_cands = [a for a in self.app.accounts if MMBotTest.EXCHANGE in a]
        if len(acc_cands) > 0:
            self.account = acc_cands[0]

        self.assertEqual(len(acc_cands), 1)
        self.assertIn(MMBotTest.EXCHANGE, self.account)

    def test_book(self):
        book = self.getBook()
        bestBid = D(book.best_bid[0])
        bestAsk = D(book.best_ask[0])
        self.assertGreater(bestAsk, bestBid)

    def test_balances(self):
        for account, baldi in self.app.total.iteritems():
            self.assertIn(MMBotTest.EXCHANGE, self.account)

            if len(baldi) > 0:
                for ccy, amt in baldi.iteritems():
                    logger.info("{} {}".format(ccy, amt))

    def broken_function(self):
        raise Exception('This is broken')

    def test_invalidAccount(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        with self.assertRaises(Exception) as context:
            account = 'wtf' + self.account + 'asdf'
            exchange, alias = account.split(':')
            internalid = self.app.lmtorder("wtf" + self.account + "asdf", MMBotTest.PAIR, OrderMsg.BUY, utils.norm_str(MMBotTest.A_REALLY_LARGE_NUMBER), limitBid)
        self.assertTrue('no info for {} on {}'.format(MMBotTest.PAIR, exchange) in str(context.exception))

    def test_buyAwayFromMarket_WithBalance(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        self.placeAndCancel(OrderMsg.BUY, self.minordersize, limitBid, 1)

    def test_sellAwayFromMarket_WithBalance(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        self.placeAndCancel(OrderMsg.SELL, self.minordersize, limitAsk, 1)

    # def test_buyAtMarket_WithBalance(self):
    #     aggrBid, aggrAsk = self.findAggressiveBidAndAsk()
    #     self.placeAndCancel(OrderMsg.BUY, self.minordersize, aggrBid, 1)
    #
    # def test_sellAtMarket_WithBalance(self):
    #     aggrBid, aggrAsk = self.findAggressiveBidAndAsk()
    #     self.placeAndCancel(OrderMsg.SELL, self.minordersize, aggrAsk, 1)

    def test_buyAwayFromMarket_WithoutBalance(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.BUY, utils.norm_str(MMBotTest.A_REALLY_LARGE_NUMBER), limitBid)
        self.assertEqual(internalid, None)

    def test_sellAwayFromMarket_WithoutBalance(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.SELL, utils.norm_str(MMBotTest.A_REALLY_LARGE_NUMBER), limitAsk)
        self.assertEqual(internalid, None)

    def test_lmtorderProposedId(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        proposedid = str(uuid.uuid4())
        internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.SELL, self.minordersize, limitAsk, proposed_id=proposedid)
        self.assertEqual(internalid, proposedid)

    def test_lmtorderDuplicateProposedId(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        proposedid = str(uuid.uuid4())
        internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.SELL, self.minordersize, limitAsk, proposed_id=proposedid)
        self.assertEqual(internalid, proposedid)
        time.sleep(15)
        # try sending another order with a duplicated proposedid
        internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.SELL, self.minordersize, limitAsk, proposed_id=proposedid)
        self.assertEqual(None, internalid)

    def test_orderLessThanMinSize(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        lotsize = self.app.symbols.getlotsize(MMBotTest.EXCHANGE, MMBotTest.PAIR)
        smallsize = lotsize / D(2)
        internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.BUY, utils.norm_str(smallsize), limitBid)
        self.assertEqual(None, internalid)

    def test_orderIncorrectPrecision(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk(useCorrectTick=False)
        internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.BUY, self.minordersize, limitBid)
        self.assertEqual(None, internalid)

    def test_sendZeroSizeOrder(self):
        limitBid, limitAsk = self.findPassiveBidAndAsk()
        with self.assertRaises(Fault) as context:
            internalid = self.app.lmtorder(self.account, MMBotTest.PAIR, OrderMsg.BUY, '0', limitBid)
        print context.exception
        self.assertTrue('exceptions.AssertionError' in str(context.exception))


if __name__ == '__main__':
    unittest.main()

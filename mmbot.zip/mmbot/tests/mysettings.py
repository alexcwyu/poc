REDIS_HOST='127.0.0.1'
REDIS_PORT='6379'
MD_HOST='127.0.0.1'
MD_PORT = 8011
OMS_HOST='127.0.0.1'
OMS_PORT = 8012
MD_LOGDIR = 'data/log/'
ORDERBOOK_LOGDIR = 'data/log/'
OMS_LOGDIR = 'data/log/'
MD_TRADE_CACHE_SECS=2
#credentials = [{'venue': 'anxpro', 'alias': 'wilson', 'uid': 'wilson.pau@gmail.com',
#                'apiKey': 'd2b117e3-c048-4971-a0ae-e43583cfde43',
#                'secret': 'pWmPXXfjqYB3vgN+H1K8ZuBOCk/mSY2IZMWis9E0+OVioIWHsV2FckpZnHl0WfV8btJQYDfRwlRsOexc/HdcCA=='}]
#credentials = [{'venue': 'binance', 'alias': 'wilson', 'uid': 'wilson.pau@gmail.com',
#               'apiKey': 'D4U4DYlP1I6EDX4BSxynO3lRXcgX6pR6f5F95DbNpBnCPxqruH83z4D197xb3evg',
#               'secret': 'XSlzMkj0h7XtRcxo43owGHFhnAkH3DaVKfvEmQJi3lEYv0Lilh1xCUOl6nmjPPDK'}]
# credentials = [{'venue': 'bitmex', 'alias': 'wilson', 'uid': 'wilson.pau@gmail.com',
#                 'apiKey': 'O9ptrTba_Gu1b7e2QohcYsuY',
#                 'secret': 'Us_79BwfEAhNDo_ayeUk7lppGwXqYx48E6o3TX4AZdRi3vZc'}]
# bitmex TestNET
#credentials = [{'venue': 'bitmex', 'alias': 'wilson', 'uid': 'wilson.pau@gmail.com',
#                'apiKey': '40Wo-CrSeQqm1US0TmPaZb8J',
#                'secret': '0IVtOGm9NWytMUTAmiL9Z0D3UGfvkboGZLrd6oWxBvKkZKXp'}]

credentials = [{'venue': 'bittrex', 'alias': 'wilson', 'uid': 'wilson.pau@gmail.com',
              'apiKey': '6291c25e7393497286a69a8a5103f618',
              'secret': 'd8d56fad37cf48ccb3d3cdda7e8a1556'}]

#credentials = {'venue': 'binance',
#                 'alias': 'sensusmarkets',
#                 'apiKey': 'La84qrpptKjBcmOlXOQORgIa1elr7eSmMRWQHks03cANkrP42CGqFQZ4H6WYQfx1',
#                 'secret': 'lie993cCAhIcIXbbVAs3NAgv5WDIwn3oPdTB9YF1h8WOEfJRhVtA5HXi5HTVWQ15'},

# credentials = {'venue': 'binance',
#                  'alias': 'wilson',
#                  'apiKey': 'D4U4DYlP1I6EDX4BSxynO3lRXcgX6pR6f5F95DbNpBnCPxqruH83z4D197xb3evg',
#                  'secret': 'XSlzMkj0h7XtRcxo43owGHFhnAkH3DaVKfvEmQJi3lEYv0Lilh1xCUOl6nmjPPDK'},

#sub_symbols = {'bittrex':['BTC/USDT', 'ETH/BTC']}


#sub_symbols = {'anxpro': ['BTC/HKD','LTC/BTC']}
#sub_symbols = {'binance': ['ETH/BTC','LTC/BTC']}
#sub_exchanges = {'bitmex':['XBTZ17','LTCZ17']}
#sub_symbols = {'bitmex':['XBTZ17','XBTUSD']}
sub_symbols = {'bittrex': ['XEM/ETH']}
#!/usr/bin/env python
import threading
import pubsub
import time, datetime
from utils import OrderMsg

exchange = 'anxpro'
pair = 'BTC/USD'

class CPTester(pubsub.TradingApp):

    def __init__(self, period=10):
        pubsub.TradingApp.__init__(self)
        
        self.period=period
        #subscribe to symbols
        #for account in self.accounts:
        self.subscribe(exchange, pair)

        acc_cands = [a for a in self.accounts if exchange in a]
        if len(acc_cands) > 0:
            self.account = acc_cands[0]
        else:
            raise Exception('Account on %s not available' % exchange)
        threading.Timer(self.period, self.placecancel).start()
        
    # 
    # HB function, gets called every n secs; if no open orders, submit one x % away from market
    #  if has open order, then cancel it
    #
    def placecancel(self):
        account = [a for a in self.accounts if exchange in a][0]
        print 'placecancel', account
        book = self.getbook(exchange, pair)

        #wait for data to populate
        if len(book['bids']) > 0 and len(book['asks']) > 0:

            bestBid = book['bids'][0]
            bestAsk = book['asks'][0]
            mid = (float(bestBid[0]) + float(bestAsk[0]))/2.0

            exchorders = [o for o in self.orders if o.account == account]
            
            print bestBid, bestAsk, '<<< top of book'
            print 'orders before ', exchorders

            #See if we already have active orders on this exchange, if so, cancel
            anydels = False
            for o in exchorders:
                if o.status == OrderMsg.OPEN and o.account == account:
                    print 'cancelling ', o.internalid
                    self.cancelorder(o.internalid)
                    anydels = True
            if anydels:
                time.sleep(3)
                print 'orders after ', [o for o in self.orders if o.account == account]
            
            #if there are no active orders, then place
            limitPrice = '%.2f' % float(mid * 0.5) #TODO: this is clunky - need to handle precision well

            print limitPrice, '<<BUY in 3 seconds'
            time.sleep(3)
            
            orderobj = self.lmtorder(account, pair, OrderMsg.BUY, '0.1', limitPrice)
            if orderobj:
                print 'placement success!', orderobj.internalid

        threading.Timer(self.period, self.placecancel).start()

# This script oscillates between submitting a lowball limit order for the exchange and canceling
if __name__ == '__main__':
    CPTester().run()

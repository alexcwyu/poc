#!/usr/bin/env python

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018

import time
import threading
from cdecimal import Decimal as D
from utils import OrderMsg, isfloat, pricepp, human_format
import numpy as np
from collections import defaultdict
import prices
import risk
import operator
import reference

# Other algos/todos:
# Joinchicken - join but yank
# Best -> needs a price limit
# POV, VWAP, slice
# OMS needs internalization to solve crossing issue

def algogroupfactory(tapp, agdict):
    state = agdict.get('state', {})
    algolst = [algofactory(tapp, ad) for ad in agdict['algos']]
    for algo in algolst:
        algo.update_avg_price()
    agobj = globals()[agdict['type']](tapp, agdict['name'], agdict['strategy'], algolst, **agdict['kwargs'])
    for k, v in state.items():
        if k == 'starttimes':
            starttimes = []
            for t in v:
                starttimes.append(D(t))
            v = starttimes
        elif k == 'tohedge':
            v = dict(v)
            v = {k0:D(v0) for k0, v0 in v.iteritems()}
            v = defaultdict(D, v) 
        elif k == 'workingalgos':
            walgos = [algofactory(tapp, ad0) for ad0 in v]
            for a0 in walgos:
                a0.update_avg_price()
            v = walgos
        elif k == 'stoppedalgos':
            salgos = [algofactory(tapp, ad0) for ad0 in v]
            for a0 in salgos:
                a0.update_avg_price()
            v = salgos
    
        setattr(agobj, k, v)
    return agobj

def algofactory(tapp, algodict):
    state = algodict.get('state', {})
    algoobj = globals()[algodict['type']](tapp, **algodict['kwargs'])
    for k, v in state.items():
        if k == 'myids':
            v = set(v)
        elif k == 'myfills':
            v = dict(v)
        elif isfloat(v):
            v = D(v)
        elif k == 'actualfills':
            d = {}
            for id, f in v.items():
                d[id] = (D(f[0]), D(f[1]))
            v = dict(d)
        try:
            setattr(algoobj, k, v)
        except:
            pass

    return algoobj

class AlgoGroup(object):
    INACTIVE = 'inactive'
    WORKING = 'working'
    ERROR = 'error'

    def __init__(self, tapp, name, strategy, algolst):
        # save off the kwargs
        self.kwargs = {}

        self.tapp = tapp
        self.algolst = algolst
        self.name = name
        self.strategy = strategy
        self.state = self.INACTIVE
        self.lock = threading.Lock()
        self.showalgoinfo = True

        for algo in self.algolst:
            algo.strategy = strategy
        
    def start(self):
        if self.state == self.ERROR:
            self.tapp.logger.warning('cannot start algo group which has errors')
            return
        self.state = self.WORKING
        self.work()

    def stop(self):
        self.state = self.INACTIVE
        self.work()

    def add_algo(self, algo):
        if self.state == self.INACTIVE:
            self.algolst.append(algo)

    # override this function for more specific behavior
    def work(self):
        with self.lock:
            self._work()

        #if all([a.state == Algo.DONE for a in self.algolst]):
        #    self.state = self.INACTIVE
            
    def _work(self):
        raise Exception('Implement me')

    def subscriptions(self):
        subs = []
        for a in self.algolst:
            subs += a.subscriptions()
        return set(subs)

    def ismine(self, internalid):
        return any([a.ismine(internalid) for a in self.algolst])

    def on_fill_event(self, internalid, fillobj):
        for a in self.algolst:
            if a.ismine(internalid):
                a.on_fill(fillobj)
                return

    def on_order_event(self, internalid):
        with self.lock:
            for a in self.algolst:
                if a.ismine(internalid):
                    a.on_order_event(internalid)
                    break
        self.work()
                
    def __repr__(self):
        pre = '{} {} {:.5} {}\n'.format(self.__class__.__name__, self.strategy, self.name, self.state)
        if self.showalgoinfo:
            pre += '\n'.join(['  ' + str(x) for x in self.algolst])
        return pre

    def json_state(self):
        jsonstate = {'algos': [x.json_state() for x in self.algolst],
                     'strategy': self.strategy,
                     'name': self.name,
                     'kwargs': self.kwargs,
                     'type': self.__class__.__name__}
        jsonstate.update(self._getstate_json())
        return jsonstate

    # override this function for extra state variables
    def _getstate_json(self):
        return {'state': {'state': self.state}}

    @property
    def killable(self):
        return all([a.killable for a in self.algolst])

    @property
    def deletable(self):
        return (self.state in [self.INACTIVE, self.ERROR]) and all([a.deletable for a in self.algolst])

    @property
    def haserror(self):
        return self.state == self.ERROR or any([a.state == Algo.ERROR for a in self.algolst])

class DefaultGroup(AlgoGroup):
    def _work(self):
        for a in self.algolst:
            if self.state == self.INACTIVE:
                a.stop()
            elif self.state == self.WORKING:
                a.start()
            else:
                raise Exception('Invalid AG state {}'.format(self.state))
            a.work()

            
class TimedGroup(AlgoGroup):
    #timesecs is the time between start of algo n and start of algo n+1
    def __init__(self, tapp, name, strategy, algolst, timesecs):
        super(TimedGroup, self).__init__(tapp, name, strategy, algolst)
        # save off the kwargs
        self.kwargs = {'timesecs': timesecs}
        self.timesecs = D(timesecs)
        assert self.timesecs > 0
        assert len(self.algolst) >= 2
        self.starttimes = [D(0)] * len(self.algolst)

    def _getstate_json(self):
        stlist = []
        for t in self.starttimes:
            stlist.append(str(t))

        return {'state': {'state': self.state,
                          'starttimes': stlist}}

    def _work(self):
        if self.state == self.INACTIVE:
            for a in self.algolst:
                a.stop()
                a.work()
        elif self.state == self.WORKING:

            for num, algo in enumerate(self.algolst):
                if num == 0:
                    algo.start()
                    algo.work()
                    if self.starttimes[num] == 0:
                        self.starttimes[num] = algo.start_t
                else:
                    if self.starttimes[num] == 0:
                        self.starttimes[num] = self.starttimes[num-1] + self.timesecs

                    if D(time.time()) >= self.starttimes[num]:
                        algo.start()
                        algo.work()
        else:
            raise Exception('Invalid AG state {}'.format(self.state))


class HedgeGroup(AlgoGroup):
    # The zero'th order is always the main order
    def __init__(self, tapp, name, strategy, algolst):
        super(HedgeGroup, self).__init__(tapp, name, strategy, algolst)
        assert len(self.algolst) >= 2  # needs one main algo and one or more hedge algos

    def _work(self):
        if self.state == self.INACTIVE:
            for a in self.algolst:
                a.stop()
                a.work()
        elif self.state == self.WORKING:
            mainalgo = self.algolst[0]
            mainalgo.start()
            mainalgo.work()
            main_pctdone = mainalgo.filled/mainalgo.qty
            for h in self.algolst[1:]:
                h_pctdone = h.filled/h.qty
                if h_pctdone < main_pctdone:
                    h.start()
                else:
                    h.stop()
                h.work()
        else:
            raise Exception('Invalid AG state {}'.format(self.state))


#on every fill it calls a hedge request
#pauses if unable to hedge
class HedgeRequestGroup(AlgoGroup):
    def __init__(self, tapp, name, strategy, algolst):
        super(HedgeRequestGroup, self).__init__(tapp, name, strategy, algolst)

    def _work(self):
        for a in self.algolst:
            if self.state == self.INACTIVE:
                a.stop()
            elif self.state == self.WORKING:
                a.start()
            else:
                raise Exception('Invalid AG state {}'.format(self.state))
            a.work()

    def on_fill_event(self, internalid, fillobj):
        with self.lock:
            deltadict = defaultdict(lambda: D(0)) #CCY:delta
            for a in self.algolst:
                if a.ismine(internalid):
                    a.on_fill(fillobj)

            if fillobj.amt > 0:
                base = self.tapp.symbols.getbaseccy(a.venue, a.sym)
                quote = self.tapp.symbols.getquoteccy(a.venue, a.sym)
                price = a.avgp if a.avgp else prices.getprice(base, quote)

                if base and quote:
                    if self.tapp.symbols.instrumenttype(a.venue, a.sym) == reference.Symbols.SPOT:
                        baseqty = D(fillobj.amt)
                    else:
                        [(bc, bcd), (qc, qcd)] = risk.calcdelta(a.venue, a.sym, price)
                        baseqty = bcd * D(fillobj.amt)
                    quoteqty = baseqty * price
                
                    if a.side == OrderMsg.BUY: #bot base
                        deltadict[base] += baseqty
                        deltadict[quote] -= quoteqty
                    else:
                        deltadict[base] -= baseqty
                        deltadict[quote] += quoteqty

            self.tapp.hedge_request(self.name, dict(deltadict))
        self.work()


class SingleContractHedgerGroup(AlgoGroup):
    def __init__(self, tapp, name, strategy, algolst, hedgeaccount, hedgecontract, hedgechunk):
        #LIKE FOR LIKE ONLY!
        super(SingleContractHedgerGroup, self).__init__(tapp, name, strategy, algolst)
        self.kwargs = {'hedgeaccount': hedgeaccount, 'hedgecontract': hedgecontract, 'hedgechunk': hedgechunk}
        self.sizelmt = D(hedgechunk) * 50
        self.schunk = hedgechunk
        venue = hedgeaccount.split(':')[0]
        self.mult = self.tapp.symbols.getmultiplier(venue, hedgecontract)
        self.ccy = self.tapp.symbols.getbaseccy(venue, hedgecontract)

        self.algolst = [Snipe(tapp, hedgeaccount, hedgecontract, OrderMsg.BUY, '(* mid 1.01)', str(self.sizelmt), self.schunk),
                        Snipe(tapp, hedgeaccount, hedgecontract, OrderMsg.SELL, '(* mid 0.99)', str(self.sizelmt), self.schunk)]
        self.amtdict = defaultdict(D)

        self.algolst[0].strategy = strategy
        self.algolst[1].strategy = strategy
        self.unhedged = D(0)
        self.currentdelta = D(0)
        
    def __repr__(self):
        pre = '{} {} {} {}\n'.format(self.__class__.__name__, self.strategy, self.name, self.state)
        if self.showalgoinfo:
            pre += 'Received: {:.2} Hedged: {:.2} ToHedge: {:.2}\n'.format(self.amtdict[self.ccy], self.currentdelta, self.unhedged)
            pre += '\n'.join(['  ' + str(x) for x in self.algolst])
        return pre

        
    def hedge_request(self, source, amtdict):
        self.tapp.logger.info(amtdict)
        for k,v in amtdict.items():
            self.amtdict[k] += D(v)
        
    def _work(self):
        if self.state == self.INACTIVE:
            for a in self.algolst:
                if a.state != Algo.WORKING and float(a.filled/a.qty) > 0.8:
                    a.qty += self.sizelmt #TODO create interface in algo to increase qty
                    a.remain = a.qty - a.filled #This should go in the algo
                    if a.state == Algo.DONE:
                        a.state = Algo.INACTIVE
                a.stop()
                a.work()

        elif self.state == self.WORKING:
            refp = self.tapp.getgrefp('{}/USD'.format(self.ccy))
            if refp is None: refp = prices.getprice(self.ccy, 'USD')
            if refp is None:
                self.tapp.logger.error('Got no price help me!')
                return
            
            buyalgo, sellalgo = self.algolst[0], self.algolst[1]
            contractcurrentdelta = buyalgo.filled - sellalgo.filled
            self.currentdelta = contractcurrentdelta*self.mult/refp
            
            self.unhedged = self.amtdict[self.ccy] + self.currentdelta
            if self.unhedged > D(self.schunk)*self.mult/refp: #we need to sell
                buyalgo.stop()
                sellalgo.start()
            elif self.unhedged < -D(self.schunk)*self.mult/refp:
                sellalgo.stop()
                buyalgo.start()
            else:
                sellalgo.stop()
                buyalgo.stop()
            sellalgo.work()
            buyalgo.work()
        else:
            raise Exception('Invalid AG state {}'.format(self.state))
        
class CentralizedHedgeGroup(AlgoGroup):

    def __init__(self, tapp, name, strategy, algolst):
        super(CentralizedHedgeGroup, self).__init__(tapp, name, strategy, algolst)
        self.liq_preference = ['USD', 'HKD', 'JPY', 'USDT', 'BTC', 'ETH', 'XRP', 'BCH', 'LTC', 'EOS', 'ADA', 'ETC', 'BTG', 'NEO', 'MIOTA',
                          'XMR', 'DASH', 'XLM']
        # ignore these venues for now as hedger doesn't check balrequired for futures hedges
        self.skipvenues = ['bitmextest', 'bitflyer']
        self.hedgevenues = []
        self.book_depth = 15
        self.nominalusd = D(500)
        self.ttl = 5
        self.hedge_allowance = D(500)  # only starts hedging if above this USD amount

        self.workingalgos = []
        self.stoppedalgos = []
        self.tohedge = defaultdict(lambda: D(0))
        self.rehedged = False
        self.garbagecollect = False
        self.chedgelock = threading.RLock()
    
    def _getstate_json(self):
        return {'state': {'state': self.state,
                          'rehedged': self.rehedged,
                          'workingalgos': [x.json_state() for x in self.workingalgos],
                          'stoppedalgos': [x.json_state() for x in self.stoppedalgos],
                          'tohedge': {k:str(v) for k, v in self.tohedge.iteritems()},
                          'hedgevenues': self.hedgevenues}}

    def set_hedgevenues(self, hedgevenues):
        self.hedgevenues = hedgevenues
        self.tapp.save_state()

    def add_algo(self, algo):
        algo.strategy = self.strategy
        self.algolst.append(algo)
        self.workingalgos.append(algo)
        self.tapp.save_state() 
    
    def remove_algo(self, algo):
        if algo in self.algolst:
            self.algolst.remove(algo)
        if algo in self.stoppedalgos:
            self.stoppedalgos.remove(algo)
        self.tapp.save_state()

    def subscriptions(self):
        subs = []
        for venue, syms in self.tapp.subscriptions.items():
            for sym in syms:
                subs.append((venue, sym))
        return set(subs)
    
    def _work(self):
        with self.chedgelock:
            if self.rehedged:
                if len(self.stoppedalgos) == 0:
                        self.dohedge()
                        self.rehedged = False
                else:
                    for a in self.stoppedalgos[:]:
                        if a.state == Algo.INACTIVE:
                            self.remove_algo(a)
            else:
                if self.garbagecollect and self.deletable:
                    for a in self.algolst[:]:
                        if a.state == DONE:
                            self.remove_algo(a)
                    self.garbagecollect = False        

        for a in self.algolst:
            if self.state == self.INACTIVE:
                a.stop()
            elif self.state == self.WORKING:
                a.start()
            else:
                raise Exception('Invalid AG state {}'.format(self.state))
            a.work()

    def hedge_request(self, source, amtdict):
        with self.chedgelock:
            for ccy, val in amtdict.items():
                prevval = self.tohedge[ccy]
                newval = prevval + D(val)
                if newval == 0:
                    self.tohedge.pop(ccy, None)
                else:
                    self.tohedge[ccy] = newval

            self.dohedge()

    def dohedge(self):
        trades = []
        unhedgedgrossdelta = self.getunhedgedgrossdelta()
        if unhedgedgrossdelta > self.hedge_allowance:
            proposed = defaultdict(lambda: D(0))
            coinuniverse = set(self.tohedge.keys() + self.liq_preference)
            ordered = sorted([(self.getcoinpref(ccy), ccy) for ccy in coinuniverse], key = operator.itemgetter(0,1))
            for _, coin in ordered[::-1]:
                pos = self.tohedge[coin] + proposed[coin]
                if pos == D(0): continue
                hedges = self.pick_hedges(coin, -pos)
                if len(hedges) == 0:
                    self.tapp.logger.info('no options to hedge out of {}'.format(coin))
                else:
                    top_hedge = hedges[0]
                    converted_to = top_hedge['quote']
                    rate = top_hedge['price']
                    newcoins = pos * rate
                    proposed[coin] += -pos
                    proposed[converted_to] += newcoins
                    trades.append(top_hedge)
            self.rehedged = self.rehedge(trades)
            if self.rehedged:
                return

            self.createalgos(trades)

            for ccy in proposed.keys():
                self.tohedge[ccy] = self.tohedge[ccy] + proposed[ccy]

    def rehedge(self, trades):
        rehedged = False

        for intrade in trades:
            for algo in self.workingalgos[:]:
                workbase = self.tapp.symbols.getbaseccy(algo.venue, algo.sym)
                workquote = self.tapp.symbols.getquoteccy(algo.venue, algo.sym)

                if workbase == intrade['base'] and workquote == intrade['quote']:
                    if algo.remain != 0 and algo.side != intrade['side']:
                        rehedged = True
                        # reverse the remain amount and put it back onto tohedge
                        if self.tapp.symbols.instrumenttype(algo.venue, algo.sym) == reference.Symbols.SPOT:
                            n = 1 if algo.side == OrderMsg.SELL else -1
                        else:
                            workprice = algo.avgp if algo.avgp else prices.getprice(workbase, workquote)
                            [(bc, bcd), (qc, qcd)] = risk.calcdelta(algo.venue, algo.sym, workprice)
                            n = bcd if algo.side == OrderMsg.SELL else -bcd
                        self.tapp.logger.info('algo.remain {}'.format(algo.remain))
                        workbasesize = n * algo.remain
                        workquotesize = -workbasesize * workprice

                        self.tohedge[workbase] += workbasesize
                        self.tohedge[workquote] += workquotesize
                        self.stop()
                        self.workingalgos.remove(algo)
                        self.stoppedalgos.append(algo)

        return rehedged

    def pick_hedges(self, coin, qty):
        if qty == 0: raise Exception('Nothing to hedge')
        accounts = self.tapp.wallets.keys()
        liqpref = self.getcoinpref(coin)
        tradeable = []
        for acc in accounts:
            venue, alias = acc.split(':')
            if venue in self.skipvenues: continue
            #if hedgevenues is not populated then allow any venue
            if len(self.hedgevenues) > 0 and venue not in self.hedgevenues: continue
        
            ccybaldict = self.tapp.getspottradable(acc)
            if not ccybaldict: continue
        
            for sym in self.tapp.symbols.SYMBOLS[venue]:
                if self.tapp.symbols.instrumenttype(venue, sym) == reference.Symbols.SPOT:
                    baseccy = self.tapp.symbols.getbaseccy(venue, sym)
                    quoteccy = self.tapp.symbols.getquoteccy(venue, sym)
                    # only trade syms that will move our risk to a liquidity prefered coin
                    if baseccy == coin and self.getcoinpref(quoteccy) < liqpref:
                        # calculate price to trade
                        book = self.tapp.getbook(venue, sym)
                        basis = self.tapp.cp.getbasis(venue, sym)
                        if book:
                            baseusd = '{}/USD'.format(baseccy)
                            baseusdrefp = self.tapp.getgrefp(baseusd)
                            basebal = D(ccybaldict.get(baseccy, 0))
                            quoteusd = '{}/USD'.format(quoteccy)
                            quoteusdrefp = self.tapp.getgrefp(quoteusd)
                            quotebal = D(ccybaldict.get(quoteccy, 0))
                            price = self.findweightedprice(book, self.book_depth, venue, sym, qty)
                            side = OrderMsg.BUY if qty > 0 else OrderMsg.SELL
                            size = self.tapp.symbols.round_lot(venue, sym, np.abs(qty))

                            if baseusdrefp and quoteusdrefp:
                                appendtrade = False
                                if qty > 0 and (quotebal * quoteusdrefp > self.nominalusd) and (quotebal > price * size):
                                    appendtrade = True
                                elif qty < 0 and (basebal * baseusdrefp > self.nominalusd) and (basebal > size):
                                    appendtrade = True

                                if appendtrade:
                                    self._appendtrade(tradeable, acc, sym, side, price, price * quoteusdrefp * basis,
                                                      coin, quoteccy, size)
                            else:
                                if baseusdrefp is None:
                                    self.tapp.logger.warning('norefconversion {}'.format(baseusd))
                                if quoteusdrefp is None:
                                    self.tapp.logger.warning('norefconversion {}'.format(quoteusd))

        # add the futures but do not check margin requirements
        contracts = self.tapp.symbols.get_avail_derivs(self.skipvenues)
        for venue, futs in contracts.iteritems():
            if len(self.hedgevenues) > 0 and venue not in self.hedgevenues: continue
            accs = [acc0 for acc0 in accounts if acc0.split(':')[0] == venue]

            for f in futs:
                fut = f[0]
                futbaseccy = self.tapp.symbols.getbaseccy(venue, fut)
                futquoteccy = self.tapp.symbols.getquoteccy(venue, fut)

                if futbaseccy == coin and self.getcoinpref(futquoteccy) < liqpref:
                    book = self.tapp.getbook(venue, fut)
                    basis = self.tapp.cp.getbasis(venue, fut)
                    multiplier = self.tapp.symbols.getmultiplier(venue, fut)

                    if book and multiplier:
                        quoteusd = '{}/USD'.format(futquoteccy)
                        quoteusdrefp = self.tapp.getgrefp(quoteusd)
                        mid = book.indicative_mid
                        if mid:
                            [(bc, bcd), (qc, qcd)] = risk.calcdelta(venue, fut, mid)                        
                            size = self.tapp.symbols.round_lot(venue, fut, D(qty) / bcd)
                            price = self.findweightedprice(book, self.book_depth, venue, fut, size)

                            if price:
                                side = OrderMsg.BUY if qty > 0 else OrderMsg.SELL

                                if quoteusdrefp:
                                    for acc0 in accs:
                                        self._appendtrade(tradeable, acc0, fut, side, price, price * quoteusdrefp * basis,
                                                          coin, futquoteccy, np.abs(size))
                                else:
                                    self.tapp.logger.warning('norefconversion {}'.format(quoteusd))

        tradeable = sorted(tradeable, key=lambda x: x['usdprice'])

        # if we are trying to sell then sort by dearest first
        if qty < 0 and len(tradeable) > 0:
            tradeable = tradeable[::-1]

        return tradeable

    def createalgos(self, trades):
        for trade in trades:
            kojpl = '(* mid 1.01)' if trade['side'] == OrderMsg.BUY else '(* mid 0.99)'
            kwargs = {"account": trade['account'],
                       "sym": trade['symbol'],
                       "side": trade['side'],
                       "kojpl": kojpl,
                       "qty": str(trade['size']),
                       "schunk": str(trade['size']),
                       "ttl": self.ttl}

            algo = Work(self.tapp, **kwargs)
            self.add_algo(algo)
            #algo.start()

    def _appendtrade(self, trades, account, sym, side, price, usdprice, coin, quoteccy, sz):
        trades.append({'account': account,
                      'symbol': sym,
                      'side': side,
                      'price': price,
                      'usdprice': usdprice,
                      'base': coin,
                      'quote': quoteccy,
                      'size': sz})

    def findweightedprice(self, book, depth, venue, sym, qty):
        qtyseen = D(0)
        sumproduct = D(0)
        pxsizepairs = None
        if qty > 0:  # buying
            pxsizepairs = book.best_asks(depth, cleanorders=self.tapp.ourmktasks(venue, sym))
        elif qty < 0:
            pxsizepairs = book.best_bids(depth, cleanorders=self.tapp.ourmktbids(venue, sym))

        if pxsizepairs:
            for i in range(depth):
                price, size = D(pxsizepairs[i][0]), D(pxsizepairs[i][1])
                qtyseen += size
                sumproduct = sumproduct + price * size
                if qtyseen >= np.abs(qty):
                    break
        else:
            return None

        return sumproduct / qtyseen if qtyseen != D(0) else None

    def getunhedgedgrossdelta(self):
        usdsize = 0
        for ccy, qty in self.tohedge.iteritems():
            if ccy != 'USDT' and (not self.tapp.symbols.isfiat(ccy)):
                usdsize += np.abs(qty) * prices.getprice(ccy, 'USD')
        return usdsize

    def getcoinpref(self, ccy):
        try:
            return self.liq_preference.index(ccy)
        except ValueError:
            return len(self.liq_preference)

class SpreadHedgeGroup(AlgoGroup):
    def __init__(self, tapp, name, strategy, algolst, spread):
        assert len(algolst) > 1
        super(SpreadHedgeGroup, self).__init__(tapp, name, strategy, algolst)
        self.kwargs = {'spread': spread}
        self.spread = D(spread)
        self.residualfiatrisks = {}
        self.currspread = None
        assert len(self.algolst) >= 2
        if tapp is None: return #Hack to allow for dummying up of AlgoGroup to check
        success = self.checkalgos()
        if not success:
            self.tapp.logger.error('error encountered while checking SpreadHedgeGroup')
            self.state = self.ERROR 
        self.showalgoinfo = True

    def __repr__(self):
        pre = '{} {} tgt spd: {} curr spd: {} {:.5} {}\n'.format(self.__class__.__name__, self.strategy, self.spread, pricepp(self.currspread), self.name, self.state)
        if self.showalgoinfo:
            pre += '\n'.join(['  ' + str(x) for x in self.algolst])
        return pre
        
    def _work(self):
        if self.state != self.ERROR:
            self.currspread = self.checkspread()
            if self.currspread is None:
                self.state = self.ERROR 
                return

        if self.state == self.INACTIVE or self.state == self.ERROR:
            for a in self.algolst:
                a.stop()
                a.work()
        elif self.state == self.WORKING:
            mainalgo = self.algolst[0]
            main_pctdone = mainalgo.filled/mainalgo.qty

            if self.currspread > self.spread:
                mainalgo.start()
            else:
                mainalgo.stop()

            mainalgo.work()
            
            for h in self.algolst[1:]:
                h_pctdone = h.filled/h.qty
                if h_pctdone < main_pctdone:
                    h.start()
                else:
                    h.stop()
                h.work()
        else:
            raise Exception('Invalid AG state {}'.format(self.state))

    def checkalgos(self):
        self.checked = True
        buyccys = [self.tapp.symbols.getbaseccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.BUY] \
                    + [self.tapp.symbols.getquoteccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.SELL]
        sellccys = [self.tapp.symbols.getquoteccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.BUY] \
                    + [self.tapp.symbols.getbaseccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.SELL]
        buyccysset = set(buyccys)
        sellccysset = set(sellccys)
        if len(buyccys) != len(buyccysset) or len(sellccys) != len(sellccysset):
            self.tapp.logger.error('Duplicate ccys exist')
            return False
        else:
            diff = buyccysset.symmetric_difference(sellccysset)
            self.residualfiatrisks['buy'] = buyccysset - sellccysset
            self.residualfiatrisks['sell'] = sellccysset - buyccysset
            if len(diff) == 0:
                return True
            else:
                if all(self.tapp.symbols.isfiat(x) or x =='USDT' for x in diff):
                    return True
                else:
                    self.tapp.logger.error('Residual non-fiat risks exist: {}'.format(diff))
                    return False

    def checkspread(self):
        symdict = {}

        for a in self.algolst:
            book = self.tapp.getbook(a.venue, a.sym)
            if book is None: return False
            if a.side == OrderMsg.BUY:
                asks = book.best_asks(1, cleanorders=self.tapp.ourmktasks(a.venue, a.sym))
                if asks: 
                    symdict[a.sym] = 1/D(asks[0][0])
                else:
                    return D(0)
            elif a.side == OrderMsg.SELL:
                bids = book.best_bids(1, cleanorders=self.tapp.ourmktbids(a.venue, a.sym))
                if bids:
                    symdict[a.sym] = D(bids[0][0])
                else:
                    return D(0)

        spread = D(1)
        for sym, value in symdict.iteritems():
            spread *= value

        for side, ccys in self.residualfiatrisks.iteritems():
            for ccy in ccys:
                (baseccy, quoteccy) = ('USD', ccy) if side == 'buy' else (ccy, 'USD')
                refp = self.tapp.getgrefp('{}/{}'.format(baseccy, quoteccy))
                if refp is None:
                    return None
                spread *= refp

        return spread - D(1)          

class SpreadBasketGroup(AlgoGroup):
    def __init__(self, tapp, name, strategy, algolst, spread):
        assert len(algolst) > 1
        super(SpreadBasketGroup, self).__init__(tapp, name, strategy, algolst)
        self.kwargs = {'spread': spread}
        self.spread = D(spread)
        self.residualfiatrisks = {}
        self.currspread = None
        assert len(self.algolst) >= 2
        if tapp is None: return #Hack to allow for dummying up of AlgoGroup to check
        success = self.checkalgos()
        if not success:
            self.tapp.logger.error('error encountered while checking SpreadBasketGroup')
            self.state = self.ERROR 
        self.showalgoinfo = True

    def __repr__(self):
        pre = '{} {} tgt spd: {} curr spd: {} {:.5} {}\n'.format(self.__class__.__name__, self.strategy, self.spread, pricepp(self.currspread), self.name, self.state)
        if self.showalgoinfo:
            pre += '\n'.join(['  ' + str(x) for x in self.algolst])
        return pre
        
    def _work(self):
        if self.state != self.ERROR:
            self.currspread = self.checkspread()
            if self.currspread is None:
                self.state = self.ERROR
                return

        if self.state == self.INACTIVE or self.state == self.ERROR:
            for a in self.algolst:
                a.stop()
                a.work()
        elif self.state == self.WORKING:
            self.currspread = self.checkspread()
            if self.currspread is None:
                self.state = self.ERROR
                return

            inrange = (self.currspread > self.spread)
            pctdones = [a.filled / a.qty for a in self.algolst]
            avgpctdone = np.mean(pctdones)
            #It is possible that one algo could run ahead and the spread closes
            for pctd, a in zip(pctdones, self.algolst):
                if pctd <= avgpctdone and inrange:
                    a.start()
                else:
                    a.stop()
                a.work()
        else:
            raise Exception('Invalid AG state {}'.format(self.state))

    def checkalgos(self):
        self.checked = True
        buyccys = [self.tapp.symbols.getbaseccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.BUY] \
                    + [self.tapp.symbols.getquoteccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.SELL]
        sellccys = [self.tapp.symbols.getquoteccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.BUY] \
                    + [self.tapp.symbols.getbaseccy(a.venue, a.sym) for a in self.algolst if a.side == OrderMsg.SELL]
        buyccysset = set(buyccys)
        sellccysset = set(sellccys)
        if len(buyccys) != len(buyccysset) or len(sellccys) != len(sellccysset):
            self.tapp.logger.error('Duplicate ccys exist')
            return False
        else:
            diff = buyccysset.symmetric_difference(sellccysset)
            self.residualfiatrisks['buy'] = buyccysset - sellccysset
            self.residualfiatrisks['sell'] = sellccysset - buyccysset
            if len(diff) == 0:
                return True
            else:
                if all(self.tapp.symbols.isfiat(x) or x =='USDT' for x in diff):
                    return True
                else:
                    self.tapp.logger.error('Residual non-fiat risks exist')
                    return False

    def checkspread(self):
        symdict = {}

        for a in self.algolst:
            book = self.tapp.getbook(a.venue, a.sym)
            if book is None: return False
            if a.side == OrderMsg.BUY:
                asks = book.best_asks(1, cleanorders=self.tapp.ourmktasks(a.venue, a.sym))
                if asks: 
                    symdict[a.sym] = 1/D(asks[0][0])
                else:
                    return D(0)
            elif a.side == OrderMsg.SELL:
                bids = book.best_bids(1, cleanorders=self.tapp.ourmktbids(a.venue, a.sym))
                if bids:
                    symdict[a.sym] = D(bids[0][0])
                else:
                    return D(0)

        spread = D(1)
        for sym, value in symdict.iteritems():
            spread *= value

        for side, ccys in self.residualfiatrisks.iteritems():
            for ccy in ccys:
                (baseccy, quoteccy) = ('USD', ccy) if side == 'buy' else (ccy, 'USD')
                refp = self.tapp.getgrefp('{}/{}'.format(baseccy, quoteccy))
                if refp is None:
                    return None
                spread *= refp

        return spread - D(1)          

class BasketGroup(AlgoGroup):
    def __init__(self, tapp, name, strategy, algolst):
        assert len(algolst) > 1
        super(BasketGroup, self).__init__(tapp, name, strategy, algolst)

    def _work(self):
        if self.state == self.INACTIVE:
            for a in self.algolst:
                a.stop()
                a.work()
        elif self.state == self.WORKING:
            pctdones = [a.filled / a.qty for a in self.algolst]
            avgpctdone = np.mean(pctdones)
            for pctd, a in zip(pctdones, self.algolst):
                if pctd <= avgpctdone:
                    a.start()
                else:
                    a.stop()
                a.work()
        else:
            raise Exception('Invalid AG state {}'.format(self.state))

# Base class for single market single symbol single working order algo
class Algo(object):
    INACTIVE = 'inactive'
    WORKING = 'working'
    DONE = 'done'
    ERROR = 'error'

    def __init__(self, tapp, account, sym, side, kojpl, qty, schunk=None):
        self.alias = self.__class__.__name__
        # save off the kwargs
        self.kwargs = {'account': account, 'sym': sym, 'side': side, 'qty': qty, 
                       'kojpl': kojpl, 'schunk': schunk}

        assert type(qty) == str
        self.tapp = tapp
        assert ':' in account
        self.account = account
        self.venue = account.split(':')[0]
        self.sym = sym
        self.lotsize = self.tapp.symbols.getlotsize(self.venue, self.sym)
        assert side in [OrderMsg.BUY, OrderMsg.SELL]
        self.side = side
        self.qty = D(qty)
        assert self.islotsizemult(self.qty), "lot size: %r" % self.lotsize
        assert self.qty > 0

        # TWAP has None for schunk so this is required
        if schunk is None:
            self.schunk = None 
        else:
            self.schunk = D(schunk)
            assert self.islotsizemult(self.schunk), "lot size: %r" % self.lotsize
            assert self.schunk > 0
        
        self.kojpl = kojpl
        self.kopriceobj = prices.Price(kojpl, prices.Context(self.venue, self.sym))

        self.remain = D(qty)
        self.filled = D(0)
        self.myfills = {}
        self.lock = threading.Lock()
        self.state = self.INACTIVE
        self.start_t = D(0)
        self.elapsed = D(0)
        self.avgp = None
        self.actualfills = {}

        self.workingid = None
        self.myids = set()
        self.retries = 0

        self.nextsendtime = 0
        self.nextcxltime = 0

        self.__strategy = '/' #default root strategy

    @property
    def koprice(self):
        result = self.kopriceobj.evalprice(self.tapp)
        if result is not None:
            result = D(result)
        return result

    @property
    def strategy(self):
        return self.__strategy
        
    @strategy.setter
    def strategy(self, value):
        if len(value) > 0 and value[0] == '/' and type(value) == str:
            self.__strategy = value

    @property
    def killable(self):
        return self.workingid == None and self.state in [self.INACTIVE, self.DONE, self.ERROR]

    @property
    def deletable(self):
        return self.workingid == None and self.state in [self.INACTIVE, self.DONE, self.ERROR]

    def islotsizemult(self, num):
        return int(num / self.lotsize) * self.lotsize == num

    # can override
    def subscriptions(self):
        set_ = self.kopriceobj.subscriptions()
        return {(self.venue, self.sym)}.union(set_)

    def start(self):
        if self.state == self.INACTIVE:
            self.retries = 0
            self.state = self.WORKING
            if self.start_t == 0: self.start_t = D(time.time())
            with self.lock:
                self._start()

    def _start(self):
        pass

    def stop(self):
        if self.state == self.WORKING:
            self.state = self.INACTIVE
            with self.lock:
                self._stop()

    def _stop(self):
        pass

    def work(self):
        if (self.start_t != 0) and (self.state not in [self.INACTIVE, self.DONE, self.ERROR]):
            self.elapsed = D(time.time()) - self.start_t
        try:
            with self.lock:
                self._work()
        except Exception as e:
            self.tapp.logger.error(e, exc_info=True)
            raise e

    # override this method
    def _work(self):
        raise Exception('Not implemented')

    def ismine(self, internalid):
        with self.lock: #avoid race condition that algo doesn't know about id it just submitted
            return internalid in self.myids

    def cancelworkingorder(self):
        if self.workingid and time.time() > self.nextcxltime:
            self.tapp.cancelorder(self.workingid)
            self.nextcxltime = time.time() + 1

    def on_fill(self, fillobj):
        self.actualfills[str(fillobj.tradeid)] = (D(fillobj.amt), D(fillobj.price))
        self.update_avg_price()

    def update_avg_price(self):
        totalqty = 0
        accum = 0
        for f in self.actualfills.values():
            accum += f[0] * f[1]
            totalqty += f[0]
        if totalqty != 0:
            self.avgp = accum / totalqty  # Warning - does not work for some fut contracts that require harmonic mean

    def check_price_ok(self, price):
        self.tapp.logger.info('check_price_ok {}'.format(price))
        kop = self.koprice
        self.tapp.logger.info('kop {}'.format(kop))
        if kop is None or price is None:
            return False

        if self.side == OrderMsg.BUY and price > kop:
            return False
        
        if self.side == OrderMsg.SELL and price < kop:
            return False
       
        return True

    def check_algo_done(self):
        return self.remain < self.lotsize

    def on_order_event(self, internalid):
        self.myfills[internalid] = self.tapp.orders[internalid].filled
        self.filled = sum([D(x) for x in self.myfills.values()])
        self.remain = self.qty - self.filled

        order0 = self.tapp.orders[internalid]
        if order0 and order0.status not in OrderMsg.LIVESTATES:
            if self.workingid == internalid:
                self.workingid = None
                self.nextcxltime = 0

            #remove if no fills
            if D(order0.filled) == 0:
                self.myids.discard(internalid)
                del self.myfills[internalid]
               
            if order0.status == OrderMsg.REJECTED:
                self.retries = self.retries + 1
                self.nextsendtime = time.time() + 1
                if (self.retries > 5):
                    self.tapp.logger.info('order {} got rejected, retrying {} times'.format(order0, self.retries))
                    if self.state == self.WORKING:
                        self.state = self.ERROR
                        self._stop()
            else:
                self.retries = 0


    # override this method
    def extra_algo_info(self):
        return ''

    def json_state(self):
        # some are params and not state
        fillstrdict = {}
        for id, f in self.actualfills.items():
            fillstrdict[id] = (str(f[0]), str(f[1]))

        return {'type': self.__class__.__name__,
                'kwargs': self.kwargs,
                'state': {'filled': str(self.filled),
                          'remain': str(self.remain),
                          'state': self.state,
                          'workingid': self.workingid,
                          'myids': list(self.myids),
                          'actualfills': dict(fillstrdict),
                          'myfills': dict(self.myfills),
                          'start_t': str(self.start_t),
                }}

    def _getusddeltas(self):
        base = self.tapp.symbols.getbaseccy(self.venue, self.sym) 
        quote = self.tapp.symbols.getquoteccy(self.venue, self.sym)
        px = prices.Price('mid:{}@{}'.format(self.sym, self.venue))
        price = px.evalprice(self.tapp)
        if price is None: return 0, 0
        quoteusdprice = prices.Price('grefp:{}/{}'.format(quote, 'USD')).evalprice(self.tapp)
        if quoteusdprice is None: return 0, 0
        usdprice = D(quoteusdprice) * D(price)
        [(_, delta), (_, _)] = risk.calcdelta(self.venue, self.sym, price)
        remdelta = usdprice * delta * self.remain
        filleddelta = usdprice * delta * self.filled
        return remdelta, filleddelta

    def __repr__(self):
        # <state> <type> <side> <account> <sym> rem: fill: working: workid: workprice: avgp: (algo specific info)
        algotype = self.alias
        workid = '-'
        workamt = '-'
        workp = '-'
        try:  # workingid can change anytime
            workid = self.workingid[:5]
            order0 = self.tapp.orders[self.workingid]
            if order0:
                workamt = str(order0.amt)
                workp = str(order0.price)
        except:
            pass

        remdelta, filleddelta = self._getusddeltas()

        prefix = '{:.4} {:.8} {:4} {:.10} {:11} pctfill:{:.4} rem:{}(${}) fill:{}(${}) working:{}, workid:{:.5} workprice:{} elapsed:{}'.format(self.state, algotype, self.side, self.account, self.sym, pricepp(self.filled/self.qty), pricepp(self.remain), human_format(int(remdelta)), pricepp(self.filled), human_format(int(filleddelta)), workamt, workid, workp, int(self.elapsed))
        if self.avgp:
            prefix += ' avgp:{}'.format(pricepp(self.avgp))
        prefix += ' koprice:{} {}'.format(self.kojpl, self.koprice)
        return prefix + self.extra_algo_info()

class TWAP(Algo):
    def __init__(self, tapp, account, sym, side, kojpl, qty, duration):
        super(TWAP, self).__init__(tapp, account, sym, side, kojpl, qty, schunk=None)
        self.kwargs.update({'duration': duration})
        del self.kwargs['schunk']

        assert type(duration) == str
        self.duration = D(duration)
        self.mincliptime = 5  # minimum clip time
        assert self.duration >= self.mincliptime

    def check_algo_done(self):
        if self.remain < self.lotsize:
            return True
    
        if self.duration - self.elapsed <= 0:
            return True

        return False

    def _work(self):
        if self.check_algo_done(): 
            self.cancelworkingorder()
            self.state = self.DONE
            return

        remtime = self.duration - self.elapsed

        if self.state == self.INACTIVE:
            if self.workingid:
                self.cancelworkingorder()

        if self.state == self.WORKING:
            pctdone = self.filled / self.qty
            pctelapsed = self.elapsed / self.duration
            ahead = pctdone > pctelapsed
            if ahead: return

            if self.workingid is None:
                maxclipsbysize = int(self.remain / self.lotsize)
                maxclipsbytime = max(int(remtime / self.mincliptime), 1)
                clipsize = maxclipsbysize / maxclipsbytime * self.lotsize
                book = self.tapp.getbook(self.venue, self.sym)
                if book is None: return
                price = None
                if self.side == OrderMsg.BUY:
                    if book.best_ask is not None:
                        price, _ = book.best_ask
                else:
                    if book.best_bid is not None:
                        price, _ = book.best_bid

                if price is None: 
                    return
                else:
                    price = D(price)
                if not self.check_price_ok(price): return

                qty = D(np.random.normal(clipsize, clipsize / 2))
                lowerbound = self.lotsize
                upperbound = 2 * clipsize - self.lotsize
                if qty <= lowerbound:
                    qty = lowerbound
                elif qty >= upperbound:
                    qty = upperbound
               
                qty = min(qty, self.remain)     
                qty = self.tapp.symbols.round_lot(self.venue, self.sym, qty)

                if time.time() < self.nextsendtime: return
                self.workingid = self.tapp.lmtorder(self.account, self.sym, self.side, str(qty), str(price),
                                                    cancross=True, strategy=self.strategy)
                self.myids.add(self.workingid)
            else:
                order0 = self.tapp.orders[self.workingid]
                # simulate FOK
                if order0 and order0.status in OrderMsg.ACTIONABLE:
                    self.cancelworkingorder()

class DynamicLimit(Algo):
    def __init__(self, tapp, account, sym, side, kojpl, qty, schunk, pricejpl, ttl, postonly):
        super(DynamicLimit, self).__init__(tapp, account, sym, side, kojpl, qty, schunk)
        self.alias = 'DynLmt'
        self.kwargs.update({'pricejpl': pricejpl, 'ttl': ttl, 'postonly': postonly})
        self.waituntil = 0
        self.ttl = D(ttl)  # ttl < 0 means requote when price changes by awaypct/10
        self.pricejpl = pricejpl
        self.priceobj = prices.Price(pricejpl, prices.Context(self.venue, self.sym))
        self.postonly = postonly
        self.warn = True
        self.hysteresis = 0.0005

    @property
    def price(self):
        result = self.priceobj.evalprice(self.tapp)
        if result is not None:
            result = D(result)
            if self.side == OrderMsg.SELL:
                result = self.tapp.symbols.round_up(self.venue, self.sym, result)
            else:
                result = self.tapp.symbols.round_dn(self.venue, self.sym, result)
        return result

    def subscriptions(self):
        set_ = self.priceobj.subscriptions()
        return super(DynamicLimit, self).subscriptions().union(set_)

    def extra_algo_info(self):
        return ' price:{} {}'.format(self.pricejpl, self.price)

    def _work(self):
        if self.check_algo_done(): 
            self.cancelworkingorder()
            self.state = self.DONE
            return

        if self.state == self.INACTIVE and self.workingid:
            self.cancelworkingorder()

        if self.price is None:
            if self.warn:
                self.tapp.logger.info('waiting for price for {}'.format(self.pricejpl))
                self.warn = False
            if self.workingid: 
                self.cancelworkingorder()
            return

        if self.state == self.WORKING:
            if self.workingid is None:
                if time.time() < self.nextsendtime: return
                if self.qty < self.schunk:
                    # in theory, schunk > qty > filled, so no explicit checks required
                    qty = self.schunk - self.filled
                else:
                    qty = min(self.remain, self.schunk)
                qty = self.tapp.symbols.round_lot(self.venue, self.sym, qty)
                
           
                self.workingid = self.tapp.lmtorder(self.account, self.sym, self.side, str(qty), str(self.price),
                                                    cancross=not self.postonly, overridechecks=True, strategy=self.strategy)
                self.myids.add(self.workingid)
                if self.ttl > 0:
                    self.waituntil = D(time.time()) + self.ttl
            else:
                order0 = self.tapp.orders[self.workingid]
                if order0 is None: return

                if self.ttl > 0:
                    if time.time() > self.waituntil:
                        if self.price == D(order0.price):
                            self.waituntil = D(time.time()) + self.ttl
                        elif order0.status in OrderMsg.ACTIONABLE:
                            self.cancelworkingorder()
                else:
                    deviation = abs(self.price - D(order0.price)) / self.price
                    if (deviation > self.hysteresis) and (order0.status in OrderMsg.ACTIONABLE):
                        self.cancelworkingorder()


# anxiousness/grefp knockout
class Work(Algo):
    def __init__(self, tapp, account, sym, side, kojpl, qty, schunk, ttl):
        super(Work, self).__init__(tapp, account, sym, side, kojpl, qty, schunk)
        self.kwargs.update({'ttl': ttl})
        self.ttl = D(ttl)
        assert self.ttl > 0
        self.waituntil = 0
        self.k = 1
        self.step = None
        self.tgtp = None

    def extra_algo_info(self):
        return ' k:{} step:{}, tgtp:{}'.format(pricepp(self.k), pricepp(self.step), pricepp(self.tgtp))

    def tgtprice(self):
        book = self.tapp.getbook(self.venue, self.sym)
        if book is None: return None
        bids = book.best_bids(5, cleanorders=self.tapp.ourmktbids(self.venue, self.sym))
        asks = book.best_asks(5, cleanorders=self.tapp.ourmktasks(self.venue, self.sym))
        best_ask, best_bid = None, None
        if bids: best_bid = D(bids[0][0])
        if asks: best_ask = D(asks[0][0])
        if best_ask is None or best_bid is None: return None

        bookwidth = best_ask - best_bid
        mid = (best_bid + best_ask)/2

        if self.side == OrderMsg.BUY:
            ticksize = self.tapp.symbols.getticksize(self.venue, self.sym, best_bid, up=True)
        else:
            ticksize = self.tapp.symbols.getticksize(self.venue, self.sym, best_ask, up=False)

        self.step = max(self.tapp.symbols.round_dn(self.venue, self.sym, bookwidth/8), ticksize)/mid
        
        if self.side == OrderMsg.BUY:
            myprice = self.tapp.symbols.round_dn(self.venue, self.sym, mid*self.k)
            return min(myprice, best_ask)
        else:
            self.step = -self.step
            myprice = self.tapp.symbols.round_up(self.venue, self.sym, mid*self.k)
            return max(myprice, best_bid)

    def _work(self):
        if self.check_algo_done():
            self.cancelworkingorder()
            self.state = self.DONE
            return

        if self.state == self.INACTIVE and self.workingid:
            self.tapp.logger.info('calling cancelworkingorder on {}'.format(self.workingid))
            self.cancelworkingorder()

        qty = min(self.schunk, self.remain)
        qty = self.tapp.symbols.round_lot(self.venue, self.sym, qty)
        self.tgtp = self.tgtprice()
        
        if self.state == self.WORKING:

            if not self.check_price_ok(self.tgtp): return
            if self.workingid is None:
                if self.tgtp:
                    if time.time() < self.nextsendtime: return
                    self.workingid = self.tapp.lmtorder(self.account, self.sym, self.side, str(qty), str(self.tgtp), cancross=True, strategy=self.strategy)
                    self.myids.add(self.workingid)
                    self.waituntil = D(time.time()) + self.ttl
            else:
                order0 = self.tapp.orders[self.workingid]
                if order0 is None: return
                if D(time.time()) > self.waituntil:
                    if self.tgtp == D(order0.price):
                        self.waituntil = D(time.time()) + self.ttl
                        self.k += self.step
                    elif order0.status in OrderMsg.ACTIONABLE:
                        self.cancelworkingorder()
                        
    def on_order_event(self, internalid):
        self.myfills[internalid] = self.tapp.orders[internalid].filled
        self.filled = sum([D(x) for x in self.myfills.values()])
        self.remain = self.qty - self.filled

        order0 = self.tapp.orders[internalid]
        if order0 and order0.status not in OrderMsg.LIVESTATES:
            #remove if no fills
            if D(order0.filled) == 0:
                self.myids.discard(internalid)
                del self.myfills[internalid]
            
            if self.workingid == internalid:
                if D(order0.filled) > 0:
                    self.k -= self.step
                else:
                    if order0.status != OrderMsg.REJECTED:
                        self.k += self.step
                    else:
                        self.retries = self.retries + 1
                        self.nextsendtime = time.time() + 1
                        if (self.retries > 5):
                            self.tapp.logger.info('order {} got rejected, retrying {} times'.format(order0, self.retries))
                            if self.state == self.WORKING:
                                self.state = self.ERROR
                                self._stop() 
                self.workingid = None
                self.nextcxltime = 0


class Snipe(Algo):
    def __init__(self, tapp, account, sym, side, kojpl, qty, schunk):
        super(Snipe, self).__init__(tapp, account, sym, side, kojpl, qty, schunk)

    def _work(self):
        if self.check_algo_done():
            self.cancelworkingorder()
            self.state = self.DONE
            return
        
        if self.state == self.INACTIVE and self.workingid:
            self.cancelworkingorder()

        if self.state == self.WORKING:
            if self.workingid is None:
                book = self.tapp.getbook(self.venue, self.sym)
                if book is None: return

                if self.side == OrderMsg.BUY:
                    ask = book.best_asks(5, cleanorders=self.tapp.ourmktasks(self.venue, self.sym))
                    if ask:
                        price = D(ask[0][0])
                        sz = D(ask[0][1])
                    else:
                        return
                else:
                    bid = book.best_bids(5, cleanorders=self.tapp.ourmktbids(self.venue, self.sym))
                    if bid:
                        price = D(bid[0][0])
                        sz = D(bid[0][1])
                    else:
                        return

                if not self.check_price_ok(price): return

                qty = min(sz, self.remain, self.schunk)
                qty = self.tapp.symbols.round_lot(self.venue, self.sym, qty)
                if time.time() < self.nextsendtime: return
                self.workingid = self.tapp.lmtorder(self.account, self.sym, self.side, str(qty), str(price),
                                                    cancross=True, strategy=self.strategy)
                self.myids.add(self.workingid)
            else:
                order0 = self.tapp.orders[self.workingid]
                # simulate FOK
                if order0 and order0.status in OrderMsg.ACTIONABLE:
                    self.cancelworkingorder()

class Slice(Algo):

    def __init__(self, tapp, account, sym, side, kojpl, qty, schunk, tchunk):
        super(Slice, self).__init__(tapp, account, sym, side, kojpl, qty, schunk)
        self.kwargs.update({'tchunk': tchunk})
        assert type(tchunk) == str  
        self.tchunk = D(tchunk)
        assert self.tchunk > 0

    def _work(self):
        if self.check_algo_done():
            self.cancelworkingorder()
            self.state = self.DONE
            return

        if self.state == self.INACTIVE and self.workingid:
            self.cancelworkingorder()

        if self.state == self.WORKING:
            theo_done = self.elapsed/self.tchunk*self.schunk
            ahead = theo_done < self.filled
            if ahead: return

            if self.workingid is None:
                book = self.tapp.getbook(self.venue, self.sym)
                if book is None: return
                price = None
                if self.side == OrderMsg.BUY:
                    if book.best_ask is not None:
                        price,_ = book.best_ask
                else:
                    if book.best_bid is not None:
                        price,_ = book.best_bid
                if not self.check_price_ok(price): return

                qty = D(np.random.normal(self.schunk, self.schunk/2))
                lowerbound = self.lotsize
                upperbound = 2 * self.schunk - self.lotsize
                if qty <= lowerbound:
                    qty = lowerbound
                elif qty >= upperbound:
                    qty = upperbound
                else:
                    qty = self.tapp.symbols.round_lot(self.venue, self.sym, qty)

                qty = min(qty, self.remain)
                qty = self.tapp.symbols.round_lot(self.venue, self.sym, qty)

                if time.time() < self.nextsendtime: return
                self.workingid = self.tapp.lmtorder(self.account, self.sym, self.side, str(qty), str(price), cancross=True, overridechecks=True, strategy=self.strategy)
                self.myids.add(self.workingid)
            else:
                order0 = self.tapp.orders[self.workingid]
                #simulate FOK
                if order0 and order0.status in OrderMsg.ACTIONABLE:
                    self.cancelworkingorder()

class Dime(Algo):
    def __init__(self, tapp, account, sym, side, kojpl, qty, schunk, joinratio):
        super(Dime, self).__init__(tapp, account, sym, side, kojpl, qty, schunk)
        self.kwargs.update({'joinratio': joinratio})
        self.joinratio = D(joinratio)
        assert self.joinratio >= 0
        self.tgtp = None

    def extra_algo_info(self):
        return ' tgtp:{}'.format(self.tgtp)

    def tgtprice(self):
        book = self.tapp.getbook(self.venue, self.sym)
        if book is None: return

        bid = book.best_bids(5, cleanorders=self.tapp.ourmktbids(self.venue, self.sym))
        ask = book.best_asks(5, cleanorders=self.tapp.ourmktasks(self.venue, self.sym))

        if bid:
            mktbestbid = D(bid[0][0])
            mktbestbidsz = D(bid[0][1])
        else:
            return

        if ask:
            mktbestask = D(ask[0][0])
            mktbestasksz = D(ask[0][1])
        else:
            return

        if self.side == OrderMsg.BUY:
            ticksize = self.tapp.symbols.getticksize(self.venue, self.sym, mktbestbid, up=True)
            mktbestbidplus1 = mktbestbid + ticksize
            if (mktbestbidsz <= self.qty * self.joinratio) or (mktbestbidplus1 >= mktbestask):
                return mktbestbid
            else:
                return mktbestbidplus1
        else:
            ticksize = self.tapp.symbols.getticksize(self.venue, self.sym, mktbestask, up=False)
            mktbestaskminus1 = mktbestask - ticksize
            if (mktbestasksz <= self.qty * self.joinratio) or (mktbestaskminus1 <= mktbestbid):
                return mktbestask
            else:
                return mktbestaskminus1
            
    def _start(self):
        self.tgtp = self.tgtprice()
            
    def _work(self):
        if self.check_algo_done():
            self.cancelworkingorder()
            self.state = self.DONE
            return

        if self.state == self.INACTIVE and self.workingid:
            self.cancelworkingorder()

        if self.state == self.WORKING:
            if self.workingid is None:
                # without this, we would actually dime outselves because the book message would come after hte order message
                if not self.tgtp:
                    self.tgtp = self.tgtprice()
                    
                if not self.check_price_ok(self.tgtp): return 
                if time.time() < self.nextsendtime: return
                qty = min(self.remain, self.schunk)
                qty = self.tapp.symbols.round_lot(self.venue, self.sym, qty)
                self.workingid = self.tapp.lmtorder(self.account, self.sym, self.side, str(qty), str(self.tgtp),
                                                    cancross=False, strategy=self.strategy)  # should be able to cross in the future
                self.myids.add(self.workingid)

            else:
                self.tgtp = self.tgtprice()
                order0 = self.tapp.orders[self.workingid]

                if self.tgtp and order0 and (D(order0.price) != self.tgtp) and (order0.status in OrderMsg.ACTIONABLE):
                    self.cancelworkingorder()

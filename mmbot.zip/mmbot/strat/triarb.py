import logging
import time
import sys
import traceback

import requests
import subprocess

from pubsub import TradingApp
from IPython import embed

rhs_currency_set = {'BTC', 'ETH'}

# Full oppoortunity set, but CCXT doesn't support most
# lhs_currency_set = {'OST', 'EOS', 'LINK', 'OAX', 'STRAT', 'HSR', 'MANA', 'WTC', 'XZC', 'IOTA', 'KNC', 'BNT', 'DASH',
#                     'BNB', 'BQX', 'VIB', 'SNGLS', 'SNM', 'SNT', 'GXS', 'NAV', 'XLM', 'EVX', 'FUN', 'CMT', 'NEBL', 'AMB',
#                     'LSK', 'AION', 'ENG', 'ENJ', 'TRX', 'DLT', 'XRP', 'LRC', 'BTS', 'WABI', 'CND', 'BTG', 'YOYO', 'MOD',
#                     'NEO', 'KMD', 'SUB', 'CTR', 'BCD', 'REQ', 'BCC', 'ETC', 'DGD', 'AST', 'POWR', 'QTUM', 'MDA', 'GVT',
#                     'SALT', 'ELF', 'BCPT', 'ADX', 'GTO', 'LTC', 'DNT', 'ADA', 'VEN', 'RDN', 'XMR', 'ZEC', 'OMG', 'EDO',
#                     'CDT', 'WAVES', 'BRD', 'WINGS', 'BAT', 'NULS', 'RCN', 'GAS', 'PPT', 'POE', 'TNT', 'ICN', 'LEND',
#                     'ZRX', 'STORJ', 'MTH', 'ICX', 'MTL', 'TNB', 'XVG', 'MCO', 'QSP', 'FUEL', 'ARK', 'ARN'}

# Limited set only supported by CCXT
# lhs_currency_set = {'MCO', 'NEO', 'OMG', 'STRAT', 'BCH', 'CTR', 'SNGLS', 'QTUM', 'SNM', 'KNC', 'ZRX', 'WTC', 'LINK',
#                     'XVG', 'FUN', 'BNB', 'SALT', 'IOTA', 'BQX'}

lhs_currency_set = {'XVG', 'QTUM', 'NEO', 'IOTA', 'OMG', 'STRAT'}
PNL_THRESHOLD = 1


def find_pair(symbol):
    if symbol[-3:] in rhs_currency_set:
        lhs = symbol[:-3]
        rhs = symbol[-3:]
    elif symbol[-4:] in rhs_currency_set:
        lhs = symbol[:-4]
        rhs = symbol[-4:]
    else:
        raise ValueError('{} cannot be resolved into a pair'.format(symbol))

    return '{}/{}'.format(lhs, rhs)


def exploratory_work():
    url = 'https://api.binance.com/api/v1/ticker/allBookTickers'
    r = requests.get(url)
    res = r.json()
    orderbooks = {}
    lhs_set = set()
    for orderbook in res:
        try:
            pair = find_pair(orderbook['symbol'])
        except ValueError as e:
            continue

        lhs, rhs = pair.split('/')

        if pair == 'ETH/BTC':
            ethbtc = orderbook
        elif rhs in rhs_currency_set:
            lhs_set.update([lhs])
            orderbooks[pair] = orderbook
    l = []
    for lhs in lhs_set:
        edge1 = lhs + '/BTC'
        edge2 = lhs + '/ETH'

        # Start with 1 BTC -> to LHS currency -> to ETH -> back to BTC
        try:
            clockwise_cycle = 1 / float(orderbooks[edge1]['askPrice']) * float(orderbooks[edge2]['bidPrice']) * float(
                ethbtc['bidPrice'])

            # Start with 1 BTC -> to ETH -> to LHS currency -> back to BTC
            anti_clockwise_cycle = 1 / float(ethbtc['askPrice']) * 1 / float(orderbooks[edge2]['askPrice']) * float(
                orderbooks[edge1]['bidPrice'])

            l += [edge1, edge2]
        except KeyError:
            continue

        print 'Pnl for {:5}: {:06.4f} {:06.4f}'.format(lhs, clockwise_cycle, anti_clockwise_cycle)


class TriangleArb(TradingApp):
    def __init__(self):
        super(TriangleArb, self).__init__(on_book=self.__on_book, md_only=True)
        self.books_not_ready = set()

        self.venue = 'binance'
        self.subscribe('%s' % self.venue, 'ETH/BTC')
        self.books_not_ready.update([(self.venue, 'ETH/BTC')])

        self.opps_fname = 'data/log/tri_arb_opps.log'
        self.opps_id_fname = 'data/log/tri_arb_opps_id.log'

        self.current_opps = dict()  # dict of string denoting path mapping to opp_id e.g. BTC:NVG:ETH:BTC->5
        self.opps_id = dict()  # dict of opp_id mapping to path e.g. 5->BTC:NVG:ETH:BTC

        try:
            self.next_opp_id = int(subprocess.check_output(['tail', '-1', 'data/log/tri_arb_opps_id.log']).split(',')[0]) + 1
        except subprocess.CalledProcessError:
            self.next_opp_id = 0

        # self.pnl_file = open('data/log/tri_arb_opps.log', 'a')
        # self.opps_id_file = open('data/log/tri_arb_opps_id.log', 'a')

        for lhs in lhs_currency_set:
            self.subscribe(self.venue, lhs + '/BTC')
            self.subscribe(self.venue, lhs + '/ETH')

            self.books_not_ready.update([(self.venue, lhs + '/BTC')])
            self.books_not_ready.update([(self.venue, lhs + '/ETH')])

    def __on_book(self, exchange, pair, data):
        try:
            self.books_not_ready.remove((exchange, pair))
        except KeyError:
            pass

        if len(self.books_not_ready) > 0:
            return

        if pair == 'ETH/BTC':
            # recalc everything
            for lhs in lhs_currency_set:
                pnl = self.__triangle_pnl(lhs)
                # self.__log_pnl(lhs, pnl)

        else:
            # only recalc triangle involving the lhs pair
            lhs = pair.split('/')[0]
            pnl = self.__triangle_pnl(lhs)

    def __triangle_pnl(self, lhs):
        ts = time.time()

        ethbtc = self.getbook(self.venue, 'ETH/BTC')
        edge1 = self.getbook(self.venue, lhs + '/BTC')
        edge2 = self.getbook(self.venue, lhs + '/ETH')

        # TODO remove try except?
        # Start with 1 BTC -> to LHS currency -> to ETH -> back to BTC
        clockwise_cycle_pnl = 1 / float(edge1.best_ask[0]) * float(edge2.best_bid[0]) * float(ethbtc.best_bid[0])
        qty_lhs = float(edge1.best_ask[1])
        qty_eth = min(qty_lhs * float(edge2.best_bid[0]), float(edge2.best_bid[1]))
        clockwise_qty = min(qty_eth * float(ethbtc.best_bid[0]), ethbtc.best_bid[1])

        # Start with 1 BTC -> to ETH -> to LHS currency -> back to BTC
        anti_clockwise_pnl = 1 / float(ethbtc.best_ask[0]) * 1 / float(edge2.best_ask[0]) * float(edge1.best_bid[0])
        qty_eth = float(ethbtc.best_ask[1])
        qty_lhs = min(qty_eth / float(edge2.best_ask[0]), float(edge2.best_ask[1]))
        anti_clockwise_qty = min(qty_lhs * float(edge1.best_bid[0]), edge1.best_bid[1])

        # print lhs, clockwise_cycle_pnl, anti_clockwise_pnl

        # if opportunity is new, generate a opportunity id and add the route to an opp table
            # write opportunity in file

        # if opportunity is existing, find the opp id

        # if no opportunity but it was existing just before, write to file the the opp has ended

        # if no opportunity but it was not existing before, do nothing

        if clockwise_cycle_pnl > PNL_THRESHOLD:
            path = 'BTC:{}:ETH:BTC'.format(lhs)
            profit_margin = clockwise_cycle_pnl
            opp_size = clockwise_qty
        elif anti_clockwise_pnl > PNL_THRESHOLD:
            path = 'BTC:ETH:{}:BTC'.format(lhs)
            profit_margin = anti_clockwise_pnl
            opp_size = anti_clockwise_qty
        else:
            profit_margin = None

        if profit_margin is not None:
            if path in self.current_opps:
                opp_id = self.current_opps[path]
            else:
                opp_id = self.next_opp_id
                self.next_opp_id += 1
                self.current_opps[path] = opp_id

                with open(self.opps_id_fname, 'a') as f:
                    f.write('{},{}\n'.format(opp_id, path))

            with open(self.opps_fname, 'a') as f:
                f.write('{},{},{},{}\n'.format(opp_id, ts, (profit_margin - 1) * 10000, opp_size))
        else:
            paths = ['BTC:{}:ETH:BTC'.format(lhs), 'BTC:ETH:{}:BTC'.format(lhs)]

            for path in paths:
                if path in self.current_opps:
                    opp_id = self.current_opps.pop(path)
                    with open(self.opps_fname, 'a') as f:
                        f.write('{},{},{},{}\n'.format(opp_id, ts, 0, 0))
                else:
                    pass

        return clockwise_cycle_pnl, anti_clockwise_pnl

    def run(self):
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            sys.exit()


def main():
    # exploratory_work()

    triarb = TriangleArb()
    triarb.run()


if __name__ == '__main__':
    main()


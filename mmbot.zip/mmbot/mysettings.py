import reference

OMS_PUBPORT='5559'
OMS_SUBPORT='5560'
MD_PUBPORT='5561'
MD_SUBPORT='5562'
EVENT_PUBPORT='5563'
EVENT_SUBPORT='5564'
CMD_PUBPORT='5565'
CMD_SUBPORT='5566'

TIMEOUT_PENDING_NEW=60*60

MONGO_HOST='prod.sensusmarkets.com'
MONGO_PORT=27017
REDIS_HOST='127.0.0.1'
REDIS_PORT=6379
CORE_HOST='127.0.0.1'
CORE_PORT=8001
ALERTSERVER_HOST='127.0.0.1'
ALERT_HBPERIOD=10
LOGDIR='log/'
MD_TRADE_CACHE_SECS=180  

MARK_INTERVAL = 60*5

venues = ['anxpro','binance','bitmex','bitfinex','bitstamp','bittrex','gdax','okexspot','okexfut','kraken','poloniex','huobipro','itbit','cf','deribit','kucoin']#'bitmextest','yobit','gateio','coinexchange','tidex','bitz','zb','hitbitc']
currencies=['BTC','ETH','USDT','LTC','XRP','BCH','ADA','EOS','ETC','BNB','SOUL']
indices=[]

manifest = reference.Symbols().generate_manifest(venues=venues, currencies=currencies, indices=indices)

if 'anxpro' in manifest:
    manifest['anxpro']['credentials'].append(
        {'alias':'sensus',
         'apiKey':'3fdafb37-2030-45df-9f39-7adfbb59be64',
         'secret':'EuOTS3vnORF3YDBdW6DwlY+oWEwkiVHK7gImdjfChHp+r8W+i7FLoSX397bPns/TMi8CBLQ+VzmunBG7aFe+SA=='})

if 'binance' in manifest:
    manifest['binance']['credentials'].append(
        {'alias':'sensus',
         'apiKey':'La84qrpptKjBcmOlXOQORgIa1elr7eSmMRWQHks03cANkrP42CGqFQZ4H6WYQfx1',
         'secret':'lie993cCAhIcIXbbVAs3NAgv5WDIwn3oPdTB9YF1h8WOEfJRhVtA5HXi5HTVWQ15'})

if 'bitmex' in manifest:
    manifest['bitmex']['credentials'].append(
        {'alias':'vfg',
         'apiKey':'rj4s76sS6RVsiXfVbbR77XsI',
         'secret':'IzUo1rrvTCY-ZHj9hqlS2yObIlq6lNMS9-PznsL4BU7UFokf'})

if 'kucoin' in manifest:
    manifest['kucoin']['credentials'].append(
        {'alias':'vfg',
         'apiKey': '5a6bfacc1e789d36286713b9',
         'secret': '455ca0a6-415b-47b0-89b6-021b650f26b8'})

if 'okexspot' in manifest:
    manifest['okexspot']['credentials'].append(
        {'alias':'vfg',
         'apiKey':'fd57f615-e9d6-47c2-9b54-7cb4eed55763',
         'secret':'8388BB8EF4A68C802FC14FA8F8CD4209'})

if 'okexfut' in manifest:
    manifest['okexfut']['credentials'].append(
        {'alias':'vfg',
         'apiKey':'fd57f615-e9d6-47c2-9b54-7cb4eed55763',
         'secret':'8388BB8EF4A68C802FC14FA8F8CD4209'})

if 'bittrex' in manifest:
    manifest['bittrex']['credentials'].append(
        {'alias':'vfg',
         'apiKey':'9ef49a5e6e6540618c0683463c539500',
         'secret':'e2881ad2cac2439c85fd0793250c218a'})

if 'yobit' in manifest:
    manifest['yobit']['defaultsyms'] = ['LOOM/ETH','LOOM/BTC','ETH/BTC']
    manifest['yobit']['credentials'].append(
        {'alias':'vfg',
         'apiKey':'552B3FB90C015C0A35DA5536ED279996',
         'secret':'be53fe85f443cb097bb84d30bf390023'})

if 'bitfinex' in manifest:
    manifest['bitfinex']['credentials'].append(
        {'alias':'vfg',
         'apiKey':'xf25sb2nzPs0Kcc7oqNT0lEdWb9l68QMyL7Yxpu1SlW',
         'secret':'O6Gz2EZOKWHodxwMKWskx9EZYJY5vOSocpN3K7qBNkP'})

if 'gateio' in manifest:        
    manifest['gateio']['credentials'].append(
       {'alias':'vfg',
        'apiKey': 'F682D6B5-EE08-4F43-8757-07FB9F5602BE',
        'secret': '64735a99f7cc0addf5be2ad002dd742758b21bc4d93000adf8ab1df9430b2cb1'})

if 'hitbtc' in manifest:
    manifest['hitbtc']['credentials'].append(
       {'alias':'vfg',
        'apiKey': '57c9e529b55ba045a8bae6a47d9c53a8',
        'secret': '462c070f6beb59319db2d14da1b35f91'})

if 'kraken' in manifest:
    manifest['kraken']['credentials'].append(
        {'alias':'vfg', 
         'apiKey': 'lMPzZfO41C/JVbBtjub7+LbaHh/uyjv9u2dAqCYtPj10uOYVsbfRlggy',
         'secret': 'KjttKHJiSrZSKIQvKF6Lj9OMWuwyjIMLKGpwqAUSBu9dD6mdLtadZsJQhYnzgFZHRNmHlYYTVp4qR0mx55NnDw=='})

if 'bitmextest' in manifest:
    manifest['bitmextest']['credentials'].append(
        {'alias':'x',
         'apiKey':'avyfqwra-clH97jv60Jf5WYi',
         'secret':'MKrUJVCswkY3YtQxKXQUKU9EAwHDB1M-XPihhub9Od4ypoYa'})

if 'itbit' in manifest:
    manifest['itbit']['credentials'].append(
        {'alias':'vfg',
         'userId': '9D917A71-16A1-40BB-BEB2-DC41B85E100B',
         'apiKey': '9bICvfABukQq9Yynt+5qzA',
         'secret': '84A26flUP9yJgQd7CbkTpZ4yHeYljG0V7qUHbEmeAVs'})

if 'deribit' in manifest:
    manifest['deribit']['credentials'].append(
        {'alias':'vfg',
         'apiKey': '2nd7qTjiCtjb3',
         'secret': 'AW7RHJY6KA3Q767XWH7VUYRB64KPLEGV'})

if 'cf' in manifest:
    manifest['cf']['credentials'].append(
        {'alias':'vfg',
         'apiKey':'kCi6TQNW5RfK8gQfdo+8c2WTs4djjxCpwlV9oPCNHlIe3EeufeQMwTPV',
         'secret':'d4FLEXEDORnrf58JkHKY+5OcfBNMJjCRe0PLZdZDCYq/h7I9+EkOBHMq6aaA7VkW1dknBQpjq97Pw3WDisfJoaSq'})

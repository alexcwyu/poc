# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, May 2018
from gevent import monkey
monkey.patch_all()
import threading
from utils import OrderMsg, Fill
import zmq.green as zmq
import time
import json
import base

# how to use:
#  set up an ssh tunnel (can use autossh)
#    autossh -L12125:localhost:12125 -i <keyfile> ec2-user@13.229.119.166
#
class lmaxuat (base.Gateway):
    def __init__(self, credentials=[]):
        super(lmaxuat, self).__init__(credentials, ccxtname='bitstamp') #dummy

        assert len(self.accounts) == 1 #data only
        self.__running = False

    def _listen(self):
        ctx = zmq.Context()
        sock = ctx.socket(zmq.SUB)
        sock.connect("tcp://localhost:12125")
        topicfilter = ""
        sock.setsockopt(zmq.SUBSCRIBE, topicfilter)
        while self.__running:
            msg = sock.recv()
            channel, msg = msg.split(None, 1) #splits first space only
            if channel == 'fullbook':
                x = json.loads(msg)
                self.dispatch('book', x['symbol'], x['bids'], x['asks'], None, time.time(), bFullBook=True)
            else:
                self.logger.error('Channel {} not supported'.format(channel))

        self.dispatch('disconnected', self.venue)

    def start(self):
        self.__running = True
        t = threading.Thread(target=self._listen)
        t.daemon = True
        t.start()
        self.dispatch('connected', self.venue)

    def stop(self):
        self.__running = False

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, April 2018
from gateways import DATADIR
from collections import defaultdict
from cdecimal import Decimal
import logging
import time, datetime, pytz
import websocket
import Queue
import threading
import hashlib
import json
import reference
import utils
from utils import OrderMsg, dec_to_str, Fill, Position, Wallet
import ccxt
import base
import re
import uuid
import os
import risk

HKT = pytz.timezone('Asia/Hong_Kong')

#Look here for exchange version:
#https://github.com/OKCoin/websocket/blob/master/python/okcoin_websocket.py

#Docs
#https://www.okex.com/ws_api.html

SPOT = reference.Symbols.SPOT
FUTURE = reference.Symbols.FUTURE
LONG = 'LONG'
SHORT = 'SHORT'
ORDERS_PAGE_LENGTH = 50 #Max 50
FIXED = 'FIXED'
CROSS = 'CROSS'
MARGIN_MODE = CROSS
LEVERAGE = 20.

CONTRACT_TYPES = ['this_week', 'next_week', 'quarter']

class okex (base.Gateway):
    def __init__(self, url, credentials=[]):
        super(okex, self).__init__(credentials=credentials, ccxtname='okex', enableRateLimit=True)
        self.url = url

        self.msgQ = Queue.Queue()
        self.procmsg = None

        self.cmap = {}
        self.bookmsgs = defaultdict(int)

        self.pinging = False
        self.pingthread = None

        self.poll_period = 10

        if len(self.accounts) > 2:
            raise Exception('Only supports 1 private')
        
        for account in self.accounts.keys():
            if account == 'data': continue

            #Temporary fields to only support 1 account; need to use self.accounts objects in the future
            self.key = self.accounts[account]['cred']['apiKey']
            self.secret = self.accounts[account]['cred']['secret']
            self.account = account

    def _on_open(self, ws):
        self.dispatch('connected', self.venue)

        self.pinging = True
        self.pingthread = threading.Thread(target=self.sendpings)
        self.pingthread.daemon = True
        self.pingthread.start()

        if len(self.accounts) > 1:
            self.send_signed({'event':'login'})

    def _on_message(self, ws, message):
        msg = json.loads(message, parse_float=Decimal, parse_int=Decimal)
        if not self.checkpong(msg):
            try:
                self.msgQ.put(msg[0])
            except Exception as e:
                self.logger.error('_on_message {} {}'.format(e, msg))

    def _on_close(self, ws):
        self.pinging = False
        if self.pingthread and self.pingthread.isAlive():
            self.pingthread.join()
        self.dispatch('disconnected', self.venue)
        
    def _on_error(self, ws, error):
        self.logger.error('Encountered an error in okex ws {}'.format(error))

    def sendpings(self):
        while self.pinging:
            self.ping()
            time.sleep(20)

    def ping(self):
        msg = {'event':'ping'}
        self.ws.send(json.dumps(msg))
        self.logger.info('ping {}'.format(time.time()))

    def checkpong(self, msg):
        try:
            if 'event' in msg and msg['event'] == 'pong':
                self.lastpong = time.time()
                self.logger.info('pong {}'.format(self.lastpong))
                return True
            else:
                return False
        except:
            return False

    def sign(self, params, secretkey):
        sign = ''
        for key in sorted(params.keys()):
            sign += key + '=' + str(params[key]) + '&'
        return hashlib.md5((sign+'secret_key='+secretkey).encode('utf-8')).hexdigest().upper()

    def send_signed(self, msg, parameters={}):
        params = {'api_key':self.key}
        params.update(parameters)
        params['sign'] = self.sign(params, self.secret)
        signedmsg = {'parameters':params}
        signedmsg.update(msg)
        #self.logger.info(signedmsg)
        self.ws.send(json.dumps(signedmsg))
        
    def start(self):
        if self.procmsg == None:
            self.procmsg=threading.Thread(target=self._process_messages, name="processmsg")
            self.procmsg.daemon = True
            self.procmsg.start()

        self.ws = websocket.WebSocketApp(self.url,
                                         on_message=self._on_message,
                                         on_open=self._on_open,
                                         on_close=self._on_close,
                                         on_error=self._on_error)
        t = threading.Thread(target=self.ws.run_forever)
        t.daemon = True
        t.start()

    def stop(self):
        self.ws.close()

    def parse(self, msg):
        self.logger.error("parse not implemented - needs to be overidden!")
    
    def convertstatus(self, status):
        #-1: cancelled, 0: pending ,1:pfill, 2:fullfill, 4:cancel request in progress
        #Well turns out because okex is at least schizophrenic 3 is also cancel request in progress for the spot API
        status0 = {-1:OrderMsg.CANCELED,
                    0:OrderMsg.NEW, #pending is actually new
                    1:OrderMsg.PARTIALLY_FILLED,
                    2:OrderMsg.FILLED,
                    3:OrderMsg.PENDING_CANCEL,
                    4:OrderMsg.PENDING_CANCEL,
                    5:OrderMsg.CANCELED}[status]
        return status0

    def _process_messages(self):
        while True:
            try:
                #need the timeout as upon a restart, self.msgQ could have changed but would have blocked on the old queue otherwise                                                                        
                msg = self.msgQ.get(timeout=0.2)
            except Exception as e:
                continue
            try:
                self.parse(msg)
            except Exception as e:
                self.logger.error('_process_messages {} {}'.format(e, msg), exc_info=True)

    def dummy_diff_fill(self, account, theirorder, ourorder):
        f2 = Decimal(0) if not theirorder.filled else Decimal(theirorder.filled)
        f1 = Decimal(0) if not ourorder.filled else Decimal(ourorder.filled)
        if f2 > f1: #Need to dummy up filled messages                                                                                                                                               
            fillamt = f2 - f1
            avgp2 = Decimal(theirorder.avgp)
            if ourorder.avgp: avgp1 = Decimal(ourorder.avgp)
            else: avgp1 = 0
            fillp = (avgp2*f2 - avgp1*f1)/fillamt

            prev_cost = 0 if ourorder.cost is None else ourorder.cost
            new_cost = 0 if theirorder.cost is None else theirorder.cost
            cost = Decimal(new_cost) - Decimal(prev_cost)
            return Fill(account=account,
                        tradeid=str(uuid.uuid4()),
                        orderid=ourorder.orderid,
                        symbol=ourorder.symbol,
                        amt=str(fillamt),
                        side=ourorder.side,
                        price=str(fillp),
                        cost=utils.norm_str(cost),
                        costccy=theirorder.costccy,
                        last_ts=theirorder.lastupdated)
        else:
            return None

        
class okexspot (okex):
    def __init__(self, credentials=[]):
        url = 'wss://real.okex.com:10441/websocket'
        super(okexspot, self).__init__(url, credentials=credentials)

    def subscribe_override(self, sym):
        self.logger.info("Trying to subscribe to symbol {}".format(sym))
        type = self.symbols.instrumenttype(self.venue, sym)
        if type == SPOT:
            vsym = self.symvert(sym=sym)
            for channel,mychan in [('ok_sub_spot_{}_depth','depth'), ('ok_sub_spot_{}_deals','trade')]:
                self.ws.send(json.dumps({'event':'addChannel',
                                         'channel':channel.format(vsym)}))
                self.bookmsgs[sym] = 0
                self.cmap[channel.format(vsym)] = (mychan, sym)
        else:
            self.logger.info("Unrecognised symbol {} type {} for okexspot".format(sym, type))

    def getrestbooks(self, symbol):
        return None
            
    def getrestopenorders(self, account):
        syms=set([self.symvert(sym=o.symbol) for o in self.open_orders_dict(account).values()])
        open_orders = []
        method = 'privatePostOrderHistory'                  
        for sym0 in syms:
            request  = {'symbol': sym0,
                        'status': 0,
                        'current_page': 1,
                        'page_length': 200}

            self.wait_for_low_priority_slot(account)
            response = self.ccxt_rest_call(account, method, [request])
            if 'orders' in response:
                open_orders += [self.parse_rest_order(account, o) for o in response['orders']]
        return open_orders

    #ccxt doesn't have fetch_orders so need to get closed orders separately
    def getrestclosedorders(self, account):
        syms=set([self.symvert(sym=o.symbol) for o in self.open_orders_dict(account).values()])
        closed_orders = []
        method = 'privatePostOrderHistory'                  
        for sym0 in syms:
            request  = {'symbol': sym0,
                        'status': 1,
                        'current_page': 1,
                        'page_length': 200}

            self.wait_for_low_priority_slot(account)
            response = self.ccxt_rest_call(account, method, [request])
            if 'orders' in response:
                closed_orders += [self.parse_rest_order(account, o) for o in response['orders']]
        return closed_orders
    
    #getrestorder need to override as ccxt fetch_order requires symbol
    def getrestorder(self, account, ordermsg):
        method = 'privatePostOrderInfo'        
        try:
            request  = {'symbol': self.symvert(sym=ordermsg.symbol),
                        'order_id': ordermsg.orderid}
            self.wait_for_low_priority_slot(account)
            response = self.ccxt_rest_call(account, method, [request])
            if 'orders' not in response or len(response['orders']) == 0:
                self.logger.info("Order not found {} cancelling internally".format(ordermsg))
                ordermsg.status=OrderMsg.CANCELED
                return ordermsg
            else:
                return self.parse_rest_order(account, response['orders'][0])
        except Exception as e:
            self.logger.error("Exception encountered in getrestorder {}".format(e), exc_info=True)
            return None

    def getrestbalances(self, account):
        request = {}
        method = 'private_post_userinfo'
        self.wait_for_low_priority_slot(account)
        response = self.ccxt_rest_call(account, method)
        borrow, freebal, totbal = {}, {}, {}
        if 'info' in response:
            if 'funds' in response['info']:

                #Not used at the moment
                #if 'borrow' in response['info']['funds']:
                    #for ccy, amt in response['info']['funds']['borrow']:
                    #    borrow[self.symbols.canonical(self.venue, ccy.upper())] = amt

                freedict = response['info']['funds']['free']
                freezed_dict = response['info']['funds']['freezed']

                totdict = defaultdict(lambda: Decimal('0'))
                for ccy in set(freedict.keys() + freezed_dict.keys()):
                    totdict[ccy] = Decimal(freedict.get(ccy, '0')) + Decimal(freezed_dict.get(ccy, '0'))

            fbal = {self.symbols.canonical(self.venue, ccy0):utils.norm_str(amt) for ccy0,amt in freedict.items()}
            tbal = {self.symbols.canonical(self.venue, ccy0):utils.norm_str(amt) for ccy0,amt in totdict.items()}

        return {'default': (tbal, fbal, fbal)}

    #override to prevent base logging message, okexspot should not have positions aside from balances
    def getrestpositions(self, account):
        return {}

    #REST overrides
    #need to override this as okex has no fill messages                                                                                                                                                  
    def getfullstate(self, account):
        #Need to lock the entire order matching process to prevent streaming from updating the state causing incorrect fill calculations
        with self.filllock:
            oodict = self.open_orders_dict(account)
            #self.logger.info('I have {} open orders'.format(len(oodict)))
            try:
                openorders = self.getrestopenorders(account)
            except Exception as e:
                self.logger.error('Error getting rest open orders {}'.format(e), exc_info=True)
                openorders = []

            orderhistory = []
            unknown_oids = set(oodict.keys()).difference(set([x.orderid for x in openorders]))
            if len(unknown_oids) > 0:
                try:
                    orderhistory = self.getrestclosedorders(account)
                except:
                    self.logger.error('Error getting rest order history', exc_info=True)
                orderhistory = [o for o in orderhistory if o.orderid in unknown_oids] #filter only for those we are interested in                                                                                                                                                   
            unknown_oids = unknown_oids - set([x.orderid for x in orderhistory])
            standalones = []

            for oid in unknown_oids:
                try:
                    unknown_order = self.getrestorder(account, oodict[oid].asordermsg())
                    if unknown_order is not None:   
                        standalones.append(unknown_order)
                except:
                    self.logger.error('Failed to get rest order {}'.format(oid), exc_info=True)

            unknown_oids = unknown_oids - set([x.orderid for x in standalones])
            if len(unknown_oids) > 0:
                self.logger.error('No info retreived for {} orders'.format(len(unknown_oids)))
                
            theirorders = openorders + orderhistory + standalones
            for theirorder in theirorders:
                if theirorder.orderid in oodict:
                    ourorder = oodict[theirorder.orderid]
                    fill = self.dummy_diff_fill(account, theirorder, ourorder)
                    if fill: self.dispatch('fill', fill)
                else: #unmatched order
                    if Decimal(theirorder.filled) > 0:
                        self.dispatch('fill', Fill(account=account,
                                                   tradeid=str(uuid.uuid4()),
                                                   orderid=theirorder.orderid,
                                                   symbol=theirorder.symbol,
                                                   amt=str(theirorder.filled),
                                                   side=theirorder.side,
                                                   price=theirorder.avgp,
                                                   cost=theirorder.cost,
                                                   costccy=theirorder.costccy,
                                                   last_ts=theirorder.lastupdated))
                self.dispatch('order', theirorder)
        self.getrestwallets(account)
        
    def parse_rest_order(self, account, orderdict):

        rejectmsg = None

        status = self.convertstatus(orderdict['status'])
        symbol = self.symvert(venuesym = orderdict['symbol'])
        assert orderdict['type'] in [OrderMsg.BUY, OrderMsg.SELL]

        cost = None
        costccy = None

        amt = Decimal(str(orderdict['amount']))
        filled = Decimal(str(orderdict['deal_amount']))
        remaining = amt-filled
        omsg = utils.OrderMsg(account=account,
                              orderid=str(orderdict['order_id']),
                              status=status,
                              symbol=symbol,
                              otype=OrderMsg.LMT,
                              amt=str(amt),
                              side=orderdict['type'],
                              price=str(Decimal(str(orderdict['price']))),
                              avgp=str(Decimal(str(orderdict['avg_price']))),
                              filled=str(filled),
                              remaining=str(remaining),
                              cost=cost,
                              costccy=costccy,
                              last_ts=float(orderdict['create_date'])/1000.,
            )

        if status == OrderMsg.REJECTED:
            omsg.rejectmsg = rejectmsg
                
        return omsg
                                                
    def parse_place_result(self, result, omsg):
        #Since omsg is from before placement, the state is still PENDING_NEW
        #Oftentimes the websocket is so fast that it's already updated the state to NEW so this would be a stale update that conflicts
        return None

    def parse_cancel_result(self, result, omsg):
        #Only deals with single cancels for now, no batch cancels
        try:
            if result['result']: 
                omsg.status = OrderMsg.CANCELED
                return omsg
            else:
                return None
        except Exception as e:
            self.logger.error("parse_cancel_result got unexpected msg {}".format(result), exc_info=True)
            return None

    def parse(self, msg):
        if 'product' in msg:
            pass

        elif 'channel' not in msg:
            self.logger.warning('Unrecognized msg - no channel supplied {}'.format(msg))
        elif msg['channel'] in ['addChannel', 'login']:
            #self.logger.info(msg)
            pass
        elif 'future' in msg['channel']:
            pass
        elif 'data' in msg and 'result' in msg['data'] and msg['data']['result'] == False:
            #This is when websocket request return unsuccessfully
            self.logger.error(str(msg))
        elif re.match('ok_sub_spot_(.*)_order', msg['channel']):
            orderdict = msg['data']
            vsym = orderdict['symbol']
            sym = self.symvert(venuesym=vsym)

            amount = Decimal(orderdict['tradeAmount'])
            filled = Decimal(orderdict['completedTradeAmount'])
            orderid = str(orderdict['orderId'])

            #buy sell buy_market sell_market
            if 'buy' in orderdict['tradeType']: side = OrderMsg.BUY
            elif 'sell' in orderdict['tradeType']: side = OrderMsg.SELL
            else: self.logger.error('trade type {} not recognized'.format(orderdict['tradeType']))
            if 'market' in orderdict['tradeType']: otype = OrderMsg.MKT
            else: otype = OrderMsg.LMT

            #-1: cancelled, 0: pending ,1:pfill, 2:fullfill, 4:cancel request in progress
            status0 = self.convertstatus(orderdict['status'])
            
            #rem qty
            rem = orderdict.get('unTrade', None)
            if rem is None:
                rem = amount - filled
            else:
                rem = Decimal(rem)

            orderobj = utils.OrderMsg(account=self.account,
                                      orderid=orderid,
                                      status=status0,
                                      symbol=sym,
                                      otype=otype,
                                      amt=utils.norm_str(amount),
                                      side=side,
                                      price=utils.norm_str(orderdict['tradeUnitPrice']),
                                      avgp=utils.norm_str(orderdict['averagePrice']),
                                      filled=utils.norm_str(filled),
                                      remaining=utils.norm_str(rem),
                                      cost=Decimal('0'),
                                      costccy=self.symbols.getbaseccy(self.venue, sym),
                                      last_ts = float(orderdict['createdDate'])/1000.,
                                      info=orderdict)

            with self.filllock:
                if filled > 0:            
                    prev_orderstate = self.oms.getorderstate(self.account, orderid).asordermsg()
                    fill = self.dummy_diff_fill(self.account, orderobj, prev_orderstate)
                    if fill:
                        self.logger.info('exchange info: {}'.format(orderdict))
                        self.logger.info('dispatching fill info {}'.format(fill))
                        self.dispatch('fill', fill)

                self.dispatch('order', orderobj)

        #'ok_sub_spot_X_balance'
        elif '_balance' in msg['channel']:

            data = msg['data']
            freedict = data['info']['free']
            freezed_dict = data['info']['freezed']

            totdict = defaultdict(lambda: Decimal('0'))
            for ccy in set(freedict.keys() + freezed_dict.keys()):
                totdict[ccy] = freedict.get(ccy, Decimal('0')) + freezed_dict.get(ccy, Decimal('0'))

            freebal = {self.symbols.canonical(self.venue, ccy0):utils.norm_str(amt) for ccy0,amt in freedict.items()}
            totbal = {self.symbols.canonical(self.venue, ccy0):utils.norm_str(amt) for ccy0,amt in totdict.items()}

            #This channel equivalent on futures seems to be bad too - don't dispatch
        
        elif '_depth' in msg['channel']:
            if msg['channel'] in self.cmap:
                mtype, sym = self.cmap[msg['channel']]
            else:
                return
            assert mtype == 'depth'
            data = msg['data']
            bids,asks = [], []

            if 'bids' in data: bids = data['bids']
            if 'asks' in data: asks = data['asks']
            ts0 = float(data['timestamp'])/1000.
            seqnum = ts0

            #For some reason the API still returns zero sizes for first query
            if self.bookmsgs[sym]==0:
                bids = [(x[0], x[1]) for x in bids if x[1] != '0']
                asks = [(x[0], x[1]) for x in asks if x[1] != '0']

            self.dispatch('book', sym, bids, asks, ts0, seqnum, bFullBook=self.bookmsgs[sym]==0)    
            self.bookmsgs[sym] += 1

        elif '_deals' in msg['channel']:
            mtype, sym = self.cmap[msg['channel']]
            assert mtype == 'trade'
            for tradedata in msg['data']:
                tid, price, size, hhmmss, side = tradedata
                size = utils.norm_str(Decimal(size))
                #okex returns hkt here (why the hell would you design it like that)
                #we have to make an assumption that it is at least the same hk date since they don't give us a friggin date
                dt = datetime.datetime.strptime(hhmmss, '%H:%M:%S')
                utcnow = pytz.UTC.localize(datetime.datetime.utcnow())
                hktimenow = utcnow.astimezone(HKT)
                hktimenow.replace(hour=dt.hour, minute=dt.minute, second=dt.second)
                utcdt = hktimenow.astimezone(pytz.UTC) #ok since hkt has no dst
                ts0 = (utcdt.replace(tzinfo=None) - datetime.datetime(1970,1,1)).total_seconds()
                side = 'S' if side == 'ask' else 'B'
                self.dispatch('trade', sym, price, size, side, ts0)

        else:
            self.logger.warning('Unhandled msg {}'.format(msg))

    def restplaceorder(self, ordermsg):
        try:
            symbol = ordermsg.symbol
            ordertype = {OrderMsg.LMT:'limit', OrderMsg.MKT:'market'}[ordermsg.otype]
            side = {OrderMsg.BUY:'buy', OrderMsg.SELL:'sell'}[ordermsg.side]
            amount = Decimal(ordermsg.amt) #s/b string? ccxt is strange                                                                
            price = Decimal(ordermsg.price)
            ccy, marginamt = self.balrequired(symbol, side, amount, price)
            wallet = self.oms.getwallet(self.account, 'default')
            if wallet: freebal = Decimal(wallet.tradable.get(ccy, '0'))
            else: freebal = Decimal(0)
            if freebal < marginamt:
                ordermsg.orderid = str(uuid.uuid4()) #dummy oid
                ordermsg.status = OrderMsg.REJECTED
                ordermsg.rejectmsg = OrderMsg.INSUFFICIENT_FUNDS
                self.dispatch('order', ordermsg)
            else:
                response = self._create_order(symbol, ordertype, side, float(amount), float(price), True)
                omsg = self.parse_place_result(response, ordermsg)
                if omsg: self.dispatch('order', omsg)
                                                
        except Exception as e:
            self.logger.error('Unable to submit order {}'.format(ordermsg), exc_info=True)
            omsg = self.parse_place_exception(e, ordermsg)
            if omsg: self.dispatch('order', omsg)

    def restcancelorder(self, ordermsg):
        try:
            result = self._cancel_order(ordermsg.orderid, ordermsg.symbol)       
            omsg = self.parse_cancel_result(result, ordermsg)
            if omsg: self.dispatch('order', omsg)
        except Exception as e:
            omsg = self.parse_cancel_exception(e, ordermsg)
            if omsg: self.dispatch('order', omsg)
            

    def _create_order(self, symbol, type, side, amount, price, openorder, params={}):
        method = 'privatePostTrade'
        order = {
            'symbol': self.symvert(sym=symbol),
            'type': side,
            'price': price,
            'amount': amount
        }
        response = self.ccxt_rest_call(self.account, method, [self.accounts[self.account]['ccxt'].extend(order, params)])
        #self.logger.info('response: ', response)
        return response

    def _cancel_order(self, orderid, symbol=None, params={}):
        if not symbol:
            raise ccxt.ExchangeError('CancelOrder() requires a symbol argument')
        method = 'privatePostCancelOrder'

        request = {
            'symbol': self.symvert(sym=symbol),
            'order_id': orderid
        }
        response = self.ccxt_rest_call(self.account, method, [self.accounts[self.account]['ccxt'].extend(request, params)])
        return response

class okexfut (okex):
    def __init__(self, credentials=[]):
        url = 'wss://real.okex.com:10440/websocket/okexapi'
        super(okexfut, self).__init__(url, credentials)
        for account in self.accounts:
            if account == 'data': continue
            self.accounts[account]['wallets'] = {'default': False}
        self.querypage = {}  #symbol: page
        self.contractids = defaultdict(lambda: defaultdict) #Some contracts are referred to by an okex contractid that isn't listed elsewhere, use this dict to cache these
        self.unrealised = {} #In cross margin mode the exchange gives only total unrealised profit by ccy, save it here for attribution when we get more position detail

        self.liquidations = set()
        self.miscfilepath = DATADIR + '/okexfut.misc'
        if os.path.exists(self.miscfilepath):
            self.miscfile = open(self.miscfilepath,'a')
        else:
            self.miscfile = open(self.miscfilepath, 'w')


    def start(self):
        super(okexfut, self).start()
        
        if len(self.accounts) > 1:
            class PeriodicLiq(base.Job):
                name = '{}'.format('getliq')
                def run(self0):
                    while self0.name in self.perpetual_jobs:
                        #self.getnewliquidations(self.account)
                        time.sleep(10)
            p = PeriodicLiq()
            if p.name not in self.perpetual_jobs:
                self.perpetual_jobs.add(p.name)
                p.start()
            else:
                self.logger.error('{} job is already running'.format(p.name))

    def stop(self):
        super(okexfut, self).stop()
        self.miscfile.close()

    def getrestbooks(self, symbol):
        return None

    def getresttrades(self, symbol):
        return None

    def getrestbalances(self, account):
        request = {}
        if MARGIN_MODE == FIXED:
            method = 'private_post_future_userinfo_4fix'            
        else:
            method = 'private_post_future_userinfo'
        self.wait_for_low_priority_slot(account)
        response = self.ccxt_rest_call(account, method)
        if 'info' in response:
            return {'default': self.parseuserinfo(account, response)}
        else:
            return {'default': ({}, {}, {})}

    def parseuserinfo(self, account, data):
        info = data['info']
        balance, tradable, withdrawable = {}, {}, {}
        for ccy0 in info:
            ccy = self.symbols.canonical(self.venue, ccy0.upper())

            if MARGIN_MODE == FIXED:
                contracts = info[ccy0]['contracts']
                ccybalance = info[ccy0]['balance']
                rights = info[ccy0]['rights']

                balance[ccy] = Decimal(str(rights))
                tradable[ccy] = Decimal(str(ccybalance))
                withdrawable[ccy] = Decimal(str(rights))

                for contract in contracts:
                    available = str(contract['available'])
                    contract_id = str(contract['contract_id'])
                    profit = str(contract['profit'])
                    unprofit = str(contract['unprofit'])
                    freeze = str(contract['freeze'])
                    contract_type = contract['contract_type']
                    balance = str(contract['balance'])
                    bond = str(contract['bond'])

                    self.contractids[contract_id] = {'available': available,
                                                     'profit': profit,
                                                     'unprofit': unprofit,
                                                     'freeze' : freeze,
                                                     'contract_type': contract_type,
                                                     'balance': balance,
                                                     'bond': bond}
                    
                    balance[ccy] = utils.norm_str(Decimal(balance[ccy] - Decimal(unprofit)))
                    tradable[ccy] = str(available)
                    withdrawable[ccy] = utils.norm_str(Decimal(withdrawable[ccy]) - Decimal(unprofit) - Decimal(profit) - Decimal(freeze))
            else:
                if len(info[ccy0]) > 0:
                    rights = str(info[ccy0]['account_rights'])
                    margin = str(info[ccy0]['keep_deposit'])
                    profit = str(info[ccy0]['profit_real'])
                    if 'profit_unreal' in info[ccy0]:
                        unprofit = str(info[ccy0]['profit_unreal'])
                    else:
                        unprofit = Decimal(rights) - Decimal(margin) - Decimal(profit)

                    self.unrealised[ccy0.upper()] = unprofit
                    self.logger.info('{} setting unrealised: {}'.format(ccy0, unprofit))
                    balance[ccy] = utils.norm_str(Decimal(rights) - Decimal(unprofit))
                    tradable[ccy] = utils.norm_str(Decimal(rights) - Decimal(margin))  #We can trade with this amount - 'available' is actually just what can be withdrawn.
                    withdrawable[ccy] = utils.norm_str(Decimal(rights) - Decimal(unprofit) - Decimal(profit))

        return (balance, tradable, withdrawable)

    def getrestpositionsforpair(self, account, base_quote, timeframe):
        if MARGIN_MODE == FIXED:
            request = {'symbol': base_quote,
                       'contract_type': timeframe,
                       'type':1}
            method = 'private_post_future_position_4fix'
        else:
            request = {'symbol': base_quote,
                       'contract_type': timeframe}
            method = 'private_post_future_position'
        #self.logger.info('getrestpositionsforpair {}'.format(request))

        self.wait_for_low_priority_slot(account)
        response = self.ccxt_rest_call(account, method, [request])

        ccy, _ = base_quote.split('_')
        ccy = self.symbols.canonical(self.venue, ccy.upper())
        holding_upnl = Decimal(0)
        posdict = {}
        if 'holding' in response:
            holdings = response['holding']
            
            for h in holdings:
                #{u'sell_available': 17,
                #u'buy_bond': 0.307365,
                #u'contract_id': 201803020020060,
                #u'buy_price_avg': 832.886,
                #u'sell_bond': 0.01942857,
                #u'sell_amount': 17,
                #u'symbol': u'eth_usd',
                #u'buy_flatprice': u'764.123',
                #u'sell_risk_rate': u'90.31',
                #u'buy_amount': 256,
                #u'buy_risk_rate': u'137.82',
                #u'sell_flatprice': u'961.538',
                #u'buy_price_cost': 832.886,
                #u'sell_profit_lossratio': u'0.31',
                #u'contract_type': u'this_week',
                #u'create_date': 1519531366000,
                #u'buy_profit_lossratio': u'47.82',
                #u'lever_rate': 10,
                #u'sell_price_avg': 875,
                #u'buy_available': 256,
                #u'sell_price_cost': 875}]}
                contractid = str(h['contract_id'])
                contract_type = h['contract_type']
                contract_id = h['contract_id']
                create_date = h['create_date']/1000.

                lpos, spos = {}, {}
                sym = self.symbols.getsymfromexchange_id_1(self.venue, "{}:{}".format(base_quote, contract_type))
                lpos['symbol'] = sym
                spos['symbol'] = sym
                lpos['account'] = account
                spos['account'] = account

                lpos['qty'] = str(h['buy_amount'])
                spos['qty'] = utils.norm_str(Decimal(-1) * Decimal(h['sell_amount']))
                lpos['unrealisedccy'] = ccy
                spos['unrealisedccy'] = ccy
                lpos['realised'] = str(h['buy_profit_real'])
                spos['realised'] = str(h['sell_profit_real'])
                lpos['realisedccy'] = ccy
                spos['realisedccy'] = ccy
                lpos['marginccy'] = ccy
                spos['marginccy'] = ccy
                lpos['avgp'] = str(h['buy_price_cost'])
                spos['avgp'] = str(h['sell_price_cost'])

                for p in [lpos, spos]:
                    qty = Decimal(p['qty'])
                    currp = self.books[p['symbol']].indicative_mid
                    if qty != 0:
                        upnl = risk.calcpnl(self.venue, p['symbol'], qty, p['avgp'], currp)
                        p['unrealised'] = utils.norm_str(upnl)
                        holding_upnl += upnl
                    else:
                        p['unrealised'] = '0'

                if MARGIN_MODE == FIXED:
                    self.logger.warning("Fixed margin code never tested")
                    lever_rate = str(h['lever_rate'])
                    lpos['maintmargin'] = str(h['buy_bond'])
                    spos['maintmargin'] = str(h['sell_bond'])
                    lpos['liqprice'] = str(h['buy_flatprice'])
                    spos['liqprice'] = str(h['sell_flatprice'])
                    
                    #Reconcile our upnl calc with last update from exchange
                    if contract_id in self.contractids:
                        exch_upnl = Decimal(self.contractids[contract_id]['unrealised'])
                        self.logger.info("incorporating exchange upnl for position {} exch {} us{}".format(lpos['symbol'], exch_upnl, holding_upnl))
                        if Decimal(lpos['qty']) != 0 and Decimal(spos['qty']) == 0:
                            lpos['unrealised'] = utils.norm_str(exch_upnl)
                        elif Decimal(spos['qty']) != 0 and Decimal(lpos['qty']) == 0:
                            spos['unrealised'] = utils.norm_str(exch_upnl)
                        else:
                            diff = exch_upnl - holding_upnl
                            lpos['unrealised'] = utils.norm_str(Decimal(lpos['unrealised']) + diff/Decimal(2))
                            spos['unrealised'] = utils.norm_str(Decimal(spos['unrealised']) + diff/Decimal(2))
                        
                else:
                    lever_rate = LEVERAGE
                    lpos['liqprice'] = str(response['force_liqu_price']).replace(',', '')
                    spos['liqprice'] = str(response['force_liqu_price']).replace(',', '')
                    #upnl reconciliation with exchange will be called later via applyupnldiff()
                
                lpos['name'] = self.pos_id(sym, LONG, MARGIN_MODE, lever_rate)
                spos['name'] = self.pos_id(sym, SHORT, MARGIN_MODE, lever_rate)

                posdict[lpos['name']] = Position.from_json(lpos)
                posdict[spos['name']] = Position.from_json(spos)
                    
        return posdict.values()
        
    #Need to override this as okex forces you to loop through the currencies
    def getrestpositions(self, account):

        pos = []
        #since each futures requires you to hold that coin as futures we only look for positions with coins that we own balances in
        wallet = self.oms.getwallet(account, 'default')
        if wallet:
            ccys = [ccy for ccy, coins in wallet.balance.items() if Decimal(coins) > 0]
        else:
            ccys = []
        for ccy0 in ccys:
            ccy = self.symbols.venueccy(self.venue, ccy0)
            for timeframe in CONTRACT_TYPES:
                #below function already has wait
                try:
                    pairpos = self.getrestpositionsforpair(account, ccy.lower() + '_usd', timeframe)
                    pos += pairpos
                except Exception as e:
                    self.logger.error("getrestpositionsforpair {} {} {} failed: {}".format(account, ccy, timeframe, e), exc_info=True)
                #time.sleep(0.2)
        return {'default': pos}

    #overriding here to allow for adjusting the calced upnl to match the rest upnl from the exchange
    def getrestwallets(self, account):
        ts = time.time() #Use the time before the request to be conservative
        if account in self.accounts:
            try:
                restbals = self.getrestbalances(account)
            except:
                self.logger.error('Failed to get balance', exc_info=True)
                restbals = None
                
            try:
                restpos = self.getrestpositions(account)
            except:
                self.logger.error('Failed to get positions', exc_info=True)
                restpos = None
                
            if 'wallets' in self.accounts[account]:
                for wal in self.accounts[account]['wallets']:
                    #Balances/positions
                    tmpwallet = self.oms.getwallet(account, wal)
                    if not tmpwallet:
                        tmpwallet = Wallet(account, wal, self.accounts[account]['wallets'][wal])
                            
                    if restbals and wal in restbals:
                        balance, trade, withdraw = restbals[wal]
                        tmpwallet.setbalances(balance, trade, withdraw)

                    #Find the last non-0 position per ccy complex and adjust the upnl to fit rest
                    if not tmpwallet.spot and restpos and wal in restpos:
                        for p in restpos[wal]:
                            tmpwallet.setposition(p)
                        try:
                            tmpwallet = self.applyupnldiff(tmpwallet)
                        except Exception as e:
                            self.logger.error("applyupnldiff threw exception {}".format(e), exc_info=True)
                    self.dispatch('wallet', tmpwallet, ts, False)

    #Sets the upnl difference between rest call and our own calc'ed upnls to the last contract
    #Also sets the margin amount to the last contract
    def applyupnldiff(self, tmpwallet):
        lastpos = {}
        holding_upnl = {}
        for p in tmpwallet.positions.values():
            ccy = self.symbols.getbaseccy(self.venue, p.symbol)
            if Decimal(p.qty) != 0:
                if ccy not in holding_upnl:
                    holding_upnl[ccy] = Decimal(p.unrealised)
                else:
                    holding_upnl[ccy] += Decimal(p.unrealised)
                if ccy not in lastpos or p.name > lastpos[ccy].name:
                    lastpos[ccy] = p

        self.logger.info('applypnldiff {} {}'.format(self.unrealised.keys(), lastpos.keys()))
        for ccy in self.unrealised:
            if ccy in holding_upnl:
                diff_upnl = Decimal(self.unrealised[ccy]) - holding_upnl[ccy]
                if ccy in lastpos:
                    newupnl = Decimal(lastpos[ccy].unrealised) + diff_upnl
                    self.logger.info("Applying exchange pnl adjustment for {} to {}, setting unrealised from {} to {}".format(ccy, lastpos[ccy].name, lastpos[ccy].unrealised, str(newupnl)))
                    lastpos[ccy].setunrealised(newupnl, lastpos[ccy].unrealisedccy)
                    tmpwallet.setposition(lastpos[ccy])
                else:
                    self.logger.error("unable to find position for {} to apply unrealised pnl adjustment".format(ccy))
        return tmpwallet

    #getrestopenorders need to override as ccxt fetchOpenOrders requires symbol
    def getrestopenorders(self, account):
        self.wait_for_low_priority_slot(account)
        return [o for o in self.getrestorders(account) if o.status in OrderMsg.LIVESTATES]

    #ccxt doesn't have fetch_orders so need to get closed orders separately
    def getrestorders(self, account):
        orders = []
        wallet = self.oms.getwallet(account, 'default')
        if wallet:
            ccys = [ccy for ccy, coins in wallet.balance.items() if Decimal(coins) > 0]
        else:
            ccys = []
        for ccy in ccys:
            base_quote = ccy.lower() + '_usd'
            for timeframe in CONTRACT_TYPES:
                for filled in [True, False]:
                    try:
                        self.wait_for_low_priority_slot(account)
                        fetched = self.fetch_orders(account, base_quote, timeframe, filled=filled)
                        orders += fetched
                    except Exception as e:
                        self.logger.error('getrestorders: {}'.format(e), exc_info=True)
        return orders

    #getrestorder need to override as ccxt fetch_order requires symbol
    def getrestorder(self, account, ordermsg):
        self.wait_for_low_priority_slot(account)
        sym0 = ordermsg.symbol
        try:
            exchange_id = self.symbols.getexchange_id_1(self.venue, sym0)
            if exchange_id is None: #If we can't find this symbol (due to expiration?):
                ordermsg.status = OrderMsg.REJECTED
                ordermsg.rejectmsg = OrderMsg.INVALID_SYMBOL
                return ordermsg
            elif ordermsg.orderid:
                base_quote, timeframe = exchange_id.split(":")
                symtype = self.symbols.instrumenttype(self.venue, sym0)
                if symtype == FUTURE:
                    ordermsgs = self.fetch_ordersbyid(account, base_quote, timeframe, [ordermsg])
                else:
                    self.logger.info("Unknown instrument type {} for venue {}".format(symtype, self.venue))
        except ccxt.OrderNotFound as onf:
            self.logger.info("Order not found {} cancelling internally".format(ordermsg))
            ordermsg.status=OrderMsg.CANCELED
            return ordermsg
        except Exception as e:
            self.logger.error("Exception encountered in getrestorder {}".format(e), exc_info=True)
            return None
        if len(ordermsgs) > 0:
            return ordermsgs[0]
        else:
            self.logger.error("getrestorder found no order {}".format(ordermsg))
            return None
                                                                
            #CCXT fetch_order doesn't work for okexfut
    #fetch_orders gets all filled or all unfilled orders for given base_quote and contract
    def fetch_orders(self, account, base_quote, timeframe, filled=False):
        page_length = 50 #Note this is the enforced max on the API
        status = 2 if filled else 1
        request = {'symbol': base_quote,
                   'contract_type': timeframe,
                   'status': status, #1 for unfilled, 2 for filled
                   'order_id': -1,
                   'current_page': 1,
                   'page_length': page_length
                   }

        method = 'privatePostFutureOrderInfo'
        self.wait_for_low_priority_slot(account)
        response = self.ccxt_rest_call(account, method, [request])
        #self.logger.info('fetch_order {} {} {} filled={} {}'.format(account, base_quote, timeframe, filled, response))

        if response['result'] == True:
            numOrders = len(response['orders'])
            if numOrders > 0:
                return map(lambda x: self.parse_rest_order(account, x), response['orders'])
        else:
            self.logger.error('fetch_orders response is False {}'.format(response))
        return []

    #fetch_ordersbyid takes a list of ordermsgs and queries orderstate for all the ones with orderids
    def fetch_ordersbyid(self, account, base_quote, timeframe, ordermsgs=[]):
        request = {'symbol': base_quote,
                   'contract_type': timeframe,
                   'order_id': ','.join([o.orderid for o in ordermsgs if o.orderid is not None])
                   }

        method = 'privatePostFutureOrdersInfo'

        if len(ordermsgs) > 0:
            self.wait_for_low_priority_slot(account)
            response = self.ccxt_rest_call(account, method, [request])

            if response['result'] == True:
                numOrders = len(response['orders'])
                if numOrders > 0:
                    if numOrders < len(ordermsgs) or None in response['orders']:
                        self.logger.error("fetch_ordersbyid returned fewer orders than we asked for {}".format(response))
                    else:
                        return map(lambda x: self.parse_rest_order(account, x), response['orders'])
            else:
                self.logger.error('fetch_ordersbyid response is False {}'.format(response))

        return []

    def parse_rest_order(self, account, odict):
        amount = str(odict['amount'])
        contract_name = odict['contract_name']
        oursymbol = self.symvert(venuesym=contract_name)
        create_date = odict['create_date']/1000.
        filled = str(odict['deal_amount'])
        fee = odict['fee']
        price = str(odict['price'])
        price_avg = str(odict['price_avg'])
        lever_rate = str(odict['lever_rate'])
        #buy sell buy_market sell_market
        side = {1:OrderMsg.BUY,
                2:OrderMsg.SELL,
                3:OrderMsg.SELL,
                4:OrderMsg.BUY}[odict['type']]

        open = odict['type'] <= 2 #type is 1 or 2 if opening, 3 or 4 if closing

        status = self.convertstatus(odict['status'])
 
        if fee:
            cost= utils.norm_str(Decimal(str(fee)) * Decimal(-1))
            costccy = self.symbols.getbaseccy(self.venue, oursymbol)
        else:
            cost = None
            costccy = None

        return utils.OrderMsg(account=account,
                              orderid=str(odict['order_id']),
                              status=status,
                              symbol=oursymbol, #converted
                              otype=OrderMsg.LMT,
                              amt=amount,
                              side=side,
                              price=price,
                              avgp=price_avg,
                              filled=filled,
                              remaining=dec_to_str(Decimal(amount) - Decimal(filled)),
                              open=open,
                              cost=cost,
                              costccy=costccy,
                              last_ts=time.time()
                              )

    #REST overrides
    #need to override this as okex has no fill messages                                                                                                                                                  
    def getfullstate(self, account):
        #Need to lock the entire order matching process to prevent streaming from updating the state causing incorrect fill calculations
        with self.filllock:
            oodict = self.open_orders_dict(account)
            self.logger.info('I have {} open orders'.format(len(oodict)))
            try:
                orders = self.getrestorders(account)
            except Exception as e:
                self.logger.error('Error getting rest orders {}'.format(e), exc_info=True)
                orders = []

            openorders = [o for o in orders if o.status in OrderMsg.LIVESTATES]
            orderhistory = [o for o in orders if o.status not in OrderMsg.LIVESTATES]

            unknown_oids = set(oodict.keys()).difference(set([x.orderid for x in openorders]))
            orderhistory = [o for o in orderhistory if o.orderid in unknown_oids] #filter only for those we are interested in
            unknown_oids = unknown_oids - set([x.orderid for x in orderhistory])
            
            standalones = []

            queries = defaultdict(list)
            for oid in unknown_oids:
                unknown_order = oodict[oid].asordermsg()
                exchange_id = self.symbols.getexchange_id_1(self.venue, unknown_order.symbol)
                if exchange_id is None: #If we can't find this symbol (due to expiration?):
                    self.logger.error("cannot find exchange id for {}".format(unknown_order))
                else:
                    queries[exchange_id].append(unknown_order)

            for exchange_id, unknown_orders in queries.items():
                base_quote, timeframe = exchange_id.split(':')
                try:
                    standalones += self.fetch_ordersbyid(account, base_quote, timeframe, ordermsgs=unknown_orders)
                except Exception as e:
                    self.logger.error ('standalone fetch failed for {}'.format(exchange_id))
            unknown_oids = unknown_oids - set([x.orderid for x in standalones])

            if len(unknown_oids) > 0:
                self.logger.error('No info retrieved for {} orders'.format(len(unknown_oids)))
                
            theirorders = openorders + orderhistory + standalones
            for theirorder in theirorders:
                if theirorder.orderid in oodict:
                    ourorder = oodict[theirorder.orderid]
                    fill = self.dummy_diff_fill(account, theirorder, ourorder)
                    if fill: self.dispatch('fill', fill)
                else: #unmatched order
                    self.logger.info('theirorder.avgp {}'.format(theirorder.avgp))
                    if Decimal(theirorder.filled) > 0:
                        self.dispatch('fill', Fill(account=account,
                                                   tradeid=str(uuid.uuid4()),
                                                   orderid=theirorder.orderid,
                                                   symbol=theirorder.symbol,
                                                   amt=str(theirorder.filled),
                                                   side=theirorder.side,
                                                   price=theirorder.avgp,
                                                   cost=theirorder.cost,
                                                   costccy=theirorder.costccy,
                                                   last_ts=theirorder.lastupdated))
                self.dispatch('order', theirorder)
        self.getrestwallets(account)

    def _on_open(self, ws):
        super(okexfut, self)._on_open(ws)
        if len(self.accounts) >= 2:
            self.subscribewschannels()
            for account in self.accounts:
                if account != 'data':
                    self.getwsorderstate(account)

    def subscribewschannels(self):
        for channel in ['ok_sub_futureusd_trades', 'ok_sub_futureusd_userinfo', 'ok_sub_futureusd_positions']:
            msg = {'event':'addChannel', 
                   'channel':channel}
            self.send_signed(msg)
            self.logger.info('subscribing {}'.format(channel))
                    
    def getwsorderstate(self, account):
        open_orders = self.open_orders_dict(account).values()
        for o in open_orders:
            exchange_id = self.symbols.getexchange_id_1(self.venue, o.symbol)
            if exchange_id is None: #If we can't find this symbol (due to expiration?):
                ordermsg = o.asordermsg()
                ordermsg.status = OrderMsg.REJECTED
                ordermsg.rejectmsg = OrderMsg.INVALID_SYMBOL
                self.dispatch('order', ordermsg)
            else:
                base_quote, timeframe = exchange_id.split(":")
                self.get_orderinfo(base_quote, timeframe, o.orderid, filled=False)
                self.get_orderinfo(base_quote, timeframe, o.orderid, filled=True)

    def subscribe_override(self, sym):
        type = self.symbols.instrumenttype(self.venue, sym)
        if type == SPOT:
            self.logger.info("Unrecognised symbol {} type {} for okexfut".format(sym, type))
            return

        exchange_id = self.symbols.getexchange_id_1(self.venue, sym)
        if exchange_id is None:
            self.logger.info("Unrecognised future {}".format(sym))
        else:
            base_quote, timeframe = exchange_id.split(":")
            base = base_quote.split("_")[0]
            self.logger.info("Recognised future {} {}, subscribing".format(base_quote, timeframe))

            for channelfmt,mychan in [('ok_sub_futureusd_{}_depth_{}','depth'), ('ok_sub_futureusd_{}_trade_{}','trade'), ('ok_sub_futureusd_{}_ticker_{}', 'ticker')]:
                channel = channelfmt.format(base.lower(), timeframe)
                try:
                    self.ws.send(json.dumps({'event':'addChannel',
                                             'channel':channel}))
                except Exception as e:
                    self.logger.error(channel, exc_info=True)
                self.bookmsgs[sym] = 0
                self.cmap[channel] = (mychan, sym)

    def get_orderinfo(self, base_quote, timeframe, orderid='-1', filled=False, querypage=1):
        channel = 'ok_futureusd_orderinfo'
        status = '2' if filled else '1'
        if base_quote not in self.querypage:
            self.querypage[base_quote] = {}
        self.querypage[base_quote][timeframe]=querypage
        msg = {'event':'addChannel',
               'channel':channel}
        params = {'symbol': base_quote,
                  'order_id': orderid,
                  'contract_type': timeframe,
                  'status': status,
                  'current_page': str(querypage),
                  'page_length': str(ORDERS_PAGE_LENGTH)
                  }
        self.send_signed(msg, params)
        self.logger.info('subscribing {}'.format(channel))

    def getnewliquidations(self, account):
        newliqs = []
        method = 'privatePostFutureExplosive'
        wallet = self.oms.getwallet(account, 'default')
        if not wallet: return
        
        totbal = wallet.balance
        for ccy0 in totbal:
            symbol = self.symbols.venueccy(self.venue, ccy0).lower() + '_usd'
            for contract in CONTRACT_TYPES:
                request = {
                    'symbol': symbol,
                    'contract_type': contract,
                    'status': 1,
                    'current_page': 1,
                    'page_length': ORDERS_PAGE_LENGTH
                }
                self.wait_for_low_priority_slot(account)
                response = self.ccxt_rest_call(account, method, [request])
                data = response.get('data', [])
                for d in data:
                    dt = d['create_date']
                    amt = d['amount']
                    price = d['price']
                    type = d['type']
                    exchange_id_1 = '{}:{}'.format(symbol, contract)
                    sym = self.symbols.getsymfromexchange_id_1(self.venue, exchange_id_1)

                    key = '{}{}{}{}{}'.format(dt, sym, amt, price, type)
                    liq = {'dt': dt,
                           'symbol': sym,
                           'amt': amt,
                           'price': price,
                           'type': type}

                    if key not in self.liquidations:
                        self.liquidations.add(key)
                        newliqs.append(liq)

        ts = time.time()
        if self.miscfile.closed:
            self.miscfile = open(self.miscfilepath, 'a')
        newliqs = sorted(newliqs, key=lambda x: x['dt'])
        for liq in newliqs:
            self.miscfile.write('{};{};\n'.format(ts, json.dumps(liq)))


    #This conversion only for futures - OKEx doesn't have the year.
    def symvert(self, sym=None, venuesym=None):
        if sym is None and venuesym is not None:
            contract_name = venuesym
            baseccy = contract_name[0:len(contract_name)-4]
            mmdd = contract_name[-4:]
            today = datetime.datetime.utcnow()
            if int(mmdd) < int(today.strftime('%m%d')):
                ymd = str(today.year + 1) + mmdd
            else:
                ymd = str(today.year) + mmdd
            return baseccy + ymd
        if sym is not None and venuesym is None:
            contract_name = sym
            baseccy = contract_name[0:len(contract_name)-8]
            mmdd = contract_name[-4:]
            return baseccy + mmdd

        raise Exception('You used this function incorrectly')

    #only gets called assuming that the order is an opening order
    def balrequired(self, symbol, side, amt, price):
        assert utils.isfloat(amt)
        assert utils.isfloat(price)

        multiplier = self.symbols.getmultiplier(self.venue, symbol)
        marginccy = self.symbols.getbaseccy(self.venue, symbol)
        requiredamt = Decimal(amt) * multiplier / Decimal(price) / Decimal(LEVERAGE)

	return marginccy, requiredamt

    #Get total amount that can be closed for an order looking to trade on 'side'                                                                                                                            
    def getcloseableamt(self, account, contract, side, margin_mode=MARGIN_MODE, leverage=LEVERAGE):
        openorders = self.oms.open_orders(account=account, include_unmatched=True)
        #self.logger.info('position {}'.format(pos))
        closeableamt = Decimal(0)
        if side == OrderMsg.BUY:
            direction = SHORT
        else:
            direction = LONG
        pos_id = self.pos_id(contract, direction, margin_mode, leverage)

        if account in self.accounts:
            wallet = self.oms.getwallet(account, 'default')
            if wallet:
                pos = wallet.positions
                if pos_id in pos:
                    position = pos[pos_id]
                    closeableamt += abs(Decimal(position.qty))
            else:
                self.logger.error('getcloseableamt could not get wallet {} {}'.format(account, 'default'))
                return Decimal(0)

        for o in openorders:
            if o.open == False and o.status in OrderMsg.LIVESTATES:
                if side == o.side:
                    closeableamt -= Decimal(o.remaining)

        return closeableamt

    def pos_id(self, contract, direction, margin_mode, leverage):
        assert direction in ['LONG', 'SHORT']
        assert margin_mode in [FIXED, CROSS]
        return '{}_{}_{}_{}'.format(contract, direction, margin_mode, utils.norm_str(Decimal(leverage)))

    def parse(self, msg):

        if 'product' in msg:
            pass

        elif 'channel' not in msg:
            self.logger.warning('Unrecognized msg - no channel supplied {}'.format(msg))
        elif msg['channel'] in ['addChannel', 'login']:
            #self.logger.info(msg)
            pass
        elif 'spot' in msg['channel']:
            pass
        elif 'data' in msg and 'result' in msg['data'] and msg['data']['result'] == False:
            #This is when websocket request returnen unsuccessfully
            self.logger.error(str(msg))
        elif '_ticker' in msg['channel']:
            if msg['channel'] in self.cmap:
                mtype, sym = self.cmap[msg['channel']]
            else:
                return
            data = msg['data']
            oi = data['hold_amount']
            self.dispatch('stats', sym, oi, data)
            
        elif '_depth' in msg['channel']:
            #self.logger.info('Msg received: {}'.format(msg['channel']))
            if msg['channel'] in self.cmap:
                mtype, sym = self.cmap[msg['channel']]
                #self.logger.info('cmap {} {}: {}'.format(mtype, sym, msg['channel']))
            else:
                #self.logger.info('cmap not found: {}'.format(msg['channel']))
                return
            assert mtype == 'depth'
            data = msg['data']
            bids,asks = [], []

            if 'bids' in data: bids = [(utils.norm_str(bid[0]), utils.norm_str(bid[1])) for bid in data['bids']]
            if 'asks' in data: asks = [(utils.norm_str(ask[0]), utils.norm_str(ask[1])) for ask in data['asks']]
            ts0 = float(data['timestamp'])/1000.
            seqnum = ts0

            #For some reason even the first msg which the API docs say should be a full book
            #still returns zero sizes.
            if self.bookmsgs[sym]==0:
                bids = [(x[0], x[1]) for x in bids if x[1] != '0']
                asks = [(x[0], x[1]) for x in asks if x[1] != '0']
                #sizes = [x[1] for x in bids + asks]
                #if '0' in sizes:
                #    self.logger.info("okexfut sym {} full book bids: {}, asks: {}".format(sym, str(bids), str(asks)))
            self.dispatch('book', sym, bids, asks, ts0, seqnum, bFullBook=self.bookmsgs[sym]==0)    
            self.bookmsgs[sym] += 1
        #ok_sub_futureusd_X_trade_Y
        elif '_trade_' in msg['channel']:
            if msg['channel'] in self.cmap: 
                mychan, sym = self.cmap[msg['channel']]
                for tradedata in msg['data']:
                    #OKEx added the amountbtc field to the api but doesn't use it consistently for all symbols
                    if len(tradedata) == 6:
                        tid, price, size, hhmmss, side, amountbtc= tradedata
                    else:
                        tid, price, size, hhmmss, side= tradedata

                    size = utils.norm_str(Decimal(size))

                    #okex returns hkt here (why the hell would you design it like that)
                    #we have to make an assumption that it is at least the same hk date since they don't give us a friggin date
                    dt = datetime.datetime.strptime(hhmmss, '%H:%M:%S')
                    utcnow = pytz.UTC.localize(datetime.datetime.utcnow())
                    hktimenow = utcnow.astimezone(HKT)
                    hktimenow.replace(hour=dt.hour, minute=dt.minute, second=dt.second)
                    utcdt = hktimenow.astimezone(pytz.UTC) #ok since hkt has no dst
                    ts0 = (utcdt.replace(tzinfo=None) - datetime.datetime(1970,1,1)).total_seconds()
                    
                    side = 'S' if side == 'ask' else 'B'
                    self.dispatch('trade', sym, price, size, side, ts0)

        #'ok_sub_futureusd_positions'
        elif 'ok_sub_futureusd_positions' in msg['channel']:
            self.logger.info(msg)
            data = msg['data']
            base_quote = data['symbol']
            ccy = self.symbols.canonical(self.venue, base_quote.split('_')[0].upper())
            poslist = data['positions']
            tmpwallet = self.oms.getwallet(self.account, 'default')
            if not tmpwallet:
                tmpwallet = Wallet(self.account, 'default', False)
            contract_id = None
            newpositions = []
            for pos in poslist:
                #position(string): position 1 long 2 short
                #contract_name(string): contract name
                #costprice(string): cost price
                #bondfreez(string): freezed bond
                #avgprice(string): average open price
                #contract_id(long): contract id
                #position_id(long): position id
                #hold_amount(string): hold amount
                #eveningup(string): evening up
                #lever_rate(long): leverage rate
                #fixmargin(double): margin
                #realized(double):real profit

                position = pos['position']

                #TODO: replace this with a proper symbol lookup on contract_id
                contract_name = self.symvert(venuesym=pos['contract_name'])
                direction = LONG if position == 1 else SHORT
                cost_price = str(pos['costprice'])
                bondfreez = str(pos['bondfreez'])
                avgprice = str(pos['avgprice'])
                contract_id = str(pos['contract_id'])
                position_id = pos['position_id']
                hold_amount = str(pos['hold_amount'])
                eveningup = pos['eveningup']
                if MARGIN_MODE == FIXED:
                    realised = str(pos['profitreal'])
                    lever_rate = str(pos['lever_rate'])
                    margin = str(pos['fixmargin'])
                else:
                    realised = str(pos['realized'])
                    lever_rate = str(LEVERAGE)
                    margin = str(pos['margin'])
                    realised = str(pos['realized'])
                
                pos_id = self.pos_id(contract_name, direction, MARGIN_MODE, lever_rate)                
                sign = Decimal(-1) if Decimal(position) == Decimal(2) else Decimal(1)
                qty = utils.norm_str(sign * Decimal(hold_amount))

                #calc unrealised
                currp = self.books[contract_name].indicative_mid
                if Decimal(qty) != 0 and currp:
                    upnl = utils.norm_str(risk.calcpnl(self.venue, contract_name, qty, avgprice, currp))
                else:
                    upnl = '0'
                    
                newpos = Position(pos_id,
                                  self.account,
                                  contract_name,
                                  qty = qty,
                                  unrealised = upnl,
                                  unrealisedccy = ccy,
                                  realised = realised,
                                  realisedccy = ccy,
                                  liqprice = None,
                                  initmargin = None,
                                  maintmargin = margin,
                                  marginccy = ccy,
                                  leverage = lever_rate,
                                  avgp = avgprice)

                newpositions.append(newpos)

            for newpos in newpositions:
                tmpwallet.setposition(newpos)
            tmpwallet = self.applyupnldiff(tmpwallet)
            self.dispatch('wallet', tmpwallet, time.time(), True)

        elif 'ok_sub_futureusd_userinfo' in msg['channel']:

            #{u'binary': Decimal('0'), 
            #u'data': {u'contracts': [{u'available': Decimal('41.64044894'), 
            #                          u'contract_id': Decimal('201804060200053'), 
            #                          u'profit': Decimal('-0.00083752'), 
            #                          u'freeze': Decimal('0.0'), 
            #                          u'balance': Decimal('0.16834171'), 
            #                          u'bond': Decimal('0.16750419')}, 
            #                         {u'available': Decimal('41.64044894'), 
            #                          u'contract_id': Decimal('201806290200057'), 
            #                          u'profit': Decimal('-0.02373659'), 
            #                          u'freeze': Decimal('0.0'), 
            #                          u'balance': Decimal('8.09170935'), 
            #                          u'bond': Decimal('8.06797276')}], 
            #          u'symbol': u'eos_usd', 
            #          u'balance': Decimal('41.64044894')}, 
            #u'channel': u'ok_sub_futureusd_userinfo'}
            #self.logger.info(msg)
            totdict = {}
            freedict = {}
            data = msg['data']
            symbol = data['symbol']
            ccy0, _ = symbol.split('_')
            ccy = self.symbols.canonical(self.venue, ccy0)

            if MARGIN_MODE == FIXED:                    
                self.logger.warning("Fixed margin code never tested")
                rights = str(data['balance'])
                totdict[ccy] = rights
                for contract in data['contracts']:
                    available = str(contract['available'])
                    contract_id = str(contract['contract_id'])
                    profit = str(contract['profit'])
                    unprofit = str(contract['unprofit'])
                    freeze = str(contract['freeze'])
                    contract_type = contract['contract_type']
                    balance = str(contract['balance'])
                    bond = str(contract['bond'])

                    freedict[ccy] = available
            else:
                if len(data.keys()) > 0:
                    rights = data['balance']
                    margin = data['keep_deposit']
                    profit = data['profit_real']
                    freedict[ccy] = utils.norm_str(Decimal(rights) - Decimal(margin)) #We can trade with this amount.
                    totdict[ccy] = str(rights)
                    #Can withdraw equity - realised profit

            #Don't dispatch - these numbers seem to be missing the unrealised pnl so we can't get the real total balance
            #self.dispatch('balance',self.account, time.time(), 'freebal', freebal, True)
            #self.dispatch('balance',self.account, time.time(), 'totbal', totbal, True)

        elif 'ok_sub_futureusd_trades' in msg['channel']:
            #{u'binary': Decimal('0'), 
            #u'data': {u'orderid': Decimal('321568351527937'), 
            #          u'contract_name': u'ETH0302', 
            #          u'fee': Decimal('0.0'), 
            #          u'user_id': Decimal('7324096'), 
            #          u'contract_id': Decimal('201803020020060'), 
            #          u'price': Decimal('800.0'), 
            #          u'create_date_str': u'2018-02-26 18:59:03', 
            #          u'amount': Decimal('1.0'), 
            #          u'status': Decimal('0'), 
            #          u'system_type': Decimal('0'), 
            #          u'unit_amount': Decimal('10.0'), 
            #          u'price_avg': Decimal('0.0'), 
            #          u'contract_type': u'this_week', 
            #          u'create_date': Decimal('1519642743649'), 
            #          u'lever_rate': Decimal('10.0'), 
            #          u'type': Decimal('1'), 
            #          u'deal_amount': Decimal('0.0')}, 
            #          u'channel': u'ok_sub_futureusd_trades'}
            
            orderdict = msg['data']
            vsym = orderdict['contract_name']
            sym = self.symvert(venuesym=vsym)

            orderid = str(orderdict['orderid'])

            #buy sell buy_market sell_market
            side = {1:OrderMsg.BUY,
                    2:OrderMsg.SELL,
                    3:OrderMsg.SELL,
                    4:OrderMsg.BUY}[orderdict['type']]

            open = orderdict['type'] <= 2 #type is 1 or 2 if opening, 3 or 4 if closing

            otype = OrderMsg.LMT

            status0 = self.convertstatus(orderdict['status'])

            qty = orderdict['amount']
            filled = orderdict['deal_amount']
            rem = qty - filled

            open = orderdict['type'] <= 2 #type is 1 or 2 if opening, 3 or 4 if closing
            cost = Decimal(-1) * orderdict['fee']
            costccy = self.symbols.getbaseccy(self.venue, sym)

            try:
                self.logger.info('orderdict[price] {}'.format(orderdict['price']))
            except Exception as e:
                self.logger.error('price field not found in orderdict: {}'.format(orderdict), exc_info=True)
            self.logger.info("GOT ORDER UPDATE!!!! {}".format(orderdict))
            orderobj = utils.OrderMsg(account=self.account,
                                      orderid=orderid,
                                      status=status0,
                                      symbol=sym,
                                      otype=otype,
                                      amt=utils.norm_str(qty),
                                      side=side,
                                      price=utils.norm_str(orderdict['price']),
                                      avgp=utils.norm_str(orderdict['price_avg']),
                                      filled=utils.norm_str(filled),
                                      remaining=utils.norm_str(rem),
                                      open=open,
                                      cost=utils.norm_str(cost),
                                      costccy=costccy,
                                      last_ts = float(orderdict['create_date'])/1000.,
                                      info=orderdict)

            fill = None
            if filled > 0:
                #self.logger.info('logging filled message to debug how to parse API\n{}'.format(str(orderdict)))
            
                prev_orderstate = self.oms.getorderstate(self.account, orderid)
                prev_filled = prev_orderstate.filled
                if prev_filled is None:
                    prev_filled = 0
                this_fill_amt = filled - Decimal(prev_filled)
                
                prev_cost = prev_orderstate.cost
                if prev_cost is None:
                    prev_cost = 0
                this_cost_amt = cost - Decimal(prev_cost)
                
                if this_fill_amt > 0:
                    fill = utils.Fill(account=self.account,
                                      tradeid=str(uuid.uuid4()),
                                      orderid=orderid,
                                      symbol=sym,
                                      amt=utils.norm_str(this_fill_amt),
                                      side=side,
                                      price=utils.norm_str(orderdict['price']),
                                      cost=utils.norm_str(this_cost_amt),
                                      costccy=costccy,
                                      last_ts=float(orderdict['create_date'])/1000.)

            self.dispatch('order', orderobj)
            self.logger.info('order cost {} {}'.format(orderobj.cost, orderobj.costccy))
            if fill:
                self.dispatch('fill', fill)
                self.logger.info('fill cost {} {}'.format(fill.cost, fill.costccy))


        elif 'ok_futureusd_userinfo' in msg['channel']:
            self.logger.warning('ok_futureusd_userinfo missing from the API docs, we are parsing from historical code')
            self.logger.warning(msg)
            data = msg['data']
            userinfo =  self.parseuserinfo(self.account, data)
            tmpwallet = self.oms.getwallet(self.account, 'default')
            if not tmpwallet:
                tmpwallet=Wallet(self.account, 'default', self.accounts[self.account]['wallets']['default'])
            if 'default' in userinfo:
                balance, trade, withdraw = userinfo
                tmpwallet.setbalances(balance, trade, withdraw, False)
                self.logger.info(data)
                tmpwallet = self.applyupnldiff(tmpwallet)
                self.dispatch('wallet', tmpwallet, time.time(), False)
                
        elif 'ok_futureusd_orderinfo' in msg['channel']:
            self.logger.warning('ok_futureusd_orderinfo missing from the API docs, we are parsing from historical code')
            self.logger.info("GOT ORDER UPDATE2!!!! {}".format(data['orders']))
            data = msg['data']
            orders = data['orders']
            for odict in orders:
                amount = odict['amount']
                contract_name = odict['contract_name']
                create_date = float(odict['create_date'])/1000.
                deal_amount = odict['deal_amount']
                fee = Decimal(-1) * odict['fee']
                lever_rate = odict['lever_rate']
                order_id = dec_to_str(odict['order_id'])
                price = odict['price']
                price_avg = odict['price_avg']
                status = odict['status']
                symbol = odict['symbol']
                type = odict['type']
                unit_amount = odict['unit_amount']

                sym = self.symvert(venuesym=contract_name)
                exchange_id = self.symbols.getexchange_id_1(self.venue, sym)
                if exchange_id:
                    base_quote, timeframe = exchange_id.split(":")

                    #buy sell buy_market sell_market
                    side = {1:OrderMsg.BUY,
                            2:OrderMsg.SELL,
                            3:OrderMsg.SELL,
                            4:OrderMsg.BUY}[type]

                    open = type <= 2 #type is 1 or 2 if opening, 3 or 4 if closing
                    otype = OrderMsg.LMT
                    status0 = self.convertstatus(odict['status'])

                    qty = amount * unit_amount
                    filled = deal_amount * unit_amount
                    rem = qty - filled
                    
                    orderobj = utils.OrderMsg(account=self.account,
                                              orderid=order_id,
                                              status=status0,
                                              symbol=sym,
                                              otype=otype,
                                              amt=utils.norm_str(qty),
                                              side=side,
                                              price=utils.norm_str(odict['price']),
                                              avgp=utils.norm_str(odict['price_avg']),
                                              filled=utils.norm_str(filled),
                                              remaining=utils.norm_str(rem),
                                              open=open,
                                              cost=utils.norm_str(fee),
                                              costccy=self.symbols.getbaseccy(self.venue, sym),
                                              last_ts = float(odict['create_date'])/1000.,
                                              info=odict)
                    self.dispatch('order', orderobj)
                else:
                    self.logger.info('no dispatch')
                    

            if len(orders) == ORDERS_PAGE_LENGTH and timeframe is not None:
                self.get_orderinfo(symbol, timeframe, querypage=self.querypage[symbol][timeframe]+1)
        else:
            self.logger.warning('Unhandled msg {}'.format(msg))


    def restplaceorder(self, ordermsg):
        try:
            symbol = ordermsg.symbol
            ordertype = {OrderMsg.LMT:'limit', OrderMsg.MKT:'market'}[ordermsg.otype]
            side = {OrderMsg.BUY:'buy', OrderMsg.SELL:'sell'}[ordermsg.side]
            amount = Decimal(ordermsg.amt) #s/b string? ccxt is strange                   
            price = Decimal(ordermsg.price)
            leverage = LEVERAGE
            margin_mode = MARGIN_MODE
            closeableamt = self.getcloseableamt(self.account, symbol, ordermsg.side, margin_mode, leverage)
            if amount <= closeableamt:
                #close this sucker
                response = self._create_order(symbol, ordertype, side, float(amount), price, False)
                omsg = self.parse_place_result(response, ordermsg)
                if omsg: self.dispatch('order', omsg)
            else:
                ccy, marginamt = self.balrequired(symbol, side, amount, price)
                wallet = self.oms.getwallet(self.account, 'default')
                if wallet: freebal = Decimal(wallet.tradable.get(ccy, '0'))
                else: freebal = Decimal(0)
                if freebal < marginamt:
                    ordermsg.orderid = str(uuid.uuid4()) #dummy oid
                    ordermsg.status = OrderMsg.REJECTED
                    ordermsg.rejectmsg = OrderMsg.INSUFFICIENT_FUNDS
                    self.dispatch('order', ordermsg)
                else:
                    response = self._create_order(symbol, ordertype, side, float(amount), price, True)
                    omsg = self.parse_place_result(response, ordermsg)
                    if omsg: self.dispatch('order', omsg)
                
        except Exception as e:
            self.logger.error('Unable to submit order {}'.format(ordermsg), exc_info=True)
            ordermsg = self.parse_place_exception(e, ordermsg)
            if ordermsg: self.dispatch('order', ordermsg)

    def restcancelorder(self, ordermsg):
        try:
            result = self._cancel_order(ordermsg.orderid, ordermsg.symbol)
            omsg = self.parse_cancel_result(result, ordermsg)
        except Exception as e:
            omsg = self.parse_cancel_exception(e, ordermsg)
        if omsg: self.dispatch('order', omsg)

    def _create_order(self, symbol, type, side, numcontracts, price, openorder, params={}):
        exchange_id = self.symbols.getexchange_id_1(self.venue, symbol)
        if exchange_id is None: return

        base_quote, timeframe = exchange_id.split(":")
        insttype = self.symbols.instrumenttype(self.venue, symbol)
        method = 'privatePost'
        order = {
            'symbol': base_quote,
            'type': side,
        }
        if insttype == FUTURE:
            method += 'Future'
            leverage = LEVERAGE

            if openorder:
                openclosetype = 1 if side == OrderMsg.BUY else 2
            else:
                openclosetype = 4 if side == OrderMsg.BUY else 3

            order = self.accounts[self.account]['ccxt'].extend(order, {
                'contract_type': timeframe,  # next_week, quarter                                                                                                                                         
                'match_price': 0,  # match best counter party price? 0 or 1, ignores price if 1                                                                                                             
                'lever_rate': leverage,  # leverage rate value: 10 or 20(10 by default)                                                                                                                           
                'price': price,
                'amount': numcontracts,
                'type': openclosetype
            })
        else:
            raise ccxt.ExchangeError(self.id + ' instrument type is not future for symbol {}'.format(symbol))
        params = self.accounts[self.account]['ccxt'].omit(params, 'cost')
        method += 'Trade'
        #self.logger.info('order: ', order)
        #self.logger.info('params: ', params)
        response = self.ccxt_rest_call(self.account, method, [self.accounts[self.account]['ccxt'].extend(order, params)])
        #self.logger.info('response: ', response)
        return response

    def _cancel_order(self, id, symbol=None, params={}):
        if not symbol:
            raise ccxt.ExchangeError(self.id + ' cancelOrder() requires a symbol argument')
        type_ = self.symbols.instrumenttype(self.venue, symbol)
        exchange_id = self.symbols.getexchange_id_1(self.venue, symbol)

        if type_ == FUTURE and exchange_id is not None:
            base_quote, timeframe = exchange_id.split(":")
            request = {
                'symbol': base_quote,
                'contract_type': timeframe,
                'order_id': id
                }
            method = 'privatePostFutureCancel'

            response = self.ccxt_rest_call(self.account, method, [self.accounts[self.account]['ccxt'].extend(request, params)])
            if 'info' in response: return response['info'] #to parse ccxt return response
            return response
        else:
            raise ccxt.ExchangeError("Cannot find future contract {} to cancel via {}".format(symbol, self.venue))
        return None

    def parse_place_result(self, result, omsg):
        if result['result']:
            omsg.orderid = str(result['order_id'])
            return omsg
        else:
            return None

    def parse_cancel_result(self, result, omsg):
        #Only deals with single cancels for now, no batch cancels
        self.logger.info(result)
        if result['result']: 
            omsg.status = OrderMsg.CANCELED
            return omsg
        else:
            return None


if __name__ == '__main__':
    logging.basicConfig()
    ok = okex()
    ok.start()
    ok.subscribe('ETH/BTC')
    time.sleep(30)

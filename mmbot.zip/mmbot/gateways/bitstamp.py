# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import logging, json
import time
import pusherclient
import ccxt
import utils
from utils import OrderMsg
from collections import defaultdict
from cdecimal import Decimal
import base

class bitstamp (base.Gateway):
    def __init__(self, credentials=[]):
        super(bitstamp, self).__init__(credentials)
        self.gotfullbook = defaultdict(bool)
        self.pusher = None

        if len(self.accounts) > 1:
            raise Exception('Not supporting private now')
        
    def parse_rest_order(self, orderbook):
        raise Exception("parse_rest_order not yet implemented for bitstamp")
        
    def _get_msghandler(self, symbol, channel, event):
        symbol = self.symvert(venuesym=symbol)
        def msghandler(message):
            recvts = time.time()
            #TODO: Fix the precision issues that currently come from the exchange - book levels are returned as string
            #      but trades and orders are returned as borked float values
            msg = json.loads(message, parse_float=Decimal, parse_int=Decimal)
            if channel == 'live_trades' and event == 'trade':
                msg = json.loads(message)   #Float fudge
                self.dispatch('trade', symbol, utils.norm_str(str(msg['price'])), utils.norm_str(str(msg['amount'])).replace('-',''), 'B' if msg['type'] == 0 else 'S', msg['timestamp'])

            elif channel in ['diff_order_book', 'order_book'] and event == 'data':
                bidlst = [(utils.norm_str(p), utils.norm_str(q)) for p,q in msg['bids']]
                asklst = [(utils.norm_str(p), utils.norm_str(q)) for p,q in msg['asks']]
                fullbook = channel == 'order_book'
                if self.gotfullbook[symbol] and fullbook:
                    pass
                else:
                    self.gotfullbook[symbol] = self.gotfullbook[symbol] or fullbook
                    seqnum = recvts
                    self.dispatch('book',symbol, bidlst, asklst, None, seqnum, bFullBook=fullbook)

            #Level 3 orderbook not supported for now
            elif channel == 'live_orders' and event in ['order_created', 'order_changed', 'order_deleted']:
                msg = json.loads(message)   #Float fudge
                pass
            else:
                self.log(logging.ERROR,'unexpected channel')
        return msghandler

    def start(self):
        #bitstamp doesn't have any private data on pusher
        if self.pusher == None:
            self.pusher = pusherclient.Pusher('de504dc5763aeef9ff52', log_level=logging.ERROR)
            self.pusher.connection.bind('pusher:connection_established', self.on_connect)
            self.pusher.connect()
        else:
            self.logger.error('pusher exists already')

    def on_connect(self, *args, **kwargs):
        #print args
        self.dispatch('connected', self.venue)
        
    def stop(self):
        self.pusher.disconnect()
        self.pusher = None
        self.dispatch('disconnected', self.venue)
        
    def subscribe_override(self, sym):
        channels = {'live_trades':['trade'],
                    'order_book':['data'],
                    'diff_order_book':['data'],
                    'live_orders':['order_created','order_changed','order_deleted']}
        vsym = self.symvert(sym=sym)
        for channel0, events in channels.iteritems():
            fullstream = channel0 + '_' + vsym if vsym != 'btcusd' else channel0
            for event in events:
                channel = self.pusher.subscribe(fullstream)
                channel.bind(event, self._get_msghandler(vsym, channel0, event))

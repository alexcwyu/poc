import symbols

REDIS_HOST='127.0.0.1'
REDIS_PORT=6379
CORE_HOST='127.0.0.1'
CORE_PORT=8001
ALERTSERVER_HOST='127.0.0.1'
ALERT_HBPERIOD=10
LOGDIR='log/'
MD_TRADE_CACHE_SECS=180
# 'anxpro','binance','bitmex','bitmextest','bitfinex','bitstamp','bittrex','gdax','hitbtc','okexspot','okexfut','kucoin','kraken','poloniex'
manifest = symbols.Symbols().generate_manifest(venues=['okexfut'],
                                               currencies=['BTC','ETH','LTC','XRP','BCH','ADA','NEO','XLM','EOS','DASH','MIOTA','XMR','OAX','ETC','XEM','LOOM'],
                                               indices=['.BXBT', '.ETHXBT', '.XRPXBT', '.LTCXBT', '.ADAXBT', '.XLMXBT', '.NEOXBT', '.ETCXBT', '.ZECXBT', '.DASHXBT', 'OKEXBTC'])




manifest['okexfut']['credentials'].append(
                    {'alias':'sensus',
                     'apiKey':'de9e0ba8-c323-4391-b1e8-3a7f8944d180',
                     'secret':'B662F0C9F0D7E71F081B53BB236727E0'})




# manifest['bitmextest']['credentials'].append(
#      {'alias':'x',
#       'apiKey':'avyfqwra-clH97jv60Jf5WYi',
#       'secret':'MKrUJVCswkY3YtQxKXQUKU9EAwHDB1M-XPihhub9Od4ypoYa'})
#
#
# manifest['bitmex']['credentials'].append(
#     {'alias':'sensus',
#      'apiKey':'dcNzpwIezhrLjXczwDv5yjYB',
#      'secret':'2Skbwa2-0XMP5gx7jFcYysg8Gmm7obRYDmgfFeg7uj6MI_cB'})
#
# manifest['kucoin']['credentials'].append(
#                    {'alias':'sensus',
#                     'apiKey': '5a6bfacc1e789d36286713b9',
#                     'secret': '455ca0a6-415b-47b0-89b6-021b650f26b8'})
# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from cdecimal import Decimal as D
import uuid
import time
import threading
import functools
from collections import defaultdict
import utils
import oms
from utils import OrderMsg, Fill, Wallet, Position
import rest
import base

class kucoin(base.Gateway):
    def __init__(self, credentials, ccxtname=None, enableRateLimit=True):
        super(kucoin, self).__init__(credentials, enableRateLimit=enableRateLimit)
        self.poll_period = 5
        self.fills = defaultdict(dict) #oid -> dict of fills by fillid
        self.seenfills = set()
        
    def parse_rest_fills(self, account, fillsdict):
        assert fillsdict['status'] == 'closed'
        
        return Fill(account=account,
                    tradeid=fillsdict['info']['oid'],
                    orderid=fillsdict['info']['orderOid'],
                    symbol=fillsdict['symbol'],
                    amt=str(fillsdict['info']['amount']),
                    side=fillsdict['info']['direction'].lower(),
                    price=str(fillsdict['info']['dealPrice']),
                    cost=str(fillsdict['info']['fee']),
                    costccy=str(fillsdict['info']['coinType']),
                    last_ts=float(fillsdict['timestamp'])/1000.)
        
        
    def parse_rest_order(self, account, orderdict):
        status = orderdict['status']
        assert status == 'open'
        if status == 'open':
            if orderdict['filled'] > 0:
                status = OrderMsg.PARTIALLY_FILLED
            else:
                status = OrderMsg.NEW
        assert orderdict['type'] in [OrderMsg.MKT, OrderMsg.LMT]
        side = orderdict['side'].lower()
        assert side in [OrderMsg.BUY, OrderMsg.SELL]

        fee = orderdict['fee']
        if fee:
            cost = str(fee['cost']) if fee['cost'] else None
            costccy = fee['currency']
        else:
            cost = None
            costccy = None

        if orderdict['filled'] + orderdict['remaining'] != orderdict['amount']:
            self.logger.error("Filled + remaining not equal to amount, feed from exchange is: {}".format(orderdict))
            
        return OrderMsg(account=account,
                        orderid=str(orderdict['id']),
                        status=status,
                        symbol=orderdict['symbol'],
                        otype=orderdict['type'],
                        amt=str(orderdict['amount']),
                        side=side,
                        price=str(orderdict['price']),
                        avgp=None, #str(orderdict['average']),
                        filled=str(orderdict['filled']),
                        remaining=str(orderdict['remaining']),
                        cost=cost,
                        costccy=costccy,
                        last_ts=float(orderdict['timestamp'])/1000.,
                        info=orderdict['info']
        )

    def getfullstate(self, account):
        try:
            self.logger.info('Custom get full state {}'.format(self.open_orders_dict(account)))

            myactives = self.oms.open_orders(account)
            syms = set([o.symbol for o in myactives])
            open_orders = []
            dealt_orders = [] #dealt orders are actually fills
            for sym0 in syms:
                open_orders += self.ccxt_rest_call(account, 'fetch_open_orders', [sym0])
                dealt_orders += self.ccxt_rest_call(account, 'fetch_closed_orders', [sym0])
                
            open_orders = [self.parse_rest_order(account, o) for o in open_orders]
            dealt_orders = [self.parse_rest_fills(account, f) for f in dealt_orders]

            for fillobj in dealt_orders:
                self.fills[fillobj.orderid][fillobj.tradeid] = fillobj
                if fillobj.tradeid not in self.seenfills:
                    self.dispatch('fill',fillobj)
                    self.seenfills.add(fillobj.tradeid)

            #Kucoin is so shit that querying individual orders does not work (the api works but doesn't give you order state)
            #So have to assume that if order is not in open list nor dealt list then it was canceled
            their_open_orders = {oo.orderid:oo for oo in open_orders}

            for order0 in myactives:
                if order0.orderid is not None:
                    #orders that are still open whether New or Partially Filled
                    if order0.orderid in their_open_orders:
                        omsg = their_open_orders[order0.orderid]
                        self.dispatch('order',omsg)
                        del their_open_orders[order0.orderid]
                        
                    #orders that have been fully filled (no longer open according to them so must be fully filled or canceled)
                    elif order0.orderid in self.fills:
                        fills = self.fills[order0.orderid].values()
                        filled_amt = sum([D(f.amt) for f in fills])

                        omsg = order0.asordermsg()
                        omsg.filled = str(filled_amt)
                        if D(omsg.filled) == D(omsg.amt):
                            omsg.status = OrderMsg.FILLED
                        else:
                            omsg.status = OrderMsg.CANCELED
                        self.dispatch('order',omsg)

                    #presumably cancelled
                    else:
                        omsg = order0.asordermsg()
                        omsg.status = OrderMsg.CANCELED
                        self.dispatch('order', omsg)

            #orders we don't already know about
            for oid, omsg in their_open_orders.items():
                self.dispatch('order', omsg)

            ts = time.time()
            restbals = self.getrestbalances(account)
            tmpwallet = self.oms.getwallet(account, 'default')
            if not tmpwallet:
                tmpwallet = Wallet(account, 'default', self.accounts[account]['wallets']['default'])
            if 'default' in restbals:
                args = restbals['default']
                tmpwallet.setbalances(*args)
            self.dispatch('wallet', tmpwallet, ts, False)
                
        except:
            self.logger.error('exception encountered', exc_info=True)
        
    def getrestopenorders(self, account):
        raise NotImplementedError
                                        
    def getrestorder(self, account, ordermsg):
        raise NotImplementedError #The below doesn't work
        # sym0 = self.open_orders_dict[orderid].symbol
        # side = self.open_orders_dict[orderid].side
        # orderdict = self.ccxt.fetch_order(orderid, sym0, params={'type': side.upper()})
        # return self.parse_rest_order(orderdict)

    def parse_place_result(self, orderinfo, ordermsg):
        oinfo = orderinfo.get('info')
        if oinfo.get('success', False):
            ordermsg.status = OrderMsg.NEW
            ordermsg.orderid = orderinfo['id']
        else:
            uniqueid = str(uuid.uuid4())
            ordermsg.orderid = uniqueid
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
        return ordermsg

    #Override base as needs additional info
    def restcancelorder(self, ordermsg):
        try:
            result = self.ccxt_rest_call(ordermsg.account, 'cancel_order', [ordermsg.orderid, ordermsg.symbol], {'params':{'type':ordermsg.side.upper()}})
            omsg = self.parse_cancel_result(result, ordermsg)
        except Exception as e:
            omsg = self.parse_cancel_exception(e, ordermsg)
        if omsg: self.dispatch('order', omsg)


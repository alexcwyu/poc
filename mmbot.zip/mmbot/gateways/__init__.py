#!/usr/bin/env python

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018

DATADIR = 'data'
from gateways.anxpro import anxpro
from gateways.bitmex import bitmex
from gateways.bitmextest import bitmextest
from gateways.binance import binance
from gateways.bittrex import bittrex
from gateways.bitstamp import bitstamp
from gateways.bitfinex import bitfinex
from gateways.gdax import gdax
from gateways.okex import okexspot, okexfut
from gateways.poloniex import poloniex
from gateways.rest import gateio, kraken, hitbtc2, tidex, coinexchange
from gateways.kucoin import kucoin
from gateways.itbit import itbit
from gateways.test import test
from gateways.huobipro import huobipro
from gateways.yobit import yobit
from gateways.lmaxuat import lmaxuat
from gateways.deribit import deribit
from gateways.cf import cf
from gateways.coinmex import coinmex
from gateways.bitforex import bitforex

venues = ['anxpro', 'bitmex', 'binance', 'bittrex', 'bitstamp', 'bitfinex','gdax', 'gateio', 'kraken', 'hitbtc2', 'okexspot', 'okexfut','kucoin', 'bitmextest', 'tidex', 'coinexchange', 'poloniex', 'huobipro','itbit','test','yobit','lmaxuat','deribit','cf','coinmex','bitforex']

#dynamically generate rest data points
def ClassFactory(name, argnames, BaseClass):
#    def __init__(self, **kwargs):
#        print kwargs
#        for key, value in kwargs.items():
#            if key not in argnames:
#                raise TypeError("Argument {} not valid for {}".format(key, self.__class__.__name__))
#            setattr(self, key, value)
#        BaseClass.__init__(self, name[:-len("Class")])
    newclass = type(name, (BaseClass,),{}) #last dict is to override any functions
    return newclass

import ccxt
from gateways.base import Gateway
for exch in ccxt.exchanges:
    if exch not in venues:
        globals()[exch] = ClassFactory(exch, ['credentials','ccxtname','enableRateLimit'], Gateway)
        venues.append(exch)


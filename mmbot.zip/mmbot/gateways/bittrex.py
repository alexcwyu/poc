# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from gevent import monkey
monkey.patch_all()
import threading, uuid
import time
import datetime
import logging
import arrow
import uuid
import utils
from utils import OrderMsg, Fill
from cdecimal import Decimal as D
from collections import defaultdict
from requests import Session
from signalr import Connection
import cfscrape
import base

#
# see https://github.com/aloysius-pgast/bittrex-signalr-client/blob/master/lib/client.js for inspiration
# see https://www.bittrex.com/signalr/hubs

EPOCH = datetime.datetime(1970, 1, 1)

class bittrex(base.Gateway):
    def __init__(self, credentials=[]):
        super(bittrex, self).__init__(credentials)
        self.poll_period = 5
        
        self.timeout = 120000
        self.url = 'http://socket.bittrex.com/signalr'

        session = Session()
        scraper = cfscrape.create_scraper(sess=session)
        self.connection = Connection(self.url, scraper)

        self.corehub = self.connection.register_hub('CoreHub')
        self.connection.received += self.__debug
        self.connection.error += self.__error
        
        self.nounce = defaultdict(int)
        self.NOUNCE_INIT = -1

    def start(self):
        self.connection.start()
        # Register callbacks to handle messages that arrive
        #self.corehub.client.on('updateSummaryState', self.??)
        self.corehub.client.on('updateExchangeState', self.__orderbook_updates)

        t=threading.Thread(target=self.connection.wait)
        t.daemon=True
        t.start()

        self.dispatch('connected', self.venue)

    def stop(self):
        self.connection.close()
        self.dispatch('disconnected', self.venue)
        
    def subscribe_override(self, sym):
        vsym = self.symvert(sym=sym)
        self.corehub.server.invoke('SubscribeToExchangeDeltas', vsym)
        self.nounce[sym] = self.NOUNCE_INIT #reset nounce with internal symbol
        self.__get_snapshot(sym)

    def __get_snapshot(self, symbol):
        pair0 = self.symvert(sym=symbol)
                                             
        def fullbookfunc(msg):
            msg['MarketName'] = pair0 #for some
            #print msg.keys(), msg['MarketName'], '<<<'
            self.__orderbook_updates(msg, isSnapshot=True)

        self.corehub.invoke_with_callback('QueryExchangeState', fullbookfunc, pair0)            

            
    def __error(self, error):
        print('error', error)

    def __debug(self, *args, **kwargs):
        return

    def __orderbook_updates(self, msg, isSnapshot=False):
        """
        Orderbook message types:

        0 - new order entries at matching price, you need to add it to the orderbook
        1 - cancelled / filled order entries at matching price, you need to delete it from the orderbook
        2 - changed order entries at matching price (partial fills, cancellations), you need to edit it in the orderbook

        https://github.com/n0mad01/node.bittrex.api/issues/23

        :param msg:
        :return:
        """
        #print msg['Nounce'], len(msg['Sells']), len(msg['Buys']), isSnapshot

        recvts = time.time()
        bids = []
        asks = []
        trades = []
        pair = self.symvert(venuesym=msg['MarketName'])

        #MD should be able to handle this:
        #if not isSnapshot and self.nounce[pair] == self.NOUNCE_INIT:
        #    self.log(logging.WARNING,'Need fullbook update first')
        #    return

        if self.nounce[pair] == self.NOUNCE_INIT:
            self.nounce[pair] = msg['Nounce']
        elif msg['Nounce'] < self.nounce[pair]:
            self.logger.warning('Nounce out of order: {} {} vs {}'.format(pair, msg['Nounce'], self.nounce[pair]))
            self.nounce[pair] = msg['Nounce'] #update it regardless
        elif msg['Nounce'] > self.nounce[pair] + 1:            
            self.logger.warning('Nounce skipped: {} {} vs {}'.format(pair, msg['Nounce'], self.nounce[pair]))
            self.__get_snapshot(pair)
        else:
            self.nounce[pair] = msg['Nounce']

        for bid in msg['Buys']:
            type_ = bid.get('Type',0)
            price = utils.norm_str(bid['Rate'])
            qty = utils.norm_str(bid['Quantity'])

            if type_ == 0:
                bids.append((price, qty))
            elif type_ == 1:
                bids.append((price, '0'))
            elif type_ == 2: # qty never seems to be negative, so I don't think this is delta
                bids.append((price, qty))
            else:
                self.logger.error('Unknown message type')
                # throw error

        for ask in msg['Sells']:
            type_ = ask.get('Type',0)
            price = utils.norm_str(ask['Rate'])
            qty = utils.norm_str(ask['Quantity'])
            
            if type_ == 0:
                asks.append((price, qty))
            elif type_ == 1:
                asks.append((price, '0'))
            elif type_ == 2:  # qty never seems to be negative, so I don't think this is delta
                asks.append((price, qty))
            else:
                self.logger.error('Unknown message type')

        self.dispatch('book', pair, bids, asks, None, recvts, bFullBook=isSnapshot)
        
        for fill in msg['Fills']:
            if isSnapshot:
                price = utils.norm_str(fill['Price'])
                qty = utils.norm_str(fill['Quantity'])
                side = fill['OrderType'][0] #'B' or 'S'
                ts0 = (arrow.get(fill['TimeStamp']).naive - EPOCH).total_seconds()
            else:
                price = utils.norm_str(fill['Rate'])
                qty = utils.norm_str(fill['Quantity'])
                side = 'B' if fill['OrderType'] == 'BUY' else 'S'
                ts0 = (arrow.get(fill['TimeStamp']).naive - EPOCH).total_seconds()
            trades.append((price, qty, side))
            self.dispatch('trade', pair, price, qty, side, ts0)


    #REST overrides
    #need to override this as bittrex has no fill messages
    def getfullstate(self, account):
        oodict = self.open_orders_dict(account)
        self.logger.info('I have {} open orders'.format(len(oodict)))
        try:
            openorders = self.getrestopenorders(account)
        except:
            self.logger.error('Error getting rest open orders')
            openorders = []

        orderhistory = []
        unknown_oids = set(oodict.keys()).difference(set([x.orderid for x in openorders]))
        if len(unknown_oids) > 0:
            try:
                orderhistory = self.ccxt_rest_call(account, 'fetch_orders')
            except:
                self.logger.error('Error getting rest order history')
            orderhistory = [self.parse_rest_order(account, odict) for odict in orderhistory]
            orderhistory = [o for o in orderhistory if o.orderid in unknown_oids] #filter only for those we are interested in

        unknown_oids = unknown_oids - set([x.orderid for x in orderhistory])
        standalones = []
        for oid in unknown_oids:
            try:
                standalones.append(self.getrestorder(account, oodict[oid].asordermsg()))
            except:
                self.logger.error('Failed to get rest order {}'.format(oid))

        unknown_oids = unknown_oids - set([x.orderid for x in standalones])
        if len(unknown_oids) > 0:
            self.logger.error('No info retreived for {} orders'.format(len(unknown_oids)))
            #Decide what to do here - reject or cancel?

        theirorders = openorders + orderhistory + standalones
        for theirorder in theirorders:
            if theirorder.orderid in oodict:
                ourstate = oodict[theirorder.orderid]
                f2 = D(theirorder.filled)
                f1 = D(ourstate.filled)
                if f2 > f1: #Need to dummy up filled messages
                    fillamt = f2 - f1
                    avgp2 = D(theirorder.avgp)
                    if ourstate.avgp: avgp1 = D(ourstate.avgp)
                    else: avgp1 = 0
                    fillp = (avgp2*f2 - avgp1*f1)/fillamt
                    self.dispatch('fill', Fill(account=account,
                                               tradeid=str(uuid.uuid4()),
                                               orderid=ourstate.orderid,
                                               symbol=ourstate.symbol,
                                               amt=str(fillamt),
                                               side=ourstate.side,
                                               price=str(fillp),
                                               last_ts=theirorder.lastupdated))
            else: #unmatched order
                if D(theirorder.filled) > 0:
                    self.dispatch('fill', Fill(account=account,
                                               tradeid=str(uuid.uuid4()),
                                               orderid=theirorder.orderid,
                                               symbol=theirorder.symbol,
                                               amt=str(theirorder.filled),
                                               side=theirorder.side,
                                               price=theirorder.avgp,
                                               last_ts=theirorder.lastupdated))
            self.dispatch('order', theirorder)

        self.getrestwallets(account)
            
    
    def parse_place_result(self, orderinfo, ordermsg):
        success = orderinfo['info']['success']
        if success:
            ordermsg.status = OrderMsg.NEW
            ordermsg.orderid = orderinfo['info']['result']['uuid']
            return ordermsg
        else:
            return None
        
    def parse_cancel_result(self, result, ordermsg):
        success = result.get('success', False)
        if success:
            ordermsg.status = OrderMsg.CANCELED
            return ordermsg
        else:
            return None

    def parse_rest_fill(self, account, fdict):
        raise Exception('Bittrex does not support fill messages')
        
    def parse_rest_order(self, account, orderdict):
        odict = orderdict['info']
        #Bittrex supports 3 functions that may call this
        # 1 - /market/getopenorders (this is the one that ccxt uses for fetch_open_orders)
        # 2 - /account/getorder
        # 3 - /account/getorderhistory
        # The 3 odict types are slightly different with #2 being the most different

        symbol = self.symvert(venuesym=odict['Exchange'])
        qty = utils.norm_str(str(odict['Quantity']))
        remaining = utils.norm_str(str(odict['QuantityRemaining']))
        filled = utils.norm_str(D(qty)-D(remaining))        

        #HACK: Assumes that this was a limit order
        price = utils.norm_str(str(odict['Limit'])) if 'Limit' in odict else None

        avgp = None
        if odict['PricePerUnit'] is not None:
            avgp = utils.norm_str(str(odict['PricePerUnit']))

        otype = odict.get('Type', odict.get('OrderType', None))
        side = OrderMsg.BUY if otype in ('LIMIT_BUY', 'MARKET_BUY') else OrderMsg.SELL        
        if otype in ('LIMIT_BUY', 'LIMIT_SELL'):
            otype = OrderMsg.LMT
        elif otype in ('MARKET_BUY', 'MARKET_SELL'):
            otype = OrderMsg.MKT
        else:
            otype = OrderMsg.LMT #default
            
        #Parse side and status
        if 'Timestamp' in odict: #type 3 message; know it's closed
            if D(remaining) == 0: status = OrderMsg.FILLED
            else: status = OrderMsg.CANCELED
        elif 'isOpen' in odict: #type 2 message
            if not odict['isOpen']:
                if D(remaining) == 0: status = OrderMsg.FILLED
                else: status = OrderMsg.CANCELED
            else:
                if D(remaining) == 0: status = OrderMsg.FILLED
                elif D(filled) > 0: status = OrderMsg.PARTIALLY_FILLED
                else: status = OrderMsg.NEW
                if odict.get('CancelInitiated', False):
                    status = OrderMsg.PENDING_CANCEL
        else: #type 1 message - open order
            if D(remaining) == 0: status = OrderMsg.FILLED
            elif D(filled) > 0: status = OrderMsg.PARTIALLY_FILLED
            else: status = OrderMsg.NEW
            if odict.get('CancelInitiated', False):
                status = OrderMsg.PENDING_CANCEL

        return utils.OrderMsg(account=account,
                              orderid=odict['OrderUuid'],
                              status=status,
                              symbol=symbol, #converted
                              otype=otype,
                              amt=qty,
                              side=side,
                              price=price, #problem if none       
                              avgp=avgp,
                              filled=filled,
                              remaining=remaining)

            

"""
Orderbook message types:

0 - new order entries at matching price, you need to add it to the orderbook
1 - cancelled / filled order entries at matching price, you need to delete it from the orderbook
2 - changed order entries at matching price (partial fills, cancellations), you need to edit it in the orderbook

https://github.com/n0mad01/node.bittrex.api/issues/23
"""

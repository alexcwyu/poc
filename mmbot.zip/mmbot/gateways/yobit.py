# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Wilson Pau <wilson@valuefocus.cc>, April 2018
from cdecimal import Decimal as D
import uuid
import utils
from utils import OrderMsg, Fill
import base


class yobit(base.Gateway):
    def __init__(self, credentials, ccxtname=None, enableRateLimit=True):
        super(yobit, self).__init__(credentials, enableRateLimit=enableRateLimit)
        self.poll_period = 10

    # REST overrides
    # need to override this as bittrex has no fill messages
    def getfullstate(self, account):
        with self.filllock:
            oodict = self.open_orders_dict(account)
            try:
                openorders = self.getrestopenorders(account)
            except Exception as e:
                self.logger.error('Error getting rest open orders')
                self.logger.error(e)
                openorders = []

            unknown_oids = set(oodict.keys()).difference(set([x.orderid for x in openorders]))

            standalones = []
            for oid in unknown_oids:
                try:
                    standalones.append(self.getrestorder(account, oodict[oid].asordermsg()))
                except Exception as e:
                    self.logger.error('Failed to get rest order {}'.format(oid))
                    self.logger.error(e) 

            unknown_oids = unknown_oids - set([x.orderid for x in standalones if x])
            if len(unknown_oids) > 0:
                self.logger.error('No info retreived for {} orders'.format(len(unknown_oids)))
                # Decide what to do here - reject or cancel?

            theirorders = openorders + standalones
            for theirorder in theirorders:
                if theirorder.orderid in oodict:
                    ourstate = oodict[theirorder.orderid]
                    f2 = D(theirorder.filled)
                    f1 = D(ourstate.filled)
                    if f2 > f1:  # Need to dummy up filled messages
                        fillamt = f2 - f1
                        avgp2 = D(theirorder.avgp)
                        if ourstate.avgp:
                            avgp1 = D(ourstate.avgp)
                        else:
                            avgp1 = 0
                        fillp = (avgp2 * f2 - avgp1 * f1) / fillamt
                        fill = Fill(account=account,
                               tradeid=str(uuid.uuid4()),
                               orderid=ourstate.orderid,
                               symbol=ourstate.symbol,
                               amt=str(fillamt),
                               side=ourstate.side,
                               price=str(fillp),
                               last_ts=theirorder.lastupdated)
                        self.dispatch('fill', fill)
                else:  # unmatched order
                    if D(theirorder.filled) > 0:
                        fill = Fill(account=account,
                               tradeid=str(uuid.uuid4()),
                               orderid=theirorder.orderid,
                               symbol=theirorder.symbol,
                               amt=str(theirorder.filled),
                               side=theirorder.side,
                               price=theirorder.avgp,
                               last_ts=theirorder.lastupdated)
                        self.dispatch('fill', fill)
                self.dispatch('order', theirorder)
        self.getrestwallets(account)

    def getrestopenorders(self, account):
        syms=set([o.symbol for o in self.open_orders_dict(account).values()])
        open_orders = []
        for sym0 in syms:
            open_orders += self.ccxt_rest_call(account, 'fetchOpenOrders', [sym0])
        return [self.parse_rest_order(account, oo) for oo in open_orders]

    def parse_place_result(self, orderinfo, ordermsg):
        success = orderinfo['info']['success']
        if success:
            ordermsg.status = self._parse_status(orderinfo)
            ordermsg.orderid = orderinfo['id']
            return ordermsg
        else:
            return None

    def _parse_status(self, orderinfo):
        status = None
        exchstatus = orderinfo['status']
        if exchstatus == 'open':
            if not orderinfo['filled'] or D(orderinfo['filled']) == 0:
                status = OrderMsg.NEW
            else:
                status = OrderMsg.PARTIALLY_FILLED
        elif exchstatus == 'closed':
            if not orderinfo['remaining'] or D(orderinfo['remaining']) == 0:
                status = OrderMsg.FILLED
            else:
                status = OrderMsg.CANCELED
        elif exchstatus == 'canceled':
            status = OrderMsg.CANCELED
        return status

    def parse_cancel_result(self, result, ordermsg):
        success = result.get('success', False)
        if success:
            ordermsg.status = OrderMsg.CANCELED
            return ordermsg
        else:
            return None

    def parse_rest_fill(self, account, fdict):
        raise Exception('Yobit does not support fill messages')

    def parse_rest_order(self, account, orderdict):
        self.logger.info('parse_rest_order {}'.format(orderdict))
        symbol = orderdict['symbol']
        filled = utils.norm_str(str(orderdict['filled'])) if orderdict['filled'] else '0'
        remaining = utils.norm_str(str(orderdict['remaining'])) if orderdict['remaining'] else '0'
        status = self._parse_status(orderdict)
        side = orderdict['side']
        price = utils.norm_str(str(orderdict['price']))
        qty = utils.norm_str(str(orderdict['amount'])) if orderdict['amount'] else utils.norm_str(D(filled) + D(remaining))
        otype = orderdict['type']
        cost = utils.norm_str(str(orderdict['cost'])) if orderdict['cost'] else '0'
        avgp = None
        if D(cost) != 0 and D(filled) != 0: 
            avgp = D(cost) / D(filled)
            
        omsg = utils.OrderMsg(account=account,
                              orderid=orderdict['id'],
                              status=status,
                              symbol=symbol,
                              otype=otype,
                              amt=qty,
                              side=side,
                              price=price,
                              avgp=avgp,
                              filled=filled,
                              remaining=remaining)

        return omsg

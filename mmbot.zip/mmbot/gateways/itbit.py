# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from cdecimal import Decimal as D
import uuid
import time
import threading
from collections import defaultdict
import hashlib
import utils
import dateparser
import oms
from utils import OrderMsg, Fill
import base

# itbit is restonly for data and privates
class itbit(base.Gateway):
    def __init__(self, credentials, ccxtname=None, enableRateLimit=True):
        super(itbit, self).__init__(credentials, enableRateLimit=enableRateLimit)
        self.poll_period = 5
        for account in self.accounts.keys():
            if account == 'data': continue

            userid = self.accounts[account]['cred']['userId']
            for item in self.ccxt_rest_call(account, 'fetch_wallets', [{'userId':userid}]):
                self.accounts[account]['ccxt'].register_walletid(item['id']) #custom function to set default in ccxt
                break
            self.logger.info('Only supporting one wallet for now')
            break

    def parse_rest_order(self, account, odict):
        return super(itbit, self).parse_rest_order(account, odict)

    def parse_rest_fill(self, account, fdict):
        #itBit does not have execution ids in the fill objects; I will use the md5 hash of the timestamp to be the tradeid

        ts = time.mktime(dateparser.parse(fdict['timestamp']).timetuple())
        return Fill(account=account,
                    tradeid=hashlib.md5(fdict['timestamp']).hexdigest(),
                    orderid=fdict['orderId'],
                    symbol=self.symvert(venuesym=fdict['instrument']),
                    amt=utils.norm_str(fdict['currency1Amount']),
                    side=fdict['direction'],
                    price=utils.norm_str(fdict['rate']),
                    last_ts=ts)

    def getrestfills(self, account, oids):
        ccxt = self.accounts[account]['ccxt']
        #Only gets last 50 for now (no proxy for this one for now)
        results = ccxt.privateGetWalletsWalletIdTrades(ccxt.extend({'walletId':ccxt.walletid}))
        fills = [self.parse_rest_fill(account, fdict) for fdict in results['tradingHistory']]
        return [f for f in fills if f.orderid in oids]


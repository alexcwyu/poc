# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Wilson Pau <wilson@valuefocus.cc>, April 2018
from cdecimal import Decimal as D
import uuid
import time
import json
import threading
import functools
from collections import defaultdict
import utils
import hmac
import hashlib
import oms
from utils import OrderMsg, Fill, Wallet, Position, norm_str
import requests
import base
import base64

class coinmex(base.Gateway):
    def __init__(self, credentials, ccxtname=None, enableRateLimit=True):
        super(coinmex, self).__init__(credentials, ccxtname='kucoin', enableRateLimit=enableRateLimit)
        self.accounts['data']['ccxt'] = None
        self.poll_period = 1
        self.rooturl = 'https://www.coinmex.com'
        self.coi = set() #coins of interest
        self.soi = set() #symbols of interest

        #overwrite the base class implementation of ccxt:w
        for cred in credentials:
            account = '{}:{}'.format(self.venue, cred['alias'])
            self.accounts[account]['ccxt'] = None

    def symvert(self, sym=None, venuesym=None):
        if sym is None and venuesym is not None:
            return self.symbols.canonicalsym(self.venue, venuesym)
        if sym is not None and venuesym is None:
            return self.symbols.venuesym(self.venue, sym).lower()
        raise Exception('Function used incorrectly')

    def getrestbooks(self, symbol):
        self.coi.add(self.symbols.getbaseccy(self.venue, symbol))
        self.coi.add(self.symbols.getquoteccy(self.venue, symbol))
        self.soi.add(symbol)

        vsym = self.symvert(sym=symbol)
        if vsym is None:
            self.logger.error('{} is not a valid symbol'.format(symbol))
            return None

        try:
            url = '{}/api/v1/spot/public/products/{}/orderbook'.format(self.rooturl, vsym)     
            response = requests.get(url)
            data = json.loads(response.text)
            bids, asks = [], []
            for x in data['asks']:
                asks.append((x[0], x[1]))
            for x in data['bids']:
                bids.append((x[0], x[1]))
            return {'bids':bids, 'asks':asks}
        except:
            self.logger.error('Could not get books for {}. Response was {}'.format(symbol, response), exc_info=True)
            return None
        time.sleep(0.5) 

    def getresttrades(self, symbol):
        vsym = self.symvert(sym=symbol)
        if vsym is None:
            self.logger.error('{} is not a valid symbol'.format(symbol))
            return None

        try:
            url = '{}/api/v1/spot/public/products/{}/fills'.format(self.rooturl, vsym)
            response = requests.get(url)     
            data = json.loads(response.text)
            trades = []
            for x in data:
                ts = x[3]
                trades.append({'timestamp': ts/1000.,
                               'side': {'buy':'S', 'sell':'B'}[x[2]], # api gives maker side, we want taker
                               'price': x[0], # string already
                               'amount': x[1] # ditto   
                              })
            return trades
        except:
            self.logger.error('Could not get trades for {}. Rsponse was {}'.format(symbol, response), exc_info=True)
            return []   
    
    def get_nonce(self):
        return str(round(time.time(),3))

    def sign_message(self, secret, msg):
        hmac_digest = hmac.new(secret, msg, hashlib.sha256).digest()
        return base64.b64encode(hmac_digest)

    # override base
    def getfullstate(self, account):
        oodict = self.open_orders_dict(account, reject_pending_new = (self.gfs_call_count == 0))
        self.logger.info('Begin custom get full state {} {} {}'.format(account, oodict, self.gfs_call_count))
        self.gfs_call_count += 1
        try:
            openorders = self.getrestopenorders(account)
        except:
            self.logger.error('Error getting rest open orders', exc_info=True)
            openorders = []

        for order0 in openorders:
            if order0.orderid in oodict:
                fill = self.dummy_diff_fill(account, order0, oodict[order0.orderid].asordermsg())
                if fill:    
                    self.dispatch('fill', fill)
            self.dispatch('order', order0)

        open_oids = set(oodict.keys())
        unknown_oids = open_oids.difference(set([x.orderid for x in openorders])) 

        for oid in unknown_oids:
            self.logger.info('Getting state for previously open order {} {}'.format(account, oid))
            ourorder = oodict[oid].asordermsg()
            ordermsg = self.getrestorder(account, ourorder)
            if ordermsg:
                fill = self.dummy_diff_fill(account, ordermsg, ourorder)
                if fill:    
                    self.dispatch('fill', fill)
                self.dispatch('order', ordermsg)

        self.getrestwallets(account)

    def gen_headers(self, account, signature, nonce):
        key = self.accounts[account]['cred']['apiKey']
        passphrase = self.accounts[account]['cred']['passphrase']
        return {'ACCESS-KEY':key, 'ACCESS-SIGN':signature, 'ACCESS-TIMESTAMP':nonce, 'ACCESS-PASSPHRASE':passphrase, 'content-type':'application/json'}

    def getrestbalances(self, account):
        secret = self.accounts[account]['cred']['secret']
        balance, trade, withdraw = {}, {}, {}
        nonce = self.get_nonce()
        reqpath = '/api/v1/spot/ccex/account/assets'
        msg = '{}GET{}'.format(nonce, reqpath)
        signature = self.sign_message(secret, msg)
        url = '{}{}'.format(self.rooturl, reqpath)
    
        try:
            self.wait_for_low_priority_slot(account)
            response = requests.get(url, headers=self.gen_headers(account, signature, nonce))
            data = json.loads(response.text)
            for x in data:
                coin = x['currencyCode']
                balance[coin] = x['balance']
                trade[coin] = x['available']
                withdraw[coin] = utils.norm_str(D(x['balance']) - D(x.get('frozen', '0')))
        except:
            self.logger.error('Failed to get balances', exc_info=True)
        return {'default': (balance, trade, withdraw)}

    def restplaceorder(self, ordermsg):
        account = ordermsg.account
        secret = self.accounts[account]['cred']['secret']
        vsym = self.symvert(sym=ordermsg.symbol)
        nonce = self.get_nonce()
        reqpath = '/api/v1/spot/ccex/orders'
        self.logger.info('placing order {} {} {} {}'.format(vsym, ordermsg.side, ordermsg.amt, ordermsg.price))
        data = json.dumps({
            'code': vsym,
            'side': ordermsg.side,
            'type': 'limit', 
            'size': ordermsg.amt,
            'price': ordermsg.price,
            'funds': '0'
        })
        msg = '{}POST{}'.format(nonce, reqpath) + data
        signature = self.sign_message(secret, msg)
        url = '{}{}'.format(self.rooturl, reqpath)
        success = False
        try:
            response = requests.post(url, headers=self.gen_headers(account, signature, nonce), data=data)
            r = json.loads(response.text)
            self.logger.info('r {}'.format(r))
            if r.get('result', False):
                success = True
                self.logger.info(r)
                ordermsg.orderid = r['orderId']
        except:
            self.logger.error('Exception occured', exc_info=True)
        
        if not success:
            self.logger.error('Failed to place an order')
            ordermsg.orderid = str(uuid.uuid4())
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED

        self.dispatch('order', ordermsg)

    def restcancelorder(self, ordermsg):
        account = ordermsg.account
        secret = self.accounts[account]['cred']['secret']
        nonce = self.get_nonce()
        vsym = self.symvert(sym=ordermsg.symbol)
        reqpath = '/api/v1/spot/ccex/orders/{}'.format(ordermsg.orderid)
        data = json.dumps({'code': vsym})
        msg = '{}DELETE{}'.format(nonce, reqpath) + data
        signature = self.sign_message(secret, msg)
        url = '{}{}'.format(self.rooturl, reqpath)
        try:
            response = requests.delete(url, headers=self.gen_headers(account, signature, nonce), data=data)
        except:
            self.logger.error('Exception occured', exc_info=True)

    def getrestorder(self, account, ordermsg):
        self.wait_for_low_priority_slot(account)
        account = ordermsg.account
        secret = self.accounts[account]['cred']['secret']
        nonce = self.get_nonce()
        vsym = self.symvert(sym=ordermsg.symbol)
        reqpath = '/api/v1/spot/ccex/orders/{}?code={}'.format(ordermsg.orderid, vsym)
        msg = '{}GET{}'.format(nonce, reqpath)
        signature = self.sign_message(secret, msg)
        url = '{}{}'.format(self.rooturl, reqpath)
            
        try:
            response = requests.get(url, headers=self.gen_headers(account, signature, nonce))
            data = json.loads(response.text)
            if response.status_code == 200:
                return self.parse_rest_order(account, data)
        except:
            self.logger.error('Failed to get open orders for {}'.format(ordermsg.symbol), exc_info=True)
            return None

    def getrestopenorders(self, account):
        secret = self.accounts[account]['cred']['secret']
        openorders = []
        for sym in self.soi.copy():
            nonce = self.get_nonce()
            vsym = self.symvert(sym=sym)
            reqpath = '/api/v1/spot/ccex/orders?code={}&status=open'.format(vsym)
            msg = '{}GET{}'.format(nonce, reqpath)
            signature = self.sign_message(secret, msg)
            url = '{}{}'.format(self.rooturl, reqpath)
            
            try:
                self.wait_for_low_priority_slot(account)
                response = requests.get(url, headers=self.gen_headers(account, signature, nonce))
                data = json.loads(response.text)
                self.logger.info('data {}'.format(data))
                for x in data:
                    self.logger.info('x {}'.format(x))
        
                    omsg = self.parse_rest_order(account, x)
                    openorders.append(omsg)
            except:
                self.logger.error('Failed to get open orders for {}'.format(sym), exc_info=True)
        return openorders

    def dummy_diff_fill(self, account, theirorder, ourorder):
        f2 = D(theirorder.filled)
        f1 = D(ourorder.filled)
        if f2 > f1:
            fillamt = f2 - f1
            avgp2 = D(theirorder.avgp)
            if ourorder.avgp: avgp1 = D(ourorder.avgp)
            else: avgp1 = 0
            fillp = (avgp2*f2 - avgp1*f1)/fillamt

            prev_cost = D(0) if ourorder.cost is None else D(ourorder.cost)
            new_cost = D(0) if theirorder.cost is None else D(theirorder.cost)
            cost = new_cost - prev_cost
            return Fill(account=account,
                        tradeid=str(uuid.uuid4()),
                        orderid=ourorder.orderid,
                        symbol=ourorder.symbol,
                        amt=utils.norm_str(fillamt),
                        side=ourorder.side,
                        price=utils.norm_str(fillp),
                        cost=utils.norm_str(cost),
                        costccy=theirorder.costccy,
                        last_ts=theirorder.lastupdated)
        else:
            return None 

    def parse_rest_order(self, account, orderdict):
        self.logger.info('orderdict {}'.format(orderdict))
        symbol = self.symvert(venuesym=orderdict['code'])
        amount = orderdict['volume']
        filled = orderdict['filledVolume']
        rem = utils.norm_str(D(amount) - D(filled))
        status = orderdict['status']

        if status == 'open':
            status = OrderMsg.NEW
        elif status == 'filled':
            status = OrderMsg.FILLED
        elif status == 'canceled':
            status = OrderMsg.CANCELED
        elif status == 'cancel':
            status = OrderMsg.PENDING_CANCEL
        elif status == 'partially-filled':
            status = OrderMsg.PARTIALLY_FILLED

        omsg = utils.OrderMsg(account=account,
                              orderid=str(orderdict['orderId']),
                              status=str(status),
                              symbol=str(symbol),
                              otype=str(orderdict['orderType']),
                              amt=str(amount),
                              side=str(orderdict['side']),
                              price=str(orderdict['price']),
                              avgp=str(orderdict['averagePrice']),
                              filled=str(filled),
                              remaining=rem,
                              cost=None,
                              costccy=None,
                              last_ts=float(orderdict['createdDate']/1000.),
                              info=None
        )
        return omsg

    def parse_rest_fill(self, account, fillsdict):
        raise NotImplementedError
        
        



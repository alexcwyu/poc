# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, May 2018
from gevent import monkey
monkey.patch_all()
import time
import threading
import gevent.queue as Queue
import datetime
import base64
import hashlib
import os
import quickfix44 as fix44
import quickfix as fix
import base

class fixapp(fix.Application):
    mdreqid = 0
    def __init__(self, gateway, key, secret):
        self.gw = gateway
        self.key = key
        self.secret = secret
        self.sessionid = None

        super(fixapp, self).__init__()
        
    def getmdreqid(self):
        self.mdreqid += 1
        return str(self.mdreqid)
        
    def onCreate(self, sessionid):
        print 'FIXAPP created', sessionid

    def onLogon(self, sessionid):
        self.gw.dispatch('connected', self.gw.venue)
        self.sessionid = sessionid
        self.seclistrequest()

    def onLogout(self, sessionid):
        self.gw.dispatch('disconnected', self.gw.venue)
        self.sessionid = None
    
    def toAdmin(self, message, sessionid):
        msgType = fix.MsgType()
        message.getHeader().getField(msgType)
        if msgType.getValue() == fix.MsgType_Logon:
            rand32 = os.urandom(32)
            nonce = base64.b64encode(rand32)
            pwd = base64.b64encode(hashlib.sha256(nonce + self.secret).digest())
            message.setField(fix.Username(self.key))
            message.setField(fix.Password(pwd))
            message.setField(fix.RawData(nonce))

    def toApp(self, message, sessionid): return
    def fromAdmin(self, message, sessionid): return

    def seclistrequest(self):
        msg = fix44.SecurityListRequest()
        msg.setField(fix.SecurityReqID('1'))
        msg.setField(fix.SecurityListRequestType(fix.SecurityListRequestType_ALL_SECURITIES))
        try:
            fix.Session.sendToTarget(msg, self.sessionid)
        except fix.SessionNotFound as e:
            print 'no session'
        
    def mdrequest(self, sym): #BTC-29JUN18 -14000-C
        msg = fix44.MarketDataRequest()
        msg.setField(fix.Symbol(sym))
        msg.setField(fix.MDReqID(self.getmdreqid()))
        msg.setField(fix.SubscriptionRequestType(fix.SubscriptionRequestType_SNAPSHOT_PLUS_UPDATES))
        #msg.setField(fix.MarketDepth(20))
        #DeribitTradeAmount
        #DeribitSinceTimestamp

        group = fix44.MarketDataRequest().NoMDEntryTypes()
        for md in [fix.MDEntryType_BID, fix.MDEntryType_OFFER, fix.MDEntryType_TRADE]:
            group.setField(fix.MDEntryType(md))
            msg.addGroup(group)
        try:
            fix.Session.sendToTarget(msg, self.sessionid)
        except fix.SessionNotFound as e:
            print 'no session'
    
    def fromApp(self, message, sessionid):
        msgType = fix.MsgType()
        message.getHeader().getField(msgType)
        mtype = msgType.getValue()
        if mtype == fix.MsgType_SecurityList:
            norelatedsyms = fix.NoRelatedSym()
            message.getField(norelatedsyms)
            for i in range(norelatedsyms.getValue()):
                j = i + 1
                group = fix44.SecurityList().NoRelatedSym()
                message.getGroup(j, group)
                Fsymbol = fix.Symbol()
                group.getField(Fsymbol)
                print Fsymbol.getValue()

        elif mtype == fix.MsgType_MarketDataRequestReject:
            print 'md request rejected, recover!'
                
        elif mtype == fix.MsgType_MarketDataSnapshotFullRefresh:
            Fsymbol = fix.Symbol()
            FMDReqID = fix.MDReqID()
            message.getField(Fsymbol)
            symbol = str(Fsymbol.getValue())
            nomdentries = fix.NoMDEntries()
            message.getField(nomdentries)
            bids, asks, trades = [], [], []
            for i in range(nomdentries.getValue()):
                j = i + 1
                group = fix44.MarketDataSnapshotFullRefresh().NoMDEntries()
                message.getGroup(j, group)
                FPrice = fix.MDEntryPx()
                FSize = fix.MDEntrySize()
                FType = fix.MDEntryType()
                FDateTime = fix.StringField(272)#MDEntryDate()
                FSide = fix.Side()
                group.getField(FPrice)
                group.getField(FSize)
                group.getField(FType)
                
                if FType.getValue() == fix.MDEntryType_TRADE:
                    group.getField(FDateTime)
                    group.getField(FSide)
                    dt = datetime.datetime.strptime(FDateTime.getValue(), '%Y%m%d-%H:%M:%S.%f')
                    ts0 = time.mktime(dt.utctimetuple())
                    if FSide.getValue() == fix.Side_BUY: side = 'B'
                    elif FSide.getValue() == fix.Side_SELL: side = 'S'
                    else: side = 'U'
                    trades.append({'side':side,
                                   'price':str(FPrice.getValue()),
                                   'size':str(FSize.getValue()),
                                   'ts':ts0})
                else:
                    assert FType.getValue() in [fix.MDEntryType_BID, fix.MDEntryType_OFFER]
                    if FType.getValue() == fix.MDEntryType_BID:
                        bids.append((str(FPrice.getValue()), str(FSize.getValue())))
                    else:
                        asks.append((str(FPrice.getValue()), str(FSize.getValue())))

            self.gw.q.put(['book', symbol, bids, asks, None, time.time(), True])
            #self.gw.dispatch('book', symbol, bids, asks, None, time.time(), bFullBook=True)
            for trade in sorted(trades, key=lambda x:x['ts']):
                self.gw.q.put(['trade', symbol, trade['price'], trade['size'], trade['side'], trade['ts']])
                #self.gw.dispatch('trade', symbol, trade['price'], trade['size'], trade['side'], trade['ts'])

        elif mtype == fix.MsgType_MarketDataIncrementalRefresh:
            Fsymbol = fix.Symbol()
            #FMDReqID = fix.MDReqID()
            message.getField(Fsymbol)
            #message.getField(FMDReqID)
            symbol = str(Fsymbol.getValue())
            nomdentries = fix.NoMDEntries()
            message.getField(nomdentries)
            bids, asks, trades = [], [], []
            for i in range(nomdentries.getValue()):
                j = i + 1
                group = fix44.MarketDataIncrementalRefresh().NoMDEntries()
                message.getGroup(j, group)
                FAction = fix.MDUpdateAction()
                FType = fix.MDEntryType()
                FPrice = fix.MDEntryPx()
                FSize = fix.MDEntrySize()
                FDateTime = fix.StringField(272)#MDEntryDate()
                FSide = fix.Side()
                #FIndex = fix.Price()
                
                group.getField(FAction)
                group.getField(FType)
                group.getField(FPrice)


                if FType.getValue() == fix.MDEntryType_TRADE:
                    group.getField(FDateTime)
                    group.getField(FSide)
                    group.getField(FSize)
                    dt = datetime.datetime.strptime(FDateTime.getValue(), '%Y%m%d-%H:%M:%S.%f')
                    ts0 = time.mktime(dt.utctimetuple())
                    if FSide.getValue() == fix.Side_BUY: side = 'B'
                    elif FSide.getValue() == fix.Side_SELL: side = 'S'
                    else: side = 'U'
                    trades.append({'side':side,
                                   'price':str(FPrice.getValue()),
                                   'size':str(FSize.getValue()),
                                   'ts':ts0})
                else:
                    assert FType.getValue() in [fix.MDEntryType_BID, fix.MDEntryType_OFFER]
                    if FAction.getValue() == fix.MDUpdateAction_DELETE:
                        size = '0'
                    else:
                        assert FAction.getValue() in [fix.MDUpdateAction_NEW, fix.MDUpdateAction_CHANGE]
                        group.getField(FSize)
                        size = str(FSize.getValue())
                    
                    if FType.getValue() == fix.MDEntryType_BID:
                        bids.append((str(FPrice.getValue()), size))
                    else:
                        asks.append((str(FPrice.getValue()), size))

            self.gw.q.put(['book', symbol, bids, asks, None, time.time(), False])
            #self.gw.dispatch('book', symbol, bids, asks, None, time.time(), bFullBook=False)
            for trade in sorted(trades, key=lambda x:x['ts']):
                self.gw.q.put(['trade', symbol, trade['price'], trade['size'], trade['side'], trade['ts']])
                #self.gw.dispatch('trade', symbol, trade['price'], trade['size'], trade['side'], trade['ts'])

        
        else:
            print mtype, '<<<!!!!'
        

class deribit (base.Gateway):
    def __init__(self, credentials=[]):
        super(deribit, self).__init__(credentials, ccxtname='bitstamp')
        self.accounts['data']['ccxt'] = None
        self.poll_period = -1
        assert len(credentials) == 1
        self.key = credentials[0]['apiKey']
        self.secret = credentials[0]['secret']
        self._running = False
        self.q = Queue.Queue()

    def listen(self):
        while self._running:
            try:
                msg = self.q.get(timeout=0.01)
                if msg[0] == 'book': #kwarg ruins it
                    self.dispatch('book', msg[1], msg[2], msg[3], msg[4], msg[5], bFullBook=msg[6])
                elif msg[0] == 'trade':
                    self.dispatch(*msg)
            except Queue.Empty:
                continue
            
        
    def connect(self): #don't need gfs so override connect directly
        self.mdstate.clear_subscriptions(self.venue)
        self.start()

    def start(self):
        try:
            settings = fix.SessionSettings('gateways/deribit.fixsettings')
            self.app = fixapp(self, self.key, self.secret)
            storeFactory = fix.FileStoreFactory(settings)
            logFactory = fix.ScreenLogFactory(settings)
            self.con = fix.SocketInitiator(self.app, storeFactory, settings, logFactory)
            self.con.start()
        except fix.ConfigError as e:
            print e

        self._running = True
        t = threading.Thread(target=self.listen)
        t.deamon = True
        t.start()

    def stop(self):
        self.con.stop()
        self._running = False

    def subscribe(self, sym): #override this to get rid of rest behavior
        if self.mdstate.is_subscribed(self.venue, sym):
            self.logger.info('already subscribed')
            return
        self.app.mdrequest(str(sym))

    def unsubscribe(self, sym):
        pass

    def placeorder(self, internalid, ordermsg):
        raise Exception('Not implemented')

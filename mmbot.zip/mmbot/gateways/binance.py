# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from collections import defaultdict
import logging, json
import time
import threading
import ssl
import Queue
import websocket
import requests
import uuid
import utils
from utils import OrderMsg, Fill, Wallet, Position
from cdecimal import Decimal
import ccxt
import base

#
# API Documentation:
# https://github.com/binance-exchange/binance-official-api-docs/blob/master/web-socket-streams.md
#
#

KEEPALIVE_INTERVAL=15*60 #Call keepalive for private endpoints every 15 mins
RESTART_INTERVAL=24*60*60 #Restart everything once a day

class binanceTrades(threading.Thread):
    def __init__(self, binancesymbol, parentQ, logger):
        super(binanceTrades, self).__init__(name="Trades"+binancesymbol)
        self.url = 'wss://stream.binance.com:9443/ws/%s@trade' % binancesymbol
        self.ws = websocket.WebSocketApp(self.url,
                                         on_message=self._on_message,
                                         on_open=self._on_open,
                                         on_close=self._on_close,
                                         on_error=self._on_error
        )
        self.sym = binancesymbol
        self.account = 'data'
        self.Q = parentQ
        self.logger = logger
        self.daemon = True
        
    def run(self):
        self.logger.info('connecting {}'.format(self.url))
        self.ws.run_forever(sslopt = {'cert_reqs':ssl.CERT_NONE})

    def _on_message(self, ws, message):
        msg = json.loads(message, parse_float=Decimal, parse_int=Decimal)
        event = msg['e']
        if event == 'trade': self.Q.put((self.account, msg))

    def stop(self):
        self.logger.info('disconnecting {}'.format(self.url))
        self.ws.close()

    def _on_open(self, ws):
        self.logger.info('connected {}'.format(self.url))

    def _on_close(self, ws):
        self.logger.info('disconnected {}'.format(self.url))

    def _on_error(self, ws, error):
        self.logger.error('Encountered an error {}'.format(error))


class binanceDepth(threading.Thread):
    def __init__(self, binancesymbol, parentQ, logger):
        super(binanceDepth, self).__init__(name="Depth"+binancesymbol)
        self.url = 'wss://stream.binance.com:9443/ws/%s@depth' % binancesymbol
        self.ws = websocket.WebSocketApp(self.url,
                                         on_message=self._on_message,
                                         on_open=self._on_open,
                                         on_close=self._on_close,
                                         on_error=self._on_error
        )
        self.sym = binancesymbol
        self.account='data'
        self.Q = parentQ
        self.daemon = True
        self.logger = logger

        self.fb_sent = False
        self.fb = None
        self.fb_ready = False
        self.prebuffer = []
        

    def fetchfullbook(self):
        fb_url = 'https://www.binance.com/api/v1/depth?symbol=%s&limit=1000' % self.sym.upper()
        r = requests.get(fb_url)
        self.fb = r.json()
        self.fb['lastUpdateId'] = Decimal(self.fb['lastUpdateId'])
        for side in ['bids', 'asks']:
            self.fb[side] = [x[:2] for x in self.fb[side]]
            self.fb[side] = [(utils.norm_str(x[0]), utils.norm_str(x[1])) for x in self.fb[side]]
        self.fb_ready = True
            
    def run(self):
        self.logger.info('connecting {}'.format(self.url))
        self.ws.run_forever(sslopt = {'cert_reqs':ssl.CERT_NONE})

    def _on_message(self, ws, message):
        msg = json.loads(message, parse_float=Decimal, parse_int=Decimal)
        event = msg['e']
        if event == 'depthUpdate':
            #case 1 - fb not ready yet; prebuffer msgs
            if not self.fb_ready:
                assert not self.fb_sent
                self.prebuffer.append(msg)
                self.fetchfullbook()
            else:
                #case 2 fb ready but not sent yet
                if not self.fb_sent:
                    self.prebuffer.append(msg)
                    self.Q.put((self.account, {'e':'fullbook', 'a':self.fb['asks'], 'b':self.fb['bids'], 's':self.sym, 'U':self.fb['lastUpdateId']}))
                    for msg0 in self.prebuffer:
                        #TODO: needs to be a bit more stringent
                        # drop msgs where u<=lastUpdateId
                        # msg to send should have U>=lastUpdateId+1
                        if msg0['u'] > self.fb['lastUpdateId']:
                            self.Q.put((self.account, msg0))
                    self.prebuffer = []
                    self.fb_sent = True

                #case 3 fb was sent - just forward the message
                else:
                    self.Q.put((self.account, msg))
    def stop(self):
        self.logger.info('disconnecting {}'.format(self.url))
        self.ws.close()

    def _on_open(self, ws):
        self.logger.info('connected {}'.format(self.url))

    def _on_close(self, ws):
        self.logger.info('disconnected {}'.format(self.url))

    def _on_error(self, ws, error):
        self.logger.error('Encountered an error {}'.format(error))

class binancePrivate(threading.Thread):
    def __init__(self, account, listenkey, parentQ, logger):
        super(binancePrivate, self).__init__(name="Private-{}".format(account))
        self.url = 'wss://stream.binance.com:9443/ws/%s' % (listenkey)
        self.ws = websocket.WebSocketApp(self.url,
                                         on_message=self._on_message,
                                         on_open=self._on_open,
                                         on_close=self._on_close,
                                         on_error=self._on_error
        )
        self.account = account
        self.Q = parentQ
        self.daemon = True
        self.logger = logger
        self.__running = True
        
    def run(self):
        self.logger.info('connecting {}'.format(self.url))
        self.ws.run_forever(sslopt = {'cert_reqs':ssl.CERT_NONE})
                
    def _on_message(self, ws, message):
        msg = json.loads(message, parse_float=Decimal, parse_int=Decimal)
        self.Q.put((self.account, msg))
            
    def stop(self):
        self.logger.info('disconnecting private')
        self.__running = False
        self.ws.close()

    def _on_open(self, ws):
        self.logger.info('private connected account {}'.format(self.account))
        
    def _on_close(self, ws):
        self.logger.info('private closed account {}'.format(self.account))
        if self.__running:
            self.logger.info('triggering restart for account {}'.format(self.account))
            self.Q.put((self.account, {'e':'restartPrivate'}))
        
    def _on_error(self, ws, error):
        self.logger.error('Encountered an error {} account {}'.format(error, self.account))


        
class binance (base.Gateway):
    def __init__(self, credentials = []):
        super(binance, self).__init__(credentials)

        self.privates = {}
        for account in self.accounts.keys():
            if account == 'data': continue
            self.privates[account] = {}
            self.privates[account]['key'] = self.accounts[account]['cred']['apiKey']
            self.privates[account]['secret'] = self.accounts[account]['cred']['secret']
            self.privates[account]['thread'] = None
            self.privates[account]['last_keepalive'] = time.time()
            self.accounts[account]['wallets'] = {'default': True}
                
        self.httpurl = 'https://api.binance.com'
        self.procmsg = None
        self.activesubs = {}
        self.msgQ = Queue.Queue()

    def start(self, dispatch=True):

        self.last_restart = time.time()
        if self.procmsg == None:
            self.procmsg=threading.Thread(target=self._process_messages, name="processmsg")
            self.procmsg.daemon = True
            self.procmsg.start()
        
        for account in self.privates:
            if (self.privates[account]['thread'] is None or not self.privates[account]['thread'].isAlive()):
                listenkey = self.__get_listenkey(account)
                if listenkey:
                    self.privates[account]['thread']=binancePrivate(account, listenkey, self.msgQ, self.logger)
                    self.privates[account]['thread'].start()
                else:
                    self.logger.error('Could not subscribe to private account {}'.format(account))

        #Tee up data
        self.activesubs = {}
        
        if dispatch:
            self.dispatch('connected', self.venue)

    def stop(self, dispatch=True):
        for ep, v in self.activesubs.items():
            v.stop()

        for account in self.privates:
            if self.privates[account]['thread'] is not None and self.privates[account]['thread'].isAlive():
                self.logger.info('disconnecting private account {}'.format(account))
                self.privates[account]['thread'].stop()

        if dispatch:
            self.dispatch('disconnected', self.venue)

    def subscribe_override(self, sym):
        vsym = self.symvert(sym=sym)
        vsym = vsym.lower()
        self.activesubs[(sym, 'trades')]=binanceTrades(vsym, self.msgQ, self.logger)
        self.activesubs[(sym, 'trades')].start()
        self.activesubs[(sym, 'book')]=binanceDepth(vsym, self.msgQ, self.logger)
        self.activesubs[(sym, 'book')].start()

    def __get_listenkey(self, account):
        url = self.httpurl + '/api/v1/userDataStream'
        headers = {'content-type': 'application/json',
                   'X-MBX-APIKEY': self.privates[account]['key']}
        r = requests.post(url, headers=headers)
        response = json.loads(r.content)
        if 'listenKey' in response:
            return response['listenKey']
        else:
            self.logger.error('binance unable to obtain listenKey for account {}'.format(account))
            return None

    def __keep_alive(self, account):
        url = self.httpurl + '/api/v1/userDataStream'
        headers = {'content-type': 'application/json',
                   'X-MBX-APIKEY': self.privates[account]['key']}
        r = requests.put(url, headers=headers)                                                                                                

    def check_keepalives(self):
        now = time.time()
        if now - self.last_restart > RESTART_INTERVAL:
            self.logger.info("Auto restart")
            self.stop(dispatch=False)
            self.start(dispatch=False)
        else:
            for account in self.privates:
                if now - self.privates[account]['last_keepalive'] > KEEPALIVE_INTERVAL:
                    if self.privates[account]['thread'] is not None and self.privates[account]['thread'].isAlive():
                        self.__keep_alive(account)
                        self.logger.info("Keepalive called for account {}".format(account))
                        self.privates[account]['last_keepalive'] = time.time()
                    else:
                        self.logger.error("private thread dead for account {}".format(account))


    def getrestopenorders(self, account):
        syms=set([o.symbol for o in self.open_orders_dict(account).values()])
        open_orders = []
        for sym0 in syms:
            open_orders += self.ccxt_rest_call(account, 'fetchOpenOrders', [sym0])
        return [self.parse_rest_order(account, oo) for oo in open_orders]

    def getrestorder(self, account, ordermsg):
        oodict = self.open_orders_dict(account)
        if ordermsg.orderid in oodict:
            sym0 = oodict[ordermsg.orderid].symbol
            try:
                orderdict = self.ccxt_rest_call(account, 'fetch_order', [ordermsg.orderid, sym0])
            except ccxt.OrderNotFound as onf:
                return None
            return self.parse_rest_order(account, orderdict)
        else:
            return None

    def parse_place_result(self, orderinfo, omsg):
        oinfo = orderinfo.get('info',{})
        account = omsg.account
        omsg.orderid = oinfo.get('orderId',None)
        if omsg.orderid:
            return self.parse_rest_order(account, orderinfo)
        return None

    def parse_place_exception(self, exception, ordermsg):
        if 'MIN_NOTIONAL' in exception.message:
            ordermsg.orderid = str(uuid.uuid4())
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.NOTIONAL_TOO_SMALL
            return ordermsg
        return super(binance, self).parse_place_exception(exception, ordermsg)
        
    def parse_cancel_result(self, result, omsg):
        #TODO
        self.logger.info('result from parse_cancel_result {}'.format(result)) 
        if 'orderId' in result.keys():
            omsg.status = OrderMsg.CANCELED
        else:
            self.logger.error('Unexpected order cancel result format: {}'.format(result))
            return None
        return omsg

    def parse_rest_fill(self, account, filldict):
        try:
            fdict = filldict['info']
            oid = fdict['orderId']
            ostate = self.oms.getorderstate(account, oid)
            return Fill(account=account,
                        tradeid=fdict['id'],
                        orderid=fdict['orderId'],
                        symbol=ostate.symbol,
                        amt=utils.norm_str(fdict['qty']),
                        side=ostate.side,
                        price=utils.norm_str(fdict['price']),
                        last_ts=time.time())
        except:
            self.logger.error('Could not parse rest fill', exc_info=True)
            return None
    
    def parse_rest_order(self, account, orderdict):
        odict = orderdict['info']
        symbol = self.symvert(venuesym=odict['symbol'].upper())

        status = odict['status']
        if status == 'NEW':
            status = OrderMsg.NEW
        elif status == 'PARTIALLY_FILLED':
            status = OrderMsg.PARTIALLY_FILLED
        elif status == 'PENDING_CANCEL':
            status = OrderMsg.PENDING_CANCEL
        elif status == 'FILLED':
            status = OrderMsg.FILLED
        else:
            status = OrderMsg.CANCELED

        oType = str(odict['type'])
        if oType == 'LIMIT':
            oType = OrderMsg.LMT
        elif oType == 'MARKET':
            oType = OrderMsg.MKT

        side = str(odict['side'])
        if side == 'BUY':
            side = OrderMsg.BUY
        elif side == 'SELL':
            side = OrderMsg.SELL
        else:
            pass

        price = odict.get('price', None)
        if price == None:
            raise Exception("Cannot build order with no price")
        else:
            price = Decimal(price)
        
        origQty = Decimal(odict['origQty'])
        executedQty = Decimal(odict['executedQty'])
        
        sFilled = utils.dec_to_str(executedQty)
        sRemaining = utils.dec_to_str(origQty - executedQty)

        ts = 0
        if 'time' in odict:
            ts = float(odict['time'])/1000.
        else:
            ts = float(odict['transactTime'])/1000.

        #TODO: time in force?
        return utils.OrderMsg(account=account,
                              orderid=str(odict['orderId']),
                              status=status,
                              symbol=symbol, #converted
                              otype=oType,
                              amt=utils.norm_str(origQty),
                              side=side,
                              price=utils.norm_str(price),
                              avgp=odict.get('average',None),
                              filled=sFilled,
                              remaining=sRemaining,
                              cost=odict.get('cost', None),
                              costccy=odict.get('costccy',None),
                              last_ts=ts,
                              info=odict
        )

    def _process_messages(self):
        while True:
            try:
                self.check_keepalives()
                #need the timeout as upon a restart, self.msgQ could have changed but would have blocked on the old queue otherwise
                (account, msg) = self.msgQ.get(timeout=0.2)
            except Queue.Empty:
                continue
            except Exception as e:
                self.logger.error(e, exc_info=True)
                continue
            event = msg['e']
            if event == 'trade':
                price = utils.norm_str(msg['p'])
                qty = utils.norm_str(msg['q'])
                sym = self.symvert(venuesym=msg['s'].upper())
                ts = int(msg['T'])/1000.
                side = 'S'if msg['m'] else 'B' #If maker flag True then Buyer is the maker of the market, so trade is a sell.
                self.dispatch('trade', sym, price, qty, side, ts)

            elif event == 'depthUpdate':
                sym = self.symvert(venuesym=msg['s'].upper())
                ts = int(msg['E'])/1000.
                bidlst = [(utils.norm_str(x[0]), utils.norm_str(x[1])) for x in msg['b']]
                asklst = [(utils.norm_str(x[0]), utils.norm_str(x[1])) for x in msg['a']]
                seqnum = int(msg['U'])
                self.dispatch('book', sym, bidlst, asklst, ts, seqnum, bFullBook=False)

            elif event == 'fullbook':
                sym = self.symvert(venuesym=msg['s'].upper())
                ts = int(msg['U'])/1000.
                bidlst = msg['b']
                asklst = msg['a']
                seqnum = int(msg['U'])
                self.dispatch('book', sym, bidlst, asklst, ts, seqnum, bFullBook=True)

            elif event == 'restartPrivate':
                listenkey = self.__get_listenkey(account)
                if listenkey:
                    self.privates[account]['thread']=binancePrivate(account, listenkey, self.msgQ, self.logger)
                    self.privates[account]['thread'].start()
                else:
                    self.logger.error('Could not subscribe to private for account {}'.format(account))
                
            elif event == 'outboundAccountInfo':
                ts = float(msg['E'])/1000 #event time
                baldata = msg['B'] #list of balances {'a':"LTC",'f':'balance','l':'locked by open orders'}

                tmpwallet = self.oms.getwallet(account, 'default')
                if not tmpwallet:
                    tmpwallet = Wallet(account, 'default', self.accounts[account]['wallets']['default'])
                total = tmpwallet.balance
                free = tmpwallet.tradable
                for data in baldata:
                    #Binance API example has all values in this dict as string. Not officially documented as such.

                    assert all([type(x) in [str, Decimal, unicode] for x in data.values()])

                    #Assume that there are no duplicates for ccy                                                                                                                                                                                                                                                                                                                 
                    assert len(set([x['a'] for x in msg['B']])) == len(baldata)
                    ccy = self.symbols.canonical(self.venue, data['a'])
                    freecoin = data['f']
                    lockedcoin = data['l']
                    totalcoin = Decimal(freecoin) + Decimal(lockedcoin)
                    
                    free[ccy] = Decimal(freecoin)
                    total[ccy] = totalcoin

                tmpwallet.setbalances(total, free, free)
                self.dispatch('wallet', tmpwallet, ts, False)
                    
            elif event == 'executionReport': #can be trade update or order update
                eventTime = msg['E'] #event time
                symbol = self.symvert(venuesym=msg['s'].upper())
                newClientOrderId = msg['c']
                side = str(msg['S'].upper())
                if side == 'SELL':
                    side = OrderMsg.SELL
                else:
                    side = OrderMsg.BUY
                    
                otype = str(msg['o'].upper())
                if otype == 'LIMIT':
                    otype = OrderMsg.LMT
                elif otype == 'MARKET':
                    otype = OrderMsg.MKT

                timeInForce = str(msg['f'])
                origQty = utils.norm_str(msg['q'])
                price = utils.norm_str(msg['p'])
                executionType = str(msg['x'])
                orderStatus = str(msg['X'])
                orderRejectReason = msg['r']
                orderId = utils.norm_str(msg['i'])

                status = orderStatus
                if status == 'NEW':
                    status = OrderMsg.NEW
                elif status == 'PARTIALLY_FILLED':
                    status = OrderMsg.PARTIALLY_FILLED
                elif status == 'FILLED':
                    status = OrderMsg.FILLED
                elif status == 'PENDING_CANCEL':
                    status = OrderMsg.PENDING_CANCEL
                elif status == 'CANCELED':
                    status = OrderMsg.CANCELED
                elif status == 'REJECTED':
                    status = OrderMsg.REJECTED
                    rejectmsg = OrderMsg.EXCHANGE_REJECTED
                    self.logger.info("account {} orderid {} rejected by exchange, reason is {}".format(account, orderId, orderRejectReason))
                elif status == 'EXPIRED':
                    status = OrderMsg.DONE_FOR_DAY
                else:
                    self.logger.error("Unknown orderstate {}".format(status))

                lastFillQty = utils.norm_str(msg['l'])
                accFillQty = utils.norm_str(msg['z'])
                lastFillPrice = utils.norm_str(msg['L'])
                commission = utils.norm_str(msg['n'])
                commCcy = msg['N']
                tradeTime = utils.dec_to_str(msg['T'])
                tradeId = utils.dec_to_str(msg['t'])
                buyerMaker = msg['m']
                remaining = utils.norm_str(Decimal(origQty) - Decimal(accFillQty))

                ts = float(tradeTime)/1000.

                self.logger.info('binance order message for account {} {}: '.format(account, msg))
                if executionType == 'TRADE':
                    #This is an order update
                    order = OrderMsg(account=account,
                                     orderid = orderId,
                                     status=status,
                                     symbol=symbol,
                                     otype=otype,
                                     amt=origQty,
                                     side=side,
                                     price=price,
                                     avgp=None,
                                     filled=accFillQty,
                                     remaining=remaining,
                                     cost=commission,
                                     costccy=commCcy,
                                     last_ts=ts,
                                     info=msg)
                    self.dispatch('order', order)

                    fill = Fill(account = account,
                                tradeid = tradeId,
                                orderid = orderId,
                                symbol = symbol,
                                amt = lastFillQty,
                                side = side,
                                price = lastFillPrice,
                                cost = commission,
                                costccy = commCcy,
                                last_ts = ts)
                    self.dispatch('fill', fill)
                else:
                    #This is an order update
                    order = OrderMsg(account=account,
                                     orderid = orderId,
                                     status=status,
                                     symbol=symbol,
                                     otype=otype,
                                     amt=origQty,
                                     side=side,
                                     price=price,
                                     avgp=None,
                                     filled=accFillQty,
                                     remaining=remaining,
                                     cost=commission,
                                     costccy=commCcy,
                                     last_ts=ts,
                                     info=msg)
                    self.dispatch('order', order)
            else:
                self.logger.error('unhandled message')
        self.logger.info('Stop processing messages')

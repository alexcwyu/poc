# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import time
import threading
from collections import defaultdict
from cdecimal import Decimal as D
import uuid
import oms
import utils
from utils import OrderMsg, Fill
import base

class kraken(base.Gateway):
    pass

class hitbtc2(base.Gateway):
    pass

class gateio(base.Gateway):
    pass

class tidex(base.Gateway):
    pass

class coinexchange(base.Gateway):
    #Coin exchange doesn't suppoer orders API
    pass
                

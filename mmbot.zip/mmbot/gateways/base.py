# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from gevent import monkey
monkey.patch_all()
from gateways import DATADIR
import time, datetime
import os
import uuid
import logging
import threading
import Queue
import ccxt
import reference
import json, cPickle
from collections import defaultdict
from cdecimal import Decimal as D
import zmq.green as zmq
import pubsub
import utils
from utils import OrderMsg, Book, Wallet, Position
import oms
import settings
import redis
import functools

class Job(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.daemon = True
        
class GFSThread(threading.Thread):
    def __init__(self, gwref, poll_period, account):
        threading.Thread.__init__(self)
        self.gwref = gwref
        self.poll_period = poll_period
        self.account = account
        self.__running = True

    def stop(self):
        self.__running = False
        
    def run(self):
        while self.__running:
            self.gwref.getfullstate(self.account)
            if self.poll_period < 0: break #run once and drop out
            time.sleep(self.poll_period)
        
#This class is needed to prevent simultaneous out of order rest requests that cause nonce issues on same account
class RestCoordinator(threading.Thread):
    def __init__(self, gwref):
        threading.Thread.__init__(self)
        self.daemon = True
        self.gwref = gwref
        self.event = threading.Event()
        self.__running = True
        self.orderQ = Queue.Queue()

    def stop(self):
        self.__running = False

    def sortorders(self, ordermsgs):
        noprice = [o for o in ordermsgs if o.price is None] #could be mkt orders or something
        buys = [o for o in ordermsgs if o.price is not None and o.side == OrderMsg.BUY]
        sells = [o for o in ordermsgs if o.price is not None and o.side == OrderMsg.SELL]
        buys = sorted(buys, key=lambda x:-float(x.price))
        sells = sorted(sells, key=lambda x:float(x.price))
        prioritized = noprice
        n = max(len(buys), len(sells))
        for i in range(n):
            try:prioritized.append(buys[i])
            except IndexError:pass
            try:prioritized.append(sells[i])
            except IndexError:pass
        return prioritized
        
    def run(self):
        while self.__running:
            cancels, placements = [], []
            while True:
                try:
                    item = self.orderQ.get(block=True, timeout=0.1)
                    if item[0] == 'P':
                        placements.append(item[1])
                    elif item[0] == 'C':
                        cancels.append(item[1])
                except Queue.Empty:
                    break

            if len(cancels) + len(placements) > 0:
                self.gwref.logger.info('Have orders to cancel/place {} {}'.format(cancels, placements))
                self.event.clear() #Take control of the nonce
                try:
                    self.gwref.restbatchorders(cancels, placements)#, amends)
                    cancels = []
                    placements = []
                except NotImplementedError:
                    cancels = self.sortorders(cancels)
                    placements = self.sortorders(placements)

                try:
                    for omsg in cancels:
                        self.gwref.restcancelorder(omsg)
                    for omsg in placements:
                        self.gwref.restplaceorder(omsg)
                except:
                    self.gwref.logger.error('Something bad happened', exc_info=True)
            else:
                self.event.set() #Allow low priority events to run
            
        
# Gateway class
class Gateway(object):

    def __init__(self, credentials=[], ccxtname=None, enableRateLimit=True):#False):
        self.logger = logging.getLogger(self.__class__.__name__)

        #Options that subclasses should set
        self.poll_period = 30
        self.gfs_call_count = 0

        self.pm = ProxyMan()
        
        self.__running = True

        self.symbols = reference.Symbols()
        self.oms = oms.RedisOMS()
        self.pub = pubsub.Publisher()
        self.mdstate = pubsub.MDState()
        
        self.venue = self.__class__.__name__

        self.saveQ = Queue.Queue()

        self.perpetual_jobs = set()
        
        self.datalock = threading.Lock()
        self.filllock = threading.Lock()
        self.books = {}

        start_t = time.time() #TODO: load from backend - current implementation ensures we only get data newer than the gateway start to avoid duplicates
        self.lasttrade_ts = defaultdict(lambda: start_t)
        
        #TODO: load from backend (need to populate all for open_orders)
        self.fillsbyoid = defaultdict(dict) #{orderid: tradeid: fillobj}

        self._dispatcher = defaultdict(list)
        
        self.accounts = defaultdict(dict)
        ccxtvenue = self.venue if ccxtname is None else ccxtname

        #Each gateway has one data account and then 0 or more actual accounts
        self.accounts['data']['ccxt'] = getattr(ccxt, ccxtvenue)({'enableRateLimit':enableRateLimit})
        for cred in credentials:
            cred.update({'enableRateLimit':enableRateLimit})
            account = '{}:{}'.format(self.venue, cred['alias'])
            self.accounts[account]['cred'] = cred
            self.accounts[account]['ccxt'] = getattr(ccxt, ccxtvenue)(cred)
            self.accounts[account]['wallets'] = {'default': True}   #walletname: is it a spot wallet
        try:
            self.markets = self.accounts['data']['ccxt'].load_markets()
        except:
            self.logger.error('Unable to populate markets for {}'.format(self.venue))
        self.logger.info('Gateway started for {}'.format(self.venue))

        t=threading.Thread(target=self.save_loop)
        t.daemon=False #required so file will be closed properly
        t.start()

    def cmd_loop(self):
        context = zmq.Context()
        socket = context.socket(zmq.SUB)
        socket.connect("tcp://localhost:{}".format(settings.CMD_SUBPORT))
        topicfilter = "cmd:{}".format(self.venue)
        socket.setsockopt(zmq.SUBSCRIBE, topicfilter)

        while True:
            try:
                msg = socket.recv()
                channel, msg = msg.split(None, 1)

                item = json.loads(msg)
                subcmd = item['cmd']
                args = item.get('args', [])

                if subcmd == 'connect':                            
                    self.connect()

                elif subcmd == 'disconnect':
                    self.disconnect()
            
                elif subcmd == 'exit':
                    self.disconnect()
                    self.__running = False
                    self.logger.info('Exiting command loop')

                    break
                
                elif subcmd == 'subscribe':
                    symbol = args[0]
                    self.subscribe(symbol)
                    
                elif subcmd == 'unsubscribe':
                    #r.pubsub_numsub -> really unsubscribe to symbol if there are no more remaining subscribers
                    pass
                elif subcmd == 'fullbook':
                    symbol = args[0]
                    with self.datalock:
                        if symbol in self.books:
                            fb,fa,sn = self.books[symbol].bids, self.books[symbol].asks, self.books[symbol].iseq
                        else:
                            fb,fa,sn = [], [], -1

                    self.pub.publish_fullbook(self.venue, symbol, fb, fa, sn)
                    self.logger.info("FULLBOOK PUBLISHED {}, {}".format(self.venue, symbol))

                elif subcmd == 'place':
                    internalid, ordermsg = args[0], cPickle.loads(str(args[1]))
                    self.placeorder(internalid, ordermsg)
            
                elif subcmd == 'cancel':
                    internalid = args[0]
                    self.cancelorder(internalid)

                elif subcmd == 'requeststate':
                    account = args[0]
                    orderid = args[1]
                    order0 = self.getrestorder(account, self.oms.getorderstate(account, orderid).asordermsg())
                    if order0:
                        self.dispatch('order', order0)
                else:
                    raise Exception('invalid cmd {}'.format(subcmd))
            except:
                self.logger.error('Error parsing in cmd loop', exc_info=True)

    def save_loop(self):
        utcdt = datetime.datetime.utcnow().strftime('%Y%m%d')
        ofile = '{}/{}/{}.data'.format(DATADIR, utcdt, self.venue)
        odir = os.path.dirname(ofile)
        if not os.path.exists(odir):
            os.makedirs(odir)
        
        flag = 'a' if os.path.exists(ofile) else 'w'
        fhandle = open(ofile, flag)
        if flag == 'w': fhandle.write('timestamp;msgtype;venue;symbol;jsondata\n')
        
        while self.__running:
            try:
                msg = self.saveQ.get(block=True, timeout=1)
            except Queue.Empty:
                if not self.__running: break
                continue
            utcdt = datetime.datetime.utcnow().strftime('%Y%m%d')
            candfile = '{}/{}/{}.data'.format(DATADIR, utcdt, self.venue)

            if candfile != ofile:
                fhandle.close()
                ofile = candfile
                odir = os.path.dirname(ofile)
                if not os.path.exists(odir):
                    os.makedirs(odir)
                flag = 'a' if os.path.exists(ofile) else 'w'
                fhandle = open(ofile, flag)
                if flag == 'w': fhandle.write('timestamp;msgtype;venue;symbol;jsondata\n')

            stype, venue, sym, jsondata = msg
            ts = time.time()
            fhandle.write('{};{};{};{};{}\n'.format(ts,stype,venue,sym,jsondata))
        fhandle.close()
        self.logger.info('Exiting Save loop')
        
    def register_callback(self, channel, callback):
        self._dispatcher[channel].append(callback)
        
    def dispatch(self, channel, *args, **kwargs):
        
        if channel in ['book', 'trade']:
            with self.datalock:
                #publish directly to redis
                if channel == 'book':
                    symbol,lstbids,lstasks,fexchts,fseqnum = args
                    bfullbook = kwargs['bFullBook']
                    if bfullbook:
                        self.books[symbol] = Book(lstbids, lstasks, fseqnum, name='{}{}'.format(self.venue, symbol))
                        fullbids, fullasks = self.books[symbol].bids, self.books[symbol].asks
                        self.pub.publish_fullbook(self.venue, symbol, fullbids, fullasks, self.books[symbol].iseq)
                        savedata = {'bids':fullbids, 'asks':fullasks,'iseq':self.books[symbol].iseq}
                        self.saveQ.put(('fb', self.venue, symbol, json.dumps(savedata)))
                    else:
                        if symbol not in self.books: return
                        bup,aup,iseq = self.books[symbol].applyupdates(lstbids, lstasks, fseqnum)
                        self.pub.publish_bookdiffs(self.venue, symbol, bup, aup, iseq)
                        savedata = {'dbids':bup, 'dasks':aup, 'iseq':iseq}
                        self.saveQ.put(('db', self.venue, symbol, json.dumps(savedata)))
                    #self.mdstate.update_lastbook_ts(self.venue, symbol)

                else:
                    assert channel == 'trade'
                    symbol, price, amt, side, exchts = args

                    self.pub.publish_trade(self.venue, symbol, price, amt, side, float(exchts))
                    #self.mdstate.update_lasttrade_ts(self.venue, symbol, exchts)
                        
                    savedata = {'price':price, 'qty':amt, 'side':side, 'exchts':float(exchts)}
                    self.saveQ.put(('t', self.venue, symbol, json.dumps(savedata)))

                self.mdstate.register_subscription(self.venue, symbol) #Tell the world we have data
                
        elif channel == 'stats':
            symbol, oi, rawdata = args
            rawdatastr = {}
            for k,v in rawdata.items():
                rawdatastr[k] = str(v) #Does not do well with nested!
            self.saveQ.put(('stats', self.venue, symbol, json.dumps({'oi':str(oi), 'info':rawdatastr})))
                
        elif channel in ['connected', 'disconnected']:
            for func in self._dispatcher[channel]:
                func(*args, **kwargs)
  
        elif channel == 'wallet':
            self.oms.setwallet(*args, **kwargs)
            
        else:
            if channel == 'order':
                omsg = args[0]
                self.oms.order_update(omsg)

            elif channel == 'fill':
                fillobj = args[0]
                self.oms.handle_fill(fillobj)

    def wait_for_low_priority_slot(self, account):
        if account != 'data':
            #Wait for the high priority loop to set the event before we go
            self.accounts[account]['coordinator'].event.wait()
                
    def ccxt_rest_call(self, account, fname, args=[], kwargs={}):
        proxyip = self.pm.getproxy(self.venue)
        if proxyip == 'noproxy':
            self.logger.info('{} {} {} Not using a proxy'.format(threading.current_thread(), fname, str(args)))
            self.accounts[account]['ccxt'].proxies = None
        else:
            self.logger.info('{} {} {} Using {} as proxy'.format(threading.current_thread(), fname, str(args), proxyip))
            self.accounts[account]['ccxt'].proxies = {'http':proxyip, 'https':proxyip}
            
        try:
            result = getattr(self.accounts[account]['ccxt'], fname)(*args, **kwargs)
            self.pm.proxyresult(proxyip, self.venue, True)
            return result
        except Exception as e:
            self.logger.error('ccxt error', exc_info=True)
            self.pm.proxyresult(proxyip, self.venue, False)
            raise e
                
    #REST data functions - not meant to be overridden as ccxt support is actually quite good
    def getrestbooks(self, symbol):
        try:
            return self.ccxt_rest_call('data', 'fetch_l2_order_book', [symbol], {})
        except:
            self.logger.error('Could not get books for {}'.format(symbol))
            return None

    def getresttrades(self, symbol):
        try:
            return self.ccxt_rest_call('data', 'fetchTrades', [symbol], {})
        except:
            self.logger.error('Could not get trades for {}'.format(symbol))
            return []

    def rest_data_job(self, symbol):
        books = self.getrestbooks(symbol)
        if books:
            self.dispatch('book', symbol, books['bids'], books['asks'], time.time(), 0., bFullBook=True)

        trades = self.getresttrades(symbol)
        trades = sorted(trades, key=lambda x:float(x['timestamp']))
        curr_ts = 0
        for trade in trades:
            curr_ts = trade['timestamp']
            if curr_ts > self.lasttrade_ts[symbol]:
                try:
                    price = utils.norm_str(str(trade['price']))
                    amt = utils.norm_str(str(trade['amount']))
                    if trade['side']: side = trade['side'][0].upper()
                    else: side = 'U' #Unknown
                    ts = float(trade['timestamp'])/1000.
                    self.dispatch('trade', symbol, price, amt, side, ts)
                except:
                    self.logger.error('Could not parse trade {}'.format(trade))
        self.lasttrade_ts[symbol] = max(self.lasttrade_ts[symbol], curr_ts)


    def getrestbalances(self, account):
        self.wait_for_low_priority_slot(account)
        start_t = time.time()
        bal = self.ccxt_rest_call(account, 'fetch_balance')
        end_t = time.time()
        self.logger.info('Balance fetched, took {} seconds'.format(end_t-start_t))
        balance = {self.symbols.canonical(self.venue, str(ccy)):str(amt) for ccy,amt in bal['total'].items() if abs(D(amt)) > 0}
        trade = {self.symbols.canonical(self.venue, str(ccy)):str(amt) for ccy,amt in bal['free'].items() if abs(D(amt)) > 0}
        withdraw = {self.symbols.canonical(self.venue, str(ccy)):str(amt) for ccy,amt in bal['free'].items() if abs(D(amt)) > 0}

        # use default wallet
        return {'default': (balance, trade, withdraw)}

    def getrestpositions(self, account):
        #Need overriding for derivative positions
        return {}

    def getrestopenorders(self, account):
        self.wait_for_low_priority_slot(account)
        try:
            start_t = time.time()
            orderdicts = self.ccxt_rest_call(account, 'fetchOpenOrders')
            end_t = time.time()
            self.logger.info('Got {} open orders in {} secs'.format(len(orderdicts), end_t-start_t))
            return [self.parse_rest_order(account, odict) for odict in orderdicts]
        except Exception as e:
            self.logger.info('Error encountered getting open orders', exc_info=True)
            return []

    def getrestorder(self, account, ordermsg):
        self.wait_for_low_priority_slot(account)
        try:
            orderdict = self.ccxt_rest_call(account, 'fetch_order', [ordermsg.orderid])
            if orderdict:
                return self.parse_rest_order(account, orderdict)
            return None
        except ccxt.OrderNotFound as onf:
            self.logger.info('Order not found with orderid {}'.format(ordermsg.orderid), exc_info=True)
            #ordermsg.status = OrderMsg.CANCELED #Should this be a reject instead?
            #return ordermsg
            return None
        except Exception as e:
            self.logger.info('Error encountered looking for orderid {}'.format(ordermsg.orderid), exc_info=True)
            return None
        
    def getrestfills(self, account, oids):
        #needs symbol for a lot of these things
        syms = set()
        for oid in oids:
            ostate = self.oms.getorderstate(account, oid)
            
            if ostate:
                syms.add(ostate.symbol)
        filldicts = []
        for sym in syms:
            self.wait_for_low_priority_slot(account)
            filldicts += self.ccxt_rest_call(account, 'fetch_my_trades', [], {'symbol':sym})
        result = [self.parse_rest_fill(account, fdict) for fdict in filldicts]
        return [r for r in result if r is not None]

    
    def getfullstate(self, account):
        self.oids_filled_this_pass = set()
        #Orders
        oodict = self.open_orders_dict(account, reject_pending_new = (self.gfs_call_count == 0))
        self.logger.info('Begin get full state {} {} {}'.format(account, oodict, self.gfs_call_count))
        self.gfs_call_count += 1
        try:
            openorders = self.getrestopenorders(account)
        except:
            self.logger.error('Error getting rest open orders')
            openorders = []
            
        for order0 in openorders:
            if order0.orderid in oodict:
                if D(order0.filled) > D(oodict[order0.orderid].filled):
                    self.oids_filled_this_pass.add(order0.orderid)
            self.dispatch('order', order0)

        open_oids = set(oodict.keys())
        unknown_oids = open_oids.difference(set([x.orderid for x in openorders]))

        for oid in unknown_oids:
            self.logger.info('Getting state for previously open order {} {}'.format(account, oid))
            ordermsg = self.getrestorder(account, oodict[oid].asordermsg())
            if ordermsg:
                if D(ordermsg.filled) > 0:
                    self.oids_filled_this_pass.add(ordermsg.orderid)
           
                self.dispatch('order', ordermsg) #Tell oms about orders that were updated while it was offline
        #Fills
        try:
            fillobjs = self.getrestfills(account, self.oids_filled_this_pass)
            for fillobj in fillobjs:
                self.fillsbyoid[fillobj.orderid][fillobj.tradeid] = fillobj
                self.dispatch('fill', fillobj)
                self.oids_filled_this_pass.discard(fillobj.orderid)
            if len(self.oids_filled_this_pass) > 0:
                self.logger.error('Could not get fills for oids: {}'.format(self.oids_filled_this_pass))
        except:
            self.logger.error('Error getting rest fills')

        self.getrestwallets(account)

    def getrestwallets(self, account):
        ts = time.time() #Use the time before the request to be conservative
        if account in self.accounts:
            try:
                restbals = self.getrestbalances(account)
            except:
                self.logger.error('Failed to get balance', exc_info=True)
                restbals = None

            try:
                restpos = self.getrestpositions(account)
            except:
                self.logger.error('Failed to get positions', exc_info=True)
                restpos = None
            if 'wallets' in self.accounts[account]:
                for wal in self.accounts[account]['wallets']:
                    #Balances/positions  
                    tmpwallet = self.oms.getwallet(account, wal)
                    if not tmpwallet:
                        tmpwallet = Wallet(account, wal, self.accounts[account]['wallets'][wal])

                    if restbals and wal in restbals:
                        balance, trade, withdraw = restbals[wal]
                        tmpwallet.setbalances(balance, trade, withdraw)

                    if not tmpwallet.spot and restpos and wal in restpos:
                        # need this to clear positions that have been closed out
                        # wallet won't clear if getrestpositions failed
                        tmpwallet.clearpos()
                        for p in restpos[wal]:
                           tmpwallet.setposition(p)
                    self.dispatch('wallet', tmpwallet, ts, False)
            
    # open_orders_dict: Only to be called on startup (otherwise will immediately reject all un-acked orders)
    def open_orders_dict(self, account, reject_pending_new=False):
        open_orders_dict = {}
        active_orders = self.oms.open_orders(account)
        for order0 in active_orders:
            if order0.orderid:
                open_orders_dict[order0.orderid] = order0
            else:
                self.logger.error('Persisted order {} in state {} has no orderid'.format(order0.internalid, order0.status))
                if reject_pending_new:
                    omsg = order0.asordermsg()
                    omsg.status = OrderMsg.REJECTED
                    omsg.rejectmsg = OrderMsg.PENDING_NEW_TIMEOUT
                    self.dispatch('order', omsg)
        return open_orders_dict
            
    # Management API
    def connect(self):
        self.gfs_call_count = 0
        self.perpetual_jobs = set()
        self.mdstate.clear_subscriptions(self.venue)
        for account in self.accounts.keys():
            if account == 'data': continue
            if 'coordinator' not in self.accounts[account]:
                self.accounts[account]['coordinator'] = RestCoordinator(self) 
                self.accounts[account]['coordinator'].start()            
            if 'gfsthread' not in self.accounts[account]:
                self.accounts[account]['gfsthread'] = GFSThread(self, self.poll_period, account)
                self.accounts[account]['gfsthread'].start()
        self.start()

    def disconnect(self):
        for account in self.accounts.keys():
            if account == 'data': continue
            if 'coordinator' in self.accounts[account]:
                self.accounts[account]['coordinator'].stop()
                self.accounts[account].pop('coordinator', None)
            if 'gfsthread' in self.accounts[account]:
                self.accounts[account]['gfsthread'].stop()
                self.accounts[account].pop('gfsthread', None)
        self.stop()        

    def subscribe(self, sym):
        #check to see if we already have this
        if self.mdstate.is_subscribed(self.venue, sym):
            self.logger.info('already subscribed')
            return

        #get one book immediately - needs to be synchronous
        book = self.getrestbooks(sym)
        if book:
            self.dispatch('book', sym, book['bids'], book['asks'], time.time(), 0., bFullBook=True)
        
        #venue specific implementation for updates
        self.subscribe_override(sym)

    def unsubscribe(self, sym):
        pass
#        numsubs = self.pub.numsubs(self.venue, sym)
#        self.logger.info('there are {} subscribers'.format(numsubs))

#        if self.mdstate.is_subscribed(self.venue, sym) and numsubs == 0:
#            self.unsubscribe_override(sym)
#        else:
#            self.logger.info('subscription maintained as there are {} subscribers'.format(numsubs))
        
    #Override these methods for websocket implementations
    def start(self):
        #start any websockets and or threads that are required
        #dispatch 'connected' when complete
        self.dispatch('connected', self.venue)

    def stop(self):
        #should stop all threads and dispatch disconnected
        self.dispatch('disconnected', self.venue)
    
    def subscribe_override(self, sym):
        if sym in self.perpetual_jobs:
            self.logger.info('Already subscribed to {}'.format(sym))
            return

        class PeriodicData(Job):
            name = sym
            def run(self0):
                sym0 = sym
                while self0.name in self.perpetual_jobs:
                    #TODO: rate limiting besides ccxt
                    self.rest_data_job(sym0)
        p = PeriodicData()
        self.perpetual_jobs.add(p.name)
        self.logger.info('Subscribing to {}'.format(sym))
        p.start()

    def unsubscribe_override(self, sym):
        #TODO: need to check that no more clients need this data
        self.perpetual_jobs.discard(sym) #Will automatically stop any perpetual jobs

    #Override these methods if there are better versions or when we get away from ccxt
    def symvert(self, sym=None, venuesym=None):
        if sym is None and venuesym is not None:
            tryval = self.symbols.canonicalsym(self.venue, venuesym)
            if tryval: return tryval
            #self.logger.warning('Falling back on ccxt to lookup vsym {}'.format(venuesym))
            return self.accounts['data']['ccxt'].markets_by_id[venuesym]['symbol']
        if sym is not None and venuesym is None:
            tryval = self.symbols.venuesym(self.venue, sym)
            if tryval: return tryval
            #self.logger.warning('Falling back on ccxt to lookup sym {}'.format(sym))
            return self.accounts['data']['ccxt'].markets[sym]['id']
        raise Exception('You used this function incorrectly')
    
    def placeorder(self, internalid, ordermsg):
        self.logger.info('received request to place order')
        self.accounts[ordermsg.account]['coordinator'].orderQ.put(('P',ordermsg))

    def cancelorder(self, internalid):
        self.logger.info('received request to cancel order')
        ordermsg = self.oms.getorderstatebyid(internalid).asordermsg()
        self.accounts[ordermsg.account]['coordinator'].orderQ.put(('C', ordermsg))

    def modifyorder(self, orderobj):
        #parse_modify_result
        raise Exception('Modifies not yet supported')

    def restplaceorder(self, ordermsg):
        symbol = ordermsg.symbol
        ordertype = {OrderMsg.LMT:'limit', OrderMsg.MKT:'market'}[ordermsg.otype]
        side = {OrderMsg.BUY:'buy', OrderMsg.SELL:'sell'}[ordermsg.side]
        amount = float(ordermsg.amt) #s/b string? ccxt is strange
        price = float(ordermsg.price)
        ccy, marginamt = self.balrequired(symbol, side, amount, price)
        wallet = self.oms.getwallet(ordermsg.account, 'default')
        if wallet: freebal = D(wallet.tradable.get(ccy, '0'))
        else: freebal = D(0)
        if freebal < marginamt:
            ordermsg.orderid = str(uuid.uuid4()) #dummy oid
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.INSUFFICIENT_FUNDS
            self.dispatch('order', ordermsg)
        else:
            try:
                orderinfo = self.ccxt_rest_call(ordermsg.account, 'create_order', [symbol, ordertype, side, amount, price])
                omsg = self.parse_place_result(orderinfo, ordermsg)
            except Exception as e:
                self.logger.error('Unable to submit order {}'.format(ordermsg), exc_info=True)                        
                omsg = self.parse_place_exception(e, ordermsg)                        
            if omsg: 
                self.dispatch('order', omsg)

    def restcancelorder(self, ordermsg):
        try:
            result = self.ccxt_rest_call(ordermsg.account, 'cancel_order', [ordermsg.orderid, ordermsg.symbol])
            omsg = self.parse_cancel_result(result, ordermsg)
        except Exception as e:
            self.logger.error('Unable to cancel order {}'.format(ordermsg.orderid), exc_info=True)
            omsg = self.parse_cancel_exception(e, ordermsg)
        if omsg:
            self.dispatch('order', omsg)

    def restbatchorders(self, cancels, placements):#amends
        #Override this for gateways that support it
        raise NotImplementedError

    #Functions to override
    def parse_rest_fill(self, account, filldict):
        #returns fill obj
        self.logger.warning('You are using the default ccxt fill parser, parse this instead: {}'.format(filldict.get('info', {})))
        return None

    def parse_place_result(self, orderinfo, omsg):
        #returns None or Omsg
        self.logger.warning('You are using the default ccxt place parser, parse this instead: {}'.format(orderinfo.get('info', {})))
        omsg.orderid = orderinfo.get('id', None)
        if omsg.orderid: return omsg
        return None

    def parse_place_exception(self, exception, ordermsg):
        #Since this order was never submitted to the exchange and oms.on_orderupdate requires ordermsgs to have orderid's, we create a fake one here so that the oms can handle it
        ordermsg.orderid = str(uuid.uuid4())
        ordermsg.status = OrderMsg.REJECTED
        ordermsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
        return ordermsg
    
    def parse_modify_result(self, response, omsg):
        #returns None or Omsg
        return None
    
    def parse_cancel_result(self, response, omsg):
        #returns None or Omsg
        return None

    def parse_cancel_exception(self, exception, ordermsg):
        self.logger.error('parse_cancel_exception {} {}'.format(exception, type(exception)))
        #TODO: dummy up some state here?
        #if type(exception) == ccxt.OrderNotFound:
        #    return None
        return None
    
    def parse_rest_order(self, account, orderdict):
        #returns ordermsg
        self.logger.warning('You are using the default ccxt order parser, parse this instead: {}'.format(orderdict.get('info',{})))

        rejectmsg = None
        status = orderdict['status']
        if status == 'open':
            if orderdict['filled'] > 0:
                status = OrderMsg.PARTIALLY_FILLED
            else:
                status = OrderMsg.NEW
        elif status == 'closed':
            if orderdict['filled'] == orderdict['amount']:
                status = OrderMsg.FILLED
            else:
                status = OrderMsg.STOPPED
        elif status == 'canceled':
            status = OrderMsg.CANCELED
        elif status == 'rejected':
            status = OrderMsg.REJECTED
            rejectmsg = OrderMsg.EXCHANGE_REJECTED
            self.logger.info("Exchange reject msg received, order details {}".format(orderdict))
        elif status == 'expired':
            status = OrderMsg.DONE_FOR_DAY
        else:
            status = status #This should never happen - throws error
            self.logger.error("base gateway parse_rest_order found unknown status = {}".format(status))

        assert orderdict['type'] in [OrderMsg.MKT, OrderMsg.LMT]
        assert orderdict['side'] in [OrderMsg.BUY, OrderMsg.SELL]
    
        fee = orderdict['fee']
        if fee:
            cost = str(fee['cost'])
            costccy = fee['currency']
        else:
            cost = None
            costccy = None

        omsg = utils.OrderMsg(account=account,
                              orderid=str(orderdict['id']),
                              status=status,
                              symbol=orderdict['symbol'], #converted
                              otype=orderdict['type'],
                              amt=str(orderdict['amount']),
                              side=orderdict['side'],
                              price=str(orderdict['price']),
                              avgp=str(orderdict['average']),
                              filled=str(orderdict['filled']),
                              remaining=str(orderdict['remaining']),
                              cost=cost,
                              costccy=costccy,
                              last_ts=float(orderdict['timestamp']),
                              info=orderdict['info']
        )

        if status == OrderMsg.REJECTED:
            omsg.rejectmsg = rejectmsg

        return omsg
                                                                                                                                                                                                            
    def balrequired(self, symbol, side, amt, price):
        assert utils.isfloat(amt)
        assert utils.isfloat(price)

        if self.symbols.isccypair(symbol):
            base, quote = symbol.split('/')
            if side == OrderMsg.BUY:
                return quote, D(amt)*D(price)
            else:
                assert side == OrderMsg.SELL
                return base, D(amt)
        else:
            raise Exception('symbol is not a ccy pair, need to provide gateway override for balrequired')

# redis structure:
#  set: proxies -> set of ip's available for use
class ProxyMan(object):
    def __init__(self, n=10):
        self.logger = logging.getLogger('proxyman')
        self.n = n
        self.r = redis.StrictRedis()
        self._loadavailproxies()

    def reset(self): #reset all proxy info
        for key in self.r.smembers('pmkeys'):
            self.r.delete(key)
        self.r.delete('pmkeys')
        self.r.delete('proxies')

    def _loadavailproxies(self):
        self.proxies = list(self.r.smembers('proxies')) + ['noproxy']

    def getproxy(self, venue):
        self._loadavailproxies()
        timenow = time.time()
        cands = []
        for proxy in self.proxies:
            histkey = '{}:{}:history'.format(venue, proxy)
            lastkey = '{}:{}:last'.format(venue, proxy)

            history = self.r.lrange(histkey, 0, -1)
            lastcall = self.r.get(lastkey)
            try:
                lastcall = float(lastcall)
            except:
                lastcall = 0

            if len(history) > 0:
                failrate = len([x for x in history if x == 'False'])/float(self.n)
            else:
                failrate = 0

            #print proxy, failrate, lastcall
            if timenow - lastcall > 1 and failrate < 0.8:
                self.r.set(lastkey, time.time()) #prevent others from using it
                return proxy

            #jailed for a minute if failure rate = 1
            if failrate == 1 and timenow - lastcall < 60:
                pass
            else:
                cands.append((proxy, lastcall, failrate))

        if len(cands) == 0:
            self.logger.error('No more proxies left to use for {}'.format(venue))
            return 'noproxy'
                
        cands = sorted(cands, key=lambda x:x[1]) #sort by time
        self.r.set('{}:{}:last'.format(venue, cands[0][0]), time.time())
        return cands[0][0]

    def proxyresult(self, proxy, venue, suceeded):
        histkey = '{}:{}:history'.format(venue, proxy)
        lastkey = '{}:{}:last'.format(venue, proxy)
        self.r.sadd('pmkeys', histkey, lastkey)
        self.r.lpush(histkey, suceeded)
        self.r.ltrim(histkey, 0, self.n - 1) #keep only n around
        self.r.set(lastkey, time.time())

        

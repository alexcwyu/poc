# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, April 2018
import requests
from cdecimal import Decimal as D
from collections import defaultdict
from gateways import DATADIR
import os
from utils import OrderMsg, Fill, Wallet
import base
import time
import threading
import uuid

# Test scenarios
#    p_n timeout
#    rejects
#    normal order submission + cancellation
#    normal order submission + fill
#    cancel timeout

class test (base.Gateway):
    def __init__(self, credentials = []):
        #Dummy up ccxtname
        super(test, self).__init__(credentials, ccxtname='bitstamp')
        self.poll_period = -1

        if len(self.accounts) != 2:
            raise Exception('Test gateway requires 1 private ep only')

        for account in self.accounts.keys():
            if account == 'data': continue
            self.account = account
        
        self.placecount = 0
        self.cancelcount = 0

        wallet = Wallet(self.account, 'default', True)
        totbal = {'USD': '100000'}
        trade = totbal
        withdraw = totbal
        wallet.setbalances(totbal, trade, withdraw)
        
        self.dispatch('wallet', wallet, time.time(), False)

    def start(self):
        self.dispatch('connected', self.venue)

    def stop(self):
        self.dispatch('disconnected', self.venue)

    def subscribe_override(self, sym):
        pass

    def unsubscribe_override(self, sym):
        pass

    def placeorder(self, internalid, omsg):
        fillobj = None
        if omsg.symbol == 'PNTEST':
            return #ignore all ETH/BTC trades to test pending_new
        elif omsg.symbol == 'REJECTTEST':
            omsg.orderid = str(uuid.uuid4())
            omsg.status = OrderMsg.REJECTED
            omsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
        elif omsg.symbol == 'FILLTEST':
            omsg.orderid = str(uuid.uuid4())
            omsg.status = OrderMsg.FILLED

            fillobj = Fill(account=omsg.account,
                           tradeid=str(uuid.uuid4()),
                           orderid=omsg.orderid,
                           symbol=omsg.symbol,
                           amt=omsg.amt,
                           side=omsg.side,
                           price=omsg.price,
                           last_ts=time.time())
            
        else:
            omsg.orderid = str(uuid.uuid4())
            omsg.status = OrderMsg.NEW
        self.dispatch('order', omsg)
        if fillobj:
            self.dispatch('fill', fillobj)
        
    def cancelorder(self, internalid):
        orderobj = self.oms.getorderstatebyid(internalid)
        if orderobj.symbol == 'CANCELTEST':
            return

        omsg = orderobj.asordermsg()
        omsg.status = OrderMsg.CANCELED
        self.dispatch('order',omsg)

    def getrestbooks(self, symbol): pass

    def getresttrades(self, symbol): pass

    def getrestopenorders(self, account): return []

    def getrestorder(self, account, ordermsg):
        return None

    def getfullstate(self, account):
        pass

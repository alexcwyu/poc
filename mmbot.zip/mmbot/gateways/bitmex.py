# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from gateways import DATADIR
import os
import json, cPickle
import logging
import time, datetime
import requests
import hmac, hashlib, urlparse
import websocket
from collections import defaultdict
import utils
import threading
import arrow
from utils import OrderMsg, Fill, dec_to_str, Position, Wallet
from cdecimal import Decimal
import base

class bitmex (base.Gateway):
    def __init__(self, credentials=[]):
        super(bitmex, self).__init__(credentials)
        self.keylookup = {}
        self.orders, self.fills = {}, {}

        self.poll_period = -1 #gfs may be causing throttling issues
        
        if len(self.accounts) > 2:
            raise Exception('Only supporting 1 private account now')

        for account in self.accounts.keys():
            if account == 'data': continue
            self.account = account
            self.key = self.accounts[account]['cred']['apiKey']
            self.secret = self.accounts[account]['cred']['secret']
            self.accounts[account]['wallets'] = {'default': False}
                
        self.miscfilepath = DATADIR + '/bitmex.misc'
        if os.path.exists(self.miscfilepath):
            self.miscfile = open(self.miscfilepath,'a')
        else:
            self.miscfile = open(self.miscfilepath, 'w')
            self.miscfile.write('ts;msgtype;jsondata\n')

    def getrestpositions(self, account):
        positions = []
        try:
            pd = self.ccxt_rest_call(self.account, 'private_get_position')
        except:
            pd = []
            self.logger.error('Failed to get positions', exc_info=True)
        for x in pd:
            positions.append(self.parseposition(x))
        return {'default': positions}
        

    def parseposition(self, posdict):
        x = posdict
        e8 = Decimal(100000000)
        sym = x['symbol']
        qty = str(x['currentQty'])

        if 'unrealisedPnl' in x and str(x['unrealisedPnl']) not in ['None', 'null']:
            upnl = utils.norm_str(Decimal(str(x['unrealisedPnl']))/e8)
        else:
            upnl = None
        if 'realisedPnl' in x and str(x['realisedPnl']) not in ['None', 'null']:
            rpnl = utils.norm_str(Decimal(str(x['realisedPnl']))/e8)
        else:
            rpnl = None
        if 'initMargin' in x and str(x['initMargin']) not in ['None', 'null']:
            initmargin = utils.norm_str(Decimal(str(x['initMargin']))/e8)
        else:
            initmargin = None
        if 'maintMargin' in x and str(x['maintMargin']) not in ['None', 'null']:
            maintmargin = utils.norm_str(Decimal(str(x['maintMargin']))/e8)
        else:
            maintmargin = None
        marginccy = 'BTC'
        if 'liquidationPrice' in x and str(x['liquidationPrice']) not in ['None', 'null']:
            liqprice = str(x['liquidationPrice'])
        else:
            liqprice = None
        if 'avgEntryPrice' in x and str(x['avgEntryPrice']) not in ['None', 'null']:
            avgp = str(x['avgEntryPrice'])
        else:
            avgp = None
        if 'leverage' in x and str(x['leverage']) not in ['None', 'null']:
            lvg = str(x['leverage'])
        else:
            lvg = None
        pos = Position(sym,
                       self.account,
                       sym,
                       qty=qty,
                       unrealised=upnl,
                       unrealisedccy=self.symbols.getsettlementccy(self.venue, sym),
                       initmargin=initmargin,
                       maintmargin=maintmargin,
                       marginccy=marginccy,
                       liqprice=liqprice,
                       avgp=avgp,
                       leverage=lvg)
        return pos

    def restplaceorder(self, ordermsg):
        flags = getattr(ordermsg, 'flags', {'postonly':False})
        params = {}
        if flags['postonly']:
            params['execInst'] = 'ParticipateDoNotInitiate'

        symbol = ordermsg.symbol
        ordertype = {OrderMsg.LMT:'limit', OrderMsg.MKT:'market'}[ordermsg.otype]
        side = {OrderMsg.BUY:'buy', OrderMsg.SELL:'sell'}[ordermsg.side]
        amount = float(ordermsg.amt)
        price = float(ordermsg.price)

        #TODO: balrequired is not checked here as need to consider margin
        
        try:
            orderinfo = self.ccxt_rest_call(ordermsg.account, 'create_order', [symbol, ordertype, side, amount, price, params])
            omsg = self.parse_place_result(orderinfo, ordermsg)
        except Exception as e:
            self.logger.error('Unable to submit order {}'.format(ordermsg), exc_info=True)
            omsg = self.parse_place_exception(e, ordermsg)
        if omsg: self.dispatch('order', omsg)
            
        
    #Note: once we have batch restplaceorder and restcancelorder should not be called again
    # def restbatchorders(self, cancels, placements): #amends
    #     proxyip = self.pm.getproxy(self.venue)
    #     if len(cancels) > 0:
    #         canceloids = [omsg.orderid for omsg in cancels]
    #         try:
    #             response = self.accounts[self.account]['ccxt'].privateDeleteOrder({'orderID': ','.join(canceloids)})
    #             self.logger.info('PARSE ME! {}'.format(response))
                
    #         except:
    #             self.logger.error('Could not bulk cancel', exc_info=True)


    #     if len(placements) > 0:
    #         try:
    #             request = [{'symbol':o.symbol, 'side':o.side.upper(), 'orderQty':float(o.amt), 'ordType':'LIMIT', 'price':float(o.price)} for o in placements]
    #             response = self.accounts[self.account]['ccxt'].privatePostOrderBulk(body=request)
    #             #def parse_rest_order(self, account, orderdict):
    #             self.logger.info('PARSE ME! {}'.format(response))
    #         except:
    #             self.logger.error('Could not bulk place', exc_info=True)
        
    def parse_place_result(self, orderinfo, omsg):
        info = orderinfo.get('info', None)
        if info:
            return self.parse_rest_order(omsg.account, orderinfo)
        self.logger.error('could not parse msg {}'.format(orderinfo))
        return None

    parse_cancel_result = parse_place_result
    
    def parse_rest_order(self, account, orderdict):
        #Implements FIX-compatible status codes
        #http://www.onixs.biz/fix-dictionary/5.0.SP2/tagNum_39.html
        odict = orderdict.get('info', None)
        status = odict['ordStatus']

        if status not in OrderMsg.STATES:
            self.logger.error('Unknown orderstate from bitmex: %s' % odict['ordStatus'])

        price = odict.get('price', None)
        if price: price = str(price)

        amt = Decimal(odict['orderQty'])
        remaining = Decimal(odict['leavesQty'])
        filled = Decimal(odict['cumQty'])

        #bitMEX uses the following RFC 3339 string format for timestamps:
        #"2017-11-10T08:41:48.109Z"
        ts = arrow.get(odict['timestamp']).timestamp
        
        return utils.OrderMsg(account=account,
                              orderid=str(odict['orderID']),
                              status=status,
                              symbol=odict['symbol'].upper(),
                              otype=odict['ordType'].lower(),
                              amt=utils.norm_str(amt),
                              side=str(odict['side']).lower(),
                              price=price, #None or str
                              avgp=odict.get('avgPx',None),
                              filled=utils.norm_str(filled),
                              remaining=utils.norm_str(remaining),
                              cost=Decimal('0'),
                              costccy=odict.get('costccy','CCY'))

    def _on_open(self, ws):

        if len(self.accounts) > 1:
            auth = self. __get_auth()
            self.ws.send(json.dumps({'op':'authKey', 'args': [auth['key'], auth['nonce'], auth['signature']]}))
            self.ws.send(json.dumps({'op':'subscribe', 'args': ['margin','execution','order','position']}))

        self.ws.send(json.dumps({'op':'subscribe','args':['announcement','connected','insurance','liquidation','funding']})) # removed 'chat'
        self.dispatch('connected', self.venue)
        
    def _on_message(self, ws, message):
        try:
            msg = json.loads(message, parse_float=Decimal, parse_int=Decimal)
            if 'subscribe' in msg:
                if msg['success']:
                    self.logger.debug('Subscribed to %s' % msg['subscribe'])
                else:
                    self.logger.error('Unable to subscribe to %s, error: \"%s\"' % (msg['request']['args'][0], msg['error']))
            if 'request' in msg:
                if msg['success']:
                    self.logger.debug(str(msg))
                else:
                    self.logger.error(str(msg))

            elif 'status' in msg:
                if msg['status'] == 400:
                    self.logger.error(msg)
                elif msg['status'] == 401:
                    self.logger.error('API key incorrect {}'.format(msg))

            elif 'version' in msg:
                self.logger.debug('Version number {}'.format(msg['version']))
                    
            else:
                table = msg['table'] if 'table' in msg else None
                action = msg['action'] if 'action' in msg else None

                if table == 'trade':
                    for data in msg['data']:
                        ts = datetime.datetime.strptime(data['timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
                        ts = (ts - datetime.datetime(1970,1,1)).total_seconds()
                        pair = self.symvert(venuesym=data['symbol'])
                        self.dispatch('trade',
                                      pair,
                                      utils.norm_str(data['price']),
                                      utils.norm_str(data['size']),
                                      str(data['side'])[0],
                                      ts)

                elif table == 'quote':
                    pass

                elif table == 'instrument':
                    for x in msg['data']:
                        if 'openInterest' in x:
                            oi = x['openInterest']
                        else:
                            oi = None
                        self.dispatch('stats', x['symbol'], oi, x)

                elif table == 'orderBookL2':
                    if action in ['partial', 'insert']:
                        if action == 'partial':
                            assert set(msg['keys']) == {'symbol', 'id', 'side'}
                        for sym in set([x['symbol'] for x in msg['data']]):
                            bidlst = [(utils.norm_str(x['price']), utils.norm_str(x['size'])) for x in msg['data'] if x['symbol'] == sym and x['side'] == 'Buy']
                            asklst = [(utils.norm_str(x['price']), utils.norm_str(x['size'])) for x in msg['data'] if x['symbol'] == sym and x['side'] == 'Sell']
                            is_snapshot = action == 'partial'
                            pair = self.symvert(venuesym=sym)
                            self.dispatch('book', pair, bidlst, asklst, None, time.time(), bFullBook=is_snapshot)

                            for x in msg['data']:
                                key0 = '%s%d%s' % (x['symbol'], x['id'], x['side'])
                                self.keylookup[key0] = utils.norm_str(x['price'])
                        
                    elif action in ['update','delete']:
                        bidupdates = defaultdict(list)
                        askupdates = defaultdict(list)
                        for data in msg['data']:
                            #look up the price level first
                            key0 = '%s%d%s' % (data['symbol'], data['id'], data['side'])
                            
                            if key0 in self.keylookup.keys():
                                sPrice = self.keylookup[key0]
                                sSize = '0' if action == 'delete' else utils.norm_str(data['size'])
                                sym = self.symvert(data['symbol'])
                                if data['side'] == 'Buy':
                                    bidupdates[sym].append((sPrice, sSize))
                                elif data['side'] == 'Sell':
                                    askupdates[sym].append((sPrice, sSize))
                                else:
                                    self.logger.error('Invalid side')
                            else:
                                sym = self.symvert(data['symbol'])
                                if sym in self.books:
                                    self.logger.warning('Key lookup failed, no data updated for {}'.format(sym))

                        for sym in set(bidupdates.keys() + askupdates.keys()):
                            self.dispatch('book', sym, bidupdates[sym], askupdates[sym], None, time.time(), bFullBook=False)
                    else:
                        self.logger.error('wrong action received')
                        
                elif table == 'order':
                    updates = []
                    if action == 'delete':
                        self.logger.error('unexpected delete msg for orders')
                    elif action in ['partial','insert']:
                        for data in msg['data']:
                            self.orders[data['orderID']] = data
                            updates.append(data['orderID'])
                    elif action == 'update':
                        for data in msg['data']:
                            if data['orderID'] in self.orders.keys():
                                self.orders[data['orderID']].update(data)
                                updates.append(data['orderID'])
                            else:
                                self.logger.error('orderid {} not recognized'.format(data['orderID']))

                    else:
                        self.logger.error('invalid action {}'.format(action))
                            
                    for oid in updates:
                        orderdict = self.orders[oid]
                        status = orderdict['ordStatus']
                        if status not in OrderMsg.STATES:
                            self.logger.error('Unknown state {}'.format(data['ordStatus']))

                        otype = OrderMsg.LMT
                        if orderdict['ordType'] != 'Limit':
                            self.logger.error('orderdict {}'.format(orderdict))
                            raise Exception('Unknown order type {}'.format(orderdict['ordType']))

                        orderobj = utils.OrderMsg(account=self.account,
                                                  orderid=str(oid),
                                                  status=status,
                                                  symbol=str(orderdict['symbol']),
                                                  otype=otype,
                                                  amt=dec_to_str(orderdict['orderQty']),
                                                  side=OrderMsg.BUY if orderdict['side'] == 'Buy' else OrderMsg.SELL, #makes assumptions
                                                  price=None if orderdict['price'] is None else dec_to_str(orderdict['price']),
                                                  avgp=None if orderdict['avgPx'] is None else dec_to_str(orderdict['avgPx']),
                                                  filled=dec_to_str(orderdict['cumQty']),
                                                  remaining=dec_to_str(orderdict['leavesQty']),
                                                  cost=Decimal('0'),
                                                  costccy='CCY',
                                                  last_ts = None,
                                                  info=orderdict
                        )
                        #print(orderobj)
                        self.dispatch('order', orderobj)

                elif table == 'execution':
                    updates = []
                    if action == 'delete':
                        self.logger.error('unexpected delete msg for execution')
                    elif action in ['partial','insert']:
                        for data in msg['data']:
                            self.fills[data['execID']] = data
                            updates.append(data['execID'])
                    elif action == 'update':
                        for data in msg['data']:
                            if data['execID'] in self.fills.keys():
                                self.fills[data['execID']].update(data)
                                updates.append(data['execID'])
                            else:
                                self.logger.error('orderid {} not recognized'.format(data['orderID']))
                    else:
                        self.logger.error('invalid action {}'.format(action))
                    for fid in updates:

                        filldict = self.fills[fid]
                        #print ("filldict: ", filldict)
                        ts = arrow.get(filldict['transactTime']).timestamp

                        otype = OrderMsg.LMT
                        if filldict['ordType'] != 'Limit':
                            raise Exception('Unknown order type {}'.format(filldict['type']))

                        excomm = filldict['execComm']
                        if excomm is None: excomm = Decimal('0')
                        commccy = filldict['currency']
                        if commccy is None: commccy = 'CCY' #TODO: deal with this later

                        orderobj = utils.OrderMsg(account=self.account,
                                                  orderid=filldict['orderID'],
                                                  status=filldict['ordStatus'],
                                                  symbol=str(filldict['symbol']),
                                                  otype=otype,
                                                  amt=dec_to_str(filldict['orderQty']),
                                                  side=OrderMsg.BUY if filldict['side'] == 'Buy' else OrderMsg.SELL, #makes assumptions
                                                  price=None if filldict['price'] is None else dec_to_str(filldict['price']),
                                                  avgp=None if filldict['avgPx'] is None else dec_to_str(filldict['avgPx']),
                                                  filled=dec_to_str(filldict['cumQty']),
                                                  remaining=dec_to_str(filldict['leavesQty']),
                                                  cost=dec_to_str(excomm),
                                                  costccy=commccy,
                                                  last_ts = float(ts),
                                                  info=filldict
                        )
                        #print(orderobj)
                        self.dispatch('order', orderobj)

                        def default(x, dflt):
                            return dflt if x is None else x

                        #On cancels, bitmex will send a null Execution message; need to ignore it as we don't support Fills with 0 quantity
                        if filldict['lastQty'] is None: return
                        
                        fill = Fill(account = self.account,
                                    tradeid = filldict['execID'],
                                    orderid = filldict['orderID'],
                                    symbol = str(filldict['symbol']),
                                    amt = utils.norm_str(default(filldict['lastQty'], '0')),
                                    side = OrderMsg.BUY if filldict['side'] == 'Buy' else OrderMsg.SELL,
                                    price = utils.norm_str(default(filldict['lastPx'], '0')),
                                    cost = utils.norm_str(default(filldict['commission'], '0')),
                                    costccy = default(filldict['settlCurrency'], 'Xbt'),
                                    last_ts = float(ts),
                                    )
                        self.dispatch('fill', fill)
                        
                elif table == 'position':
                    if action in ['partial','insert','update']:
                        isupdate = action != 'partial'
                        wallettype = 'default'
                        if isupdate:
                            tmpwallet = Wallet(self.account, wallettype, self.accounts[self.account]['wallets'][wallettype])
                        else:
                            tmpwallet = self.oms.getwallet(self.account, wallettype)
                            if tmpwallet:
                                tmpwallet.clearpos()
                            else:
                                tmpwallet = Wallet(self.account, wallettype, self.accounts[self.account]['wallets'][wallettype])
                                
                        for data in msg['data']:
                            pos = self.parseposition(data)
                            tmpwallet.setposition(pos)

                        self.dispatch('wallet', tmpwallet, time.time(), isupdate)

                    else:
                        self.logger.error('unexpected {} msg for position'.format(action))

                elif table == 'margin':
                    self.logger.info(msg)
                    if action in ['partial','insert','update']:
                        isupdate = action != 'partial'
                        e8 = Decimal(1e8)
                        balance, tradable, withdrawable = {}, {}, {}
                        self.logger.info(msg)

                        for data in msg['data']:
                            ccy = self.symbols.canonical(self.venue, data['currency'].upper())
                            if ccy != 'BTC': self.logger.error('Balances not supplied in BTC - not expected for BitMEX')
                            if 'marginBalance' in data.keys() and 'unrealisedPnl' in data.keys():
                                balance[ccy] = dec_to_str((data['marginBalance'] - data['unrealisedPnl'])/e8)
                            if 'availableMargin' in data.keys():
                                tradable[ccy] = dec_to_str(data['availableMargin']/e8)
                            if 'withdrawableMargin' in data.keys():
                                withdrawable[ccy] = dec_to_str(data['withdrawableMargin']/e8)

                        wallettype = 'default'
                        if isupdate:
                            tmpwallet = Wallet(self.account, wallettype)
                        else:
                            tmpwallet = self.oms.getwallet(self.account, wallettype)
                            if not tmpwallet:
                                tmpwallet = Wallet(self.account, wallettype, self.accounts[self.account]['wallets'][wallettype])

                        tmpwallet.setbalances(balance, tradable, withdrawable, isupdate)
                        self.logger.info("setting balance to {}".format(balance))
                        self.dispatch('wallet', tmpwallet, time.time(), isupdate)
                        
                    else:
                        self.logger.error('unexpected {} msg for margin'.format(action))

                elif table in ['announcement','connected','insurance','liquidation','funding']: # removed 'chat'
                    ts = time.time()
                    if self.miscfile.closed:
                        self.miscfile = open(self.miscfilepath,'a')
                    self.miscfile.write('{};{};{}\n'.format(ts,table,message))

                    if table == 'liquidation':
                        self.pub.publish_liquidation(self.__class__.__name__, message)
                    
                elif action == 'partial':
                    print('partial action', msg)
                else:
                    self.logger.error('Unexpected msg {}'.format(msg))
                        
        except:
            self.logger.error('Error on message ' + message, exc_info=True)


    def _on_close(self, ws):
        self.logger.info('ws closed')
        self.dispatch('disconnected', self.venue)
        
    def _on_error(self, ws, error):
        self.logger.error('Encountered an error:{}'.format(error))
        
    def _get_instruments(self):
        url = 'https://www.bitmex.com/api/v1/instrument/activeAndIndices'
        response = requests.get(url)
        self.instrumentdata = response.json()
        return [x['symbol'] for x in self.instrumentdata if x['volume24h'] > 0]

    def __get_auth(self):
        nonce = int(self.accounts[self.account]['ccxt'].nonce())
        return {'key':self.key,
                'nonce':nonce,
                'signature':generate_signature(self.secret, 'GET', '/realtime', nonce, '')}
        
    def start(self):
        self.ws = websocket.WebSocketApp('wss://www.bitmex.com/realtime',
                                         on_message=self._on_message,
                                         on_open=self._on_open,
                                         on_close=self._on_close,
                                         on_error=self._on_error)
        t = threading.Thread(target=self.ws.run_forever)
        t.daemon = True
        t.start()

    def stop(self):
        self.miscfile.close()
        self.logger.info('Closing')
        self.ws.close()

    def subscribe_override(self, sym):
        symsubs = ['orderBookL2','trade','quote','instrument']
        if sym[0] == '.': #Hack for indices such as .BXBT - only subscribe to trades
            symsubs = ['trade']
        subs = [s + ':' + sym for s in symsubs]
        self.ws.send(json.dumps({'op':'subscribe', 'args':subs}))

    # def unsubscribe_override(self, sym):
    #     #TODO: check I am subscribed
    #     symsubs = ['orderBookL2','trade','quote','instrument']
    #     if sym[0] == '.': #Hack for indices such as .BXBT - only subscribe to trades
    #         symsubs = ['trade']
    #     subs = [s + ':' + sym for s in symsubs]
    #     self.ws.send(json.dumps({'op':'unsubscribe','args':subs}))

    def balrequired(self, symbol, side, amt, price):
        assert utils.isfloat(amt)
        assert utils.isfloat(price)

        baseccy = self.symbols.getbaseccy(self.venue, symbol)
        quoteccy = self.symbols.getquoteccy(self.venue, symbol)

        if quoteccy == 'USD' and baseccy == 'BTC':
            btcrequired = Decimal(amt) / Decimal(price)
        else:
            assert quoteccy == 'BTC'
            btcrequired = Decimal(amt) * Decimal(price)
        return 'BTC', btcrequired / Decimal(20)



def generate_signature(secret, verb, url, nonce, data):
    parsedURL = urlparse.urlparse(url)
    path = parsedURL.path
    if parsedURL.query:
        path = path + '?' + parsedURL.query
    message = bytearray(verb + path + str(nonce) + data, 'utf-8')
    return hmac.new(bytearray(secret, 'utf-8'), message, digestmod=hashlib.sha256).hexdigest()

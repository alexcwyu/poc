# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import logging, json
import threading
import time
import uuid
import base64, hashlib, hmac, urllib2, ssl
from socketIO_client import SocketIO
import ccxt
import utils
from utils import OrderMsg, Wallet
from cdecimal import Decimal
import oms
import base
            
class anxpro (base.Gateway):
    #See https://anxv3.docs.apiary.io/#reference/streaming for API documentation
    def __init__(self, credentials=[]):
        super(anxpro, self).__init__(credentials)

        if len(self.accounts) != 2:
            self.logger.error('Only supporting 1 private account now')
            raise Exception('ANX requires 1 private account for data')
        
        for account in self.accounts.keys():
            if account == 'data': continue
            self.key = self.accounts[account]['cred']['apiKey']
            self.secret = self.accounts[account]['cred']['secret']
            self.account = account
            self.accounts[account]['wallets'] = {'default': True}

        self.url = 'https://anxpro.com/'
        self.sio = None #TODO: make sio an array
        
    def start(self):
        if self.sio is None or not self.sio.connected:
            self._get_data_token()
            self.sio = SocketIO(self.url + 'streaming/3')#, wait_for_connection=True)
            self.sio.on('connect', self.on_connect)
            self.sio.on('reconnect', self.on_connect)
            self.sio.on('disconnect', self.on_disconnect)

            #error (Error object), reconnecting (#), reconnect_error(error), reconnect_failed
            
            socketio_thread=threading.Thread(target=self.sio.wait)
            socketio_thread.daemon = True
            socketio_thread.start()
        else:
            self.logger.info('SocketIO already connected')
            self.dispatch('connected', self.venue)
            
    def stop(self):
        if self.sio is not None:
            self.sio.disconnect()
        else:
            self.dispatch('disconnected', self.venue)
            
    def subscribe_override(self, sym):
        vsym = self.symvert(sym=sym)
        if vsym is None:
            self.logger.error('Symbol not available for subscription {}'.format(sym))
            return

        ttopic = 'public/trades/ANX/{}'.format(vsym)
        btopic = 'public/orderBook/ANX/{}'.format(vsym)

        self.sio.on(ttopic, self.__on_trade)
        self.sio.on(btopic, self.__on_book)
        self.sio.emit('subscribe', {'token':self.token, 'secret':self.secret, 'key':self.key, 'topics':[ttopic, btopic]})

    def on_connect(self, *args):
        ptopic = 'private/{}'.format(self.uuid)
        self.sio.on(ptopic , self.__on_private)
        self.sio.emit('subscribe', {'token':self.token,'secret':self.secret, 'key':self.key, 'topics':[ptopic]})
        self.logger.info('Subscribed to private')
        self.dispatch('connected', self.venue)
        
    def on_disconnect(self):
        if self.sio is not None and self.sio.connected:
            self.logger.error('Invalid state - sio should have disconnected')
        self.dispatch('disconnected', self.venue)
        
    #TODO: Note that ANX returns numbers as float, so need to override SocketIO parsing eventually
    def __on_trade(self, msg):
        msg = utils.byteify(msg)
        assert msg['event'] == 'exchangeTrade'
        for data in msg['data']:
            ts = int(data['timestampMillis'])/1000.
            pair = self.symvert(venuesym=data['ccyPair'])
            side = str(data['side'])[0]
            assert side in ['B','S']
            self.dispatch('trade', pair, utils.norm_str(str(data['price'])), utils.norm_str(str(data['tradedAmount'])), side, ts)

    def __on_book(self, msg):
        msg = utils.byteify(msg)
        assert msg['event'] == 'orderBook'
        for data in msg['data']:
            pair = self.symvert(venuesym=data['ccyPair'])
            ts = int(data['timestampMillis'])/1000.
            bidlst = [[utils.norm_str(str(bid['price'])), utils.norm_str(str(bid['quantity']))] for bid in data['bids']]
            asklst = [[utils.norm_str(str(ask['price'])), utils.norm_str(str(ask['quantity']))] for ask in data['asks']]
            seqnum = time.time()

            self.dispatch('book', pair, bidlst, asklst, ts, seqnum, bFullBook=True)

    def __on_private(self, msg):
        msg = utils.byteify(msg)
        if msg['event'] == 'account':
            freebalupdate = {}
            totalbalupdate = {}
            ts = time.time()
            for data in msg['data']:
                #ANX api - all fields should be strings according to doc
                assert all([type(x) in [str, Decimal] for x in data.values()])
                #Assume that there are no duplicates for ccy
                assert len(set([x['ccy'] for x in msg['data']])) == len(msg['data'])
                    
                freebalupdate[data['ccy']] = str(data['availableBalance'])
                totalbalupdate[data['ccy']] = str(data['balance'])
                
                ts = float(data['timestampMillis'])/1000.

            tmpwallet = Wallet(self.account, 'default', self.accounts[self.account]['wallets']['default'])
            tmpwallet.setbalances(totalbalupdate, freebalupdate, freebalupdate, False)
            self.dispatch('wallet', tmpwallet, ts, False)

        elif msg['event'] == 'order':
            for data in msg['data']:
                #print 'socket order'
                #print data
                assert self.uuid == data['user']
                uuid = data['uuid']
                orderState = data['orderState']
                price = data['price']
                rate = data['rate']
                orderDateTime = data['orderDateTime']
                settlementCcy = data['settlementCcy']
                tradedCcy = data['tradedCcy']
                side = data['side']
                tradedCcyTotalEstimate = data['tradedCcyTotalEstimate']
                tradedAmount = data['tradedAmount'] #Note this is a misnomer - really means tradeAmount
                tradedAmountOutstanding = data['tradedAmountOutstanding']

                #Data interpretation starts here:
                #DRAFTthis order is newly created
                #PENDING_SUBMISSIONthis order is about to be active
                #ACTIVEthis order is active
                #EXPIREDthis order is expired
                #PARTIAL_FILLthis order is partially filled
                #FULL_FILLthis order is fully filled
                #NO_FILLmainly for Market order or Immediate Or Cancel order, this order is closed without any fills
                #CANCEL_UNFUNDEDthis order is cancelled due to the user's account doesn't have enough traded currency or settlement currency to fund this trade
                #USER_CANCELthis order is canceled by user
                #CANCELLEDthis order is canceled
                #SUSPENDEDthis order is suspended
                #USER_CANCEL_PARTIALthis order is cancelled by user; and before the order was cancelled, it was partially filled
                #CANCEL_TOO_SMALLthis order is cancelled when it's outstanding amount is below tradable minimum amount
                #REPLACEDthis order is replaced by another order
                #REPLACED_PARTIALthis order is replaced by another order; and before the order was replaced, it was partially filled
                #CANCELLED_REPLACE_FAILED

                status = ""
                if orderState in ['DRAFT', 'PENDING_SUBMISSION']:
                    status = OrderMsg.PENDING_NEW
                elif orderState == 'ACTIVE':
                    status = OrderMsg.NEW
                elif orderState == 'EXPIRED':
                    status = OrderMsg.DONE_FOR_DAY
                elif orderState == 'PARTIAL_FILL':
                    status = OrderMsg.PARTIALLY_FILLED
                elif orderState == 'FULL_FILL':
                    status = OrderMsg.FILLED
                elif orderState in ['NO_FILL', 'USER_CANCEL', 'CANCELLED', 'USER_CANCEL_PARTIAL']:
                    status = OrderMsg.CANCELED
                elif orderState in ['REPLACED', 'REPLACED_PARTIAL']:
                    status = OrderMsg.REPLACED
                elif orderState in ['CANCEL_UNFUNDED', 'CANCEL_TOO_SMALL', 'CANCELLED_REPLACE_FAILED']:
                    status = OrderMsg.REJECTED
                else:
                    status = orderState
                    self.log(logging.ERROR, 'ANX: Order state {} not recognized'.format(orderState))

                symbol = self.symvert(venuesym=tradedCcy+settlementCcy)

                if side == "BUY":
                    side = OrderMsg.BUY
                else:
                    side = OrderMsg.SELL

                price = Decimal(str(price))

                qty = Decimal(str(tradedAmount))
                remaining = Decimal(str(tradedAmountOutstanding))
                filled = qty - remaining
                    
                order = utils.OrderMsg(account=self.account,
                                       orderid=uuid,
                                       status=status,
                                       symbol=symbol, #converted
                                       otype=OrderMsg.LMT,    #We don't want order type to be None - for completeness can get from REST request 
                                       amt=utils.norm_str(qty),
                                       side=side,
                                       price=utils.norm_str(price),
                                       avgp=None,
                                       filled=utils.norm_str(filled),
                                       remaining=utils.norm_str(remaining),
                                       cost=None,
                                       costccy=None,
                                       last_ts=None,
                                       info=data)
                    
                self.dispatch('order', order)

        elif msg['event'] == 'trade':
            for data in msg['data']:
                assert self.uuid == data['user']

                tradeid = data['uuid']
                orderid = data['order']
                tradedCcy = data['tradedCcy']
                settlementCcy = data['settlementCcy']
                tradedAmount = data['tradedAmount'] #Note this is a misnomer, really means tradeAmount
                settlementAmount = data['settlementAmount']
                side = data['side']
                price = data['price']
                timestampInMillis = data['timestampMillis']
                orderOutstandingFixedAmount = data['orderOutstandingFixedAmount']
                orderTotalFixedAmount = data['orderTotalFixedAmount']
                orderTradedCcyExecutedAmount = data['orderTradedCcyExecutedAmount']
                orderSettlementCcyExecutedAmount = data['orderTradedCcyExecutedAmount']
         
                status = OrderMsg.PARTIALLY_FILLED
                if Decimal(orderOutstandingFixedAmount) == 0:
                    status = OrderMsg.FILLED

                symbol = self.symvert(venuesym=tradedCcy + settlementCcy)

                if side == "BUY":
                    side = OrderMsg.BUY
                else:
                    side = OrderMsg.SELL

                amt = str(tradedAmount)
                price = str(price)
                ts = float(timestampInMillis)/1000.

                #NOTE: This OrderMsg is one that we are internally dummying up since ANX API doesn't send
                internalid = self.oms.internalid_lookup(self.account, orderid)
                price0 = oms.RedisOrderState(self.oms.r, internalid).price
                
                #order update messages on trade fills.
                order = utils.OrderMsg(account=self.account,
                                       orderid=orderid,
                                       status=status,
                                       symbol=symbol, #converted
                                       otype=OrderMsg.LMT,    #We don't want order type to be None - for completeness can get from REST request 
                                       amt=utils.norm_str(orderTotalFixedAmount),
                                       side=side,
                                       price=price0,
                                       avgp=None,
                                       filled=utils.norm_str(orderTradedCcyExecutedAmount),
                                       remaining=utils.norm_str(orderOutstandingFixedAmount),
                                       cost=None,
                                       costccy=None,
                                       last_ts=None,
                                       info=data)
                    
                self.dispatch('order', order)

                    
                fill = utils.Fill(account=self.account,
                                  tradeid=tradeid, 
                                  orderid=orderid, 
                                  symbol=symbol, 
                                  amt=utils.norm_str(tradedAmount), 
                                  side=side, 
                                  price=utils.norm_str(price), 
                                  last_ts=ts)
                self.logger.info('dispatching fill info {}'.format(tradeid))
                self.dispatch('fill', fill)
        elif msg['event'] == 'transaction':
            for data in msg['data']:
                ccy = self.symbols.canonical(self.venue, data['ccy'])
                balance = data['balanceAfter']
                
                freebalupdate = {ccy:str(balance)}
                totalbalupdate = {ccy:str(balance)}
                ts = float(data['timestampMillis'])/1000.
                wallet = self.getWallet(self.account, 'default')
                if wallet:
                    wallet.setbalances(totalbalupdate, freebalupdate, freebalupdate, True)
                    self.dispatch('wallet', wallet, ts, True)

        elif msg['event'] == 'userEvent':
            self.logger.info('{}'.format(msg))
        else:
            self.logger.error('event {} not recognized, message data {}'.format(msg['event'], msg['data']))
                
        
    def _get_data_token(self):
        result = self._request('api/3/dataToken')
        resultCode = result['resultCode']
        self.logger.info("ANX token get result code: {}".format(resultCode))
        self.token, self.uuid = result['token'], result['uuid']

    def _request(self, path, params={}):
        params = dict(params)
        params['nonce'] = self.gen_nonce()
        data = json.dumps(params)
        secret = base64.b64decode(self.secret)
        hmac_obj = hmac.new(secret, path + chr(0) + data, hashlib.sha512)
        hmac_sign = base64.b64encode(hmac_obj.digest())
        header = {
            'Content-Type': 'application/json',
            'User-Agent': 'anxv2 based client',
            'Rest-Key': self.key,
            'Rest-Sign': hmac_sign,
        }
        proxy = urllib2.ProxyHandler({'http':'127.0.0.1:8888'})
        opener = urllib2.build_opener(proxy)
        urllib2.install_opener(opener)
        request = urllib2.Request(self.url + path, data, header)
        return json.load(urllib2.urlopen(request, data), parse_float=Decimal, parse_int=Decimal)
    
    def gen_nonce(self):
        return str(ccxt.Exchange.microseconds())

    def parse_place_result(self, orderinfo, omsg):
        info = orderinfo.get('info', {})
        omsg.orderid = info.get('orderid', None)
        if omsg.orderid: return omsg
        return None
    
    def parse_cancel_result(self, result, omsg):
        info = result.get('info', {})
        rcode = info.get('resultCode', 'OK')
        if rcode in ['OK', 'CANCEL_REQUEST_SUBMITTED']:
            omsg.status = OrderMsg.PENDING_CANCEL
            return omsg
        else:
            self.logger.error(rcode)
            return None

    def parse_rest_order(self, account, orderdict):
        odict = orderdict['info']
        #Note the API says that settlement currency and traded currency are mutually exclusive when you
        #send the order. In this implementation I assume that we rely on traded currency (does not check settlement currency
        # at all
        settleCcy = odict['settlementCurrency']
        tradeCcy = odict['tradedCurrency']
        symbol = self.symvert(venuesym=tradeCcy+settleCcy)

        #Order status codes:
        #PENDING_SUBMISSION Pending to be processed by the system
        #ACTIVE Active. Pending to be matched by the system
        #EXPIRED Expired
        #PARTIAL_FILL Partially filled
        #FULL_FILL Full filled
        #NO_FILL
        status = odict['orderStatus']
        if status in ['PENDING_SUBMISSION']:
            status = OrderMsg.PENDING_NEW
        elif status in ['ACTIVE']:
            status = OrderMsg.NEW
        else:
            status = OrderMsg.CANCELED

        #order types are IMMEDIATE_OR_CANCEL, LIMIT or MARKET
        type = odict['orderType']
        if type == 'LIMIT':
            type = OrderMsg.LMT
        elif type == 'MARKET':
            type = OrderMsg.MKT

        buyTradedCcy = odict['buyTradedCurrency']
        side = OrderMsg.BUY if buyTradedCcy else OrderMsg.SELL

        sPrice = odict.get('limitPriceInSettlementCurrency',None)
        if sPrice == None:
            raise Exception("Order price not available")
        else:
            sPrice = utils.norm_str(sPrice)
        
        filled = Decimal(0)
        notional = Decimal(0)
        for trade in odict['trades']:
            tradeQty = Decimal(trade['tradedCurrencyFillAmount'])
            price = Decimal(trade['price'])
            filled += tradeQty
            notional += tradeQty * price
        averageprice = None if filled == Decimal(0) else utils.dec_to_str((notional/filled))
        
        qty = Decimal(odict['tradedCurrencyAmount'])
        sQty = utils.dec_to_str(qty)
        sRemaining = utils.dec_to_str(qty-filled)
        sFilled = utils.dec_to_str(filled)
        
        #TODO: time in force?
        return utils.OrderMsg(account=self.account,
                              orderid=str(odict['orderId']),
                              status=status,
                              symbol=symbol, #converted
                              otype=type,
                              amt=sQty,
                              side=side,
                              price=sPrice,
                              avgp=averageprice,
                              filled=sFilled,
                              remaining=sRemaining,
                              cost=odict.get('cost', None),
                              costccy=odict.get('costccy',None),
                              last_ts=None,
                              info=odict
        )

    
    def getrestfills(self, account, oids):
        #anx doesn't support rest fills - but they do come via streaming
        return []

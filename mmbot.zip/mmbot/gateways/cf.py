# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018

# Relevant samples
#  https://github.com/CryptoFacilities/WebSocket-v1-Python
#  https://github.com/CryptoFacilities/REST-v3-Python

from gateways import DATADIR
import os
import json, cPickle
import hashlib
import uuid
import logging
import sys
import time, datetime
import iso8601
from calendar import timegm
import requests
import hmac, hashlib, urlparse
import urllib2
import websocket
from collections import defaultdict
import utils
import threading
import base64
import ssl
from utils import OrderMsg, Fill, dec_to_str, Wallet, Position
from cdecimal import Decimal as D
import base

class cf (base.Gateway):
    def __init__(self, credentials=[]):
        super(cf, self).__init__(credentials, ccxtname='bitstamp')
        self.accounts['data']['ccxt'] = None
        self.poll_period = 3 #gfs

        #Disable proxies for cf as we are whitelisted (actually proxies aren't used anyway since there's no ccxt)
        self.pm.getproxy = lambda venue: 'noproxy'
        
        self.tradeseqnum = defaultdict(int) #Used to filter out seen ids SYM->tradeseq
        if len(self.accounts) > 2:
            raise Exception('Only supporting 1 private account now')

        self.apiPath = 'https://www.cryptofacilities.com/derivatives'
        self.__account = None
        for acname, account in self.accounts.items():
            if acname == 'data': continue
            self.__account = account
            self.__accname = acname
            self.timeout = 10
            self.subnonce = 0
            self.lastnoncets = 0
            self.checkCertificate = True
            self.fillhistory = defaultdict(list) #TODO: -> this needs to be inbuilt into oms orderid -> fillobj
            self.accounts[acname]['wallets'] = {'default': False}
            self.accounts[acname]['cancel_if_not_open'] = set()

            dms = threading.Thread(target=self.deadmanswitchloop)
            dms.daemon = True
            dms.start()
        
    #Rest overrides
    def getfullstate(self, account):
        #Only used to cancel postonly orders
        self.logger.info('GFS start {}'.format(self.accounts[self.__accname]['cancel_if_not_open']))
        if len(self.accounts[self.__accname]['cancel_if_not_open']) == 0: return
        myopens = self.open_orders_dict(account, reject_pending_new=False)
        self.logger.info('Begin get fullstate {} {} {}'.format(account, myopens, self.gfs_call_count))
        self.gfs_call_count += 1

        try:
            theiropens = self.getrestopenorders(account) #list of ordermsgs
            if theiropens is None: return
            theiropenoids = [o.orderid for o in theiropens]
            theirfills = self.getrestfills(account, None)
            if theirfills is None: return
            theirfilledoids = [f.orderid for f in theirfills]
            theiroids = set(theiropenoids).union(set(theirfilledoids))
        except:
            self.logger.error('Problem happened with GFS, aborting', exc_info=True)
            return

        done = []
        #exception could happen - set modification while iterating!
        try:
            for oid in self.accounts[self.__accname]['cancel_if_not_open']:
                #I think this order is still open but it's neither open nor close; must be canceled
                if oid in myopens and oid not in theiroids:
                    order0 = myopens[oid]
                    done.append(oid)
                    self.logger.info('Cannot find this order {} on exchange, cancelling!'.format(order0))
                    if order0.status == OrderMsg.PENDING_NEW and order0.orderid is None:
                        order0.orderid = str(uuid.uuid4())
                    order0.status = OrderMsg.CANCELED
                    self.dispatch('order', order0.asordermsg())
        except:
            self.logger.error('Gotcha!', exc_info=True)
                
        for oid in done:
            self.accounts[self.__accname]['cancel_if_not_open'].discard(oid)
        self.logger.info('Cancel if not open {}'.format(self.accounts[self.__accname]['cancel_if_not_open']))
                
    def getrestopenorders(self, account):
        self.wait_for_low_priority_slot(account)
        endpoint = '/api/v3/openorders'
        response = self.make_request('GET', endpoint)

        if response['result'] == 'success':
            return [self.parse_rest_order(account, odict) for odict in response['openOrders']]
        else:
            self.logger.error(response)
            return None

    def parse_rest_order(self, account, odict):
        if odict['status'] == 'untouched':
            status = OrderMsg.NEW
        elif odict['status'] == 'partiallyFilled':
            status = OrderMsg.PARTIALLY_FILLED
        else:
            self.logger.error('Not expecting this state {}'.format(odict))
            status = OrderMsg.NEW

        side = {'buy':OrderMsg.BUY, 'sell':OrderMsg.SELL}[odict['side']]
        otype = {'lmt':OrderMsg.LMT, 'stp':OrderMsg.STP}[odict['orderType']]

        return OrderMsg(account=account,
                        orderid=str(odict['order_id']),
                        status=status,
                        symbol=str(odict['symbol'].upper()),
                        otype=otype,
                        amt=utils.norm_str(D(odict['unfilledSize']) + D(odict['filledSize'])),
                        side=side,
                        price=utils.norm_str(str(odict['limitPrice'])),
                        avgp=None,
                        filled=utils.norm_str(odict['filledSize']),
                        remaining=utils.norm_str(odict['unfilledSize']),
                        cost=None,
                        costccy=None,
                        last_ts=time.time(), #odict['receivedTime'] <- TODO can parse this
                        info=odict)
        
        
    def getrestfills(self, account, oids):
        self.wait_for_low_priority_slot(account)
        endpoint = '/api/v3/fills'

        #last fill time not used
        response = self.make_request('GET', endpoint)

        if response['result'] == 'success':
            return [self.parse_rest_fill(account, fdict) for fdict in response['fills']]
        else:
            self.logger.error(response)
            return None

    def parse_rest_fill(self, account, fdict):
        dt = iso8601.parse_date(fdict['fillTime'])
        ts = timegm(dt.utctimetuple())
        return Fill(account=account,
                    tradeid=str(fdict['fill_id']),
                    orderid=str(fdict['order_id']),
                    symbol=str(fdict['symbol']).upper(),
                    amt=utils.norm_str(str(fdict['size'])),
                    side={'buy':OrderMsg.BUY, 'sell':OrderMsg.SELL}[fdict['side']],
                    price=utils.norm_str(str(fdict['price'])),
                    cost=None,
                    costccy=None,
                    last_ts=ts)

    def deadmanswitchloop(self):
        endpoint = '/api/v3/cancelallordersafter'

        while True:
            response = self.make_request('GET', endpoint, postUrl='timeout=60')

            if response['result'] == 'success':
                self.logger.info(response)
            else:
                self.logger.error(response)

            time.sleep(20)
    
    def getrestbooks(self, sym):
        #Not required since websocket always returns fullbook as first call
        self.logger.info('getrestbooks called for {}'.format(sym))
        return None

    def getrestorder(self, account, ordermsg):
        return None

    #Need to override these as well as we are no longer using ccxt
    def restbatchorders(self, cancels, placements):
        self.logger.info('batch place called! {} {}'.format(len(cancels), len(placements)))
        N = len(cancels) + len(placements)
        assert N > 0
        if N > 200: #max 200 per batch
            self.logger.error('Not supported yet!')
        endpoint = '/api/v3/batchorder'
        jsonElement = {'batchOrder':[]}
        jsonElement['batchOrder'] += [{'order':'cancel', 'order_id':omsg.orderid} for omsg in cancels]

        canceldict = {omsg.orderid:omsg for omsg in cancels}

        placedict = {}
        for i, omsg in enumerate(placements): #generate tags
            omsg.tag = str(i)
            orderflags = getattr(omsg, 'flags', {'postonly':False})
            if orderflags['postonly']:
                omsg.exchtype = 'post'
            else:
                omsg.exchtype = 'lmt'
            placedict[omsg.tag] = omsg
            
        jsonElement['batchOrder'] += [{'order':'send',
                                       'order_tag': omsg.tag,
                                       'orderType':omsg.exchtype,
                                       'symbol': omsg.symbol,
                                       'side': {OrderMsg.BUY:'buy', OrderMsg.SELL:'sell'}[omsg.side],
                                       'size': int(omsg.amt), #TODO: temp int hack
                                       'limitPrice': float(omsg.price)} for omsg in placements]
        postBody = "json=%s" % json.dumps(jsonElement)
        rejectplacements = False
        try:
            response = self.make_request("POST", endpoint, postBody=postBody)
            self.logger.info(response)
            if response['result'] == 'success':
                for omsg in self.parse_batch_response(response, canceldict, placedict):
                    if omsg: self.dispatch('order', omsg)
            else: #error
                rejectplacements = True
                self.logger.error(response)        
        except Exception as e:
            rejectplacements = True
            self.logger.error('Could not place orders', exc_info=True)

        if rejectplacements:
            for omsg in placements:
                omsg.orderid = str(uuid.uuid4())
                omsg.status = OrderMsg.REJECTED
                omsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
                self.dispatch('order', omsg)

    def parse_batch_response(self, response, canceldict, placedict):
        omsgs = []
        for item in response['batchStatus']:
            if 'order_tag' in item: #placement
                omsg = placedict.get(item['order_tag'], None)
                if omsg:
                    if item['status'] == 'placed':
                        omsg.status = OrderMsg.NEW
                        omsg.orderid = item['order_id']
                    elif item['status'] == 'attempted':
                        omsg.orderid = item['order_id']
                        self.logger.info('This order will be attempted: {}'.format(omsg.orderid))
                        self.accounts[self.__accname]['cancel_if_not_open'].add(omsg.orderid)
                        self.logger.info('Cancel if not open set: {}'.format(self.accounts[self.__accname]['cancel_if_not_open']))
                    else:
                        omsg.orderid = str(uuid.uuid4())
                        omsg.status = OrderMsg.REJECTED
                        omsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
            else:
                #cancel
                omsg = canceldict.get(item['order_id'], None)
                if omsg:
                    if item['status'] == 'cancelled':
                        omsg.status = OrderMsg.CANCELED
            omsgs.append(omsg)
        return omsgs
    
    def restplaceorder(self, ordermsg):
        self.logger.error('This function should not be called')
        orderflags = getattr(ordermsg, 'flags', {'postonly':False})
        if orderflags['postonly']:
            orderType = 'post'
        else:
            orderType = 'lmt'
        symbol = ordermsg.symbol
        side = {OrderMsg.BUY:'buy', OrderMsg.SELL:'sell'}[ordermsg.side]
        size = int(ordermsg.amt) #TODO: <-- need to check
        limitPrice = ordermsg.price
        #stopPrice
        #cliOrdId = can internalid
        endpoint = '/api/v3/sendorder'
        postBody = "orderType=%s&symbol=%s&side=%s&size=%s&limitPrice=%s" % (orderType, symbol, side, size, limitPrice)

        #if orderType == "stp" and stopPrice is not None:
        #    postBody += "&stopPrice=%s" % stopPrice
                
        #if clientOrderId is not None:
        #    postBody += "&cliOrdId=%s" % clientOrderId

        try:
            response = self.make_request("POST", endpoint, postBody=postBody)
        except:
            self.logger.error('Unable to submit order', exc_info=True)
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
            self.dispatch('order', ordermsg)
            return

        if response['result'] == 'success':
            stat = response['sendStatus']
            self.logger.info(stat)
            #response['serverTime']
            #stat['receivedTime']
            #TODO: parse with greater granularity
            #placed
            #attempted
            #invalidOrderType
            #invalidSide
            #invalidSize
            #invalidPrice
            #insufficientAvailableFunds
            #selfFill
            #tooManySmallOrders
            #marketSuspended
            #marketInactive
            #clientOrderIdAlreadyExist
            #clientOrderIdTooLong
            if stat['status'] == 'placed':
                ordermsg.status = OrderMsg.NEW
                ordermsg.orderid = stat['order_id']
            elif stat['status'] == 'attempted':
                ordermsg.orderid = stat['order_id']
                self.accounts[self.__accname]['cancel_if_not_open'].add(ordermsg.orderid)
            else:
                ordermsg.orderid = str(uuid.uuid4())
                ordermsg.status = OrderMsg.REJECTED
                ordermsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
        else:
            self.logger.error(response)
            ordermsg.orderid = str(uuid.uuid4())
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
        self.dispatch('order', ordermsg)


    def restcancelorder(self, ordermsg):
        endpoint = "/api/v3/cancelorder"
        #can specify either orderid or internalid
        #postBody = "cliOrdId=%s" % cli_ord_id
        postBody = "order_id=%s" % ordermsg.orderid
        try:
            response = self.make_request("POST", endpoint, postBody=postBody)
        except:
            self.logger.error('Problem with canceling', exc_info=True)
            return
        if response['result'] == 'success':
            #response['serverTime']
            stat = response['cancelStatus']
            #stat['receivedTime']
            # cancelled
            # partiallyFilled
            # filled
            # notFound
            if stat['status'] == 'cancelled':
                ordermsg.status = OrderMsg.CANCELED
                self.dispatch('order', ordermsg)
        else:
            self.logger.error(response)
            # apiLimitExceeded
            # authenticationError
            # accountInactive
            # requiredArgumentMissing
    
    #def symvert(self):

    # returns key account information
    def get_accounts(self):
        endpoint = "/api/v3/accounts"
        return self.make_request("GET", endpoint)
                    
    # signs a message
    def sign_message(self, endpoint, nonce, postData):
        # step 1: concatenate postData, nonce + endpoint
        message = postData + nonce + endpoint

        # step 2: hash the result of step 1 with SHA256
        sha256_hash = hashlib.sha256()
        sha256_hash.update(message.encode('utf8'))
        hash_digest = sha256_hash.digest()
        
        # step 3: base64 decode apiPrivateKey
        secret = self.__account['cred']['secret']
        secretDecoded = base64.b64decode(secret)
        
        # step 4: use result of step 3 to has the result of step 2 with HMAC-SHA512
        hmac_digest = hmac.new(secretDecoded, hash_digest, hashlib.sha512).digest()
        
        # step 5: base64 encode the result of step 4 and return
        return base64.b64encode(hmac_digest)
    
    # creates a unique nonce
    def get_nonce(self):
        ts = int(time.time() * 1000)
        if ts == self.lastnoncets:
            self.subnonce += 1
        else:
            self.subnonce = 0
            self.lastnoncets = ts
        return str(ts) + str(self.subnonce).zfill(4)
    
    # sends an HTTP request
    def make_request(self, requestType, endpoint, postUrl="", postBody=""):
        # create authentication headers
        nonce = self.get_nonce()
        self.logger.info('NONCE USED: {}'.format(nonce))
        postData = postUrl + postBody
        signature = self.sign_message(endpoint, nonce, postData)
        apikey = self.__account['cred']['apiKey']
        authentHeaders = {"APIKey": apikey, "Nonce": nonce, "Authent": signature}
        
        # create request
        url = self.apiPath + endpoint + "?" + postUrl
        
        request = urllib2.Request(url, str.encode(postBody), authentHeaders)
        request.get_method = lambda: requestType
        
        # read response
        if self.checkCertificate:
            response = urllib2.urlopen(request, timeout=self.timeout)
        else:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            response = urllib2.urlopen(request, context=ctx, timeout=self.timeout)
            
        response = response.read().decode("utf-8")
            
        # return
        return json.loads(response)

    
    #Websocket overrides
    def __subscribe_private(self, challenge):
        for feed in ['account_balances_and_margins', 'open_orders', 'open_positions', 'fills',]:# 'notifications_auth']:
            req_msg = {'event':'subscribe', 'feed':feed, 'api_key': self.__account['cred']['apiKey'],
                       'original_challenge': challenge, 'signed_challenge': self.__sign_challenge(challenge)}
            self.ws.send(json.dumps(req_msg))

    def __unsubscribe_private(self, challenge):
        self.logger.error('Why would you do this?')
        
    def _on_open(self, ws):
        self.logger.info('Connected!')
        if self.__account is not None:
            self.__request_challenge() #we need this to subscribe to private data
        self.dispatch('connected', self.venue)
        
    def _on_message(self, ws, message):
        try:
            msg = json.loads(message, parse_float=D)
            if 'event' in msg:
                if msg['event'] == 'subscribed':
                    pass
                    #for sym in msg['product_ids']: <-- depends on the message that was subscribed
                    #    #TODO: should notify mdstate here instead of dispatch(?)
                    #    self.logger.info('Subscribed to {} {}'.format(msg['feed'], sym))
                elif msg['event'] == 'subscribed_failed':
                    pass
                elif msg['event'] == 'unsubscribed':
                    pass
                elif msg['event'] == 'unsubscribed_failed':
                    pass
                elif msg['event'] == 'challenge':
                    challenge = msg['message']
                    self.__subscribe_private(challenge)
                else:
                    self.logger.error('Parsing error:' + str(msg))
                return
            
            if 'feed' in msg:
                if msg['feed'] == 'book_snapshot':
                    sym = msg['product_id']
                    seqnum = msg['seq']
                    bidlst = [(utils.norm_str(x['price']), utils.norm_str(x['qty'])) for x in msg['bids']]
                    asklst = [(utils.norm_str(x['price']), utils.norm_str(x['qty'])) for x in msg['asks']]
                    self.dispatch('book', sym, bidlst, asklst, seqnum, time.time(), bFullBook=True)
                elif msg['feed'] == 'book':
                    sym = msg['product_id']
                    seqnum = msg['seq']
                    bidlst, asklst = [], []
                    p,q = utils.norm_str(msg['price']), utils.norm_str(msg['qty'])
                    if msg['side'] == 'buy': bidlst.append((p,q))
                    else:
                        assert msg['side' ] == 'sell'
                        asklst.append((p,q))
                    self.dispatch('book', sym, bidlst, asklst, seqnum, time.time(), bFullBook=False)

                elif msg['feed'] == 'ticker':
                    sym = msg['product_id']
                    oi = str(msg['openInterest'])
                    self.dispatch('stats', sym, oi, msg)
                    
                elif msg['feed'] == 'trade_snapshot':
                    sym = msg['product_id']
                    for trade in msg['trades']:
                        sideflag = trade['side'][0].upper()

                        #ignore trades we've already seen
                        if int(trade['seq']) <= self.tradeseqnum[sym]: continue
                        self.tradeseqnum[sym] = int(trade['seq'])
                        
                        ts = float(trade['time'])/1000.
                        if trade['type'] == 'fill':
                            self.dispatch('trade', sym, utils.norm_str(trade['price']), utils.norm_str(trade['qty']), sideflag, ts)
                        elif trade['type'] == 'liquidation':
                            self.logger.info('Liquidation trade {}'.format(trade))
                        elif trade['type'] == 'termination':
                            pass
                elif msg['feed'] == 'trade':
                    sym = msg['product_id']
                    sideflag = msg['side'][0].upper()

                    if int(msg['seq']) <= self.tradeseqnum[sym]:
                        self.logger.error('Possible duplicate trade')
                    
                    ts = float(msg['time'])/1000.
                    if msg['type'] == 'fill':
                        self.dispatch('trade', sym, utils.norm_str(msg['price']), utils.norm_str(msg['qty']), sideflag, ts)
                    elif msg['type'] == 'liquidation':
                        self.logger.info('Liquidation trade {}'.format(msg))
                    elif msg['type'] == 'termination':
                        pass

                elif msg['feed'] == 'account_balances_and_margins':
                    balance, tradable, withdrawable = {}, {}, {}
                    positions = []
                    for accdict in msg['margin_accounts']:
                        accname = accdict['name']
                        #Need to refer currency by context
                        if 'f-' not in accname:
                            #self.logger.info('Account type {} not supported'.format(accname))
                            continue

                        ccy = accname.replace('f-','').split(':')[0].upper()
                        ccy = self.symbols.canonical(self.venue, ccy)

                        if ccy in balance:
                            balance[ccy] += D(str(accdict['balance']))
                        else:
                            balance[ccy] = D(str(accdict['balance'])) #current balance of the account
                        #accdict['pnl'] #pl of the account
                        #accdict['pv'] #portfolio value balance + unrealized pnl
                        if ccy in tradable:
                            tradable[ccy] += D(str(accdict['am']))
                        else:
                            tradable[ccy] = D(str(accdict['am'])) #available margin

                    #uses default wallet
                    withdrawable = tradable
                    tmpwallet = self.oms.getwallet(self.__accname, 'default')
                    if not tmpwallet:
                        tmpwallet = Wallet(self.__accname, 'default', self.accounts[self.__accname]['wallets']['default'])
                    tmpwallet.setbalances(balance, tradable, withdrawable)
                    self.dispatch('wallet', tmpwallet, time.time(), False)

                elif msg['feed'] == 'open_orders_snapshot': #full state - need to do a merge effectively

                    for x in msg['orders']:
                        #qty in this message is actually remaining
                        x['qty'] = x['qty'] + x['filled']
                    
                    open_orders = [self.parse_ws_openorder(x) for x in msg['orders']]
                    #Do a full merge here!
                    myodict = self.open_orders_dict(self.__accname, reject_pending_new=False)

                    for omsg in open_orders:
                        if omsg:
                            if omsg.orderid in myodict:
                                del myodict[omsg.orderid]
                            self.dispatch('order', omsg)

                    if len(myodict) > 0:
                        #TODO: how to deal with these orders? might be manual
                        self.logger.error('{} residual orders remain'.format(len(myodict)))
                    self.logger.info(str(msg))
                    
                elif msg['feed'] == 'open_orders': #subscription delta
                    if 'order' in msg and 'order_id' in msg['order']:
                        oid = msg['order']['order_id']
                        self.accounts[self.__accname]['cancel_if_not_open'].discard(oid)

                    if msg['is_cancel']:
                        oid = msg['order_id']
                        order = self.oms.getorderstate(self.__accname, oid)
                        if not order.exists:
                            self.logger.error('Received an oid of which I do not know about {}'.format(oid))
                            return
                        omsg = order.asordermsg()
                        
                        if msg['reason'] == 'stop_order_triggered':
                            pass #don't do anything now
                        elif msg['reason'] in {'full_fill', 'liquidation'}:
                            pass #update handled in fills
                        elif msg['reason'] == 'cancelled_by_user':
                            omsg.status = OrderMsg.CANCELED
                            self.dispatch('order', omsg)
                        elif msg['reason'] == 'not_enough_margin':
                            omsg.status = OrderMsg.REJECTED
                            omsg.rejectmsg = OrderMsg.INSUFFICIENT_FUNDS
                            self.dispatch('order', omsg)
                        elif msg['reason'] in {'market_inactive', 'cancelled_by_admin','contract_expired'}:
                            omsg.status = OrderMsg.REJECTED
                            omsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED
                            self.dispatch('order', omsg)
                        else:
                            self.logger.warning('Invalid reason received for closed order')
                    else:

                        if msg['reason'] not in {'new_placed_order_by_user', 'partial_fill', 'limit_order_from_stop'}:
                            self.logger.warning('Invalid reason received for openorder')
                        msg['order']['qty'] = msg['order']['qty'] + msg['order']['filled']
                        omsg = self.parse_ws_openorder(msg['order'])
                        if omsg: self.dispatch('order', omsg)
                        
                    self.logger.info(str(msg))

                elif msg['feed'] == 'open_positions':
                    positions = [self.parse_ws_position(pos) for pos in msg['positions']]
                    tmpwallet = self.oms.getwallet(self.__accname, 'default')
                    if not tmpwallet:
                        tmpwallet = Wallet(self.__accname, 'default', self.accounts[self.__accname]['wallets']['default'])
                    tmpwallet.clearpos()
                    for pos in positions:
                        tmpwallet.setposition(pos)
                    self.dispatch('wallet', tmpwallet, time.time(), False) #default wallet

                elif msg['feed'] in ['fills', 'fills_snapshot']:
                    for fillobj in [self.parse_ws_fill(fill) for fill in msg['fills']]:
                        self.fillhistory[fillobj.orderid].append(fillobj)
                        self.dispatch('fill', fillobj)
                    self.logger.info(str(msg))

                    #need to mark orders as filled
                    #Emit partialfills or fills
                    myodict = self.open_orders_dict(self.__accname, reject_pending_new=False)
                    for oid, ostate in myodict.items():
                        filled_amt = sum([D(f.amt) for f in self.fillhistory[oid]])
                        if filled_amt > D(ostate.filled):
                            self.accounts[self.__accname]['cancel_if_not_open'].discard(oid)

                            omsg = ostate.asordermsg()
                            omsg.status = OrderMsg.PARTIALLY_FILLED
                            if filled_amt == D(ostate.amt):
                                omsg.status = OrderMsg.FILLED
                            omsg.filled = utils.dec_to_str(filled_amt)
                            omsg.remaining = utils.dec_to_str(D(omsg.amt) - filled_amt)
                            #omsg.avgp #TODO
                            self.dispatch('order', omsg)

                else:
                    #Temporary non parsed messages
                    print '='*10
                    print msg
                    
            return
        except:
            self.logger.info(str(message), exc_info=True)

    #TODO: make these parse funcs private
    def parse_ws_fill(self, fdict):
        ts = float(fdict['time'])/1000.
        #fdict['seq']
        #fdict['cli_ord_id']
        #fdict['fill_type'] #maker, taker, liquidation, termination_winner, termination_loser
        
        return Fill(account = self.__accname,
                    tradeid = str(fdict['fill_id']),
                    orderid = str(fdict['order_id']),
                    symbol = str(fdict['instrument']),
                    amt = utils.norm_str(fdict['qty']),
                    side = OrderMsg.BUY if fdict['buy'] else OrderMsg.SELL,
                    price = utils.norm_str(fdict['price']),
                    cost = utils.norm_str('0'), #comms not available for parsing
                    costccy = 'BTC',
                    last_ts = ts)

    def parse_ws_position(self, posdict):
        symbol = str(posdict['instrument'])
        return Position(symbol,
                        self.__accname,
                        symbol,
                        qty = D(str(posdict['balance'])),
                        unrealised = D(str(posdict['pnl'])),
                        unrealisedccy = self.symbols.contract_pl_ccy(self.venue, symbol),
                        liqprice = D(str(posdict['liquidation_threshold'])),
                        leverage = D(str(posdict['effective_leverage'])),
                        avgp = D(str(posdict['entry_price'])))
        
        # posdict['entry_price'] #entry price of instrument
        # posdict['mark_price'] #mark price of instrument
        # posdict['index_price'] #index price
        # posdict['return_on_equity']
        # posdict['effective_leverage']

    def parse_ws_openorder(self, odict):
        orderid = str(odict['order_id'])
        if odict['type'] == 'limit':
            otype = OrderMsg.LMT
        else:
            self.logger.error('Cannot parse order type {}'.format(odict['type']))
            #odict['stop_price']
            return None
        #odict.get('cli_ord_id', None) #client given order id; not used now
        lastupdate = odict['time']/1000.
        status = OrderMsg.NEW                
        if odict['filled'] > 0: status = OrderMsg.PARTIALLY_FILLED
        
        return utils.OrderMsg(account=self.__accname,
                              orderid=orderid,
                              status=status,
                              symbol=str(odict['instrument']),
                              otype=otype,
                              amt=dec_to_str(odict['qty']),
                              side=OrderMsg.BUY if odict['direction'] == 0 else OrderMsg.SELL,
                              price=dec_to_str(odict['limit_price']),
                              avgp=None, #not provided in this api
                              filled=dec_to_str(odict['filled']),
                              remaining=dec_to_str(odict['qty'] - odict['filled']),
                              cost=D('0'),
                              costccy='CCY',
                              last_ts = lastupdate,
                              info=odict)

        
    def _on_close(self, ws):
        self.logger.info('ws closed')
        self.dispatch('disconnected', self.venue)
        
    def _on_error(self, ws, error):
        self.logger.error('Encountered an error:{}'.format(error))
        
    def _get_instruments(self):
        url = 'https://www.bitmex.com/api/v1/instrument/activeAndIndices'
        response = requests.get(url)
        self.instrumentdata = response.json()
        return [x['symbol'] for x in self.instrumentdata if x['volume24h'] > 0]

        
    def start(self):
        self.ws = websocket.WebSocketApp('wss://www.cryptofacilities.com/ws/v1',
                                         on_message=self._on_message,
                                         on_open=self._on_open,
                                         on_close=self._on_close,
                                         on_error=self._on_error)
        t = threading.Thread(target=lambda: self.ws.run_forever(ping_interval=30))
        t.daemon = True
        t.start()

    def stop(self):
        self.logger.info('Closing')
        if self.ws:
            self.ws.close()

    def subscribe_override(self, sym):
        for feed in ['trade', 'book', 'ticker']:
            request_msg = {'event':'subscribe', 'feed':feed, 'product_ids':[sym]}
            self.ws.send(json.dumps(request_msg))

    def unsubscribe_override(self, sym):
        #TODO: check I am subscribed
        request_msg = {'event':'unsubscribe', 'feed':'book', 'product_ids':[sym]}
        self.ws.send(json.dumps(request_msg))

    def symvert(self, sym=None, venuesym=None):
        raise Exception('CF sym and venusyms should be the same and thus this function is not required')

    def balrequired(self, symbol, side, amt, price):
        assert utils.isfloat(amt)
        assert utils.isfloat(price)

        baseccy = self.symbols.getbaseccy(self.venue, symbol)
        quoteccy = self.symbols.getquoteccy(self.venue, symbol)

        if quoteccy == 'USD':
            balrequired = abs(D(amt) / D(price))
            max_leverage = D(50) if baseccy == 'BTC' else D(20)
            return baseccy, balrequired / max_leverage
        elif quoteccy == 'BTC' and baseccy == 'XRP':
            btcrequired = abs(D(amt) * D(price))
            return 'BTC', btcrequired / D(20)
        else:
            raise Exception('Not supported')
    
    def __request_challenge(self):
        """Request a challenge from Crypto Facilities Ltd"""

        request_message = {
            "event": "challenge",
            "api_key": self.__account['cred']['apiKey']
        }
        
        request_json = json.dumps(request_message)
        self.ws.send(request_json)
        
    def __sign_challenge(self, challenge):
        """Signed a challenge received from Crypto Facilities Ltd"""
        # step 1: hash the message with SHA256
        sha256_hash = hashlib.sha256()
        sha256_hash.update(challenge.encode("utf8"))
        hash_digest = sha256_hash.digest()
        
        # step 3: base64 decode apiPrivateKey
        secret_decoded = base64.b64decode(self.__account['cred']['secret'])

        # step 4: use result of step 3 to has the result of step 2 with HMAC-SHA512
        hmac_digest = hmac.new(secret_decoded, hash_digest, hashlib.sha512).digest()

        # step 5: base64 encode the result of step 4 and return
        sch = base64.b64encode(hmac_digest).decode("utf-8")
        return sch
    

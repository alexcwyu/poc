# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import logging
from gateways import DATADIR
import os
import json, cPickle
import websocket
import threading
import time
import utils
from utils import OrderMsg, Fill
from cdecimal import Decimal as D
import base

TROLLBOX=1001 #trollbox (you will get nothing but a heartbeat)
TICKER=1002 #ticker
BASE24H=1003 #base coin 24h volume stats
HEARTBEAT=1010 #heartbeat

#https://poloniex.com/support/api/
class poloniex (base.Gateway):
    def __init__(self, credentials=[]):
        super(poloniex, self).__init__(credentials)
        if len(self.accounts) > 1:
            raise Exception('Private not supported yet')
        
        self.accounts['data']['ccxt'].load_markets()
        self.codemap = {v['info']['id']:k for k,v in self.accounts['data']['ccxt'].markets.iteritems()}
        #polling_period

    def start(self):
        self.ws = websocket.WebSocketApp("wss://api2.poloniex.com/",
                                         on_open = self.on_open,
                                         on_message = self.on_message,
                                         on_error = self.on_error,
                                         on_close = self.on_close)
        t = threading.Thread(target=self.ws.run_forever)
        t.daemon = True
        t.start()

    def stop(self):
        self.logger.info('Closing')
        self.ws.close()

    def subscribe_override(self, sym):
        vsym = self.symvert(sym=sym)
        self.ws.send(json.dumps({'command':'subscribe', 'channel':vsym}))

    #def unsubscribe_override(self, sym):
        
    def on_message(self, ws, message):
        try:
            self.__parse(message)
        except Exception as e:
            self.logger.error(str(message), exc_info=True)
            print e

    def __parse(self, message):
        msg = json.loads(message)
        code = msg[0]
        if code == HEARTBEAT: pass
        elif code == TROLLBOX: pass
        elif code == TICKER: pass
        elif code == BASE24H: pass
        elif code in self.codemap:
            sym = self.codemap[code]
            bidupdates, askupdates = [], []
            id0,seqnum,datas = msg
            for data in datas:
                dtype = data[0]
                if dtype == 'i':
                    obook = data[1]['orderBook']
                    asks, bids = obook #{price:amt}, {price:amt}
                    bidlst = [(utils.norm_str(p),utils.norm_str(q)) for p,q in bids.items()]
                    asklst = [(utils.norm_str(p),utils.norm_str(q)) for p,q in asks.items()]
                    self.dispatch('book', sym, bidlst, asklst, seqnum, time.time(), bFullBook=True)
                elif dtype == 'o':
                    _,bidask,price,amt = data
                    if bidask == 0: #1 = bid, 0=ask
                        askupdates.append((utils.norm_str(price), utils.norm_str(amt)))
                    elif bidask == 1:
                        bidupdates.append((utils.norm_str(price), utils.norm_str(amt)))
                    else:
                        print 'PROBLEM!'

                elif dtype == 't':
                    _,tradeid,direction,price,qty,exchts = data
                    side = 'B' if direction == 0 else 'S'
                    self.dispatch('trade', sym, utils.norm_str(price), utils.norm_str(qty), side, exchts)
                else:
                    print data

            if len(bidupdates)>0 or len(askupdates)>0:
                self.dispatch('book', sym, bidupdates, askupdates, seqnum, time.time(), bFullBook=False)
                    
        else:
            print msg
        
    def on_error(self, ws, error):
        print(error)

    def on_close(self, ws):
        self.dispatch('disconnected', self.venue)
    
    def on_open(self, ws):
        self.dispatch('connected', self.venue)
        
#        self.ws.send(json.dumps({'command':'subscribe','channel':'BTC_XMR'}))
#        self.ws.send(json.dumps({'command':'subscribe','channel':'BTC_ETH'}))        
        #     # ws.send(json.dumps({'command':'subscribe','channel':1001}))
        #     # ws.send(json.dumps({'command':'subscribe','channel':1002}))
        #     # ws.send(json.dumps({'command':'subscribe','channel':1003}))


if __name__ == "__main__":
    #websocket.enableTrace(True)
    logging.basicConfig()
    poloniex().start()
    while True:
        time.sleep(1)


# import urllib
# import urllib2

# ret = urllib2.urlopen(urllib2.Request('https://poloniex.com/public?command=returnTicker'))
# print json.loads(ret.read())

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Wilson Pau <wilson@valuefocus.cc>, April 2018
import logging
import json
import websocket
import threading
import time
import base
import gzip
from StringIO import StringIO
import utils
from cdecimal import Decimal

TRADE_CH = 'trade.detail'
DEPTH_CH = 'depth.step0'

class huobipro (base.Gateway):
    def __init__(self, credentials=[]):
        super(huobipro, self).__init__(credentials)
        if len(self.accounts) > 1:
            raise Exception('Private not supported yet')
        
        self.symdict = {}
        self.pinging = False

    def start(self):
        self.ws = websocket.WebSocketApp("wss://api.huobipro.com/ws",
                                         on_open = self.on_open,
                                         on_message = self.on_message,
                                         on_error = self.on_error,
                                         on_close = self.on_close)
        t = threading.Thread(target=self.ws.run_forever)
        t.daemon = True
        t.start()

    def stop(self):
        self.logger.info('Closing')
        self.ws.close()

    def subscribe_override(self, sym):
        vsym = self.symvert(sym=sym)
        base, quote = vsym.split('/')
        chsym = '{}{}'.format(base.lower(),quote.lower())
        self.symdict[chsym] = vsym
        tradesub = {"sub":'market.{}.{}'.format(chsym, TRADE_CH), 'id':'id1'}
        self.ws.send(json.dumps(tradesub))
        depthsub = {"sub":'market.{}.{}'.format(chsym, DEPTH_CH), 'id':'id1'}
        self.ws.send(json.dumps(depthsub))

    def on_message(self, ws, message):
        try:
            gzipFile = gzip.GzipFile(fileobj=StringIO(message))
            self.__parse(gzipFile.read())
        except Exception as e:
            self.logger.error(str(message), exc_info=True)

    def __parse(self, message):
        msg = json.loads(message, parse_float=Decimal, parse_int=Decimal)
        ping = msg.get('ping', None)
        if ping:
            self.ws.send(json.dumps({'pong': long(ping)}))

        channel = msg.get('ch', None)
        if channel is not None:
            if TRADE_CH in channel:
                _, chsym, _, _ = channel.split('.')
                sym = self.symdict.get(chsym, None)
                if sym is None:
                    self.logger.error('could not find {}'.chsym)
                    return
                data = msg['tick']['data']
                for item in data:
                    side = 'B' if item['direction'] == 'buy' else 'S'
                    price = item['price']
                    qty = item['amount']
                    exchts = int(item['ts']/Decimal(1000))
                    self.dispatch('trade', sym, utils.norm_str(price), utils.norm_str(qty), side, exchts)
            elif DEPTH_CH in channel:
                _, chsym, _, _ = channel.split('.')
                sym = self.symdict.get(chsym, None)
                if sym is None:
                    self.logger.error('could not find {}'.chsym)
                    return
                bidlst = [(utils.norm_str(p), utils.norm_str(q)) for p, q in msg['tick']['bids']]
                asklst = [(utils.norm_str(p), utils.norm_str(q)) for p, q in msg['tick']['asks']]
                self.dispatch('book', sym, bidlst, asklst, msg['tick']['ts'], time.time(), bFullBook=True)
            else:
                self.logger.info(msg)

    def on_error(self, ws, error):
        self.logger.error(error)

    def on_close(self, ws):
        self.pinging = False
        if self.pingthread and self.pingthread.isAlive():
            self.pingthread.join()
        self.dispatch('disconnected', self.venue)

    def on_open(self, ws):
        self.dispatch('connected', self.venue)

        self.pinging = True
        self.pingthread = threading.Thread(target=self.ping)
        self.pingthread.daemon = True
        self.pingthread.start()

    def ping(self):
        while self.pinging:
            msg = {'ping': long(time.time())}
            self.ws.send(json.dumps(msg))
            time.sleep(10)

if __name__ == "__main__":
    logging.basicConfig()
    huobipro().start()
    while True:
        time.sleep(1)

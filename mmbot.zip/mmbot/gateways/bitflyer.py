# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import threading
import time
from gateways import base
import utils

from pubnub.callbacks import SubscribeCallback
from pubnub.enums import PNStatusCategory
from pubnub.pnconfiguration import PNConfiguration
from pubnub.pubnub_tornado import PubNubTornado
from pubnub.pnconfiguration import PNReconnectionPolicy

config = PNConfiguration()
config.subscribe_key = 'sub-c-52a9ab50-291b-11e5-baaa-0619f8945a4f'
config.reconnect_policy = PNReconnectionPolicy.LINEAR
pubnub = PubNubTornado(config)

EXECUTION_CHANNELS = ['lightning_executions_BTC_JPY',
                      'lightning_executions_FX_BTC_JPY',
                      'lightning_executions_ETH_BTC']

BOARD_CHANNELS = ['lightning_board_BTC_JPY',
                  'lightning_board_FX_BTC_JPY',
                  'lightning_board_ETH_BTC']

FULLBOOK_CHANNELS = ['lightning_board_snapshot_BTC_JPY',
                     'lightning_board_snapshot_FX_BTC_JPY',
                     'lightning_board_snapshot_ETH_BTC']


class BitflyerSubscriberCallback(SubscribeCallback):
    def __init__(self, gwref):
        self.gwref = gwref
        super(BitflyerSubscriberCallback, self).__init__()

    def presence(self, pubnub, presence):
        pass  # handle incoming presence data

    def status(self, pubnub, status):
        if status.category == PNStatusCategory.PNUnexpectedDisconnectCategory:
            pass  # This event happens when radio / connectivity is lost

        elif status.category == PNStatusCategory.PNConnectedCategory:
            # Connect event. You can do stuff like publish, and know you'll get it.
            # Or just use the connected event to confirm you are subscribed for
            # UI / internal notifications, etc
            pass
        elif status.category == PNStatusCategory.PNReconnectedCategory:
            pass
        # Happens as part of our regular operation. This event happens when
        # radio / connectivity is lost, then regained.
        elif status.category == PNStatusCategory.PNDecryptionErrorCategory:
            pass
            # Handle message decryption error. Probably client configured to
            # encrypt messages and on live data feed it received plain text.

    def message(self, pubnub, message):
        # Handle new message stored in message.message
        if message.channel in EXECUTION_CHANNELS:
            sym = message.channel[21:]
            for data in message.message:
                side = 'B' if data['side'] == 'BUY' else 'S'
                price = data['price']
                qty = data['size']
                exchts = data['exec_date']
                self.dispatch('trade', sym, str(price), str(qty), side, exchts)
        else:
            bids = message.message['bids']
            asks = message.message['asks']
            bidlst = []
            asklst = []
            for bid in bids:
                p = bid['price']
                q = bid['size']
                bidlst.append((str(p), str(q)))
            for ask in asks:
                p = ask['price']
                q = ask['size']
                asklst.append((str(p), str(q)))

            if message.channel in BOARD_CHANNELS:
                sym = message.channel[16:]
                self.dispatch('book', sym, bidlst, asklst, None, time.time(), bFullBook=False)
            elif message.channel in FULLBOOK_CHANNELS:
                sym = message.channel[25:]
                self.dispatch('book', sym, bidlst, asklst, None, time.time(), bFullBook=True)

class bitflyer(base.Gateway):
    def __init__(self, credentials=[]):
        super(bitflyer, self).__init__(credentials)
        self.listener = BitflyerSubscriberCallback(self)
        pubnub.add_listener(self.listener)

    def start(self):
        pubnub.subscribe().channels(EXECUTION_CHANNELS + BOARD_CHANNELS + FULLBOOK_CHANNELS).execute()
        t = threading.Thread(target=pubnub.start)
        t.daemon = True
        t.start()

    def stop(self):
        pass


if __name__ == '__main__':
    bitflyer().start()

    while True:
        time.sleep(5)


# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from cdecimal import Decimal as D
import uuid
import time
import json
import threading
import functools
from collections import defaultdict
import utils
import hmac
import hashlib
import oms
from utils import OrderMsg, Fill, Wallet, Position
import requests
import base

class bitforex(base.Gateway):
    def __init__(self, credentials, ccxtname=None, enableRateLimit=True):
        super(bitforex, self).__init__(credentials, ccxtname='kucoin', enableRateLimit=enableRateLimit)
        self.rooturl = 'https://www.bitforex.com'
        self.accounts['data']['ccxt'] = None
        
        self.poll_period = 1

        self.coi = set() #coins of interest
        
        #overwrite the base class implementation of ccxt
        for cred in credentials:
            account ='{}:{}'.format(self.venue, cred['alias'])
            self.accounts[account]['ccxt'] = None

    def symvert(self, sym=None, venuesym=None):
        if sym is None and venuesym is not None:
            return self.symbols.canonicalsym(self.venue, venuesym)
        if sym is not None and venuesym is None:
            return self.symbols.venuesym(self.venue, sym)
        raise Exception('You used this function incorrectly')
        
    #REST data functions
    def getrestbooks(self, symbol):
        #add whatever is being subscribed to coins of interest - hack to get around their shit api
        self.coi.add(self.symbols.getbaseccy(self.venue, symbol))
        self.coi.add(self.symbols.getquoteccy(self.venue, symbol))
        
        vsym = self.symvert(sym=symbol)
        if vsym is None:
            self.logger.error('{} is not a valid symbol'.format(symbol))
            return None
        try:
            depth = 50
            url = '{}/api/v1/market/depth?symbol={}&size={}'.format(self.rooturl, vsym, depth)
            response = requests.get(url)
            r = json.loads(response.text, parse_float=D, parse_int=D)
            bids, asks = [], []
            for x in r['data']['asks']:
                asks.append((utils.norm_str(x['price']), utils.norm_str(x['amount'])))
            for x in r['data']['bids']:
                bids.append((utils.norm_str(x['price']), utils.norm_str(x['amount'])))
            return {'bids':bids, 'asks':asks}
        except:
            self.logger.error('Could not get books for {}'.format(symbol), exc_info=True)
            return None
        time.sleep(0.5) #TEMP throttle

    def getresttrades(self, symbol):
        vsym = self.symvert(sym=symbol)
        if vsym is None:
            self.logger.error('{} is not a valid symbol'.format(symbol))
            return None
        
        try:
            n = 100
            url = '{}/api/v1/market/trades?symbol={}&size={}'.format(self.rooturl, vsym, n)
            response = requests.get(url)
            r = json.loads(response.text, parse_float=D, parse_int=D)
            trades = []
            for x in r['data']:
                side = int(x['direction'])
                if side == 1: side = 'B'
                elif side == 2: side = 'S'
                else: side = 'U'
                trades.append({'timestamp': float(x['time'])/1000.,
                               'price':utils.norm_str(x['price']),
                               'amount':utils.norm_str(x['amount']),
                               'side':side})
            return trades
        except:
            self.logger.error('Could not get trades for {}'.format(symbol), exc_info=True)
            return []
        time.sleep(0.5) #TEMP throttle

    #Private API
    def get_nonce(self):
        return int(time.time()*1000)

    def sign_message(self, secret, msg):
        return hmac.new(secret, msg, hashlib.sha256).hexdigest()
    
    #override the big daddy
    def getfullstate(self, account):
        self.logger.info('Custom get full state')
        myoo = self.open_orders_dict(account, reject_pending_new = (self.gfs_call_count == 0))
        self.gfs_call_count += 1

        #get state of all my open orders with open order id
        for orderid in myoo.keys():
            omsg = self.getrestorder(account, myoo[orderid].asordermsg())
            if omsg:
                #check for fills
                fill = self.dummy_diff_fill(account, omsg, myoo[orderid].asordermsg())
                if fill: self.dispatch('fill', fill)
                self.dispatch('order',omsg)
                
        #Note - bitforex api is incomplete as in we cannot query for all open orders
        #Thus it is impossible to guarantee that state is sync'd
        self.getrestwallets(account)
    
    def getrestbalances(self, account):
        key = self.accounts[account]['cred']['apiKey']
        secret = self.accounts[account]['cred']['secret']
        balance, trade, withdraw = {}, {}, {}
        for coin in self.coi.copy():
            nonce = self.get_nonce()
            msg = '/api/v1/fund/mainAccount?accessKey={}&currency={}&nonce={}'.format(key, coin.lower(), nonce) #alphabetical order
            signature = self.sign_message(secret, msg)
            url = '{}/{}&signData={}'.format(self.rooturl, msg, signature)
            try:
                self.wait_for_low_priority_slot(account)
                response = requests.post(url)
                r = json.loads(response.text, parse_float=D, parse_int=D) #r['data']['frozen']
                #TODO: need to use canonical syms
                balance[coin] = str(r['data']['fix']) #Total assets
                trade[coin] = str(r['data']['active'])
                withdraw[coin] = str(r['data']['active'])
            except:
                self.logger.error('Failed to get balance for {}'.format(coin), exc_info=True)
        return {'default': (balance, trade, withdraw)}
            
    def restplaceorder(self, ordermsg):
        account = ordermsg.account
        key = self.accounts[account]['cred']['apiKey']
        secret = self.accounts[account]['cred']['secret']
        vsym = self.symvert(sym=ordermsg.symbol)
        nonce = self.get_nonce()
        ttype = 1 if ordermsg.side == OrderMsg.BUY else 2
        msg = '/api/v1/trade/placeOrder?accessKey={}&amount={}&nonce={}&price={}&symbol={}&tradeType={}'.format(key, ordermsg.amt, nonce, ordermsg.price, vsym, ttype) #alphabetical order
        signature = self.sign_message(secret, msg)
        url = '{}/{}&signData={}'.format(self.rooturl, msg, signature)
        print url
        success = False
        try:
            response = requests.post(url)
            r = json.loads(response.text, parse_float=D, parse_int=D)
            if r['success']:
                success = True
                self.logger.info(r)
                ordermsg.orderid = str(r['data']['orderId'])
        except:
            self.logger.error('Exception occured', exc_info=True)

        if not success:
            self.logger.error('Failed to place an order')
            ordermsg.orderid = str(uuid.uuid4())
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.EXCHANGE_REJECTED

        self.dispatch('order',ordermsg)
            
    def restcancelorder(self, ordermsg):
        account = ordermsg.account
        key = self.accounts[account]['cred']['apiKey']
        secret = self.accounts[account]['cred']['secret']
        nonce = self.get_nonce()
        vsym = self.symvert(sym=ordermsg.symbol)
        msg = '/api/v1/trade/cancelOrder?accessKey={}&nonce={}&orderId={}&symbol={}'.format(key, nonce, ordermsg.orderid, vsym)
        signature = self.sign_message(secret, msg)
        url = '{}/{}&signData={}'.format(self.rooturl, msg, signature)
        print url
        try:
            response = requests.post(url)
            r = json.loads(response.text, parse_float=D, parse_int=D)
            if r['success']:
                self.logger.info(r)
                #r['data'] #true doesn't mean canceled
        except:
            self.logger.error('Failed to cancel order', exc_info=True)

    def getrestorder(self, account, ordermsg):
        self.wait_for_low_priority_slot(account)
        key = self.accounts[account]['cred']['apiKey']
        secret = self.accounts[account]['cred']['secret']
        nonce = self.get_nonce()
        vsym = self.symvert(sym=ordermsg.symbol)
        msg = '/api/v1/trade/orderInfo?accessKey={}&nonce={}&orderId={}&symbol={}'.format(key, nonce, ordermsg.orderid, vsym)
        signature = self.sign_message(secret, msg)
        url = '{}/{}&signData={}'.format(self.rooturl, msg, signature)

        try:
            response = requests.post(url)
            r = json.loads(response.text, parse_float=D, parse_int=D)
            if r['success']:
                return self.parse_rest_order(account, r['data'])
        except:
            self.logger.error('Failed to get orderinfo: response:{}'.format(response.text), exc_info=True)
            return None
        
    def dummy_diff_fill(self, account, theirorder, ourorder):
        f2 = D(theirorder.filled)
        f1 = D(ourorder.filled)
        if f2 > f1:
            fillamt = f2 - f1
            avgp2 = D(theirorder.avgp)
            if ourorder.avgp: avgp1 = D(ourorder.avgp)
            else: avgp1 = 0
            fillp = (avgp2*f2 - avgp1*f1)/fillamt

            prev_cost = D(0) if ourorder.cost is None else D(ourorder.cost)
            new_cost = D(0) if theirorder.cost is None else D(theirorder.cost)
            cost = new_cost - prev_cost
            return Fill(account=account,
                        tradeid=str(uuid.uuid4()),
                        orderid=ourorder.orderid,
                        symbol=ourorder.symbol,
                        amt=utils.norm_str(fillamt),
                        side=ourorder.side,
                        price=utils.norm_str(fillp),
                        cost=utils.norm_str(cost),
                        costccy=theirorder.costccy,
                        last_ts=theirorder.lastupdated)
        else:
            return None
        
    def parse_rest_order(self, account, orderdict):
        status = {0: OrderMsg.NEW, 1: OrderMsg.PARTIALLY_FILLED, 2:OrderMsg.FILLED, 3:OrderMsg.CANCELED, 4:OrderMsg.CANCELED}[int(orderdict['orderState'])]
        side = {1:OrderMsg.BUY, 2:OrderMsg.SELL}[int(orderdict['tradeType'])]
        rem = utils.norm_str(orderdict['orderAmount'] - orderdict['dealAmount'])
        if orderdict['dealAmount'] > 0:
            avgp = utils.norm_str(orderdict['avgPrice'])
        else:
            avgp = None

        symbol = self.symvert(venuesym=orderdict['symbol'])
        b,q = symbol.split('/') #TODO: use reference
        costccy = q
        return OrderMsg(account=account,
                        orderid=str(orderdict['orderId']),
                        status=status,
                        symbol=symbol,
                        otype=OrderMsg.LMT,
                        amt=utils.norm_str(orderdict['orderAmount']),
                        side=side,
                        price=utils.norm_str(orderdict['orderPrice']),
                        avgp=avgp,
                        filled=utils.norm_str(orderdict['dealAmount']),
                        remaining=rem,
                        cost=utils.norm_str(orderdict['tradeFee']),
                        costccy=costccy,
                        last_ts=float(orderdict['createTime'])/1000.,
                        info=orderdict
        )


    def parse_rest_fills(self, account, fillsdict):
        raise NotImplementedError
        
    def getrestopenorders(self, account):
        raise NotImplementedError
                                        

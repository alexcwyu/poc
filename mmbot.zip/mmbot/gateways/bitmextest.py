# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from gateways import bitmex
import websocket
import threading

class bitmextest(bitmex):

    def start(self):
        nonce = int(self.accounts['data']['ccxt'].nonce())
        self.ws = websocket.WebSocketApp('wss://testnet.bitmex.com/realtime',
                                         on_message=self._on_message,
                                         on_open=self._on_open,
                                         on_close=self._on_close,
                                         on_error=self._on_error)
        t = threading.Thread(target=self.ws.run_forever)
        t.daemon = True
        t.start()
        

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import json as json
import logging
import time
import datetime
import websocket
import threading
import utils
from utils import OrderMsg
from cdecimal import Decimal
from collections import defaultdict
import base

class gdax (base.Gateway):
    def __init__(self, credentials=[]):
        super(gdax, self).__init__(credentials)
        self.ws = None

        # Diagnostics
        self.heartbeat_seqnum = dict()  # heartbeat seqnum for each pair
        self.trade_id = dict()  # latest trade id for each pair
        self.n_dropped_matches = defaultdict(int)  # number of dropped matches for each pair
        self.n_matches = defaultdict(int)  # number of matches for each pair

    def start(self):
        if self.ws is None:
            self.ws = websocket.WebSocketApp('wss://ws-feed.gdax.com',
                                             on_open=self.__on_open,
                                             on_message=self.__on_message,
                                             on_error=self.__on_error,
                                             on_close=self.__on_close)
        
            t=threading.Thread(target=self.ws.run_forever)
            t.daemon=True
            t.start()
        
    def stop(self):
        if self.ws:
            self.ws.close()
        else:
            self.dispatch('disconnected', self.venue)
        
    def subscribe_override(self, sym):
        vsym = self.symvert(sym=sym)
        #for channel in ['ticker', 'level2', 'matches']:
        self.ws.send(json.dumps({'type':'subscribe',
                                 'product_ids':[vsym],
                                 'channels':['ticker','level2','matches']}))
        
    def parse_rest_order(self, account, orderdict):
        odict = orderdict['info']
        #"id": "d0c5340b-6d6c-49d9-b567-48c4bfca13d2",
        #"price": "0.10000000",
        #"size": "0.01000000",
        #"product_id": "BTC-USD",
        #"side": "buy",
        #"stp": "dc",
        #"type": "limit",
        #"time_in_force": "GTC",
        #"post_only": false,
        #"created_at": "2016-12-08T20:02:28.53864Z",
        #"fill_fees": "0.0000000000000000",
        #"filled_size": "0.00000000",
        #"executed_value": "0.0000000000000000",
        #"status": "open",
        #"settled": false
        symbol = self.symvert(venuesym = odict['product_id'])
        status = OrderMsg.NEW if odict['status'] == "open" else OrderMsg.CANCELED
        side = OrderMsg.BUY if odict['side'] == "buy" else OrderMsg.SELL
        otype = odict['OrderType']
        if otype == "limit":
            otype = OrderMsg.LMT
        elif otype == "market":
            otype = OrderMsg.MKT

        price = odict['price'] 

        size = Decimal(odict['size'])
        filled_size = Decimal(odict['filled_size'])
        filled_value = Decimal(odict['executed_value'])
        remaining = size-filled_size
        sAvgp = None if filled_size == Decimal(0) else utils.dec_to_str(filled_value/filled_size)

        return utils.OrderMsg(account=account,
                              orderid=odict['OrderUuid'],
                              status=status,
                              symbol=symbol, #converted                                                                                      
                              otype=otype,
                              amt=utils.dec_to_str(size),
                              side=side,
                              price=price, #problem if none                                                                
                              avgp=sAvgp,
                              filled=utils.dec_to_str(filled_size),
                              remaining=utils.dec_to_str(remaining))
        

    def __on_open(self, ws):
        self.dispatch('connected', self.venue)

    def __on_error(self, ws, error):
        self.logger.error('Encountered an unknown error, restarting')

    def __on_close(self, ws):
        self.logger.info('Ws closed')
        self.ws = None
        self.dispatch('disconnected', self.venue)

    def __on_message(self, ws, jsonmsg):
        recvts = time.time()
        msg = json.loads(jsonmsg, parse_float=Decimal, parse_int=Decimal)
        #self.__track_dropped_messages(msg) #causing division problems
        try:
            self.parse(msg, recvts)
        except Exception as e:
            self.logger.error(e, exc_info=True)
        
    def __track_dropped_messages(self, msg):
        # Check for dropped ticker messages
        if msg['type'] == 'match':
            pair = msg['product_id']
            trade_id = msg['trade_id']

            self.n_matches[pair] += 1

            if pair not in self.trade_id:
                self.trade_id[pair] = trade_id
            else:
                if trade_id == self.trade_id[pair] + 1:
                    self.trade_id[pair] = trade_id
                else:
                    self.logger.debug('{0} {1} Dropped message: {2} -> {3}'.format(str(datetime.datetime.now()),
                                                                                        pair,
                                                                                        self.trade_id[pair],
                                                                                        trade_id))

                    self.n_dropped_matches[pair] += trade_id - self.trade_id[pair] - 1
                    self.logger.debug('Dropped {0} out of {1} message. ({2}%)'.format(self.n_dropped_matches[pair],
                                                                                           self.n_matches[pair] + self.n_dropped_matches[
                                                                                               pair],
                                                                                           100 * float(self.n_dropped_matches[pair])
                                                                                           / (
                                                                                               self.n_matches[pair] + self.n_dropped_matches[
                                                                                                   pair])))
                    self.trade_id[pair] = trade_id


    def parse(self, msg, recvts):
        msg_type = msg['type']

        if msg_type == 'match':
            pair = self.symvert(venuesym=msg['product_id'])
            size = utils.norm_str(msg['size'])
            price = utils.norm_str(msg['price'])
            side = 'B' if msg['side'] == 'buy' else 'S'

            # timestamp on gdax server is utc
            utcdt = datetime.datetime.strptime(msg['time'], '%Y-%m-%dT%H:%M:%S.%fZ')
            ts0 = (utcdt - datetime.datetime(1970,1,1)).total_seconds()
            seqnum = recvts
            self.dispatch('trade', pair, price, size, side, ts0)
            
        elif msg_type == 'heartbeat':
            pair = self.symvert(venuesym=msg['product_id'])
            seqnum = msg['sequence']

            if pair not in self.heartbeat_seqnum:
                self.heartbeat_seqnum[pair] = seqnum
            else:
                if seqnum == self.heartbeat_seqnum[pair] + 1:
                    self.heartbeat_seqnum[pair] = seqnum
                else:
                    self.logger.warning('message missed! gap in sequence number!')

        elif msg_type == 'snapshot':
            pair = self.symvert(venuesym=msg['product_id'])
            bids = [(utils.norm_str(bid[0]), utils.norm_str(bid[1])) for bid in msg['bids']]
            asks = [(utils.norm_str(ask[0]), utils.norm_str(ask[1])) for ask in msg['asks']]
            seqnum = recvts
            self.dispatch('book', pair, bids, asks, None, seqnum, bFullBook=True)

        elif msg_type == 'l2update':
            pair = self.symvert(venuesym=msg['product_id'])
            bids = [(utils.norm_str(price), utils.norm_str(size)) for (side,price,size) in msg['changes'] if side=='buy']
            asks = [(utils.norm_str(price), utils.norm_str(size)) for (side,price,size) in msg['changes'] if side=='sell']
            seqnum = recvts
            self.dispatch('book', pair, bids, asks, None, seqnum, bFullBook=False)

        elif msg_type == 'ticker':
            #TODO: is this better than match?
            #msg['open_24h']
            #msg['product_id'] #sequence, price, best_ask, best_bid
            #msg['side'], msg['price'], msg['trade_id'], msg['last_size']
            pass
            
        elif msg_type == 'error':
            self.logger.error(msg)
        else:
            #Other messages
            self.logger.info(msg)


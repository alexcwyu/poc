# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Wilson Pau <wilson@valuefocus.cc>, April 2018
from threading import Thread
import uuid
import json
import time
import websocket
import utils
from utils import OrderMsg, Fill, Position, Wallet
from cdecimal import Decimal as D
import base
import hmac
import hashlib
from collections import defaultdict
import numpy as np
import prices


MESSAGE_TYPES = set(['te','tu','ws','wu','os','on','ou','oc','ps','pn','pu','pc'])

class bitfinex(base.Gateway):
    def __init__(self, credentials=[]):
        super(bitfinex, self).__init__(credentials=credentials, ccxtname='bitfinex', enableRateLimit=True)

        self.poll_period = 30
        if len(self.accounts) > 2:
            raise Exception('Only supporting 1 private account now')

        self.account = None
        for account in self.accounts.keys():
            # so that it doesn't use CCXT canonicals
            self.accounts[account]['ccxt'].substituteCommonCurrencyCodes = False
            if account == 'data': continue

            #Temporary fields to only support 1 account; need to use self.accounts objects in the future
            self.key = self.accounts[account]['cred']['apiKey']
            self.secret = self.accounts[account]['cred']['secret']
            self.account = account
            self.accounts[account]['wallets'] = {'exchange': True,
                                                 'margin': False,
                                                 'funding': False}
        self.channelinfo = {}
        self.ws = None
        self.wsthread = None
        self.pingthread = None
        self.pongthread = None
        self.pong_received = False
        self.__connected = False
        self.tradablebals = {}

    def _on_message(self, ws, message):
        recvts = time.time()
        try:
            msg = json.loads(message, parse_float=D, parse_int=D)
            if type(msg) == dict:
                if msg['event'] in ['info','unsubscribed','conf','auth','unauth']:
                    self.logger.info(msg)
                elif msg['event'] == 'pong':
                    self.pong_received = True
                elif msg['event'] == 'error':
                    self.logger.error(msg)
                elif msg['event'] == 'subscribed':
                    #TODO: funding parsing
                    if msg['channel'] == 'trades':
                        self.channelinfo[msg['chanId']] = [msg['channel'], msg['pair'], recvts]
                    elif msg['channel'] == 'book':
                        self.channelinfo[msg['chanId']] = [msg['channel'], msg['symbol'][1:], recvts]
                else:
                    self.logger.info('throwing away message {}'.format(msg))
            elif type(msg) == list:
                msgtype = msg[1]
                if msgtype == 'hb':
                    return

                if (type(msgtype) != list) and (msgtype not in MESSAGE_TYPES): 
                    self.logger.info('throwing away message {}'.format(msg)) 
                    return 
    
                chanId = msg[0]
                if len(msg) > 2:
                    response = msg[2]
                    if len(response) == 0:
                        self.logger.info('throwing away message {}'.format(msg))
                        return

                # private channel
                if chanId == D(0):
                    self.logger.info('got private message {}'.format(msg))
                    if msgtype == 'wu':
                        wallettype, ccy, total, unsettled_interest, free = response
                        tmpwallet = Wallet(self.account, wallettype, self.accounts[self.account]['wallets'][wallettype])
                        balance = {}
                        tradable = {}
                        withdrawable = {}
                        if free is None: 
                            req = ['wallet_{}_{}'.format(wallettype, ccy)]
                            ws.send(json.dumps([0, 'calc', None, [req]]))
                        else:
                            tradable[ccy] = str(free)
                            withdrawable[ccy] = str(free)

                        balance[ccy] = str(total)
                        tmpwallet.setbalances(balance, tradable, withdrawable)
                        self.dispatch('wallet', tmpwallet, recvts, True)
                    elif msgtype == 'ws':
                        freedict = defaultdict(dict)
                        totdict = defaultdict(dict) 
                        calcreqs = []
                        for x in response:
                            wallettype, ccy, total, unsettled_interest, free = x
                            totdict[wallettype][ccy] = str(total)
                            # calc is required
                            if free is None:
                                req = ['wallet_{}_{}'.format(wallettype, ccy)] 
                                calcreqs.append(req)
                            else:
                                freedict[wallettype][ccy] = str(free)

                        if len(calcreqs) > 0: ws.send(json.dumps([0, 'calc', None, calcreqs]))

                        for wallettype in totdict:
                            wallet = self.oms.getwallet(self.account, wallettype)
                            if wallet:
                                wallet.setbalances(totdict[wallettype], freedict[wallettype], freedict[wallettype])
                                self.dispatch('wallet', wallet, recvts, False)
                            else:
                                self.logger.error("Could not get wallet {} {}".format(self.account, wallettype))

                    elif msgtype in ['on','ou','oc']:
                        omsg = self.parse_ws_order(response)
                        self.dispatch('order', omsg)
                    elif msgtype == 'os':
                        for res in response: 
                            omsg = self.parse_ws_order(res)  
                            self.dispatch('order', omsg)
                    elif msgtype in ['pn','pu','pc']:
                        symbol, status, amt, px, mgnfnd, mgnfndtype, pl, plper, liqprice, lvg = response
                        sym = self.symvert(venuesym=symbol[1:])
                        unrealisedccy = self.symbols.getquoteccy(self.venue, sym)
                        marginccy = self.symbols.getbaseccy(self.venue, sym) if amt < 0 else self.symbols.getquoteccy(self.venue, sym)

                        if msgtype == 'pc' and str(status) == 'CLOSED':
                            pos = Position(sym,
                                           self.account,
                                           sym,
                                           qty='0',
                                           unrealised='0',
                                           unrealisedccy=unrealisedccy,
                                           maintmargin=str(mgnfnd),
                                           marginccy=str(marginccy),
                                           liqprice='0',
                                           avgp=str(px),
                                           leverage=None)
                            w = Wallet(self.account, 'margin', self.accounts[self.account]['wallets']['margin'])
                            w.setposition(pos)
                            self.dispatch('wallet', w, time.time(), True)
                        elif pl is None:
                            req = ['position_{}'.format(symbol)]
                            ws.send(json.dumps([0, 'calc', None, [req]]))
                        else:
                            pos = Position(sym,
                                           self.account,
                                           sym,
                                           qty=str(amt),
                                           unrealised=str(pl),
                                           unrealisedccy=self.symbols.getquoteccy(self.venue, sym),
                                           maintmargin=str(mgnfnd),
                                           marginccy=str(marginccy),
                                           liqprice=str(liqprice),
                                           avgp=str(px),
                                           leverage=str(lvg))
                            w = Wallet(self.account, 'margin', self.accounts[self.account]['wallets']['margin'])
                            w.setposition(pos)
                            self.dispatch('wallet', w, time.time(), True)
                    elif msgtype == 'ps':
                        calcreqs = []
                        wallet = self.oms.getwallet(self.account, 'margin')
                        if wallet:
                            wallet.clearpos()
                        else:
                            wallet = Wallet(self.account, 'margin', self.accounts[self.account]['wallets']['margin'])
                        for x in response:
                            symbol, status, amt, px, mgnfnd, mgnfndtype, pl, plper, liqprice, lvg  = x
                            if pl is None:
                                req = ['position_{}'.format(symbol)]
                                calcreqs.append(req)
                            else:
                                sym = self.symvert(venuesym=symbol[1:])
                                marginccy = self.symbols.getbaseccy(self.venue, sym) if amt < 0 else self.symbols.getquoteccy(self.venue, sym)
                                pos = Position(sym,
                                           self.account,
                                           sym,
                                           qty=str(amt),
                                           unrealised=str(pl),
                                           unrealisedccy=self.symbols.getquoteccy(self.venue, sym),
                                           maintmargin=str(mgnfnd),
                                           marginccy=marginccy,
                                           liqprice=str(liqprice),
                                           avgp=str(px),
                                           leverage=str(lvg))
                                wallet.setposition(pos)                                
                        if len(calcreqs) > 0: ws.send(json.dumps([0, 'calc', None, calcreqs]))
                        self.dispatch('wallet', wallet, time.time(), False)
                    elif msgtype == 'tu':
                        fill = self.parse_ws_fill(response, msgtype)
                        self.dispatch('fill', fill)
                # public channels
                else:
                    self.channelinfo[chanId][-1] = recvts

                    channel, pair0, _ = self.channelinfo[chanId]
                    pair = self.symvert(venuesym=pair0.lower())
                    if channel == 'trades':
                        trades = []
                        is_snapshot = type(msg[1]) == list
                        if is_snapshot: # this is a snapshot
                            _, submsg = msg
                            for x in submsg[::-1]:
                                _, ts, amt, price = x
                                trades.append([float(ts)/1000., str(price), str(amt)])
                        else:
                            _, tetu, submsg = msg
                            if tetu == 'te': #low latency version
                                _, ts, amt, price = submsg
                                trades.append([float(ts)/1000., str(price), str(amt)])                         

                            for (ts0, sPrice, sAmt) in trades:
                                self.dispatch('trade', pair, utils.norm_str(sPrice),utils.norm_str(sAmt.replace('-','')), 'B' if float(sAmt) > 0 else 'S', ts0)
                                swappair = '{}{}'.format(pair.split('/')[0], pair.split('/')[1])
                                self.dispatch('trade', swappair, utils.norm_str(sPrice),utils.norm_str(sAmt.replace('-','')), 'B' if float(sAmt) > 0 else 'S', ts0)
                    elif channel == 'book':
                        is_snapshot = type(msg[1][0]) == list
                        if is_snapshot:
                            _, data = msg
                        else:
                            data = [msg[1]] 

                        delme = [(utils.norm_str(p), '0') for p, count, q in data if count == 0]
                        bidlst = [(utils.norm_str(p), utils.norm_str(q)) for p, count, q in data if count != 0 and q > 0]
                        asklst = [(utils.norm_str(p), utils.norm_str(abs(q))) for p, count, q in data if count != 0 and q < 0]

                        bidlst += delme
                        asklst += delme
                        seqnum = recvts
                        self.dispatch('book', pair, bidlst, asklst, None, seqnum, bFullBook=is_snapshot)
                        swappair = '{}{}'.format(pair.split('/')[0], pair.split('/')[1]) 
                        self.dispatch('book', swappair, bidlst, asklst, None, seqnum, bFullBook=is_snapshot)
        except:
            self.logger.error('Error on message {}'.format(message), exc_info=True)

    def _on_open(self, ws):
        self.logger.info('on_open')
        self.dispatch('connected', self.venue)
        if self.account: self.auth()
        #self.pingthread = Thread(target=self._send_ping)
        #self.pingthread.daemon = True
        #self.pingthread.start()

        #self.pongthread = Thread(target=self._check_pong)
        #self.pongthread.daemon = True
        #self.pongthread.start()

    def _on_close(self, ws):
        self.logger.info('Ws closed')
        self.stop()

    def _on_error(self, ws, error):
        self.logger.info('Encountered an unknown error, restarting')
        #self.stop()

    def start(self):
        if self.ws is None:
            self.ws = websocket.WebSocketApp('wss://api.bitfinex.com/ws/2',
                                             on_message=self._on_message,
                                             on_open=self._on_open,
                                             on_close=self._on_close,
                                             on_error=self._on_error)

            self._connect()

    def _connect(self):
        if self.wsthread:
            self.wsthread.join()
            self.wsthread = None
        self.wsthread = Thread(target=lambda: self.ws.run_forever(ping_interval=30))
        self.wsthread.daemon = True
        self.wsthread.start()

    def stop(self):
        self.logger.info('{} ws instance'.format(self.ws))
        if self.ws:
            self.ws.close()
            self.ws = None
       
        self.dispatch('disconnected', self.venue)

    def _send_ping(self):
        while True:
            self.logger.info('sending ping')
            self.ws.send(json.dumps({'event':'ping'}))
            time.sleep(10)

    def _check_pong(self):
        while True:
            time.sleep(30)
            self.logger.info('checking pong')
            if self.pong_received:
                self.pong_received = False
            else:
                self.reconnect()

    def auth(self):
        nonce = str(self.accounts[self.account]['ccxt'].nonce())
        self.logger.info('nonce from auth {}'.format(nonce))
        auth_string = 'AUTH' + nonce
        auth_sig = hmac.new(self.secret.encode(), auth_string.encode(), hashlib.sha384).hexdigest()
        payload = {'event':'auth', 'apiKey':self.key, 'authSig':auth_sig, 'authPayload':auth_string, 'authNonce':nonce}
        self.ws.send(json.dumps(payload))

    def subscribe(self, sym):
        # ignore all the swap pairs, as thewe will be subscribed for spots
        if '/' not in sym:
            return

        bitfinexsymbol = 't{}'.format(self.symvert(sym=sym).upper())
        #TODO: funding
        self.ws.send(json.dumps({'event':'subscribe','channel':'trades','symbol':bitfinexsymbol}))
        self.ws.send(json.dumps({'event':'subscribe','channel':'book','symbol':bitfinexsymbol, 'prec':'P0', 'freq':'F0', 'len':'25'}))

    def placeorder(self, internalid, ordermsg):
        self.logger.info('submitting order {}'.format(internalid))
        flags = getattr(ordermsg, 'flags', {'postonly':False})
        
        symbol = ordermsg.symbol
        account = ordermsg.account
        side = ordermsg.side
        amount = ordermsg.amt
        price = ordermsg.price
        insuffbal = False

        if self.symbols.isccypair(symbol):
            ordertype = {OrderMsg.LMT:'exchange limit', OrderMsg.MKT:'exchange market'}[ordermsg.otype]
            wallet = self.oms.getwallet(self.account, 'exchange')
            ccy, marginamt = self.balrequired(symbol, side, amount, price)
            if wallet:
                freebal = D(wallet.tradable.get(ccy, '0'))
            else:
                freebal = D(0)
            if freebal < marginamt:
                insuffbal = True
        else:
            ordertype = {OrderMsg.LMT:'limit', OrderMsg.MKT:'market'}[ordermsg.otype]
            wallet = self.oms.getwallet(self.account, 'margin')
            
            if wallet:
                positions = wallet.positions
            else:
                positions = {}
            posize, tradesize = D(0), D(0)
            if symbol in positions:
                currentpos = D(positions[symbol].qty)
                baseccy = self.symbols.getbaseccy(self.venue, symbol) 
                usdpx = prices.getprice(baseccy, 'USD') #self.books[baseccy.upper() + '/USD'].indicative_mid
                tradesize = usdpx * D(amount) if side == OrderMsg.BUY else -usdpx * D(amount)
                posize = usdpx * D(currentpos)
                
            marginamt = self.tradablebals.get(symbol, D(0))
            lowerbound = min(posize, 0) - marginamt
            upperbound = max(posize, 0) + marginamt
            if (posize + tradesize < lowerbound) or (posize + tradesize > upperbound):
                insuffbal = True        
                       
        if insuffbal:
            ordermsg.orderid = str(uuid.uuid4()) #dummy oid
            ordermsg.status = OrderMsg.REJECTED
            ordermsg.rejectmsg = OrderMsg.INSUFFICIENT_FUNDS
            self.dispatch('order', ordermsg)
        else:
            try:
                symbol = '{}{}'.format('t', self.symvert(sym=symbol).upper())
                qty = amount if side == OrderMsg.BUY else utils.norm_str(D(-1)*D(amount))     
                req = {'cid':int(time.time()*1000), 'type':ordertype.upper(), 'symbol':symbol, 'amount':qty, 'price':price}

                if flags['postonly']:
                    req.update({'flags': 4096})
                
                self.ws.send(json.dumps([0, 'on', None, req]))
                #orderinfo = self.ccxt_rest_call(self.account, 'create_order', [symbol, ordertype, side, amount, price])
                #self.logger.info('Place order result: {}'.format(orderinfo))
                #omsg = self.parse_place_result(orderinfo, ordermsg)
            except Exception as e:
                self.logger.error('Unable to submit order {}'.format(ordermsg), exc_info=True)
                omsg = self.parse_place_exception(e, ordermsg)
                self.dispatch('order', omsg)

    
    def cancelorder(self, internalid):
        self.logger.info('cancelling internalid {}'.format(internalid))
        orderobj = self.oms.getorderstatebyid(internalid)
        req = {'id': int(orderobj.orderid)} 
        self.ws.send(json.dumps([0, 'oc', None, req]))

    def getrestbalances(self, account):
        response = self.ccxt_rest_call(account, 'fetch_balance')
        freebal, totbal = defaultdict(dict), defaultdict(dict)
        if 'info' in response:
            info = response['info']
            for x in info:
                wallettype = x['type']
                ccy = x['currency'].upper()
                available = x['available']
                amount = x['amount']
                # map it to websocket v2 naming conventions
                if wallettype == 'trading': wallettype = 'margin'
                elif wallettype == 'deposit': wallettype = 'funding'
                freebal[wallettype][ccy] = str(available)
                totbal[wallettype][ccy] = str(amount)
        return {k:(totbal[k], freebal[k], freebal[k]) for k in totbal.keys()}

    def parse_ws_order(self, wsorder):
        x = wsorder
        orderId = x[0]
        symbol = x[3]
        tsupdate = x[5]
        remaining = x[6]
        origQty = x[7]
        ordertype = x[8]
        exchstatus = x[13]
        price = x[16]
        priceavg = x[17]
   
        if ordertype.split(' ')[0] == 'EXCHANGE':  
            symbol = self.symvert(venuesym=symbol[1:].lower())
        else:
            symbol = symbol[1:]

        es = exchstatus.split(' ')
        status = es[0].strip()
        if status == 'ACTIVE':
            ordstatus = OrderMsg.NEW
        elif status == 'EXECUTED':
            ordstatus = OrderMsg.FILLED
        elif status == 'PARTIALLY':
            ordstatus = OrderMsg.PARTIALLY_FILLED
        elif status == 'INSUFFICIENT':
            ordstatus = OrderMsg.REJECTED
        elif status == 'CANCELED':
            ordstatus = OrderMsg.CANCELED
        elif status == 'POSTONLY':
            if len(es) > 1 and es[1].strip() == 'CANCELED':
                ordstatus = OrderMsg.CANCELED
                 

        if ordertype in ['MARKET', 'EXCHANGE MARKET']:
            otype = OrderMsg.MKT
        else:
            otype = OrderMsg.LMT

        side = OrderMsg.BUY if origQty > 0 else OrderMsg.SELL
        price = D(0) if otype == OrderMsg.MKT else utils.norm_str(price)
        priceavg = None if priceavg == D(0) else utils.norm_str(priceavg)
        origQty = np.abs(origQty)
        remaining = np.abs(remaining)
        filled = origQty - remaining

           
        order = OrderMsg(account=self.account,
                         orderid=utils.norm_str(orderId),
                         status=ordstatus,
                         symbol=symbol,
                         otype=otype,
                         amt=utils.norm_str(origQty),
                         side=side,
                         price=price,
                         avgp=priceavg,
                         filled=utils.norm_str(filled),
                         remaining=utils.norm_str(remaining),
                         cost=None,
                         costccy=None,
                         last_ts=float(tsupdate)/1000.,
                         info=None)
        return order
    
    def parse_ws_fill(self, trade, msgtype):
        symbol = self.symvert(venuesym=trade[1][1:].lower())
        execamt = trade[4]
        side = OrderMsg.BUY if execamt > 0 else OrderMsg.SELL       
        ordertype = trade[6]
        # sometimes ordertype can come back as None, could be due to ws API being in beta
        # if this is the case, our best way to determine whether this is traded on margin 
        # or exchange is by checking whether the fee ccy is equal to quote ccy if we are selling
        # and equal to base ccy if we are buying. This doesn't catch all cases however, hopefully API
        # will improve
        marginsym = trade[1][1:]
        exchangesym = self.symvert(venuesym=marginsym.lower())
        feeccy = trade[10]
        if ordertype is None:
            if (self.symbols.getbaseccy(self.venue, symbol) == feeccy and side == OrderMsg.BUY) or \
                    (self.symbols.getquoteccy(self.venue, symbol) == feeccy and side == OrderMsg.SELL):
                symbol = exchangesym 
            else:
                symbol = marginsym                
        elif ordertype.split(' ')[0] == 'EXCHANGE':
            symbol = exchangesym  
        else:
            symbol = marginsym
    

        fill = Fill(account=self.account,
                    tradeid=utils.dec_to_str(trade[0]),
                    orderid=utils.dec_to_str(trade[3]),
                    symbol=symbol,
                    amt=utils.norm_str(np.abs(execamt)),
                    side=side,
                    price=utils.norm_str(trade[5]),
                    cost=utils.norm_str(-trade[9]),
                    costccy=feeccy,
                    last_ts=float(trade[2])/1000.)
        return fill

    def parse_place_result(self, orderinfo, omsg):
        oinfo = orderinfo.get('info',{})
        account = omsg.account
        omsg.orderid = oinfo.get('order_id', None)
        if omsg.orderid:
            return self.parse_rest_order(account, orderinfo)

    def parse_cancel_result(self, result, omsg):
        self.logger.info('result from parse_cancel_result {}'.format(result))
        if 'id' in result.keys():
            omsg.status = OrderMsg.CANCELED
        else:
            self.logger.error('Unexpected order cancel result format: {}'.format(result))
            return None
        return omsg

    def parse_rest_order(self, account, orderdict):
        odict = orderdict['info']
        islive = odict['is_live']
        iscancelled = odict['is_cancelled']
        executedamt = str(odict['executed_amount'])
        otype = str(odict['type'])
        symbol = str(odict['symbol'])
        side = str(odict['side'])
        origamt = str(odict['original_amount'])
        remaining = str(odict['remaining_amount'])
        avgp = str(odict['avg_execution_price'])
        avgp = None if D(avgp) == D(0) else avgp
        price = str(odict['price'])
        ts = float(odict['timestamp'])

        if 'exchange' in otype:
            symbol = self.symvert(venuesym=symbol)
        else:
            symbol = symbol.upper()

        if 'limit' in otype:
            otype = OrderMsg.LMT
        else:
            otype = OrderMsg.MKT

        if iscancelled:
            status = OrderMsg.CANCELED
        elif islive:
            if D(executedamt) == 0:
                status = OrderMsg.NEW
            else:
                status = OrderMsg.PARTIALLY_FILLED 
        else:
            status = OrderMsg.PENDING_CANCEL
        
        return utils.OrderMsg(account=account,
                              orderid=str(odict['id']),
                              status=status,
                              symbol=symbol,
                              otype=otype,
                              amt=origamt,
                              side=side,
                              price=price,  
                              avgp=avgp,
                              filled=executedamt,
                              remaining=remaining,
                              cost=None,
                              costccy=None,
                              last_ts=ts,
                              info=odict
        )

    def getrestpositions(self, account):
        positions = []
        try:
            pd = self.ccxt_rest_call(account, 'privatePostPositions')
        except:
            pd = []
            self.logger.error('Failed to get positions', exc_info=True)
        for x in pd:
            if x['status'].lower() == 'active':
                symbol = self.symvert(venuesym=x['symbol'].upper())
                qty=str(x['amount'])
                if 'margin_funding' in x:
                    maintmargin=str(x['margin_funding']),
                else:
                    maintmargin=None

                marginccy = self.symbols.getbaseccy(self.venue, symbol) if qty < 0 else self.symbols.getquoteccy(self.venue, symbol)

                if 'price_liq' in x:
                    liqprice=str(x['price_liq'])
                else:
                    liqprice=None
                if 'base_price' in x:
                    avgp= str(x['base_price'])
                else:
                    avgp=None

                if 'leverage' in x:
                    leverage = str(x['leverage'])
                else:
                    leverage = None
                    
                pos = Position(symbol,
                               self.account,
                               symbol,
                               qty=qty,
                               unrealised=str(x['pl']),
                               unrealisedccy=self.symbols.getquoteccy(self.venue, symbol),
                               maintmargin=maintmargin,
                               marginccy=marginccy,
                               liqprice=liqprice,
                               avgp=avgp,
                               leverage=leverage)
                positions.append(pos)
        return {'margin': positions}

    def getfullstate(self, account):
        super(bitfinex, self).getfullstate(account)
        self._get_tradable_balances() 
    
    def _get_tradable_balances(self):
        marginlimits = self.ccxt_rest_call(self.account, 'privatePostMarginInfos')[0]['margin_limits'] 
        for ml in marginlimits:
            self.tradablebals[ml['on_pair']] = D(ml['tradable_balance'])

    def getrestfills(self, account, oids):
        syms = set()
        for oid in oids:
            ostate = self.oms.getorderstate(account, oid)

            if ostate:
                syms.add(ostate.symbol)
        filldicts = []
        for sym in syms:
            sym0 = sym
            if not self.symbols.isccypair(sym):
                sym0 = '{}/{}'.format(self.symbols.getbaseccy(self.venue, sym), self.symbols.getquoteccy(self.venue, sym))
            filldicts += self.ccxt_rest_call(account, 'fetch_my_trades', [], {'symbol':sym0})
            for fd in filldicts:
                fd['symbol'] = sym
        result = [self.parse_rest_fill(account, fdict) for fdict in filldicts]
        return [r for r in result if r is not None]

    def parse_rest_fill(self, account, fillsdict):
        return Fill(account=account,
                    tradeid=str(fillsdict['info']['tid']),
                    orderid=str(fillsdict['info']['order_id']),
                    symbol=fillsdict['symbol'],
                    amt=utils.norm_str(fillsdict['info']['amount']),
                    side=fillsdict['info']['type'].lower(),
                    price=utils.norm_str(fillsdict['info']['price']),
                    cost=utils.norm_str(-fillsdict['info']['fee_amount']),
                    costccy=str(fillsdict['info']['fee_currency']),
                    last_ts=float(fillsdict['timestamp'])/1000.)

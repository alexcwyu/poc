# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from cdecimal import Decimal as D
import numpy as np
import json

class customloglevel:
    #INFO=20, WARNING=30, ERROR=40
    HB = 19 #below info so will be filtered out by alertserver and not saved to file
    FILL = 38
    ALERT = 39
    NAMEMAP = {HB: 'HB',
               FILL: 'FILL',
               ALERT: 'ALERT'}

def precision(sNumber):
    sNumber = norm_str(sNumber) #make sure it's a normalized string
    assert type(sNumber) == str
    if '.' in sNumber:
        items = sNumber.split('.')
        assert len(items) == 2
        return len(items[-1])
    else:
        return 0

def norm_str(num):
    if not (type(num) in [unicode, str, D, float, int]):
        print type(num)
        print num
    assert type(num) in [unicode, str, D, float, int], '{} {}'.format(num, type(num))  
    dec = D(num)
    return dec_to_str(dec.normalize())

def dec_to_str(dec):
    if type(dec) != D:
        print 'Decimal expected but got {} {} instead'.format(type(dec), dec)
        assert type(dec) == D
    sign, digits, exponent = dec.as_tuple()
    sSign = '-' if sign == 1 else ''
    prefix = ''
    suffix = ''
    if exponent < 0:
        shift_digits = len(digits) + exponent 
        if shift_digits > 0:
            prefix = ''.join([str(x) for x in digits[0:shift_digits]]) + '.'
        else:
            prefix = '0.' + ''.join(['0' for x in range(-shift_digits)])
        suffix = ''.join([str(x) for x in digits[exponent:]])
    else:
        prefix = ''.join([str(x) for x in digits])
        suffix = ''.join(['0' for x in range(exponent)])
        #print dec.as_tuple()
        #print sSign + prefix + suffix
    return sSign + prefix + suffix

#Util method for ASCII-fying json loading from exchanges
def byteify(input):
    if isinstance(input, dict):
        return {byteify(key): byteify(value) for key, value in input.iteritems()}
    elif isinstance(input, list):
        return [byteify(element) for element in input]
    elif isinstance(input, unicode):
        return input.encode('utf-8')
    else:
        return input
                                
def isfloat(input):
    try:
        float(input)
        return True
    except ValueError:
        return False
    except TypeError:
        return False

#Pretty-printing display for time
def timepp(secs):
    try:
        secs = float(secs)
        if secs < 1:
            return '{}ms'.format(int(secs*1000))
        elif secs < 60:
            return '{}s'.format(int(secs))
        elif secs >= 60 and secs <= 60*60:
            return '{}m'.format(int(secs/60.))
        else:
            return '{}h'.format(int(secs/60./60.))
    except:
        return '-'
    
#Pretty-printing display function for prices
def pricepp(price):
    if price is None:
        return '-'
    
    if price is np.nan or price != price:
        return '-'

    if not isinstance(price, D):
        price = D(price)

    displaychars = 9
    px = D(str(price))
    tup = px.as_tuple()
    digits = list(tup.digits)
    firstexp = len(digits) + tup.exponent
    
    #If digits to display can fit then just display:
    fmtdisp = "{0:.2f}".format(px)
    if len(norm_str(px)) <= displaychars:
        return norm_str(px)
    elif abs(px) > 10 and len(fmtdisp) <= displaychars:
        return "{0:.2f}".format(px)
    elif abs(firstexp) <= 3:
        return "{0:.6f}".format(px)        
    else:
        sign = '-' if tup.sign else ''
        if len(digits) <= 2:
            head = digits
        elif px > 1:
            head = digits[0:5]
        else:
            head = [digits[0]]
        dp = digits[len(head):5]
        dec = '.' + ''.join([str(x) for x in dp]) if len(dp)>0 else ''
        exp = -len(head) + firstexp

        head = ''.join([str(x) for x in head])
        dp = '.'+''.join([str(x) for x in dp])
        return '{sign}{head}{dec}e{exp}'.format(sign=sign, head=head, dec=dec, exp=exp)

def sf_increment(sigfigs, number):
    assert type(sigfigs) == int
    assert sigfigs > 0
    assert type(number) not in [int, float]

    if type(number) != D:
        number = D(number)

    sign, digits, exp = number.as_tuple()
    digits = list(digits)

    newexp = exp + len(digits) - sigfigs
    return D(10) ** (D(newexp))

def human_format(num):
    num = float('{:.3g}'.format(num))
    magnitude = 0
    while abs(num) >= 1000:
        magnitude += 1
        num /= 1000.0
    return '{}{}'.format('{:f}'.format(num).rstrip('0').rstrip('.'), ['', 'K', 'M', 'B', 'T'][magnitude])

#support k, m suffixes
def from_human_format(numstr):
    lookup = {'k':1000, 'm':1000000}
    if numstr[-1] in ['k','m']:
        numstr = dec_to_str((D(numstr[:-1])*lookup[numstr[-1]]).normalize())
    return numstr

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, June 2018
import time
from cdecimal import Decimal as D

class Position(object):

    def __init__(self, name,
                 account,
                 symbol,
                 qty = "0",
                 unrealised=None,
                 unrealisedccy='BTC',
                 realised=None,
                 realisedccy='BTC',
                 liqprice=None,
                 initmargin=None,
                 maintmargin=None,
                 marginccy=None,
                 leverage=None,
                 avgp=None):
        self.__name = name
        self.__account = account
        self.__symbol = symbol
        self.__qty = qty
        self.__unrealised = unrealised
        self.__unrealisedccy = unrealisedccy
        if not self.__unrealisedccy: self.__unrealisedccy = 'BTC'
        self.__realised = realised
        self.__realisedccy = realisedccy
        if not self.__realisedccy: self.__realisedccy = 'BTC'
        self.__liqprice = liqprice
        self.__initmargin = initmargin
        self.__maintmargin = maintmargin
        self.__marginccy = marginccy
        if not self.__marginccy: self.__marginccy = 'BTC'
        self.__leverage = leverage
        self.__avgp = avgp
        
    def setunrealised(self, unrealised, ccy='BTC'):
        assert isinstance(unrealised, D)
        assert isinstance(ccy, str) or isinstance(ccy, unicode)
        self.__unrealised = unrealised
        self.__unrealisedccy = ccy

    def setrealised(self, realised, ccy='BTC'):
        assert isinstance(realised, D)
        assert isinstance(ccy, str) or isinstance(ccy, unicode)
        self.__realised = realised
        self.__realisedccy = ccy

    def setmargin(self, init, maintenance, ccy='BTC'):
        assert isinstance(init, D)
        assert isinstance(maintenance, D)
        assert isinstance(ccy, str) or isinstance(ccy, unicode)
        self.__initmargin = init
        self.__maintmargin = maintenance
        self.__marginccy = ccy

    @property
    def name(self):
        return self.__name

    @property
    def account(self):
        return self.__account

    @property
    def symbol(self):
        return self.__symbol

    @property
    def qty(self):
        if self.__qty is None:
            return '0'
        else:
            return self.__qty

    @qty.setter
    def qty(self, qty):
        self.__qty = qty

    @property
    def unrealised(self):
        if self.__unrealised is None:
            return '0'
        else:
            return self.__unrealised

    @property
    def unrealisedccy(self):
        return self.__unrealisedccy

    @property
    def realised(self):
        if self.__realised is None:
            return '0'
        else:
            return self.__realised

    @property
    def realisedccy(self):
        return self.__realisedccy

    @property
    def liqprice(self):
        if self.__liqprice is None:
            return '0'
        else:
            return self.__liqprice

    @liqprice.setter
    def liqprice(self, liqprice):
        self.__liqprice = liqprice

    @property
    def initmargin(self):
        if self.__initmargin is None:
            return '0'
        else:
            return self.__initmargin

    @property
    def maintmargin(self):
        if self.__maintmargin is None:
            return '0'
        else:
            return self.__maintmargin

    @property
    def marginccy(self):
        return self.__marginccy
        
    @property
    def leverage(self):
        if self.__leverage is None:
            return '0'
        else:
            return self.__leverage

    @leverage.setter
    def leverage(self, leverage):
        assert isinstance(leverage, D)
        assert D(leverage) > 0
        self.__leverage = leverage

    @property
    def avgp(self):
        if self.__avgp is None:
            return '0'
        else:
            return self.__avgp

    @avgp.setter
    def avgp(self, avgp):
        self.__avgp = avgp
    
    def to_json(self):
        return {'name': self.__name,
                'account': self.__account,
                'symbol': self.__symbol,
                'qty': str(self.__qty),
                'unrealised': str(self.__unrealised),
                'unrealisedccy': self.__unrealisedccy,
                'realised': str(self.__realised),
                'realisedccy': self.__realisedccy,
                'liqprice': str(self.__liqprice),
                'initmargin': str(self.__initmargin),
                'maintmargin': str(self.__maintmargin),
                'marginccy': self.__marginccy,
                'leverage': str(self.__leverage),
                'avgp': str(self.__avgp)}

    @staticmethod
    def from_json(di):
        def none_or_str(field):
            x = di.get(field, None)
            if x is None or x == 'None': return None
            else: return str(x)
            
        return Position(di['name'],
                        di['account'],
                        di['symbol'],
                        qty=none_or_str('qty'),
                        unrealised=none_or_str('unrealised'),
                        unrealisedccy=none_or_str('unrealisedccy'),
                        realised=none_or_str('realised'),
                        realisedccy=none_or_str('realisedccy'),
                        liqprice=none_or_str('liqprice'),
                        initmargin=none_or_str('initmargin'),
                        maintmargin=none_or_str('maintmargin'),
                        marginccy=none_or_str('marginccy'),
                        leverage=none_or_str('leverage'),
                        avgp=none_or_str('avgp'))

    def __repr__(self):
        return str(self.to_json())

        
class Wallet(object):
    
    def __init__(self, account, walletname, spot=False):
        self.__account = account
        self.__name = walletname
        self.__spot = spot
        self.__balance = {}
        self.__tradable = {}
        self.__withdrawable = {}
        self.__positions = {}
        self.__ts = time.time()

    def setts(self, ts):
        self.__ts = ts

    def setbalances(self, balance, tradable, withdrawable, isupdate=False):
        if isupdate:
            for key in balance:
                self.__balance[key] = balance[key]
            for key in tradable:
                self.__tradable[key] = tradable[key]
            for key in withdrawable:
                self.__withdrawable[key] = withdrawable[key]
        else:
            self.__balance = balance
            self.__tradable = tradable
            self.__withdrawable = withdrawable

    def setposition(self, position):
        self.__positions[position.name] = position

    def clearpos(self):
        self.__positions = {}
        
    #Getters & Setters
    @property
    def account(self):
        return self.__account

    @property
    def venue(self):
        if self.account:
            return self.account.split(':')[0]
        return None
    
    @property
    def name(self):
        return self.__name

    @property
    def spot(self):
        return self.__spot

    @property
    def balance(self):
        return self.__balance

    @property
    def tradable(self):
        return self.__tradable

    @property
    def withdrawable(self):
        return self.__withdrawable

    @property
    def positions(self):
        return self.__positions

    @property
    def lastupdated(self):
        return self.__ts
        
    def __repr__(self):
        return 'Wallet: {} {} {} {} {} {}'.format(self.__account, self.__name, str(self.__balance), str(self.__tradable), str(self.withdrawable), str(self.__positions))

    def to_json(self):
        return {'account': self.__account,
                'name': self.__name,
                'spot': self.__spot,
                'balance': self.__balance,
                'tradable': self.__tradable,
                'withdrawable': self.__withdrawable,
                'positions': {k: v.to_json() for k, v in self.__positions.items()}}
            
    @staticmethod
    def from_json(di):
        assert 'account' in di
        assert 'name' in di
        assert 'spot' in di
        assert 'balance' in di
        assert 'tradable' in di
        assert 'withdrawable' in di
        assert 'positions' in di
        def zero_or_str(x):
            if x is 'None': return '0'
            else: str(x)

        wallet = Wallet(di['account'], di['name'], di['spot'])
        b = {k: zero_or_str(v) for k, v in di['balance'].items()}
        t = {k: zero_or_str(v) for k, v in di['tradable'].items()}
        w = {k: zero_or_str(v) for k, v in di['withdrawable'].items()}
        wallet.setbalances(b, t, w)
        for p in di['positions'].values():
            wallet.setposition(Position.from_json(p))
        return wallet

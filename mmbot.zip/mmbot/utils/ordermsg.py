# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import time
import logging
from cdecimal import Decimal as D

class OrderMsg(object):
    BUY = 'buy'
    SELL = 'sell'

    LMT = 'limit'
    MKT = 'market'
    STP = 'stop' #not supported yet
    TYPES = [LMT, MKT, STP]

    PENDING_NEW = 'Pending New'
    NEW = 'New'
    PARTIALLY_FILLED = 'PartiallyFilled'
    FILLED = 'Filled'
    DONE_FOR_DAY = 'DoneForDay'
    PENDING_CANCEL = 'Pending Cancel'
    PENDING_REPLACE = 'Pending Replace'
    REPLACED = 'Replaced'
    CANCELED = 'Canceled'
    REJECTED = 'Rejected'
    STOPPED = 'Stopped'

    #STATES is a dict of states plus their FIX precedence
    STATES = {PENDING_NEW: 2,
              NEW: 2,
              PARTIALLY_FILLED: 4,
              FILLED: 8,
              DONE_FOR_DAY: 10,
              PENDING_CANCEL: 12,
              PENDING_REPLACE: 11,
              REPLACED: 3,
              CANCELED: 5,
              REJECTED: 2,
              STOPPED: 7}

    #Convenience lists for if an order is still live or not
    LIVESTATES = [PENDING_NEW, NEW, PARTIALLY_FILLED, PENDING_CANCEL, PENDING_REPLACE, REPLACED]
    ACTIONABLE = [NEW, PARTIALLY_FILLED, REPLACED]

    INSUFFICIENT_FUNDS = 'insufficient funds'
    INVALID_ACCOUNT = 'invalid account'
    INVALID_SYMBOL = 'invalid symbol'
    EXCHANGE_REJECTED = 'exchange rejected'
    PENDING_NEW_TIMEOUT = 'pending new timeout'
    RATE_LIMITING = 'rate limiting'
    LOT_SIZE_INCORRECT = 'lot size incorrect'
    TICK_SIZE_INCORRECT = 'tick size incorrect'
    NOTIONAL_TOO_SMALL = 'notional too small'
    NOTIONAL_TOO_BIG = 'notional too big'
    LOT_SIZE_TOO_SMALL = 'lot size too small'
    PRICE_TOO_LOW = 'price too low'
    CANNOT_CROSS_SELF = 'cannot cross self'
    CANNOT_CROSS_MKT = 'cannot cross mkt'
    REJECT_MSGS = [INSUFFICIENT_FUNDS, INVALID_ACCOUNT, INVALID_SYMBOL, EXCHANGE_REJECTED, PENDING_NEW_TIMEOUT, RATE_LIMITING, LOT_SIZE_INCORRECT, TICK_SIZE_INCORRECT, NOTIONAL_TOO_SMALL, NOTIONAL_TOO_BIG, LOT_SIZE_TOO_SMALL, PRICE_TOO_LOW, CANNOT_CROSS_SELF, CANNOT_CROSS_MKT]
    
    def __init__(self, account, orderid, status, symbol, otype, amt, side, price=None, avgp=None, filled='0', remaining=None, open=True, cost='0', costccy='BTC', last_ts=None, info=None):
        if filled == '0' and remaining is None:
            remaining = amt
        assert type(amt) == str
        if otype == self.LMT:
            assert price is not None and type(price) == str
        #else:
        #    assert otype == self.MKT and price is None
        assert status in OrderMsg.STATES
        self.__account = account
        self.__orderid = orderid
        self.__status = status
        self.__symbol = symbol
        self.otype = otype
        self.__amt = amt
        self.side = side
        self.__price = price
        self.__avgp = avgp
        self.__filled = filled
        self.__remaining = remaining
        self.__open = open
        self.__cost = cost
        self.__costccy = costccy
        if amt is not None and filled is not None and remaining is not None and self.status in OrderMsg.LIVESTATES:
            #print self.__filled, self.__remaining, self.__amt, '<<<'
            #print account, orderid
            fl = D(self.__filled).normalize()
            rm = D(self.__remaining).normalize()
            am = D(self.__amt).normalize()
            #assert fl + rm == am, 'filled {} remaining {} amount {}'.format(fl, rm, am)
        
        if last_ts is None: 
            self.__ts = time.time()
        else:
            assert type(last_ts) == float
            self.__ts = last_ts #last update timestamp
        self.info = info
        self.__rejectmsg = None
        
    #Getters & Setters
    @property
    def account(self):
        return self.__account

    @property
    def venue(self):
        if self.account:
            return self.account.split(':')[0]
        return None
    
    @property
    def symbol(self):
        return self.__symbol

    @property
    def orderid(self):
        return self.__orderid

    @orderid.setter
    def orderid(self, value):
        if self.__orderid is None:
            self.__orderid = value
            self.__ts = time.time()
        else:
            raise Exception('OrderID can only be set once')
            
    @property
    def side(self):
        return self.__side
    
    @side.setter
    def side(self, value):
        assert value in [OrderMsg.BUY, OrderMsg.SELL]
        self.__ts = time.time()
        self.__side = value
    
    @property
    def otype(self):
        return self.__otype

    @otype.setter
    def otype(self, value):
        assert value in [OrderMsg.LMT, OrderMsg.MKT]
        self.__ts = time.time()
        self.__otype = value
    
    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, value):
        assert value in OrderMsg.STATES
        self.__ts = time.time()
        self.__status = value

    @property
    def lastupdated(self):return self.__ts

    @property
    def amt(self): return self.__amt
    
    @property
    def price(self): return self.__price

    @price.setter
    def price(self, value):
        assert type(value) == str
        self.__price = value
    
    @property
    def avgp(self): return self.__avgp

    @avgp.setter
    def avgp(self, value):
        assert type(value) == str
        self.__avgp = value

    @property
    def filled(self): return self.__filled

    @filled.setter
    def filled(self, value):
        assert type(value) == str
        self.__filled = value

    @property
    def rejectmsg(self): return self.__rejectmsg

    @rejectmsg.setter
    def rejectmsg(self, value):
        assert value in OrderMsg.REJECT_MSGS
        assert self.__rejectmsg is None #order can only be rejected once
        self.__rejectmsg = value
        
    @property
    def remaining(self): return self.__remaining

    @remaining.setter
    def remaining(self, value):
        assert type(value) == str
        self.__remaining = value

    @property
    def open(self): return self.__open

    @open.setter
    def open(self, value):
        assert value in [True, False]
        self.__open = value

    @property
    def cost(self): return self.__cost

    @cost.setter
    def cost(self, value):
        assert type(value) == str
        self.__cost = value

    @property
    def costccy(self): return self.__costccy

    @costccy.setter
    def costccy(self, value):
        assert type(value) == str
        self.__costccy = value

    @property
    def last_ts(self): return self.__ts

    @last_ts.setter
    def last_ts(self, value):
        assert value is None or utils.isfloat(value)
        self.__ts = float(value)

    @property
    def venue(self):
        return self.__account.split(':')[0]
    
    def __repr__(self):
        open = 'O' if self.__open else 'C'
        if self.__status == self.REJECTED:
            statusinfo = '{}:{}'.format(self.__status, self.rejectmsg)
        else:
            statusinfo = self.__status
        return '{} {} {} {} {} {} {} {} {}'.format(self.__account, str(self.__orderid), statusinfo, self.__price, open, self.__side, self.__amt, self.__symbol, self.__filled, self.info)

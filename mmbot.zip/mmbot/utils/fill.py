# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from ordermsg import OrderMsg
import time
import datetime

class Fill(object):

    def __init__(self, account, tradeid, orderid, symbol, amt, side, price, cost=None, costccy=None, last_ts=None, internalid=None, strategy='/'):
        self.__account = account
        self.__tradeid = tradeid
        self.__orderid = orderid
        self.__symbol = symbol
        assert type(amt) == str
        assert float(amt) > 0
        self.__amt = amt
        assert side in [OrderMsg.BUY, OrderMsg.SELL]
        self.__side = side
        assert type(price) == str
        self.__price = price
        self.__cost = cost
        self.__costccy = costccy
        if last_ts is None: last_ts = time.time()
        self.__ts = last_ts
        self.internalid = internalid
        self.strategy = strategy

    @property
    def account(self):
        return self.__account

    @property
    def symbol(self):
        return self.__symbol

    @property
    def orderid(self):
        return self.__orderid

    @orderid.setter
    def orderid(self, value):
        if self.__orderid is None:
            self.__orderid = value
            self.__ts = time.time()
        else:
            raise Exception('OrderID can only be set once')

    @property
    def tradeid(self):
        return self.__tradeid

    @tradeid.setter
    def tradeid(self, value):
        if self.__tradeid is None:
            self.__tradeid = value
            self.__ts = time.time()
        else:
            raise Exception('TradeID can only be set once')
    
    @property
    def amt(self):
        return self.__amt

    @property
    def side(self):
        return self.__side
    
    @property
    def price(self):
        return self.__price
    
    @property
    def cost(self):
        return self.__cost

    @property
    def costccy(self):
        return self.__costccy

    @property
    def last_updated(self):
        return self.__ts

    def to_json(self):
        return {'account':self.__account, 'tradeid':self.__tradeid, 'orderid':self.__orderid,
                'symbol':self.__symbol, 'amt':self.__amt, 'side':self.__side, 'price':self.__price,
                'cost':self.__cost, 'costccy':self.__costccy, 'timestamp':self.__ts, 'internalid':self.internalid, 'strategy':self.strategy}

    @staticmethod
    def from_json(di):
        def none_or_str(x):
            if x is None: return x
            else: return str(x)
        
        return Fill(account=none_or_str(di['account']),
                    tradeid=none_or_str(di['tradeid']),
                    orderid=none_or_str(di['orderid']),
                    symbol=none_or_str(di['symbol']),
                    amt=none_or_str(di['amt']),
                    side=none_or_str(di['side']),
                    price=none_or_str(di['price']),
                    cost=none_or_str(di['cost']),
                    costccy=none_or_str(di['costccy']),
                    last_ts=di['timestamp'],
                    internalid=di.get('internalid',None),
                    strategy=di.get('strategy','/'))

    def __repr__(self):
        try:
            dt = datetime.datetime.utcfromtimestamp(self.__ts).strftime('%Y-%m-%d %H:%M:%S')
        except:
            dt = self.__ts
        return '{} {} {} {} {} {} {} {} {} {} {}'.format(dt, self.__account, str(self.__orderid)[:10], str(self.__tradeid)[:10], self.__price, self.__side, self.__amt, self.__symbol, self.__cost, self.__costccy, self.strategy)


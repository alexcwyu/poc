import time
import iso8601
import datetime
from calendar import timegm

class Transfer(object):
    PENDING = 'pending'
    TRANSIT = 'transit'
    COMPLETED = 'completed'
    STATES = {PENDING, TRANSIT, COMPLETED}
    FIELDS = ['account_from', 'account_to', 'amount', 'ccy', 'withdraw_fee', 'withdraw_ccy', 'deposit_fee', 'deposit_ccy', 'network_fee', 'network_ccy', 'initiated_t', 'withdraw_t', 'deposit_t', 'rmk']

    def getfields(self):
        return self.FIELDS

    @property
    def status(self):
        timenow = time.time()
        deposit_t = getattr(self, 'deposit_t', None)
        withdraw_t = getattr(self, 'withdraw_t', None)
        if deposit_t is None: deposit_t = timenow + 10
        if withdraw_t is None: withdraw_t = timenow + 10

        if timenow > deposit_t:
            return self.COMPLETED
        if timenow > withdraw_t:
            return self.TRANSIT
        return self.PENDING
    
    def __repr__(self):
        try:
            init_t = datetime.datetime.utcfromtimestamp(self.initiated_t)
            return '{} {} {} {} {} --> {}'.format(init_t, self.status, self.amount, self.ccy, self.account_from, self.account_to)
        except Exception as e:
            return 'Fields incorrect {}'.format(e)

    #includes conversion code for time
    def set(self, fieldname, value):
        if fieldname in ['initiated_t', 'withdraw_t', 'deposit_t']:
            value = timegm(iso8601.parse_date(value).timetuple()) #convert to epoch timestamp for storage
        setattr(self, fieldname, value)

    def get(self, fieldname, value):
        return getattr(self, fieldname, value)

    def to_json(self):
        dict_ = {'status':self.status} #save this into db for easy queries
        for field in self.getfields():
            dict_[field] = getattr(self, field, None)
        return dict_

    @staticmethod
    def from_json(dict_):
        xfer = Transfer()
        for field in xfer.getfields():
            setattr(xfer, field, dict_.get(field, None))
        return xfer

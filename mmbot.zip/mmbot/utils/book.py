# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import threading
import time
import sortedcontainers
import logging
import utils
from cdecimal import Decimal

class Book(object):

    def __init__(self, bidlst, asklst, seqnum, strictseqcheck=False, name=None):
        '''Constructor.

        Parameters
        ----------
        bidlst: list
                tuples of form (sPrice, sSize), normalized str
        asklst: list
                tuples of form (sPrice, sSize), normalized str
        seqnum: integer or float
        strictseqcheck: bool
                        if on, checks whether seqnums are consecutive (seqnums need to be ints)
        Returns
        -------
        None
        '''
        self.lock = threading.Lock()

        self.name = name
                
        if strictseqcheck:
            assert type(seqnum) == int
        else:
            assert type(seqnum) in {int, float}

        self._strictseqcheck = strictseqcheck
        self._seqnum = seqnum
        self._iseq = 0 #internal integer seq

        with self.lock:
            self._bids = sortedcontainers.SortedDict(lambda x: -float(x)) #sort by decreasing price
            self._asks = sortedcontainers.SortedDict(lambda x: float(x))
            self._bids.update({sp:sz for sp,sz in bidlst})
            self._asks.update({sp:sz for sp,sz in asklst})

            #There should be no zero sizes
            assert '0' not in set(self._bids.values()).union(set(self._asks.values()))
            
        self._droppedmsgs = False
        self.lastupdated = time.time()
        
    def applyupdates(self, bid_updates, ask_updates, seqnum):
        '''Applies updates to the existing book
        Parameters
        ----------
        bid_updates: list
                     list of tuples in the form (sPrice, sSize) where sSize can be '0'
        ask_updates: list
                     same as above
        seqnum: int or float 
                depending on if strictseqcheck
        '''
        self.lastupdated = time.time()
        with self.lock:
            
            
            if self._strictseqcheck:
                #case 0: the update is in the past or present; discard it
                if seqnum <= self._seqnum:
                    return [], [], self._iseq
                #case 1: the update is too far in the future - still do the updating but set a flag
                elif seqnum > self._seqnum + 1:
                    self._droppedmsgs = True
                    #return [], [], self._iseq
                #case 2: the update is just right
                else:
                    assert seqnum - self._seqnum == 1
            else:
                #case 0: update is in the past -> ignore
                if seqnum <= self._seqnum:
                    return [], [], self._iseq
                
            self._seqnum = seqnum

            valid_bids = []
            for (sp,sz) in bid_updates:
                if Decimal(sz) > 0:
                    self._bids[sp] = sz
                    valid_bids.append(sp)
                else:
                    if sp in self._bids: del self._bids[sp]

            valid_asks = []
            for (sp,sz) in ask_updates:
                if Decimal(sz) > 0:
                    self._asks[sp] = sz
                    valid_asks.append(sp)
                else:
                    if sp in self._asks: del self._asks[sp]

            #censor book
            if len(valid_bids) > 0:
                maxbid = max([float(x) for x in valid_bids])
                while len(self._asks) > 0:
                    _minask,_ = self._asks.peekitem(index=0)
                    if float(_minask) <= maxbid:
                        sp,_ = self._asks.popitem(last=False) #remove from front
                        ask_updates.append((sp, '0')) #removals of levels
                    else:
                        break
                
            if len(valid_asks) > 0:
                minask = min([float(x) for x in valid_asks])
                while len(self._bids) > 0:
                    _maxbid,_ = self._bids.peekitem(index=0)
                    if float(_maxbid) >= minask:
                        sp,_ = self._bids.popitem(last=False)
                        bid_updates.append((sp, '0'))
                    else:
                        break

            self._iseq += 1
            return bid_updates, ask_updates, self._iseq


    @property
    def iseq(self):
        return self._iseq
    
    @property
    def bids(self):
        with self.lock:
            return self._bids.items()

    @property
    def asks(self):
        with self.lock:
            return self._asks.items()

    @property
    def droppedmsgs(self):
        return self._droppedmsgs

    #High performance access methods
    @property
    def indicative_mid(self):
        bid = self.best_bid
        ask = self.best_ask
        if bid is None and ask is None:
            return None
        elif bid is None:
            return Decimal(ask[0])
        elif ask is None:
            return Decimal(bid[0])
        else:
            price = (Decimal(bid[0]) + Decimal(ask[0])) / Decimal(2)
            return price

    @property
    def best_bid(self):
        x = self.best_bids(1)
        if len(x) == 1: return x[0]
        return None

    @property
    def best_ask(self):
        x = self.best_asks(1)
        if len(x) == 1: return x[0]
        return None
    
    def best_bids(self, depth, cleanorders = []):
        if cleanorders == []:
            with self.lock:
                return [(bid, self._bids[bid]) for bid in self._bids.islice(stop=depth)]
        else:
            removelevels = {}
            for (sp, sz) in cleanorders:
                if utils.norm_str(sp) in removelevels:
                    removelevels[utils.norm_str(sp)] += Decimal(sz)
                else:
                    removelevels[utils.norm_str(sp)] = Decimal(sz)

            clean_best_bids = []
            with self.lock:
                bids = self._bids
            depthcount = 0
            for bid in bids.islice(stop=(depth+len(removelevels))):
                if bid in removelevels:
                    size = Decimal(self._bids[bid]) - removelevels[bid]
                    # this is required for book delays where we are actually cleaning an old book
                    clean_best_bids.append((bid, utils.norm_str(min(max(size, 0), self._bids[bid])))) 
                    depthcount += 1
            
                else:
                    clean_best_bids.append((bid, self._bids[bid]))
                    depthcount += 1
                if depthcount >= depth:
                    break
            return clean_best_bids
    
    def best_asks(self, depth, cleanorders = []):
        if cleanorders == []:
            with self.lock:
                return [(ask, self._asks[ask]) for ask in self._asks.islice(stop=depth)]
        else:
            removelevels = {}
            for (sp, sz) in cleanorders:
                if utils.norm_str(sp) in removelevels:
                    removelevels[utils.norm_str(sp)] += Decimal(sz)
                else:
                    removelevels[utils.norm_str(sp)] = Decimal(sz)

            clean_best_asks = []
            with self.lock:
                asks = self._asks
            depthcount = 0
            for ask in asks.islice(stop = (depth + len(removelevels))):
                if ask in removelevels:
                    size = Decimal(self._asks[ask]) - removelevels[ask]
                    if size > 0:
                        clean_best_asks.append((ask, utils.norm_str(min(max(size, 0),  self._asks[ask])))) 
                        depthcount += 1
                else:
                    clean_best_asks.append((ask, self._asks[ask]))
                    depthcount += 1
                if depthcount >= depth:
                    break
            return clean_best_asks


def test():
    b = Book([('101','33'), ('99','22'), ('1','2')], [('200','2'),('199','3'), ('195','4')], 0)

    print(b.bids)
    print(b.asks)

    b_u, a_u, iseq = b.applyupdates([('101','0'), ('98','5'), ('196','2')], [('198','444')], 1.)

    print('='*8)
    print(b_u)
    print(a_u)
    print('='*8)
    print(b.bids)
    print(b.asks)
    print('='*8)


if __name__ == '__main__':
    test()

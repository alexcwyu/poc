import urwid
import pubsub
import orderview

class TradingAppUI(urwid.ListBox):
    def __init__(self, tapp, view):
        self.model = tapp
        self.view = view

        self.focusdict = {'titlebar': 'focusbar',
                          'linebox' : 'focusbar'}
        body = urwid.SimpleFocusListWalker([urwid.AttrMap(urwid.BoxAdapter(self.view, 50), '', self.focusdict)])
        self.ovadapter = None
                
        super(TradingAppUI, self).__init__(body)

    def addorderview(self):
        if self.ovadapter is None:
            self.ordermodel = orderview.OrderViewEngine(self.model)
            self.orderview = orderview.OrderView(self.ordermodel)
            self.ovadapter = urwid.AttrMap(urwid.BoxAdapter(self.orderview, 25), '', self.focusdict)
            self.body.append(self.ovadapter)

    def removeorderview(self):
        if self.ovadapter in self.body:
            self.body.remove(self.ovadapter)        
        
    def refresh(self):
        for widget in self.body:
            if widget is not None:
                widget.base_widget.refresh()

    def handle_input(self, key):
        if key in ['Q','q']:
            raise urwid.ExitMainLoop()
        
    def run(self):

        palette = [('titlebar', 'dark red', ''),
                   ('focusbar', 'dark red,bold', ''),
                   ('linebox', '', ''),
                   ('headers','white,bold',''), #dark green,bold
                   ('highlight','white,bold', 'dark blue'), #background color
                   ('custom', 'white,bold', ''),]
            
        main_loop = urwid.MainLoop(self, palette=palette, unhandled_input=self.handle_input)
        
        def refresh(_loop, _data):
            self.refresh()
            main_loop.set_alarm_in(0.5, refresh)

        main_loop.set_alarm_in(0, refresh)
        main_loop.run()
                                                

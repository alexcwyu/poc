export REFERENCEDB=$HOME/mmbot/reference/reference.db
export CMCLATEST=$HOME/coinmktcap/latest.json
export ECBLATEST=$HOME/ecbfx/latest.json
export PYTHONPATH=$PYTHONPATH:$HOME/mmbot

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
from cdecimal import Decimal as D
import json
import time
import os
import reference

def loadccys():
    pdi = {'USD':'1'}
    fiatccys = ['USD', 'EUR', 'AUD']
    x = json.load(open(os.environ['CMCLATEST']))
    ecbfx = json.load(open(os.environ['ECBLATEST']))

    for item in x:
        sym = item['symbol']
        price_usd = 0 if not item['price_usd'] else float(item['price_usd'])
        pdi[sym] = price_usd

    for ccy, price in ecbfx['rates'].iteritems():
        pdi[ccy] = (1 / price) * ecbfx['rates']['USD']
        if ccy not in fiatccys: fiatccys.append(ccy)

    pdi['EUR'] = ecbfx['rates']['USD']

    return pdi, fiatccys

def getprice(base, quote, verbose=False):
    if base == quote: return D(1)

    global PDI, LAST_REFRESH
    if time.time() - LAST_REFRESH > 10 * 60:
        PDI, FIATCCYS = loadccys()
        LAST_REFRESH = time.time()

    if base not in PDI.keys() or quote not in PDI.keys():
        if verbose:
            print('No rate available for {0}/{1}'.format(base, quote))
        return None
    
    return D(PDI[base])/D(PDI[quote])

PDI, FIATCCYS = loadccys()
LAST_REFRESH = time.time()


#TODO: Deprecate the stuff above?

def isnumeric(str_):
    try:
        float(str_)
        return True
    except ValueError:
        return False

# Use prefix notation
# (+ (* mid:XBTUSD@bitmex mid:ETHBTC@bitmex) 1) // ETH/USD price + 1
# (/ (+ bid ask) 2) // symbol depends on context; effectively gives mid

#TODO: below is tightly bound to tradingapp - bad arch? - maybe should go into algos lib
class Context(object):
    def __init__(self, venue, symbol):
        s = reference.symbols.Symbols()
        if symbol in s.get_symbols(venue):
            self.venue = venue
            self.symbol = symbol
        else:
            raise Exception('{} {} not in the system'.format(venue, symbol))

class Price(object):
    def __init__(self, specification, context=None):
        self.specification = specification
        self.tokens = specification.replace('(','').replace(')','').split()

        #Must be an odd number of tokens
        if len(self.tokens) % 2 == 0: raise Exception('Invalid format')
        
        self.context = context

        #initializes subscriptions and also checks the specs if proper
        self.__subs = set()
        numspecs = [token for token in self.tokens if token not in ['+','-','*','/']]

        if len(numspecs) == 0: raise Exception('Invalid format')
        
        for ns in numspecs:
            self.__subs = self.__subs.union(NumSpec(ns, self.context).subscriptions())

        self._lastupdated = 0
        #TODO: need a check that actually tries to evaluate the expression with constants first
            
    def subscriptions(self):
        return self.__subs

    @property
    def lastupdated(self):
        return self._lastupdated
    
    def evalprice(self, tapp):
        stack = []
        timestamps = []
        for t in reversed(self.tokens):
            if t in ['+','-','*','/']:
                lft = stack[-1]
                if lft is not None:
                    ns = NumSpec(lft, self.context)
                    lft = ns.evalprice(tapp)
                    timestamps.append(ns.lastupdated)
                rgt = stack[-2]
                if rgt is not None:
                    ns = NumSpec(rgt, self.context)
                    rgt = ns.evalprice(tapp)
                    timestamps.append(ns.lastupdated)
                if lft is None or rgt is None:
                    stack[-2:] = [None]
                else:
                    if t == '+': stack[-2:] = [str(D(lft) + D(rgt))]
                    elif t == '-': stack[-2:] = [str(D(lft) - D(rgt))]
                    elif t == '*': stack[-2:] = [str(D(lft) * D(rgt))]
                    elif t == '/': stack[-2:] = [str(D(lft) / D(rgt))]
            else:
                ns = NumSpec(t, self.context)
                res = ns.evalprice(tapp)
                timestamps.append(ns.lastupdated)
                stack.append(res)
        self._lastupdated = min(timestamps)
        assert len(stack) == 1, 'Malformed expression'
        return stack[0]

# Valid grammar
#  absolute price: [pricestr]
#  clean book:     [bid|ask|mid]:SYM@VENUE
#  grefprice:      grefp:SYM
#  theo value:     tv:SYM@VENUE
class NumSpec(object):
    def __init__(self, specification, context=None):

        assert type(specification) == str, specification
        self.ptype = None
        self.__price = None

        if context:
            self.sym, self.venue = context.symbol, context.venue
        else:
            self.sym, self.venue = None, None
        self._lastupdated = 0
        self.__subscriptions = set()
        if isnumeric(specification):
            self.ptype = 'ABSOLUTE'
            self.__price = specification
        else:
            items = specification.split(':')
            ptype = items[0]
            if ptype not in ['bid','ask','mid','grefp','tv']:
                raise Exception('Invalid price spec')
            
            if ':' not in specification:
                if context is None:
                    raise Exception('Invalid price spec - no context')
                self.sym = context.symbol
                self.venue = context.venue
            else:
                #at this point specification will include a colon
                _, syminfo = specification.split(':')
                if ptype == 'grefp':
                    self.sym = syminfo
                else:
                    if '@' not in syminfo: raise Exception('Invalid price spec - need to specify venue')
                    self.sym, self.venue = syminfo.split('@')
            self.__subscriptions.add((self.venue, self.sym))
            self.ptype = ptype.upper()
        
    def subscriptions(self):
        return self.__subscriptions

    def __repr__(self):
        return str(self.__price)

    @property
    def lastupdated(self):
        return self._lastupdated
    
    def evalprice(self, tapp):
        if self.ptype == 'ABSOLUTE':
            self._lastupdated = time.time()
        elif self.ptype == 'MID':
            book = tapp.getbook(self.venue, self.sym)
            if book is not None:
                self._lastupdated = book.lastupdated
                ask = book.best_asks(1, cleanorders=tapp.ourmktasks(self.venue, self.sym))
                bid = book.best_bids(1, cleanorders=tapp.ourmktbids(self.venue, self.sym))
                try:
                    self.__price = str((D(bid[0][0]) + D(ask[0][0]))/2)
                except:
                    self.__price = None
            
        elif self.ptype == 'BID':
            book = tapp.getbook(self.venue, self.sym)
            if book is not None:
                self._lastupdated = book.lastupdated
                bid = book.best_bids(1, cleanorders=tapp.ourmktbids(self.venue, self.sym))
                if bid: self.__price = bid[0][0]
                else: self.__price = None
            
        elif self.ptype == 'ASK':
            book = tapp.getbook(self.venue, self.sym)
            if book is not None:
                self._lastupdated = book.lastupdated
                ask = book.best_asks(1, cleanorders=tapp.ourmktasks(self.venue, self.sym))
                if ask: self.__price = ask[0][0]
                else: self.__price = None
            
        elif self.ptype == 'GREFP':
            self.__price = tapp.getgrefp(self.sym)
            self._lastupdated = tapp.getgrefp_lastupdated(self.sym)
            
        else:
            assert self.ptype == 'TV'
            self.__price = tapp.gettv(self.venue, self.sym)
            self._lastupdated = tapp.gettv_lastupdated(self.venue, self.sym)

        if self.__price is None: return None
        return str(self.__price)


from cdecimal import Decimal as D
import numpy as np
import time
import reference
import prices
import redis

class MakerParams(object):
    def __init__(self):
        self.r = redis.StrictRedis()

    def getavailmodels(self):
        return self.r.smembers('makermodels')

    def getavailparams(self, makername):
        return self.r.hgetall('makerparams:{}'.format(makername))
    
    def getparam(self, makername, key):
        return self.r.hget('makerparams:{}'.format(makername), key)

    def setparam(self, makername, key, value):
        self.r.sadd('makermodels', makername)
        self.r.hset('makerparams:{}'.format(makername), key, value)

    def removeparam(self, makername, key):
        self.r.hdel('makerparams:{}'.format(makername), key)
        
    def removemaker(self, makername):
        self.r.srem('makermodels', makername)
        for k,v in self.r.hgetall('makerparams:{}'.format(makername)).items():
            self.r.hdel('makerparams:{}'.format(makername), k)

    def removeall(self):
        for model in self.getavailmodels():
            self.removemaker(model)
            
class MakerModel(object):
    BUY_ONLY = 'buy'
    SELL_ONLY = 'sell'
    BOTH_SIDES = 'both'
    NO_QUOTE = 'none'
    
    # quoteratio is defined by tail size / front size, and is used to specify the steepness of the shape 
    def __init__(self, makername, refprice, venue, symbol, size, levels, quoteratio=D(1), minwidth=D('0.025'), maxwidth=D('0.05'), skew=D(1)):
        self.mp = MakerParams()
        self.makername = makername
        self.venue = venue
        self.symbol = symbol
        self.skew = skew
        self.size = size
        self.levels = levels
        assert self.levels > 0
        self.quoteratio = D(quoteratio)
        assert self.quoteratio >= 0
        self.minwidth = minwidth
        self.maxwidth = maxwidth
        assert self.maxwidth >= self.minwidth
        assert type(refprice) == prices.Price
        self.pricespec = refprice #expects type prices.Price
        self.s = reference.Symbols()

        self.widenmult = D('1')
        self.finalratio = self.widenmult * self.quoteratio
        self.flowskewlmt = D('0.5')
        self.maxratio = D('4')

        self.tradestats = []
        self.bids, self.asks = [], []
        self.hedgedqtyusd = D('0')
        self.prevmid = None
        self.saveparams()

        self.start_t = time.time()

        self.flow_skew = 0

    def saveparams(self):
        self.mp.setparam(self.makername, 'quoteratio', str(self.quoteratio))
        self.mp.setparam(self.makername, 'levels', str(self.levels))
        self.mp.setparam(self.makername, 'skew', str(self.skew))
        self.mp.setparam(self.makername, 'size', str(self.size))
        self.mp.setparam(self.makername, 'minwidth', str(self.minwidth))
        self.mp.setparam(self.makername, 'maxwidth', str(self.maxwidth))
        self.mp.setparam(self.makername, 'hedgedqtyusd', str(self.hedgedqtyusd))
        self.mp.setparam(self.makername, 'flowskewlmt', str(self.flowskewlmt))
        self.mp.setparam(self.makername, 'maxratio', str(self.maxratio))

    def loadparams(self):
        #TODO: make this load more efficient (pipeline)
        #No param checking! #Decimal params
        for param in ['skew', 'size', 'quoteratio', 'minwidth', 'maxwidth', 'hedgedqtyusd', 'flowskewlmt', 'maxratio']:
            val = self.mp.getparam(self.makername, param)
            if val is not None:
                setattr(self, param, D(val))
                
        for param in ['levels']:
            val = self.mp.getparam(self.makername, param)
            if val is not None:
                setattr(self, param, int(val))
                
    def on_trade(self, trade):
        self.tradestats.append(trade)
                
    def calcparams(self):
        LOOKBACK = 60*10
        self.loadparams()
        self.tradestats = [t for t in self.tradestats if float(t['ts']) > time.time() - LOOKBACK]

        prices = [float(t['price']) for t in self.tradestats]
        if len(prices) > 0:
            H = max(prices)
            L = min(prices)
            self.widenmult = max((D(H/L)-1) * 2 * 100, 1)
            
        self.finalratio = self.widenmult * self.quoteratio          
        lifts = sum([float(t['qty']) for t in self.tradestats if t['side'] == 'B'])
        hits = sum([float(t['qty']) for t in self.tradestats if t['side'] == 'S'])
        hlratio = (lifts + 1)/(hits + 1)
        maxratio = float(self.maxratio)
        hlratio = max(min(maxratio, hlratio), 1/maxratio)
        self.hlratio = hlratio

        elapsed = time.time() - self.start_t
        weight = min(elapsed, LOOKBACK)/float(LOOKBACK)
        
        self.flow_skew = self.flowskewlmt * D(np.log(hlratio)/np.log(maxratio)) * D(weight)

    @property
    def lastupdated(self):
        return self.pricespec.lastupdated
        
    def refreshmarket(self, tapp, side, inventory_skew):
        assert side in [self.BUY_ONLY, self.SELL_ONLY, self.BOTH_SIDES, self.NO_QUOTE]
        mid = self.pricespec.evalprice(tapp)
        if mid is None or self.maxwidth < self.minwidth:
            self.bids = []
            self.asks = []
            return
        mid = D(mid)       
        mid = mid * self.skew * inventory_skew

        hminw = self.minwidth/2
        flowskew = self.flow_skew * hminw
        mid = mid * (1 + flowskew)
        ourbestbid = self.s.round_dn(self.venue, self.symbol, mid*(1-hminw))
        ourbestask = self.s.round_up(self.venue, self.symbol, mid*(1+hminw))
        ticksz = self.s.getticksize(self.venue, self.symbol, price=mid)
        widthinticks = ourbestask - ourbestbid
        
        #Localize to this market
        book = tapp.getbook(self.venue, self.symbol)
        if book is not None:
            mktbids = book.best_bids(1, cleanorders=tapp.ourmktbids(self.venue, self.symbol))
            mktasks = book.best_asks(1, cleanorders=tapp.ourmktasks(self.venue, self.symbol))

            if mktbids is None and mktasks is None: #no book available - just quote what we were gonna do anyways
                pass

            elif mktbids is None:
                theirbestask = D(mktasks[0][0])
                if theirbestask < ourbestbid:
                    #need to hide and slide
                    ourbestbid = theirbestask - ticksz
                    ourbestask = ourbestbid + widthinticks

            elif mktasks is None:
                theirbestbid = D(mktbids[0][0])
                if theirbestbid > ourbestask:
                    ourbestask = theirbestbid + ticksz
                    ourbestbid = ourbestask - widthinticks
                
            else: #book is available - check both sides
                theirbestask = D(mktasks[0][0])
                theirbestbid = D(mktbids[0][0])
                if theirbestbid > ourbestask:
                    ourbestask = theirbestbid + ticksz
                    ourbestbid = ourbestask - widthinticks
                if theirbestask < ourbestbid:
                    #need to hide and slide
                    ourbestbid = theirbestask - ticksz
                    ourbestask = ourbestbid + widthinticks

        if self.levels == 1 or self.minwidth == self.maxwidth: #degenerate case
            bidps = [ourbestbid]
            askps = [ourbestask]
        else:
            quotedepth = (self.maxwidth - self.minwidth)/2
            spacing = quotedepth/(self.levels-1)
            bidps = [ourbestbid*(1 - i*spacing) for i in range(self.levels)]
            askps = [ourbestask*(1 + i*spacing) for i in range(self.levels)]
            bidps = [self.s.round_dn(self.venue, self.symbol, x) for x in bidps]
            askps = [self.s.round_up(self.venue, self.symbol, x) for x in askps]

        if self.levels == 1:
            bidqty, askqty = [self.size], [self.size]
        else:
            frontsz = self.s.round_lot(self.venue, self.symbol, self.size*2/(self.finalratio + 1)/D(self.levels)) 
            tailsz = frontsz * self.finalratio
            delta = (tailsz - frontsz)/(D(self.levels) - 1)
            bidqty = [self.s.round_lot(self.venue, self.symbol, frontsz+delta*i) for i,x in enumerate(bidps)]
            askqty = [self.s.round_lot(self.venue, self.symbol, frontsz+delta*i) for i,x in enumerate(askps)]

        if side == self.NO_QUOTE:
            bidps, bidqty, askps, askqty = [], [], [], []
        elif side == self.BUY_ONLY:
            askps, askqty = [], []
        elif side == self.SELL_ONLY:
            bidps, bidqty = [], []
        else:
            assert side == self.BOTH_SIDES
                
        self.bids = [(p,q) for p,q in zip(bidps, bidqty)]
        self.asks = [(p,q) for p,q in zip(askps, askqty)]

        self.prevmid = mid

import smtplib
import xmlrpclib
from email.mime.text import MIMEText
import time
import logging
from collections import defaultdict

x=xmlrpclib.ServerProxy('http://localhost:5959', allow_none=True)
lastsent = defaultdict(float)

def alert(msg, topic='system', period=0):
    global lastsent
    lastsenttime = lastsent[msg]
    if lastsenttime < time.time() - period:
        try:
            x.send_alert(msg, topic)
            lastsent[msg] = time.time()
        except:
            logging.error(str(msg))
            logging.error('Exception occured, is alertserver running?', exc_info=True)

def email(recipients, subject, smsg):
    try:
        msg = MIMEText(smsg)
        msg['Subject'] = subject
        msg['From'] = 'alerts@sensusmarkets.com'
        msg['To'] = ', '.join(recipients)
        s = smtplib.SMTP('localhost')
        s.sendmail('alerts@sensusmarkets.com', recipients, msg.as_string())
        s.quit()
    except:
        logging.error('Failed to email')
    


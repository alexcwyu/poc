import time
import threading
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
import telegram
from slackclient import SlackClient
import logging
from collections import defaultdict

class Messenger(object):
    def alert(self, msg, topic):
        pass

    def stop(self):
        pass

class Telegram(Messenger):
    def __init__(self, cfg):
        self.updater = Updater(cfg['token'])
        dispatcher = self.updater.dispatcher
        self.jobq = self.updater.job_queue
        self.updater.start_polling()
        self.topicmap = defaultdict(list)
        for channel, topics in cfg['channels'].items():
            for topic in topics:
                self.topicmap[topic].append(channel)

    def alert(self, msg, topic):
        for channel in self.topicmap.get(topic, []):
            def callback(bot, job):
                bot.send_message(chat_id=channel, text=msg)
            self.jobq.run_once(callback, 0)

    def stop(self):
        self.updater.stop()
        
class Slack(Messenger):
    def __init__(self, cfg):
        self.sc = SlackClient(cfg['token'])
        self.topicmap = defaultdict(list)
        for channel, topics in cfg['channels'].items():
            for topic in topics:
                self.topicmap[topic].append(channel)
        
    def alert(self, msg, topic):
        for channel in self.topicmap.get(topic, []):
            self.sc.api_call('chat.postMessage', channel=channel, text=msg, username='usr')

    def stop(self):
        pass

class Email(Messenger):
    def __init__(self, cfg):
        #channels are distribution lists
        self.mailer = None
        self.topicmap = defaultdict(list)

    def alert(self, msg, topic):
        pass

    def stop(self):
        pass

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import os

template = '''
OMS_PUBPORT='5559'
OMS_SUBPORT='5560'
MD_PUBPORT='5561'
MD_SUBPORT='5562'
EVENT_PUBPORT='5563'
EVENT_SUBPORT='5564'
CMD_PUBPORT='5565'
CMD_SUBPORT='5566'

MONGO_HOST='127.0.0.1'
MONGO_PORT='27017'
REDIS_HOST='127.0.0.1'
REDIS_PORT=6379

ALERTSERVER_HOST='127.0.0.1'
ALERT_HBPERIOD=10

LOGDIR='log/'
MD_TRADE_CACHE_SECS=180
manifest = {
'venue': {'defaultsyms': ['sym1', 'sym2'],
          'credentials': [
               {'alias': '-',
               'apiKey': '',
               'secret': ''}
          ]},
       }
'''

# build a dictionary of [shortname -> account]
def build_shortname_to_account_map():
    if manifest is None: return None

    result = {}
    for venue, values in manifest.iteritems():
        creds = values['credentials']
        for x in creds:
            if 'alias' in x:
                acc = '{}:{}'.format(venue, x['alias'])
                if 'shortname' in x:
                    result[x['shortname']] = acc
                result[acc] = acc
    return result

# build a dictionary of [account -> shortname]
def build_account_to_shortname_map():
    if manifest is None: return None

    result = {}
    for venue, values in manifest.iteritems():
        creds = values['credentials']
        for x in creds:
            if 'alias' in x:
                acc = '{}:{}'.format(venue, x['alias'])
                if 'shortname' in x:
                    result[acc] = x['shortname']
                result[acc] = acc
    return result

def convaccount(shortname):
    venuedict = build_shortname_to_account_map()
    return venuedict.get(shortname, None)

def convshortname(account):
    venuedict = build_account_to_shortname_map()
    return venuedict.get(account, None)

try:
    from mysettings import *
except Exception as e:
    print e
    if not os.path.exists('mysettings.py'):
        print 'mysettings.py file not found, creating from template'
        with open('mysettings.py', 'w') as f:
            f.write(template)
    raise Exception('Please populate mysettings file first')

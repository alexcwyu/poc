#!/usr/bin/env python
# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Jeffrey Ma <jeff@valuefocus.cc>, April 2018
import zmq
import os
import time
import logging
import threading
import uuid
import json, cPickle
from cdecimal import Decimal as D
from utils import OrderMsg, Fill, Position, Wallet
import utils
from collections import defaultdict
import settings
from pymongo import MongoClient
import redis
import pubsub
import redis_lock

DEFAULT_TIMEOUT = 10
ID_DISP = 5

#one OMS to rule them all - can be called from gateways as well as pubsub
#
# redis data structures
#   keys:
#      tradeid:<tradeid>
#   hsets:
#      order:<internalid>
#      freebal:<acc>
#      totbal:<acc>
#      posinfo:<acc>:<posid> field -> value
#      internalid_lookup acc:oid -> internalid
#      T:order:<internalid> <status> -> update_time (for latency)
#      strategy_lookup <internalid> -> strat
#   sets:
#      accounts
#      active_orders
#      unmatched_orders
#      inactive_orders
#      posinfo:<acc> -> set of posid
#      external_orders
#
# oms_events
#      type=order, event=(one for each ostate), internalid
#      type=wallet
#      type=fill, fillobj=pickled fillobj

#
#  TODO: we need locks? -> probably for the OState object
#

OMS_EVENTS = 'oms_events'

class RedisOrderState(object):

    @staticmethod
    def delete(internalid):
        r = redis.StrictRedis(settings.REDIS_HOST, settings.REDIS_PORT)
        r.delete('order:{}'.format(internalid))
    
    def __init__(self, redis0, internalid):
        self.internalid = internalid
        self.key = 'order:{}'.format(self.internalid)
        self.r = redis0
        self.account = None
        self.status = None
        self.symbol = None
        self.orderid = None
        self.side = None
        self.otype = None
        self.price = None
        self.avgp = None
        self.amt = None
        self.filled = None
        self.remaining = None
        self.cost = None
        self.costccy = None
        self.rejectmsg = None
        self.lastupdated = 0
        self.open = True
        self.exists = self.r.hexists(self.key, 'status') #status will always be there
        if self.exists:
            self.__loadstate()

    def __loadstate(self):
        self.account, self.status, self.symbol, __orderid, self.side, self.otype, __price, __avgp, self.amt, self.filled, self.remaining, __cost, self.costccy, __open, self.rejectmsg, __lastupdated = self.r.hmget(self.key, ['account','status','symbol','orderid','side','otype','price','avgp','amt','filled','remaining','cost','costccy','open','rejectmsg','lastupdated'])

        if __orderid == 'None': #redis does not support Null value
            self.orderid = None
        else:
            self.orderid = __orderid
        if __price == 'None':
            self.price = None
        else:
            self.price = __price
        if __avgp == 'None':
            self.avgp = None
        else:
            self.avgp = __avgp
            
        if __cost == 'None':
            self.cost = None
        else:
            self.cost = __cost
        self.open =  __open == 'True'
        self.lastupdated = float(__lastupdated)
            
    @property
    def venue(self):
        if self.account:
            return self.account.split(':')[0]
        return None

    def asordermsg(self):
        if self.exists:
            omsg = OrderMsg(self.account, self.orderid, self.status, self.symbol, self.otype, self.amt, self.side, price=self.price, avgp=self.avgp, filled=self.filled, remaining=self.remaining, open=self.open)
            try:
                omsg.rejectmsg = self.rejectmsg
            except:
                pass
            return omsg
        else:
            return None
            
    def update(self, omsg):
        assert type(omsg) == OrderMsg
        justfilled = False
        
        if not self.exists:
            avgp = utils.norm_str(omsg.avgp) if omsg.avgp else None
            cost = utils.norm_str(omsg.cost) if omsg.cost else None
            
            self.r.hmset(self.key, {'account':omsg.account,
                                    'status':omsg.status,
                                    'symbol':omsg.symbol,
                                    'orderid':omsg.orderid,
                                    'side':omsg.side,
                                    'otype':omsg.otype,
                                    'price':utils.norm_str(omsg.price),
                                    'avgp':avgp,
                                    'amt':utils.norm_str(omsg.amt),
                                    'filled':utils.norm_str(omsg.filled),
                                    'remaining':utils.norm_str(omsg.remaining),
                                    'cost':cost,
                                    'costccy':str(omsg.costccy),
                                    'rejectmsg':omsg.rejectmsg,
                                    'lastupdated':omsg.lastupdated})
            self.__loadstate()
            self.exists = True
        else:
            updates = {}
            if not ((omsg.account == self.account) and
                    (omsg.symbol == self.symbol) and
                    (omsg.otype == self.otype) and
                    (omsg.side == self.side) and
                    (omsg.price is not None)):#Limit orders must have price field

                logging.info('{} {} {} {} {} {} {} {} {}'.format(omsg.account, self.account, omsg.symbol, self.symbol, omsg.otype, self.otype, omsg.side, self.side, omsg.price))

                raise Exception('omsg mismatch {}'.format(omsg))
            if self.orderid is None:
                self.orderid = omsg.orderid
                self.r.hset(self.key, 'orderid', omsg.orderid)
            else:
                assert self.orderid == omsg.orderid

            self.lastupdated = float(omsg.lastupdated)
            updates['lastupdated'] = omsg.lastupdated
            
            if self.status == omsg.status:
                self.open = omsg.open
                self.r.hset(self.key, 'open', str(omsg.open))
                last_filled = D(self.filled)
                new_filled = D(omsg.filled)

                if new_filled < last_filled:
                    logging.error('Invalid state transition from {} to {}'.format(self, omsg))
                    return None
                elif new_filled > last_filled:
                    justfilled = True
                    self.filled = omsg.filled
                    updates['filled'] = omsg.filled
                    self.remaining = omsg.remaining
                    updates['remaining'] = omsg.remaining
                    self.avgp = omsg.avgp
                    updates['avgp'] = omsg.avgp
                    self.cost = omsg.cost
                    updates['cost'] = omsg.cost
                    self.costccy = omsg.costccy
                    updates['costccy'] = omsg.costccy
                else: #new_filled == last_filled:
                    return None #nothing changed

            elif self.status == OrderMsg.NEW and omsg.status == OrderMsg.PENDING_NEW: #sometimes state can come back so fast on ws that rest is lagging
                logging.error('Invalid state transition from N -> P_N, look into the gw to eliminate race conditions please, ignoring ordermsg: {}'.format(omsg))

            elif self.status == OrderMsg.CANCELED and omsg.status == OrderMsg.PENDING_CANCEL:
                logging.error('Invalid state transition from C -> P_C, look into the gw to eliminate race conditions please, ignoring ordermsg: {}'.format(omsg))
                
            elif self.status in OrderMsg.LIVESTATES and (OrderMsg.STATES[omsg.status] >= OrderMsg.STATES[self.status] or omsg.status not in OrderMsg.LIVESTATES):
                self.price = omsg.price
                self.status = omsg.status
                self.filled = omsg.filled
                self.remaining = omsg.remaining
                self.avgp = omsg.avgp
                self.cost = omsg.cost
                self.costccy = omsg.costccy
                self.open = omsg.open
                updates.update({'price':self.price, 'avgp':self.avgp, 'status':self.status, 'filled':self.filled, 'remaining':self.remaining, 'open':str(self.open), 'cost':self.cost, 'costccy':self.costccy})
            else:
                logging.error('Invalid state transition from {} to {} - update ignored'.format(self.status, omsg.status))
                logging.error('Ignored ordermsg: {}'.format(omsg))
                return None
            
            self.r.hmset(self.key, updates)
            
        self.log_event_time()
            
        return {'event':self.status, 'justfilled':justfilled}

    def log_event_time(self, event_name=None):
        #used for latency measurement
        if event_name is None: event_name = self.status
        self.r.hsetnx('T:{}'.format(self.key), event_name, time.time())

    def to_json(self):
        return {'internalid':self.internalid, 'account':self.account, 'status':self.status, 'orderid':self.orderid, 'side':self.side, 'otype':self.otype, 'price':self.price, 'avgp':self.avgp, 'amt':self.amt, 'filled':self.filled, 'remaining':self.remaining, 'cost':self.cost, 'costccy':self.costccy,'rejectmsg':self.rejectmsg, 'lastupdated':self.lastupdated, 'open':self.open}
        
    def __repr__(self):
        if self.exists:
            omsg = self.asordermsg()
            return '{} {}'.format(self.internalid[:ID_DISP], omsg)
        else:
            return '{} no data'.format(self.internalid)

    
class RedisOMS(object):
    #Three sets - active_orders, unmatched_orders and inactive_orders
    def __init__(self):

        self.mclient = MongoClient('mongodb://{}:{}/'.format(settings.MONGO_HOST, settings.MONGO_PORT))
        self.fillsdb = self.mclient.db.fills
        self.inactivesdb = self.mclient.db.inactives
        
        self.cmd = pubsub.Commander()
        self.r = redis.StrictRedis(settings.REDIS_HOST, settings.REDIS_PORT)
        self.logger = logging.getLogger('oms')
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.connect("tcp://localhost:{}".format(settings.OMS_PUBPORT))
        self.lock = threading.Lock()
        #time.sleep(1) #Hack to wait for socket to connect; TODO: should use something else
        self.tlock = threading.Lock()
        self.redislock = redis_lock.Lock(self.r, 'omslock') #with redis_lock.Lock(redis, 'lockname')
        
    #called by master
    def reset(self):
        for wallet in self.r.smembers('wallets'):
            self.r.delete('balance:{}'.format(wallet))
            self.r.delete('tradable:{}'.format(wallet))
            self.r.delete('withdrawable:{}'.format(wallet))
            posinfo_set = 'posinfo:{}'.format(wallet)
            existing_posids = self.r.smembers(posinfo_set)
            for posid in existing_posids:
                posinfokey = 'posinfo:{}:{}'.format(wallet, posid)
                self.r.delete(posinfokey)
            self.r.delete(posinfo_set)
            self.r.delete(wallet)
        self.r.delete('wallets')
        self.r.delete('accounts')
        #balances as well and all orders? or just inactive
        redis_lock.reset_all(self.r)

    def save_inactive_to_mongo(self):
        for inactive_id in self.inactives():            
            x = RedisOrderState(self.r, inactive_id)
            di = x.to_json()
            stratcache = self.r.hget('strategy_lookup', inactive_id)
            if stratcache: di['strategy'] = stratcache
            else: di['strategy'] = '/'

            #See if we need to save it
            existing = self.inactivesdb.find_one({'internalid': inactive_id})
            if existing is None:
                self.inactivesdb.insert_one(di)

            #Delete it from redis
            RedisOrderState.delete(inactive_id)
            self.r.srem('inactive_orders', inactive_id)
            self.r.hdel('internalid_lookup', '{}:{}'.format(x.account, x.orderid))

    def get_fill_history(self, sincetimestamp):
        fills = self.fillsdb.find({"timestamp": {"$gte": sincetimestamp}}).sort('timestamp')
        return [Fill.from_json(f) for f in fills]
        
    def placeorder(self, internalid, account, symbol, side, ordertype, amt, price, strategy, postonly):
        x = RedisOrderState(self.r, internalid)
        if x.exists:
            #duplicated internalid
            return False

        if (type(amt) != str) or (float(amt) <= 0) or (type(price) != str):
            self.logger.error('Invalid params amt:{} amt_type:{} price:{} price_type:{}'.format(amt, type(amt), price, type(price)))
            return False
        
        #assert type(amt) == str and float(amt) > 0
        #assert type(price) == str
        price = utils.norm_str(price)
        amt = utils.norm_str(amt)

        omsg = OrderMsg(account=account, orderid=None, status=OrderMsg.PENDING_NEW, symbol=symbol, otype=ordertype, amt=amt, side=side, price=price)

        x.update(omsg)
        if account not in self.r.smembers('accounts'):
            self.logger.error('account not available')
            omsg.status = OrderMsg.REJECTED
            omsg.rejectmsg = OrderMsg.INVALID_ACCOUNT
            self.r.sadd('inactive_orders', internalid)
            self.order_update(omsg)
            return False
        else:
            self.r.sadd('unmatched_orders', internalid)

            msg = {'type':'order', 'event':x.status, 'internalid':internalid}
            with self.lock:
                self.socket.send("{} {}".format(OMS_EVENTS, json.dumps(msg)))

            #save off the strategy
            self.r.hset('strategy_lookup', internalid, strategy)
                
            venue,alias = account.split(':')
            self.logger.info('submitting order {}'.format(internalid))
            omsg.flags = {'postonly':postonly}
            self.cmd.place(venue, internalid, omsg)

        return True
            
    def cancel(self, internalid):
        if self.r.sismember('active_orders', internalid):
            x=RedisOrderState(self.r, internalid)

            if x.status in [OrderMsg.NEW, OrderMsg.PARTIALLY_FILLED, OrderMsg.REPLACED]:

                venue,alias = x.account.split(':')
                x.log_event_time('Cancel Initiated')
                self.cmd.cancel(venue, internalid)
                return True
            else:
                self.logger.error('Order is not actionable, cancels will not be queued')
                return False

        if self.r.sismember('unmatched_orders', internalid):
            #self.logger.info('Order is unmatched and waiting for a reply, do not spam the gateway')
            return False
            

        if self.r.sismember('inactive_orders', internalid):
            #for some reason, sometimes tapp doesn't get the update
            redis_order = RedisOrderState(self.r, internalid)
            omsg = redis_order.asordermsg()
            msg = {'type':'order', 'event':omsg.status, 'internalid':internalid}
            self.logger.error('Never received a on_cancel for this order: {}'.format(omsg))
            self.socket.send("{} {}".format(OMS_EVENTS, json.dumps(msg)))
            return False
        
        self.logger.error('could not find internalid or no longer active {}'.format(internalid))
        return False

    #TODO: check if exchange api has functionality
    # def modify(self,):
    #     pass
    
    # def batchplace(self, orders):
    #     pass
    
    # def cancelall(self, account=None):
    #     pass

    def _geninternalid(self):
        return str(uuid.uuid4())
            
    def neworderid(self, internalid, orderid):
        pass #new orderids are matched by heuristic now instead of exact match
    
    def internalid_lookup(self, account, oid):
        if oid is None: return None
        return self.r.hget('internalid_lookup', '{}:{}'.format(account,oid))

    def handle_fill(self, fillobj):
        #Not locking this; assuming that gateways will call this properly
        rkey = 'tradeid:{}:{}'.format(fillobj.account, fillobj.tradeid)

        if self.r.exists(rkey):
            self.logger.error('Seen this fill already, ignoring {}'.format(fillobj))
            return
        else:
            self.r.setex(rkey, 60*60*24*7, True) #expire after a week
            
        fillobj.internalid = self.internalid_lookup(fillobj.account, fillobj.orderid)

        stratcache = self.r.hget('strategy_lookup', fillobj.internalid)
        if stratcache: #add strategy annotation
            fillobj.strategy = stratcache
        
        jsondict = fillobj.to_json()
        self.fillsdb.insert_one(jsondict)
            
        msg = {'type':'fill', 'fillobj':cPickle.dumps(fillobj)}
        self.socket.send("{} {}".format(OMS_EVENTS, json.dumps(msg)))

    #Note - kwarg of internalid allows updating of ordermsgs without orderid (this might cause issues)
    def order_update(self, ordermsg):
        with self.tlock: #redis lock will throw an exception if used in same process
            with self.redislock:
                self._order_update(ordermsg)

    def _order_update(self, ordermsg):
        self.logger.info(ordermsg)

        internalid = self.internalid_lookup(ordermsg.account, ordermsg.orderid)

        if internalid:
            #1) already have this oid in our db
            result = RedisOrderState(self.r, internalid).update(ordermsg)
        else:
            #2) match by account,price,amt,side
            #TODO: speed this up with an index by account
            matched = False
            unmatched = self.unmatched()
            if len(unmatched) >= 20:
                self.logger.info("unmatched order count: {}".format(len(unmatched)))
            for id0 in unmatched:
                order0 = RedisOrderState(self.r, id0)
                if order0.orderid is not None: #This should not happen
                    self.logger.critical("Order found in unmatched orders that already has orderid, moving to actives. {}".format(order0))
                    
                if order0.account == ordermsg.account and \
                   utils.norm_str(order0.price) == utils.norm_str(ordermsg.price) and \
                   utils.norm_str(order0.amt) == utils.norm_str(ordermsg.amt) and \
                   order0.symbol == ordermsg.symbol and \
                   order0.side == ordermsg.side:
                    matched = True
                    result = order0.update(ordermsg)
                    internalid = order0.internalid
                    self.r.hset('internalid_lookup', '{}:{}'.format(ordermsg.account, ordermsg.orderid), internalid)
                    self.r.srem('unmatched_orders', id0)
                    self.r.sadd('active_orders', id0)
                    break

            if not matched:
                #3) external order                                                                                                                                                                          
                internalid = self._geninternalid()
                self.r.sadd('external_orders', internalid)
                result = RedisOrderState(self.r, internalid).update(ordermsg)
                self.logger.info('creating an external order {}'.format(result))
                self.r.hset('internalid_lookup', '{}:{}'.format(ordermsg.account, ordermsg.orderid), internalid)

        if result is None: #no updates
            return

        if result['event'] in OrderMsg.LIVESTATES:
            self.r.sadd('active_orders', internalid)
            #self.r.srem('inactive_orders', internalid)
        else:
            self.r.srem('active_orders', internalid)
            self.r.sadd('inactive_orders', internalid)
            self.r.srem('external_orders', internalid)
        
        #broadcast msg to listeners
        if result['event'] in [OrderMsg.DONE_FOR_DAY, OrderMsg.CANCELED, OrderMsg.REPLACED, OrderMsg.REJECTED, OrderMsg.STOPPED, OrderMsg.PENDING_CANCEL] and result['justfilled']:
            msg = {'type':'order', 'event':OrderMsg.PARTIALLY_FILLED, 'internalid':internalid}
            self.socket.send("{} {}".format(OMS_EVENTS, json.dumps(msg)))

        msg = {'type':'order', 'event':result['event'], 'internalid':internalid}
        self.socket.send("{} {}".format(OMS_EVENTS, json.dumps(msg)))
    
    def actives(self):
        #get all active redisorders
        return self.r.smembers('active_orders')

    def inactives(self):
        return self.r.smembers('inactive_orders')
    
    def unmatched(self):
        #get all unmatched redisorders
        return self.r.smembers('unmatched_orders')

    def clear_unmatched(self, internalid):
        self.r.srem('unmatched_orders', internalid)
    
    def isexternal(self, internalid):
        return internalid in self.r.smembers('external_orders')
    
    def open_orders(self, account=None, include_unmatched=False):
        #TODO: use index?
        result = []
        activeorders = [RedisOrderState(self.r, id0) for id0 in self.actives()]
        if include_unmatched:
            activeorders += [RedisOrderState(self.r, id0) for id0 in self.unmatched()]
        for order0 in activeorders:
            if account is None:
                result.append(order0)
            else:
                if order0.account == account:
                    result.append(order0)                
        return result

    def getorderstatebyid(self, internalid):
        return RedisOrderState(self.r, internalid)
    
    def getorderstate(self, account, oid):
        if account is None or oid is None: return None
        intid = self.r.hget('internalid_lookup', '{}:{}'.format(account,oid))
        order = RedisOrderState(self.r, intid)
        return order

    def accounts(self):
        return self.r.smembers('accounts')

    def walletnames(self):
        return self.r.smembers('wallets')

    def addwallet(self, account, name, spot):
        p = self.r.pipeline(transaction=True)
        walletname = '{}#{}'.format(account, name)
        p.sadd('accounts', account)
        p.sadd('wallets', walletname)
        p.hset(walletname, 'spot', spot)
        p.hset(walletname, 'ts', time.time())
        p.execute()
        self.socket.send("{} {}".format(OMS_EVENTS, json.dumps({'type':'wallet', 'acc':account, 'wallet':name})))

    def removewallet(self, account, name):
        walletname = '{}#{}'.format(account, name)
        self.r.srem('wallets', walletname)
        p = self.r.pipeline(transaction=True)
        p.delete('balance:{}'.format(walletname))
        p.delete('tradable:{}'.format(walletname))
        p.delete('withdrawable:{}'.format(walletname))
        p.execute()
        posinfo_set = 'posinfo:{}'.format(walletname)
        existing_posids = self.r.smembers(posinfo_set)
        for posid in existing_posids:
            posinfokey = 'posinfo:{}:{}'.format(walletname, posid)
            p.delete(posinfokey)
        p.delete(posinfo_set)
        p.delete(walletname)
        p.execute()
        self.socket.send("{} {}".format(OMS_EVENTS, json.dumps({'type':'wallet', 'acc':account, 'wallet':name})))

    def setwallet(self, wallet, ts, isupdate):
        walletname = '{}#{}'.format(wallet.account, wallet.name)
        isnewwallet = True
        if not self.r.sismember('wallets', walletname):
            self.addwallet(wallet.account, wallet.name, wallet.spot)
            isnewwallet = False

        p = self.r.pipeline(transaction=True)
        p.hset(walletname, 'ts', ts)

        for which in ['balance', 'tradable', 'withdrawable']:
            key = '{}:{}'.format(which, walletname)
            newdict = wallet.balance
            if which == 'tradable':
                newdict = wallet.tradable
            elif which == 'withdrawable':
                newdict = wallet.withdrawable
                
            if isupdate:
                currdict = self.r.hgetall(key)
                for ccy, amt in newdict.items():
                    if ccy not in currdict or D(amt) != D(currdict[ccy]):
                        p.hset(key, ccy, amt)
            else:
                p.delete(key)
                for ccy, amt in newdict.items():
                    p.hset(key, ccy, amt)
            p.execute()

        posinfo_set = 'posinfo:{}'.format(walletname)
        existing_posids = self.r.smembers(posinfo_set)

        #delete all keys belonging to this walletname
        if not isupdate:
            for posid in existing_posids:
                posinfokey = 'posinfo:{}:{}'.format(walletname, posid)
                p.delete(posinfokey)
                p.delete(posinfo_set)
                
        for posid, pos in wallet.positions.items():
            posinfokey = 'posinfo:{}:{}'.format(walletname, posid)
            for field,val in pos.to_json().items():
                if val != 'None' or field in ['name', 'symbol', 'account']:
                    p.hset(posinfokey, field, val)
                    p.sadd(posinfo_set, posid)
        p.execute()
                
        #TODO: publish only when there is a change
        self.socket.send("{} {}".format(OMS_EVENTS, json.dumps({'type':'wallet', 'acc':wallet.account, 'wallet':wallet.name})))
        return isnewwallet

    def getwallet(self, account, walletname):
        accwal = '#'.join([account, walletname])
        w = None
        if self.r.sismember('wallets', accwal):        
            spot = True if self.r.hget(accwal, 'spot') == 'True' else False
        
            balance = self.r.hgetall('{}:{}'.format('balance', accwal))
            tradable = self.r.hgetall('{}:{}'.format('tradable', accwal))
            withdrawable = self.r.hgetall('{}:{}'.format('withdrawable', accwal))

            ts = float(self.r.hget(accwal, 'ts'))

            w = Wallet(account, walletname, spot=spot)
            w.setts(ts)
            w.setbalances(balance, tradable, withdrawable)
            for posid in self.r.smembers('posinfo:{}'.format(accwal)):
                posinfokey = 'posinfo:{}:{}'.format(accwal, posid)
                posdict = self.r.hgetall(posinfokey)
                if len(posdict) > 0:
                    pos = Position.from_json(posdict)
                    w.setposition(pos)                        
        return w
                                
    def timeout(self, internalid):
        if self.r.sismember('unmatched_orders', internalid):
            #Reject the order if still in pending new - should we request the gateway to do this? Might be too slow
            redis_order = RedisOrderState(self.r, internalid)
            omsg = redis_order.asordermsg()
            omsg.status = OrderMsg.REJECTED
            omsg.rejectmsg = OrderMsg.PENDING_NEW_TIMEOUT
            if omsg.orderid is None:
                omsg.orderid = str(uuid.uuid4()) #dummy id
            self.order_update(omsg)
        elif self.r.sismember('active_orders', internalid):
            x=RedisOrderState(self.r, internalid)
            self.cmd.requeststate(x.venue, x.account, x.orderid) #should this be internalid?


#!/usr/bin/env python
# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, April 2018
import urwid
import logging
import pubsub
import utils
from utils import OrderMsg
    

class OrderView(urwid.Frame):
    def __init__(self, ove):
        self.ove = ove
        self._selectable = True
        
        text = urwid.Text('')
        filler = urwid.Filler(text, valign='top', top=1, bottom=1)
        padding = urwid.Padding(filler, left=1, right=1)
        self.orderbox = urwid.AttrMap(urwid.LineBox(padding), 'linebox')

        myorders = 'mine' if self.ove.show_myorders else 'all'
        header_text = urwid.Text('Orders [{}, show inactive={}]'.format(myorders, self.ove.show_inactive))
        self.header = urwid.AttrMap(header_text, 'titlebar')
        
        instructions = urwid.Text(['[m/M] my/all orders, [i/I] show inactive'])
        
        super(OrderView, self).__init__(body=self.orderbox, header=self.header, footer=instructions)
        self.refresh()

    def keypress(self, size, key):
        if key in ['r', 'R']:
            self.refresh()
        elif key in ['i', 'I']:
            self.ove.toggle_show_inactive()
        elif key in ['m', 'M']:
            self.ove.toggle_show_myorders()
        else:
            return key

        
    def refresh(self):
        titlefmt = '{:^15}'
        updates = [
            ('headers', titlefmt.format('')),
            ('headers', titlefmt.format('')),
        ]

        updates.append(('','\n'))

        data = self.ove.getdata()
        
        for o in data:
            updates.append(('', str(o)))                    
            updates.append(('','\n'))

        myorders = 'mine' if self.ove.show_myorders else 'all'
        new_header_text = 'Orders [{}, show inactive={}]'.format(myorders, self.ove.show_inactive)
        self.header.base_widget.set_text(new_header_text)
        self.orderbox.base_widget.set_text(updates)

class OrderViewEngine(object):
    def __init__(self, tapp):
        assert isinstance(tapp, pubsub.TradingApp)
        self.tapp = tapp
        self.show_inactive = True
        self.show_myorders = False

    def toggle_show_inactive(self):
        self.show_inactive = not self.show_inactive

    def toggle_show_myorders(self):
        self.show_myorders = not self.show_myorders

    def getdata(self):
        orders = self.tapp.orders if self.show_myorders else self.tapp.allorders
        showorders = [order for intid, order in orders.items() if (order.status in OrderMsg.LIVESTATES or self.show_inactive)]
        return sorted(showorders, key=lambda x:float(0 if x.price is None else x.price), reverse=True)
    
    

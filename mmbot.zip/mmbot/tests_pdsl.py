import os
import time
import pubsub
from prices import Price

tapp = pubsub.TradingApp()
tapp.start()

#plimit=mid:ETH/BTC@kucoin*mid:BTC/USD@bitfinex

p1 = Price('1234')
p2 = Price('999')
p3 = Price('mid:ETH/BTC@kucoin')
p4 = Price('bid:ETH/BTC@kucoin')
p5 = Price('ask:ETH/BTC@kucoin')
p6 = Price('grefp:ETH/BTC')
p7 = Price('tv:ETH/BTC@kucoin')
p8 = Price('(+ bid:ETH/BTC@kucoin ask:ETH/BTC@kucoin)')
p9 = Price('(/ (+ mid:ETH/BTC@kucoin 3) 2)')
p10 = Price('(- ask:ETH/BTC@kucoin bid:ETH/BTC@kucoin)')
p11 = Price('(/ grefp:ETH/BTC bid:ETH/BTC@kucoin)')
p12 = Price('(* grefp:BTC/USD bid:ETH/BTC@kucoin)')
p13 = Price('mid:XBTUSD@bitmex')
p14 = Price('grefp:USD/USD')

#Test case for invalid price specs
#pwrong = Price('mkte')
#pwrong = Price('mid:XBTUSD@bitmex mid:XBTUSD@bitmex mid:XBTUSD@bitmex') #<-- should be invalid but isn't detected
#pwrong = Price('mkt')

#Should be invalid
#pwrong = Price('+')
#pwrong = Price('+ +')

subs = set()
px = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p12, p13, p14]
for pobj in px:
    subs = subs.union(pobj.subscriptions())
    
for v,sym in subs:
    tapp.subscribe(v, sym)

while True:
    os.system('clear')
    for p in px:
        print '{}: {}'.format(p.specification, p.evalprice(tapp))
    time.sleep(5)
    print '='*10

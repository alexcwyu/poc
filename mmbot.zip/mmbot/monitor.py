#!/usr/bin/env python
import logging
import copy
import threading
import os
import pubsub
import random
import time
import Queue
from cdecimal import Decimal as D
from collections import defaultdict
from utils import Book, OrderMsg

#
# OMS monitoring - goal: make sure updates are still happening
#                - submit a test order far from market for each exchange every so often
#                - assert that free balance changes within a time
#                - then cancel the order
class Monitor(pubsub.TradingApp):
    def __init__(self, period=60, premdisc=0.5):
        super(Monitor, self).__init__()
        self.pd=premdisc
        for venue, symlist in self.subscriptions.items():
            for sym in symlist:
                self.subscribe(venue, sym)
        self.allowed_failures = 3
        self.consec_fail_count = defaultdict(int)

    def random_orders(self):
        rorders = {}
        for account in self.accounts:
            venue,alias = account.split(':')
            cand_orders = []
            for sym in self.subscriptions[venue]:
                minlot = self.symbols.getlotsize(venue, sym)
                if venue == 'bitmex':
                    minlot = D(100)
                thisbook = self.getbook(venue, sym)
                if thisbook:
                    for side,price in [(OrderMsg.BUY, D(thisbook.best_bid[0])*D(1-self.pd)),
                                       (OrderMsg.SELL, D(thisbook.best_ask[0])*D(1+self.pd))]:
                        if side == OrderMsg.BUY:
                            price = self.symbols.round_dn(venue, sym, price)
                        else:
                            assert side == OrderMsg.SELL
                            price = self.symbols.round_up(venue, sym, price)
                        ccy, amt = self.symbols.balrequired(venue, sym, side, minlot, price)
                        free = self.free[account].get(ccy,'0')
                        if D(amt) < D(free):
                            cand_orders.append((sym, side, minlot, price, ccy))
            if len(cand_orders) > 0:
                rorders[account] = random.choice(cand_orders)
        return rorders

    def cancelallactive(self):
        for order in self.orders.values():
            if order.status in OrderMsg.LIVESTATES:
                self.cancelorder(order.internalid)
                    
    
    def run(self):
        try:
            self._run()
        except KeyError:
            pass

        finally:
            self.cancelallactive()

    def _run(self):
        while True:
            fails = []
            ccy_to_check = {} #{account: ccy}
            ccy_val = {} #{account : value}
            self.submitting = set()
            for account, order in self.random_orders().items():
                symbol, side, qty, price, ccy = order
                ccy_to_check[account] = ccy
                ccy_val[account] = copy.deepcopy(self.free[account][ccy])
                self.logger.info('submitting {} {}'.format(account, order))
                id0 = self.lmtorder(account, symbol, side, str(qty), str(price))
                if id0:
                    self.submitting.add(id0)
                else:
                    fails.append(account)
                    del ccy_to_check[account]
                    del ccy_val[account]

            timeout = time.time() + 5
            while len(self.submitting) > 0 and time.time() < timeout:
                time.sleep(1) #wait for placements

            time.sleep(5) #wait for freebals to update

            for account, ccy in ccy_to_check.items():
                newfreebal = self.free[account][ccy]
                if newfreebal == ccy_val[account]:
                    fails.append(account)
                    self.logger.error('freebal did not update on {}'.format(account))

            self.cancelallactive()

            timeout = time.time() + 5
            self.logger.info('waiting for cancels')
            while len([o for o in self.orders.values() if o.status in OrderMsg.LIVESTATES]) > 0 or time.time() < timeout:
                time.sleep(1)

            self.logger.info('sleeping until next check')
            time.sleep(60)

    def on_new(self, internalid):
        self.submitting.discard(internalid)

    def nullfunc(self, *args, **kwargs): pass
        
    on_canceled = nullfunc
    on_pending_new = nullfunc

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    Monitor().run()

    

# Copyright (C) Value Focus Global Limited - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
# Written by Eric Mak <eric@valuefocus.cc>, April 2018
import utils
import reference
from cdecimal import Decimal

syms = reference.Symbols()
#returns list of tuples of CCY, delta as Decimal
def calcdelta(venue, symbol, price):

    basedelta = None
    quotedelta = None
    if venue == 'bitmex':
        if syms.getbaseccy(venue, symbol) == 'BTC': #inverse futures
            basedelta = Decimal(1)/Decimal(price)
            quotedelta = -Decimal(1)
        else:
            basedelta = Decimal(1)
            quotedelta = -Decimal(price)
    elif venue == 'okexfut':
        multiplier = syms.getmultiplier(venue, symbol)
        if syms.instrumenttype(venue, symbol) == reference.Symbols.FUTURE: #okex has inverse futures
            basedelta = Decimal(1)/Decimal(price) * multiplier
            quotedelta = Decimal(-1) * multiplier

    elif venue == 'cf':
        if syms.isinverse(venue, symbol):
            basedelta = Decimal(1)/Decimal(price)
            quotedelta = Decimal(-1)
        else:
            basedelta = Decimal(1)
            quotedelta = -Decimal(price)
            
    else:
        basedelta = Decimal(1)
        quotedelta = -Decimal(price)

    return [(syms.getbaseccy(venue, symbol), basedelta),
            (syms.getquoteccy(venue, symbol), quotedelta)]

def calcpnl(venue, symbol, qty, startpx, endpx):
    basedelta, quotedelta = calcdelta(venue, symbol, startpx)
    b_ccy, b_delta = basedelta
    pnl = Decimal(qty) * (Decimal(endpx)-Decimal(startpx))/Decimal(startpx) * b_delta
    return pnl

import json
import tornado.auth
import tornado.escape
import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web
import Settings
import uuid
import cPickle
import xmlrpclib

from tornado.options import define, options

autotrader = xmlrpclib.ServerProxy('http://localhost:9988')
USER='eric'
PWD='aw890p34b;klasdf'
ACCOUNT = 'bitmextest:x'
SYMBOL = 'ETHH18'
ALGO_LIMIT = 1
ERRORS = []
SRV_ERR = "Algo system is down contact support for help"

define("port", default=8090, help="run on the given port", type=int)

class BaseHandler(tornado.web.RequestHandler):
    def get_current_user(self):
        return self.get_secure_cookie("user")

class MainHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        global ERRORS
        username = tornado.escape.xhtml_escape(self.current_user)
        self.render("index.html", symbol=SYMBOL, errormsg = ERRORS)

class ClearErrors(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        global ERRORS
        ERRORS = []
        self.redirect("/")
        
class ATState(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        global ERRORS
        try:
            currstate = autotrader.rpc_fullstate()
            ERRORS = [e for e in ERRORS if e != SRV_ERR]
        except:
            if SRV_ERR not in ERRORS:
                ERRORS.append(SRV_ERR)
            self.write(SRV_ERR)
            return
        html = ''
        for name,x in currstate.items():
            html+='<tr>'
            for col in ['side','symbol','state','qty','filled','avgp']:
                html+= '<td>{}</td>'.format(x.get(col, '-'))

            if x['state'] in ['working']:
                html += '<td><a href="/stop?algoname={}">stop</td>'.format(name)
            elif x['state'] in ['inactive', 'paused']:
                html += '<td><a href="/start?algoname={}">start</td>'.format(name)
            else:
                html += '<td></td>'
            html+='</tr>'
        #if any are working -> disable current algo panel and also disable order placements
        self.write(html)

class ATAdd(BaseHandler):
    def is_number(self, val):
        try:
            float(val)
            return True
        except ValueError:
            pass
        return False
    
    @tornado.web.authenticated
    def get(self):
        global ERRORS
        side = self.get_argument("side",'')
        qty = self.get_argument("qty",'')
        schunk = self.get_argument("schunk",'')
        tchunk = self.get_argument("tchunk",'')
        if side not in ['buy','sell']:
            ERRORS.append('Side needs to be in either buy or sell')
        elif not self.is_number(tchunk) or not self.is_number(schunk) or not self.is_number(qty):
            ERRORS.append('Fields need to be numeric')
        else:
            try:
                result = autotrader.rpc_add_algo(str(uuid.uuid4()), 'TWAP', json.dumps({'account':ACCOUNT, 'sym':SYMBOL, 'side':side, 'qty':qty, 'schunk':schunk, 'tchunk':tchunk}))
                ERRORS = [e for e in ERRORS if e != SRV_ERR]
                if not result['success']:
                    ERRORS.append(result['msg'])
            except:
                if SRV_ERR not in ERRORS:
                    ERRORS.append(SRV_ERR)
            
            
        self.redirect('/')
        
class ATStart(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        global ERRORS
        algoname = self.get_argument("algoname", None)
        #only allow one algo to be running at a time?

        try:
            currstate = autotrader.rpc_fullstate()
            ERRORS = [e for e in ERRORS if e != SRV_ERR]
        except:
            if SRV_ERR not in ERRORS: ERRORS.append(SRV_ERR)
            self.redirect('/')
            
        if len([x for x in currstate.values() if x['state'] == 'working']) < ALGO_LIMIT:
            try:
                result = autotrader.rpc_startalgo(algoname)
                ERRORS = [e for e in ERRORS if e != SRV_ERR]
                if not result['success']:
                    ERRORS.append(result['msg'])
            except:
                if SRV_ERR not in ERRORS: ERRORS.append(SRV_ERR)
        else:
            ERRORS.append('Only {} Algo can be working at a time'.format(ALGO_LIMIT))
        self.redirect('/')

class ATStop(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        global ERRORS
        algoname = self.get_argument("algoname", '')
        try:
            result = autotrader.rpc_stopalgo(algoname)
            ERRORS = [e for e in ERRORS if e != SRV_ERR]
        except:
            if SRV_ERR not in ERRORS: ERRORS.append(SRV_ERR)
            
        self.redirect('/')
        
class AuthLoginHandler(BaseHandler):
    def get(self):
        try:
            errormessage = self.get_argument("error")
        except:
            errormessage = ""
        self.render("login.html", errormessage = errormessage)

    def check_permission(self, password, username):
        if username == USER and password == PWD:
            return True
        return False

    def post(self):
        username = self.get_argument("username", "")
        password = self.get_argument("password", "")
        auth = self.check_permission(password, username)
        if auth:
            self.set_current_user(username)
            self.redirect(self.get_argument("next", u"/"))
        else:
            error_msg = u"?error=" + tornado.escape.url_escape("Login incorrect")
            self.redirect(u"/auth/login/" + error_msg)

    def set_current_user(self, user):
        if user:
            self.set_secure_cookie("user", tornado.escape.json_encode(user))
        else:
            self.clear_cookie("user")

class AuthLogoutHandler(BaseHandler):
    def get(self):
        self.clear_cookie("user")
        self.redirect(self.get_argument("next", "/"))

class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", MainHandler),
            (r"/state", ATState),
            (r"/add", ATAdd),
            (r"/start", ATStart),
            (r"/stop", ATStop),
            (r"/clearerrors", ClearErrors),
            (r"/auth/login/", AuthLoginHandler),
            (r"/auth/logout/", AuthLogoutHandler),
        ]
        settings = {
            "template_path":Settings.TEMPLATE_PATH,
            "static_path":Settings.STATIC_PATH,
            "debug":Settings.DEBUG,
            "cookie_secret": Settings.COOKIE_SECRET,
            "login_url": "/auth/login/"
        }
        tornado.web.Application.__init__(self, handlers, **settings)

def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    main()
